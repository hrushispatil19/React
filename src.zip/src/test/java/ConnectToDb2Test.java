/*
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.ibm.db2.jcc.am.Connection;



public class ConnectToDb2Test {
	public static void main(String[] args) {
		Connection conn= null;

			try {
				

				Class.forName("com.ibm.db2.jcc.DB2Driver");
				
				conn = (Connection) DriverManager.getConnection("jdbc:db2://aa00.mvs.sbc.com:446/DBA3","dk699u","JU03EB27");
				System.out.println("**** Created a JDBC connection to the data source");
				Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery("SELECT REQUEST_ID FROM DBA3LRD1.LRT002_REQUEST fetch first 10 rows only");
				while (rs.next()) {
			        String reqID = rs.getString(1);
			        
			        System.out.println("LSR No from DBA3 = " + reqID);
				}
					
					  System.out.println("**** Fetched all rows from JDBC ResultSet");
					  
					  rs.close(); System.out.println("**** Closed JDBC ResultSet"); stmt.close();
					  System.out.println("**** Closed JDBC Statement"); conn.commit();
					  System.out.println ( "**** Transaction committed" ); conn.close();
					  System.out.println("**** Disconnected from data source");
					 
					 
			      
			}
			
			
			catch(ClassNotFoundException e) {
				e.printStackTrace();
			}
			catch(SQLException e) {
				e.printStackTrace();
			}
	}
}
*/