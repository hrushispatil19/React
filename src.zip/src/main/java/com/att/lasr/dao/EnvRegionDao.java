package com.att.lasr.dao;

import java.util.List;

public interface EnvRegionDao {
	public boolean validateEnvRegion(String environment, String region) ;	 
}
