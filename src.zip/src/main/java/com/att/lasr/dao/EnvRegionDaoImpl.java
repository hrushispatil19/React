package com.att.lasr.dao;

import org.springframework.stereotype.Repository;

@Repository
public class EnvRegionDaoImpl implements EnvRegionDao {
	public boolean validateEnvRegion(String environment, String region) {

		return environment.equalsIgnoreCase("Development/Test")
				&& region.equalsIgnoreCase("A0 - 12 states Dev");
	}
}
