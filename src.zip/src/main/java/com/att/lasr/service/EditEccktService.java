package com.att.lasr.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.att.lasr.model.EditEccktTableRow;
import com.att.lasr.model.Header;
import com.att.lasr.model.MQReceivedData;
import com.att.lasr.model.NotesFupBindingData12States;
import com.att.lasr.model.ShowError;
import com.att.lasr.model.SubData;
import com.att.lasr.model.SubHeader;
import com.att.lasr.utils.MQMessageStringBuilder;
import com.att.lasr.utils.MQReadUtil;
import com.att.lasr.utils.MQWriteUtil;
import com.att.lasr.utils.enums.LastInd;
import com.att.lasr.utils.enums.LogInd;
import com.att.lasr.utils.enums.Process;
import com.att.lasr.utils.enums.ProcessGroupInd;
import com.att.lasr.utils.enums.ProcessMode;
import com.att.lasr.utils.enums.RecIdFor12State;
@Service
public class EditEccktService {

	@Autowired
	private MQReadUtil mqReadUtil;

	@Autowired
	private MQWriteUtil mqWriteUtil;

	@Autowired
	HttpSession httpSession;

	List<ShowError> showEccktErrorList = new ArrayList<ShowError>();

	public void writeSaveEditEccktDataToMQ(List<EditEccktTableRow> editEccktDataList, String user_id,
			String object_handle, HttpSession session, ModelMap map) {
		String numCount = getNumCount(editEccktDataList.size() + 1);
		Header header = prepareSaveHeader(user_id, object_handle, numCount);
		StringBuilder subHeaderandData = new StringBuilder();

		String dataString = "";

		// 049 RecId code
		List<NotesFupBindingData12States> dataObject_049 = (List<NotesFupBindingData12States>) session
				.getAttribute("treeViewList_049");

		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();
		SubHeader subHeader = prepareSaveSubHeader(RecIdFor12State.CS_RECID_HEADER.getRecIdValue());

		for (NotesFupBindingData12States notesFupBindingData12States : dataObject_049) {

			session.setAttribute("Lrs_No", notesFupBindingData12States.getRequest_id().substring(0, 17).trim());
			dataString = notesFupBindingData12States.getNotesFupBindingData12String();
			subHeaderandData.append(mqMessageStringBuilder.addHeader(header));
			subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString).toString());

		}

		subHeader = prepareSaveSubHeader(RecIdFor12State.CS_RECID_UPDATE_ECCKTS.getRecIdValue());

		for (EditEccktTableRow row : editEccktDataList) {
			
			if(row.getEcckt_attr().contains("U")) {
				row.setEcckt_attr("Y");
			}
			
			dataString = row.getEditEccktDataString();
			subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString));

		}
		//System.err.println(mqMessageStringBuilder.getMqMessageString());
		boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder,session);
		
		if (isWritten) {

			MQReceivedData mqReceivedData;
			
			try {

			mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
			 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
			  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
		//	  Header receivedHeader = mqReceivedData.getHeader(); 
			  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
					System.out.println("*************inside if*************** "); 
					mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
				} 
			  
			  
			  System.out.println(mqReceivedData.getHeader().toString()); 
		} catch (Exception e) { 
			// TODO Auto-generated catch block 
			 mqReceivedData = mqReadUtil.readDataFromMQ(session); 
			e.printStackTrace(); 


		}
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
			Header receivedHeader = mqReceivedData.getHeader();
			SubData subData = subDatas.get(RecIdFor12State.CS_RECID_ERROR.getRecIdValue());
			System.err.println("return code: "+receivedHeader.getReturn_code());
			ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
			//System.out.println("subData: " + subData);
			if (subData != null) {
				//SubHeader receivedSubHeader = subData.getSubHeader();
				String[] subDataRows = subData.getSubDataRows();

				String[] attributes = mqReadUtil.getAttributes(subDataRows[0], 4);
				if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {

					
					String ecckt_msg = readErrorMsgsJson.getErrorMsg("LG0017");
					session.setAttribute("ecckt_err_msg", ecckt_msg);

					ShowErrorService showErrorService = new ShowErrorService();
					showEccktErrorList = showErrorService.getErrorList(attributes[0].trim(), attributes[1],
							"", "U");

					
					session.setAttribute("showError", showEccktErrorList);

				}

				
			}
			if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("000")) {

				String ecckt_msg = readErrorMsgsJson.getErrorMsg("LG0016");
				session.setAttribute("ecckt_info_msg", ecckt_msg);

			}
			if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("889")) {

				String ecckt_msg = readErrorMsgsJson.getErrorMsg("LG0067");
				session.setAttribute("ecckt_err_msg", ecckt_msg);

			}
			if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("888")) {

				String ecckt_msg = readErrorMsgsJson.getErrorMsg("LG0022");
				session.setAttribute("ecckt_err_msg", ecckt_msg);

			}
		}

	}

	public List<ShowError> getEccktErrorList() {
		return showEccktErrorList;
	}

	private SubHeader prepareSaveSubHeader(String recId) {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_UPDATE.getProcessModeCode());
		subHeader.setRecord_type(recId);
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private Header prepareSaveHeader(String user_id, String object_handle, String numCount) {
		// Prepare Header
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_REQUEST.getProcessCode());
		header.setTab_ind("672");
		header.setProcess_group_ind(ProcessGroupInd.SAVE_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail(numCount);
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}

	public List<EditEccktTableRow> getInpuDataObject(String input, HttpSession session) {
		// TODO Auto-generated method stub
		List<EditEccktTableRow> editEccktList = new ArrayList<EditEccktTableRow>();
		String[] sentData = input.split("\\$,");
		int index = 0;
		List<EditEccktTableRow> list = (ArrayList) session.getAttribute("treeViewList_672");
		List<String> eccktList= new ArrayList<String>();
		for(int i=0;i<list.size();i++)
		{
			String ecckt= list.get(i).getEcckt();
			if(ecckt== null)
			{
				ecckt="";
			}
			eccktList.add(ecckt);
		}
		
		
		for (String row : sentData) {
			System.out.println("row data: " + row);
			String[] subData = row.trim().split(" ");

			if(subData.length > 2) {
			EditEccktTableRow r = list.get(index);
			r.setNumname(subData[0].trim().toUpperCase());
			r.setNum_nbr(subData[1].trim().toUpperCase());
			r.setEcckt(getHashReplaceData(subData[2].trim().toUpperCase()));
			
			editEccktList.add(r);
			
			index++;
			}
		}
		
		List<EditEccktTableRow> updatedEccktRows= getUpdatedRows(editEccktList,eccktList);

		return updatedEccktRows;

	}

	public List<EditEccktTableRow> getUpdatedRows(List<EditEccktTableRow> newList,List<String> eccktList) {
		
		List<EditEccktTableRow> updatedList= new ArrayList<EditEccktTableRow>();
		for(int i=0;i<newList.size();i++)
		{
			EditEccktTableRow tableRow=newList.get(i);
			if(!newList.get(i).getEcckt().equalsIgnoreCase(eccktList.get(i)))
			{
				updatedList.add(tableRow);
			}
		}
		return updatedList;
	}

	private String getHashReplaceData(String ecckt) {

		if (ecckt.contains("#,")) {
			return "";
		} else {
			return ecckt;
		}
	}

	private String getNumCount(int size) {
		String numCount = String.format("%04d", size);
		return numCount;
	}

}
