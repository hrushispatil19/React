package com.att.lasr.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.lasr.dao.EnvRegionDao;

@Service
public class EnvRegionService {
	@Autowired
    EnvRegionDao envRegionDao;
		
	public boolean validateEnvRegion(String environment, String region) {
        
        return envRegionDao.validateEnvRegion(environment, region);
    }
}
