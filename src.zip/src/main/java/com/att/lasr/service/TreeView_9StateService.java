/**
 * 
 */
package com.att.lasr.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.lasr.model.*;
import com.att.lasr.utils.FormatUtil;
import com.att.lasr.utils.MQMessageStringBuilder;
import com.att.lasr.utils.MQReadUtil;
import com.att.lasr.utils.MQWriteUtil;
import com.att.lasr.utils.enums.LastInd;
import com.att.lasr.utils.enums.LogInd;
import com.att.lasr.utils.enums.Process;
import com.att.lasr.utils.enums.ProcessGroupInd;
import com.att.lasr.utils.enums.ProcessMode;
import com.att.lasr.utils.enums.RecIdFor12State;
import com.att.lasr.utils.enums.RecIdFor9State;
import com.att.lasr.utils.enums.TabInd;
import com.nimbusds.oauth2.sdk.util.CollectionUtils;

@Service
public class TreeView_9StateService {
	@Autowired
	private MQReadUtil mqReadUtil;

	@Autowired
	private MQWriteUtil mqWriteUtil;

	List<ShowError> showError = new ArrayList<ShowError>();
	// ErrorCodeData errorCodeData = new ErrorCodeData();
	ShowErrorService showErrorService = new ShowErrorService();
	List<ShowError> focError = new ArrayList<ShowError>();
	List<ShowError> postbilltask = new ArrayList<ShowError>();
	
	//=============================sneha===================
	
		public ConformationTaskMain writeSelectedRequestPostToBill(ConformationTaskMain conformationTaskMain, String user_id, String object_handle, HttpSession session) {

			Header header = null;
			SubHeader subHeader = null;
			StringBuilder subHeaderandData = new StringBuilder();
			System.out.println("Service:::111:inside:user_id::user_id::::"+user_id);
			String dataString049 = "";
			
			int count = 0000;
			focError.clear();
		List<NotesFupBindingData9States> conformationList_049 = conformationTaskMain.getNotesFupBindingData9States();
		
		List<NotesFupBindingData12States> conformationList_12States  = (List<NotesFupBindingData12States>)session.getAttribute("treeViewList_049");
		
		String dataString585 = "";
		String dataString588 = "";
		List<PostToBillTask_RecId585> postToBillTask9_585 = conformationTaskMain.getPostToBillTask_RecId585();
		
		List filterRecidList = (ArrayList)session.getAttribute("treeViewList");
			MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();
			String statesIdentity = (String)session.getAttribute("States");
			if(filterRecidList.contains("049")) {
				
				if(statesIdentity.equalsIgnoreCase("Y")){
					 for (NotesFupBindingData12States notesFupBindingData9States : conformationList_12States){
			                count++;
			                session.setAttribute("Lrs_No", notesFupBindingData9States.getRequest_id().substring(0, 17).trim());
//			                System.out.println("::::::susheel:val 999999inside for:LrsNo:session::"+session.getAttribute("Lrs_No"));
			                dataString049 = notesFupBindingData9States.getNotesFupBindingData12String();
//			                System.out.println("::::::dataString: confirmationTask_RecId_049_new for::::"+dataString049);
			               
			                }
				}else {
				
				for (NotesFupBindingData12States notesFupBindingData9States : conformationList_12States){
					count++;
					session.setAttribute("Lrs_No", notesFupBindingData9States.getRequest_id().substring(0, 17).trim());
//					System.out.println("::::::susheel:val 999999inside for:LrsNo:session::"+session.getAttribute("Lrs_No"));
					dataString049 = notesFupBindingData9States.getNotesFupBindingData9String();
//					System.out.println("::::::dataString: confirmationTask_RecId_049_new for::::"+dataString049);
					
					}
				}
				}	
				
			  if(filterRecidList.contains("585")) {
			  
			  for (PostToBillTask_RecId585 postToBillTask_RecId585_New :
			  postToBillTask9_585) { count++; } }
			
			if(filterRecidList.contains("049")) {
				String countVal = "";
				
				System.out.println("Count:::"+count);
				if(count<10) {
					System.out.println("less:::");
					countVal= "000"+count;
				}
				if(count>=10) {
					System.out.println("greater:::");
					countVal= "00"+count;
				}
				System.err.println("::::::Heade count for::::"+countVal);
				
				header = preparePostToBillHeader(user_id, object_handle, countVal);
				
				subHeader = prepareSubHeader(RecIdFor9State.CS_RECID_HEADER.getRecIdValue());
				subHeaderandData.append(mqMessageStringBuilder.addHeader(header));
				subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString049.toString()));
			}
			
			if(filterRecidList.contains("585")) {
				for (PostToBillTask_RecId585 postToBillTask_RecId585_New : postToBillTask9_585) {
					count++;
					if(postToBillTask_RecId585_New.getPd_attr().contains("U")) {
						postToBillTask_RecId585_New.setPd_attr("Y");
					}
				
				dataString585 = postToBillTask_RecId585_New.getSelectRequest585DataString();
				
//					System.out.println("::::::dataString: postToBillTask_RecId585 for::::"+dataString585);
					subHeader = prepareSubHeader(RecIdFor9State.CS_RECID_POST_TO_BILL.getRecIdValue());
					subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString585.toString()));
					}
				}
			
			
			
//			System.out.println("::::::subHeaderandData:::: for::::"+subHeaderandData.toString());
			String mqMessageString = mqMessageStringBuilder.getMqMessageString();
//			System.out.println("::::::58144444 formqMessageString::::"+mqMessageString);
			boolean isWritten = mqWriteUtil.writeDataToMQString(mqMessageString,session);
			//boolean isWritten = false;
		//	String reg= (String) session.getAttribute("myReg");

			if (isWritten) {
				
				
				
				

				MQReceivedData mqReceivedData;
				
				try {

				mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
				 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
				  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
			//	  Header receivedHeader = mqReceivedData.getHeader(); 
				  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
						System.out.println("*************inside if*************** "); 
						mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
					} 
				  
				  
				  System.out.println(mqReceivedData.getHeader().toString()); 
			} catch (Exception e) { 
				// TODO Auto-generated catch block 
				 mqReceivedData = mqReadUtil.readDataFromMQ(session); 
				e.printStackTrace(); 


			}
//			System.out.println("::::::mqReceivedData for::::"+mqReceivedData);
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
//			System.out.println("::::::subDatas for::::"+subDatas);
			Header receivedHeader = mqReceivedData.getHeader();
			conformationTaskMain.setHeader(receivedHeader);
//			System.out.println("::::::receivedHeader for::::returncode::::"+receivedHeader.getReturn_code());
			SubData subData = subDatas.get(RecIdFor12State.CS_RECID_ERROR.getRecIdValue());
			SubData subData585 = subDatas.get(RecIdFor9State.CS_RECID_POST_TO_BILL.getRecIdValue());
			SubData subData588 = subDatas.get(RecIdFor9State.CS_RECID_POST_TO_BILL_ORD.getRecIdValue());
			SubData subData550 = subDatas.get(RecIdFor9State.CS_RECID_CONFIRM.getRecIdValue());
			//SubData subData50 = subDatas.get(RecIdFor9State.CS_RECID_LSR.getRecIdValue());
//			System.out.println("subData: "+ subData);
			if (subData != null) {

				String[] subDataRows = subData.getSubDataRows();
				if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
				for (String subDataRow : subDataRows) {

				String[] sentData = subDataRow.split(",");
//				System.out.println("sentData after separation" + sentData);
				for (String a : sentData) {

				ShowErrorService showErrorService = new ShowErrorService();
				ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
				String uon_msg = readErrorMsgsJson.getErrorMsg(a.substring(0, 6).trim());

				focError = showErrorService.getErrorListMultiple(a.substring(0, 6).trim(), uon_msg, "", "U",focError);

				//focMulipleError.add(focError);
				//session.setAttribute("showError", focError);
				System.err.println("ERRORS 600*****" + focError.toString());
				}}
				}
				}
			
			
				if(subData585 != null) {
				String[] subDataRows585 = subData585.getSubDataRows();
				if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
				for (String subDataRow : subDataRows585) {

				String[] sentData = subDataRow.split(",");
				System.out.println("sentData after separation" + sentData);
				for (String a : sentData) {

				ShowErrorService showErrorService = new ShowErrorService();
				ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
				String uon_msg = readErrorMsgsJson.getErrorMsg(a.substring(0, 6).trim());

				focError = showErrorService.getErrorListMultiple(a.substring(0, 6).trim(), uon_msg, "", "U",focError);

				//focMulipleError.add(focError);
				//session.setAttribute("showError", focError);
				System.err.println("ERRORS * inside 560" + focError.toString());
				}}
				}}
				if(subData588 != null) {
				String[] subDataRows588 = subData588.getSubDataRows();
				if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
				for (String subDataRow : subDataRows588) {

				String[] sentData = subDataRow.split(",");
				System.out.println("sentData after separation" + sentData);
				for (String a : sentData) {

				ShowErrorService showErrorService = new ShowErrorService();
				ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
				String uon_msg = readErrorMsgsJson.getErrorMsg(a.substring(0, 6).trim());

				focError = showErrorService.getErrorListMultiple(a.substring(0, 6).trim(), uon_msg, "", "U",focError);

				//focMulipleError.add(focError);
				//session.setAttribute("showError", focError);
				System.err.println("ERRORS Inside 568 ******" + focError.toString());
				}}
				}}
				if(subData550 != null) {
					String[] subDataRows550 = subData550.getSubDataRows();
					if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
						for (String subDataRow : subDataRows550) {
							
							String[] sentData = subDataRow.split(",");
//							System.out.println("sentData after separation" + sentData);
							for (String a : sentData) {
							
								ShowErrorService showErrorService = new ShowErrorService();
							ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
							String uon_msg = readErrorMsgsJson.getErrorMsg(a.substring(0, 6).trim());
							String Lsr_no = (String) session.getAttribute("Lrs_No");
//							System.out.println("LSR no==="+Lsr_no);
							
							focError = showErrorService.getErrorListMultiple(a.substring(0, 6).trim(), uon_msg, "", "lsrn=" +Lsr_no+" "+"unknown",focError);
							
							
							//focMulipleError.add(focError);
							//session.setAttribute("showError", focError);
							System.err.println("ERRORS *550*****" + focError.toString());
						}}
					}}

				session.setAttribute("showError", focError);

				}
			return conformationTaskMain;

			}
		//===================sneha end==================

	public List writeSelectedRequestDataToTreeView(SelectRequestData selectRequestData, String user_id,
			HttpSession session, String object_handle, List treeViewList) {

		Header header = prepareTreeHeader(user_id, object_handle, Process.CS_REQUEST.getProcessCode());
		SubHeader subHeader = prepareTreeSubHeader();

		selectRequestData.setPrevnext_cde("R");
		List<SelectRequestTableRow9> selectedRequestTableRow = selectRequestData.getSelectRequestTableRows9();
		// String dataString = selectRequestData.getSelectRequestDataString();
		String dataString = "";
		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();
		for (SelectRequestTableRow9 selectRequestTableRow : selectedRequestTableRow) {

			String tabValue = "N";
			dataString = selectRequestTableRow.getSelectRequestTreeDataString(tabValue);
			mqMessageStringBuilder.addHeaderSubHeaderAndData(header, subHeader, dataString);

		}
		boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder,session);

		if (isWritten) {

			MQReceivedData mqReceivedData;
			
			try {

			mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
			 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
			  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
		//	  Header receivedHeader = mqReceivedData.getHeader(); 
			  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
					System.out.println("*************inside if*************** "); 
					mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
				} 
			  
			  
			  System.out.println(mqReceivedData.getHeader().toString()); 
		} catch (Exception e) { 
			// TODO Auto-generated catch block 
			 mqReceivedData = mqReadUtil.readDataFromMQ(session); 
			e.printStackTrace(); 


		}
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
			Header receivedHeader = mqReceivedData.getHeader();
			selectRequestData.setHeader(receivedHeader);
//			System.out.println("=============="+mqReceivedData);
			//added by nisha for confirnationRemarks Review
			SubData subData_654Recid = subDatas.get(RecIdFor9State.CS_RECID_FAC_CHK_MSG_VIEW.getRecIdValue());
			
			SubData subData_889Recid = subDatas.get(RecIdFor9State.CS_RECID_DISPLAY_CONFIRM_ECVER_V6.getRecIdValue());
			 
			
			SubData subData_500Recid = subDatas.get(RecIdFor9State.CS_RECID_RPL_CKT.getRecIdValue());
			SubData subData_510Recid = subDatas.get(RecIdFor9State.CS_RECID_RPL_PRILOC.getRecIdValue());
			SubData subData_156Recid = subDatas.get(RecIdFor9State.CS_RECID_RPL_FEATURES.getRecIdValue());
			SubData subData_511Recid = subDatas.get(RecIdFor9State.CS_RECID_RPL_SECLOC.getRecIdValue());
			SubData subData_109Recid = subDatas.get(RecIdFor9State.CS_RECID_RPL_SEC_FEATURES.getRecIdValue());
			SubData subData_532Recid = subDatas.get(RecIdFor12State.CS_RECID_FUP_EDIT.getRecIdValue());
			SubData subData_683Recid = subDatas.get(RecIdFor9State.CS_RECID_CENTREX_COMMONBLOCK.getRecIdValue());
			SubData subData_684Recid = subDatas.get(RecIdFor9State.CS_RECID_CENTREX_STATIONNUMBER.getRecIdValue());
			SubData subData_680Recid = subDatas.get(RecIdFor9State.CS_RECID_CENTREX_RESALE.getRecIdValue());

			SubData subData_211Recid = subDatas.get(RecIdFor9State.CS_RECID_TRANS_CALL_TC.getRecIdValue());
			// ruby
			SubData subData_641Recid = subDatas.get(RecIdFor9State.CS_RECID_DIDPBX_PORT.getRecIdValue());
			SubData subData_642Recid = subDatas.get(RecIdFor9State.CS_RECID_DIDPBX_LOOPPORT.getRecIdValue());

			SubData subData_212Recid = subDatas.get(RecIdFor9State.CS_RECID_TRANS_CALL_TG.getRecIdValue());
			SubData subData_213Recid = subDatas.get(RecIdFor9State.CS_RECID_TG_TC.getRecIdValue());
			// kiran
			
			treeViewList = setSortErrorsData(selectRequestData, subDatas, session, treeViewList);
			// aprajita
			List treeViewList9_842 = new ArrayList(); // Channel9 Loopport IUS channel9_842(9States)
			List treeViewList9_159 = new ArrayList(); // Channel9 Feature_159(9 States)
			List treeViewList9_157 = new ArrayList(); // F_ feature detail9_157(9States)
			List treeViewList9_158 = new ArrayList(); // trunkgrp tgfeature9_158(9 States)
			List treeViewList9_841 = new ArrayList(); // ISDN port ius channel9 _841(9states)
			List treeViewList9_210 = new ArrayList(); // ISDN port pri disc tn (9states)
			SubData subData_841Recid = subDatas.get(RecIdFor9State.CS_RECID_ISDN_PORT.getRecIdValue());
			SubData subData_159Recid = subDatas.get(RecIdFor9State.CS_RECID_CHAN_FEATURES.getRecIdValue());
			SubData subData_157Recid = subDatas.get(RecIdFor9State.CS_RECID_F_FEATURES.getRecIdValue());
			SubData subData_158Recid = subDatas.get(RecIdFor9State.CS_RECID_TG_FEATURES.getRecIdValue());
			SubData subData_210Recid = subDatas.get(RecIdFor9State.CS_RECID_TRANS_CALL_TN.getRecIdValue());
			SubData subData_842Recid = subDatas.get(RecIdFor9State.CS_RECID_ISDN_LOOPPORT.getRecIdValue());

			// rupa
			List treeViewList154 = new ArrayList();
			List treeViewList160 = new ArrayList();
			List treeViewList161 = new ArrayList();
			List treeViewList105 = new ArrayList();
			List treeViewList106 = new ArrayList();
			List treeViewList102 = new ArrayList();
			List treeViewList100 = new ArrayList();
			List treeViewList050 = new ArrayList();
			//rks
			List treeViewList_570 = new ArrayList();
			SubData subData_570Recid = subDatas.get(RecIdFor9State.CS_RECID_REJECT_SUMM.getRecIdValue());
			SubData subData_105Recid = subDatas.get(RecIdFor9State.CS_RECID_DISCONNECT.getRecIdValue());
			SubData subData_106Recid = subDatas.get(RecIdFor9State.CS_RECID_TC.getRecIdValue());
			SubData subData_154Recid = subDatas.get(RecIdFor9State.CS_RECID_ACCT_FEATURES.getRecIdValue());
			SubData subData_160Recid = subDatas.get(RecIdFor9State.CS_RECID_HUNTING.getRecIdValue());
			SubData subData_161Recid = subDatas.get(RecIdFor9State.CS_RECID_HUNTING_DETAIL.getRecIdValue());
			SubData subData_050Recid = subDatas.get(RecIdFor9State.CS_RECID_LSR.getRecIdValue());
			SubData subData_102Recid = subDatas.get(RecIdFor9State.CS_RECID_FINAL_BILL.getRecIdValue());
			SubData subData_100Recid = subDatas.get(RecIdFor9State.CS_RECID_END_USER.getRecIdValue());
			// rashmita
			SubData subData_802Recid = subDatas.get(RecIdFor9State.CS_RECID_TRUNK_LOOPPORT.getRecIdValue());
			SubData subData_801Recid = subDatas.get(RecIdFor9State.CS_RECID_TRUNK_PORT.getRecIdValue());

			// bharti and shalu start

			List treeViewList_150 = new ArrayList();
			List treeViewList_155 = new ArrayList();
			List treeViewList_107 = new ArrayList();
			List treeViewList_108 = new ArrayList();
			List treeViewList_350 = new ArrayList();
			List treeViewList_275 = new ArrayList();
			List treeViewList200 = new ArrayList();
			List treeViewList300 = new ArrayList();
			SubData subData_150Recid = subDatas.get(RecIdFor9State.CS_RECID_RESALE.getRecIdValue());
			SubData subData_155Recid = subDatas.get(RecIdFor9State.CS_RECID_FEATURES.getRecIdValue());
			SubData subData_107Recid = subDatas.get(RecIdFor9State.CS_RECID_PRODUCT_DISCONNECT.getRecIdValue());
			SubData subData_108Recid = subDatas.get(RecIdFor9State.CS_RECID_PRODUCT_TC.getRecIdValue());
			SubData subData_350Recid = subDatas.get(RecIdFor9State.CS_RECID_PORT.getRecIdValue());
			SubData subData_275Recid = subDatas.get(RecIdFor9State.CS_RECID_LOOPPORT.getRecIdValue());
			SubData subData_200Recid = subDatas.get(RecIdFor9State.CS_RECID_LOOP.getRecIdValue());
			SubData subData_300Recid = subDatas.get(RecIdFor9State.CS_RECID_LOOPNP.getRecIdValue());
			// sneha
			SubData subData_681Recid = subDatas.get(RecIdFor9State.CS_RECID_CENTREX_PORT.getRecIdValue());
			SubData subData_682Recid = subDatas.get(RecIdFor9State.CS_RECID_CENTREX_LOOPPORT.getRecIdValue());
				 
			
			SubData subData9_585Recid = subDatas.get(RecIdFor9State.CS_RECID_POST_TO_BILL.getRecIdValue());
			SubData subData9_588Recid = subDatas.get(RecIdFor9State.CS_RECID_POST_TO_BILL_ORD.getRecIdValue());
			// bharti shalu end

			// supriya
			SubData subData_800Recid = subDatas.get(RecIdFor9State.CS_RECID_TRUNK_RESALE.getRecIdValue());
			// Divya
			SubData subData_925Recid = subDatas.get(RecIdFor9State.CS_RECID_DRTY_TXT_SECTION_VIEW.getRecIdValue());

			SubData subData_895Recid = subDatas.get(RecIdFor9State.CS_RECID_DISPLAY_COMPLETE_DIRDTL_V6.getRecIdValue());

			SubData subData_929Recid = subDatas.get(RecIdFor9State.CS_RECID_FOC_HUNTING_VIEW.getRecIdValue());
			SubData subData_930Recid = subDatas.get(RecIdFor9State.CS_RECID_FOC_HUNTING_DTL_VIEW.getRecIdValue());

			SubData subData_926Recid = subDatas.get(RecIdFor9State.CS_RECID_LSR_EU_VIEW.getRecIdValue());
			SubData subData_927Recid = subDatas.get(RecIdFor9State.CS_RECID_SE_ORDS_VIEW.getRecIdValue());

			SubData subData_928Recid = subDatas.get(RecIdFor9State.CS_RECID_SERVICE_SECTION_VIEW.getRecIdValue());
			
			SubData subData_880Recid = subDatas.get(RecIdFor9State.CS_RECID_DISPLAY_CONFIRM_FIX_V6.getRecIdValue());
			SubData subData_888Recid = subDatas.get(RecIdFor9State.CS_RECID_DISPLAY_CONFIRM_REQORD_V6.getRecIdValue());
			SubData subData_882Recid = subDatas.get(RecIdFor9State.CS_RECID_DISPLAY_CONFIRM_DTL_V6.getRecIdValue());
			
			SubData subData_886Recid = subDatas.get(RecIdFor9State.CS_RECID_DISPLAY_CONFIRM_NOPROD_V6.getRecIdValue());

			//SubData subData_888Recid = subDatas.get(RecIdFor9State.CS_RECID_DISPLAY_CONFIRM_REQORD_V6.getRecIdValue());
			// Nisha
			SubData subData_890Recid = subDatas.get(RecIdFor9State.CS_RECID_DISPLAY_COMPLETE_FIX_V6.getRecIdValue());
			SubData subData_898Recid = subDatas.get(RecIdFor9State.CS_RECID_DISPLAY_COMPLETE_REQORD_V6.getRecIdValue());
			
			
			// vipul
			SubData subData_049Recid = subDatas.get(RecIdFor9State.CS_RECID_HEADER.getRecIdValue());
			treeViewList = requestTypeC_Z_9State(selectRequestData, subDatas, session, treeViewList);
			treeViewList = confirmationTaskGeneral(selectRequestData, subDatas, session, treeViewList);
			// Saurabh
			treeViewList = correctingConfTaskNoProd(selectRequestData, subDatas, session, treeViewList);
			treeViewList = correctingConfTask9(selectRequestData, subDatas, session, treeViewList);
			treeViewList = confirmationTaskNoProd(selectRequestData, subDatas, session, treeViewList);
			
			//Supriya
			treeViewList = jeopardyTaskListData(selectRequestData, subDatas, session, treeViewList);
			
			//Hrushikesh- Completion Provider Task With Loss
			treeViewList = completionProviderTaskWithLoss(selectRequestData, subDatas, session, treeViewList);
			//rks 570
			/////////////////////////////570/////////////////////////////
			if (subData_570Recid != null && subData_570Recid.getSubHeader().getRecord_type().equals("570")) {
				//List<FollowUpData9States> treeViewList_549 = new ArrayList();
				SubHeader receivedSubHeader = subData_570Recid.getSubHeader();
				String[] subDataRows = subData_570Recid.getSubDataRows();
				
				treeViewList.add("570");
				
				
				
				
			}
			// Vipul
			if (subData_049Recid != null && subData_049Recid.getSubHeader().getRecord_type().equals("049")) {
				
				getSubData_049RecidData(subData_049Recid,treeViewList,selectRequestData,session,receivedHeader);
				
				
			}
////////////////////////////////////////////////////////////yash//////////////////
	////////*****************************540***********************/////
			
			
			if (subData_532Recid != null && subData_532Recid.getSubHeader().getRecord_type().equals("532")) {
				SubHeader receivedSubHeader = subData_532Recid.getSubHeader();
				String[] subDataRows = subData_532Recid.getSubDataRows();
				treeViewList.add("532");
				List treeViewList_532 = new ArrayList();
//				System.out.println("sub data for 532" + Arrays.toString(subDataRows));

//int i = 0;
				FollowUpTableRow followUpUser = new FollowUpTableRow();
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 17);
//					System.out.println("attributes:=532:Reqid======> " + Arrays.toString(attributes));

					followUpUser.setWorked_ind_attr(attributes[0]);
					followUpUser.setWorked_ind(attributes[1]);
					followUpUser.setCancel_ind_attr(attributes[2]);
					followUpUser.setCancel_ind(attributes[3]);
					followUpUser.setNotes_datetime(attributes[4]);
					followUpUser.setUser_id_attr(attributes[5]);
					followUpUser.setUser_id(attributes[6]);
					followUpUser.setLasr_ver_attr(attributes[7]);
					followUpUser.setLasr_ver(attributes[8]);
					followUpUser.setFollow_up_date_attr(attributes[9]);
					followUpUser.setFollow_up_date(attributes[10]);
					followUpUser.setFup_worked_date_attr(attributes[11]);
					followUpUser.setFup_worked_date(attributes[12]);
					followUpUser.setFup_end_date_attr(attributes[13]);
					followUpUser.setFup_end_date(attributes[14]);
					followUpUser.setNotes_attr(attributes[15]);
					followUpUser.setNotes(attributes[16]);

					treeViewList_532.add(followUpUser);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				session.setAttribute("followUpUser", followUpUser); // System.out.println("++++treeViewList+++before
																	// session+++"+treeViewList_543);
				session.setAttribute("treeViewList_532", treeViewList_532);

			}

			// for RecId 890 and 898

			if (subData_890Recid != null && subData_890Recid.getSubHeader().getRecord_type().equals("890")) {

				SubHeader receivedSubHeader = subData_890Recid.getSubHeader();
				String[] subDataRows = subData_890Recid.getSubDataRows();

				List<CompletionLSOG6> treeViewList890 = new ArrayList();
				treeViewList.add("890");

				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 11);
					// System.out.println("subData_890Recid======> " + Arrays.toString(attributes));
					CompletionLSOG6 completionLSOG6 = new CompletionLSOG6();

					completionLSOG6.setA_cver(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
					completionLSOG6.setA_atn(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
					completionLSOG6.setA_rt(attributes[2] != null && attributes[2] != "" ? attributes[2] : " ");
					completionLSOG6.setA_ecver(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
					completionLSOG6
							.setD_t_sent_local(attributes[4] != null && attributes[4] != "" ? attributes[4] : " ");
					completionLSOG6.setResponse_d_t_sent_central_time(
							attributes[5] != null && attributes[5] != "" ? attributes[5] : " ");
					completionLSOG6
							.setA_comp_dt_attr(attributes[6] != null && attributes[6] != "" ? attributes[6] : " ");
					completionLSOG6.setComp_dt(attributes[7] != null && attributes[7] != "" ? attributes[7] : " ");
					completionLSOG6
							.setA_company_code_attr(attributes[8] != null && attributes[8] != "" ? attributes[8] : " ");
					completionLSOG6
							.setA_comapny_code(attributes[9] != null && attributes[9] != "" ? attributes[9] : " ");
					completionLSOG6.setA_an(attributes[10] != null && attributes[10] != "" ? attributes[10] : " ");

					treeViewList890.add(completionLSOG6);
				}
				session.setAttribute("treeViewList890", treeViewList890);
				selectRequestData.setSubHeader(receivedSubHeader);

			}

			if (subData_898Recid != null && subData_898Recid.getSubHeader().getRecord_type().equals("898")) {

				SubHeader receivedSubHeader = subData_898Recid.getSubHeader();
				String[] subDataRows = subData_898Recid.getSubDataRows();
				List<CompletionActivityRLSOG6LscInfo> treeViewList898 = new ArrayList();
				treeViewList.add("898");

				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 11);
					// System.out.println("subData_898Recid======> " + Arrays.toString(attributes));

					CompletionActivityRLSOG6LscInfo completionActivityRLSOG6LscInfo = new CompletionActivityRLSOG6LscInfo();

						completionActivityRLSOG6LscInfo
						.setOld_dtm(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
				completionActivityRLSOG6LscInfo
						.setOld_ord(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
				completionActivityRLSOG6LscInfo
						.setOrd_attr(attributes[2] != null && attributes[2] != "" ? attributes[2] : " ");
				completionActivityRLSOG6LscInfo
						.setOrd(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");


					treeViewList898.add(completionActivityRLSOG6LscInfo);

				}
				session.setAttribute("treeViewList898", treeViewList898);
				selectRequestData.setSubHeader(receivedSubHeader);

			}
			
			// for recId 654 adde by nisha
			if (subData_654Recid != null && subData_654Recid.getSubHeader().getRecord_type().equals("654")) {

				SubHeader receivedSubHeader = subData_654Recid.getSubHeader();
				String[] subDataRows = subData_654Recid.getSubDataRows();
				List<ConfiramtionRemarksReview> treeViewList654 = new ArrayList();
				treeViewList.add("654");

				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 4);
//				 System.out.println("subData_654Recid======> " + Arrays.toString(attributes));

					
					ConfiramtionRemarksReview confiramtionRemarksReview = new	ConfiramtionRemarksReview();
					  
					confiramtionRemarksReview.setFac_msg_attr(attributes[0]);
					confiramtionRemarksReview.setFac_msg(attributes[1]); 
					confiramtionRemarksReview.setRemarks_attr(attributes[2]); 
					confiramtionRemarksReview.setRemarks(attributes[3] );
					 

				treeViewList654.add(confiramtionRemarksReview);

				}
				System.out.println("=========treeViewList654==========");;
				treeViewList654.forEach(x->System.out.println(x));
				session.setAttribute("treeViewList654", treeViewList654);
				selectRequestData.setSubHeader(receivedSubHeader);

			}
			//for RecId subData_889Recid adde by nisha
			
			if (subData_889Recid != null && subData_889Recid.getSubHeader().getRecord_type().equals("889")) {

				SubHeader receivedSubHeader = subData_889Recid.getSubHeader();
				String[] subDataRows = subData_889Recid.getSubDataRows();
				List<ResponseEcver> treeViewList889 = new ArrayList();
				treeViewList.add("889");

				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 4);
//				 System.out.println("subData_889Recid======> " + Arrays.toString(attributes));

					
				 ResponseEcver responseEcver = new	ResponseEcver();
					  
				 responseEcver.setEcver(attributes[0]);
					
					treeViewList889.add(responseEcver);

				}
				System.out.println("=========treeViewLis889==========");
				treeViewList889.forEach(x->System.out.println(x));
				session.setAttribute("treeViewList889", treeViewList889);
				selectRequestData.setSubHeader(receivedSubHeader);

			}

			

			
			// kiran

			if (subData_680Recid != null && subData_680Recid.getSubHeader().getRecord_type().equals("680")) {

				getSubData_680RecidData(subData_680Recid,treeViewList,selectRequestData,session);
				
			
			}

			if (subData_500Recid != null && subData_500Recid.getSubHeader().getRecord_type().equals("500")) {

				SubHeader receivedSubHeader = subData_500Recid.getSubHeader();
				String[] subDataRows = subData_500Recid.getSubDataRows();
				List<Resaleprivatelinecircuit9states> treeViewList_500 = new ArrayList();
				treeViewList.add("500");
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 44);
					// System.out.println("attributes:=500:Reqid======> " +
					// Arrays.toString(attributes));
					Resaleprivatelinecircuit9states resaleprivatelinecircuit12states = new Resaleprivatelinecircuit9states();

					resaleprivatelinecircuit12states
							.setItem_num(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
					resaleprivatelinecircuit12states
							.setLnum_attr(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
					resaleprivatelinecircuit12states
							.setLnum(attributes[2] != null && attributes[2] != "" ? attributes[2] : " ");
					resaleprivatelinecircuit12states
							.setCkta_attr(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
					resaleprivatelinecircuit12states
							.setCkta(attributes[4] != null && attributes[4] != "" ? attributes[4] : " ");
					resaleprivatelinecircuit12states
							.setSvc_cd_attr(attributes[5] != null && attributes[5] != "" ? attributes[5] : " ");
					resaleprivatelinecircuit12states
							.setSvc_cd(attributes[6] != null && attributes[6] != "" ? attributes[6] : " ");
					resaleprivatelinecircuit12states
							.setCkttyp_attr(attributes[7] != null && attributes[7] != "" ? attributes[7] : " ");
					resaleprivatelinecircuit12states
							.setCkttyp(attributes[8] != null && attributes[8] != "" ? attributes[8] : " ");
					resaleprivatelinecircuit12states
							.setEcckt_attr(attributes[9] != null && attributes[9] != "" ? attributes[9] : " ");
					resaleprivatelinecircuit12states
							.setEcckt(attributes[10] != null && attributes[10] != "" ? attributes[10] : " ");

					resaleprivatelinecircuit12states
							.setMtp_attr(attributes[11] != null && attributes[11] != "" ? attributes[11] : " ");
					resaleprivatelinecircuit12states
							.setMtp(attributes[12] != null && attributes[12] != "" ? attributes[12] : " ");
					resaleprivatelinecircuit12states
							.setWire_attr(attributes[13] != null && attributes[13] != "" ? attributes[13] : " ");
					resaleprivatelinecircuit12states
							.setWire(attributes[14] != null && attributes[14] != "" ? attributes[14] : " ");
					resaleprivatelinecircuit12states
							.setDisc_ecckt_attr(attributes[15] != null && attributes[15] != "" ? attributes[15] : " ");
					resaleprivatelinecircuit12states
							.setDisc_ecckt(attributes[16] != null && attributes[16] != "" ? attributes[16] : " ");
					// resaleprivatelinecircuit12states.setScreenName("Circut");
					resaleprivatelinecircuit12states
							.setLc_attr(attributes[17] != null && attributes[17] != "" ? attributes[17] : " ");
					resaleprivatelinecircuit12states
							.setLc(attributes[18] != null && attributes[18] != "" ? attributes[18] : " ");
					resaleprivatelinecircuit12states
							.setFrf_attr(attributes[19] != null && attributes[19] != "" ? attributes[19] : " ");
					resaleprivatelinecircuit12states
							.setFrf(attributes[20] != null && attributes[20] != "" ? attributes[20] : " ");
					resaleprivatelinecircuit12states
							.setEcckt2_attr(attributes[21] != null && attributes[21] != "" ? attributes[21] : " ");
					resaleprivatelinecircuit12states
							.setEcckt2(attributes[22] != null && attributes[22] != "" ? attributes[22] : " ");
					resaleprivatelinecircuit12states
							.setDnum_attr(attributes[23] != null && attributes[23] != "" ? attributes[23] : " ");
					resaleprivatelinecircuit12states
							.setDnum(attributes[24] != null && attributes[24] != "" ? attributes[24] : " ");
					resaleprivatelinecircuit12states
							.setDqty_attr(attributes[25] != null && attributes[25] != "" ? attributes[25] : " ");
					resaleprivatelinecircuit12states
							.setDqty(attributes[26] != null && attributes[26] != "" ? attributes[26] : " ");
					resaleprivatelinecircuit12states
							.setFrcktspd_attr(attributes[27] != null && attributes[27] != "" ? attributes[27] : " ");
					resaleprivatelinecircuit12states
							.setFrcktspd(attributes[28] != null && attributes[28] != "" ? attributes[28] : " ");
					resaleprivatelinecircuit12states
							.setFrdlcityp_attr(attributes[29] != null && attributes[29] != "" ? attributes[29] : " ");
					;
					resaleprivatelinecircuit12states
							.setFrdlcityp(attributes[30] != null && attributes[30] != "" ? attributes[30] : " ");
					;
					resaleprivatelinecircuit12states
							.setFrdlci_attr(attributes[31] != null && attributes[31] != "" ? attributes[31] : " ");
					resaleprivatelinecircuit12states
							.setFrdlci(attributes[32] != null && attributes[32] != "" ? attributes[32] : " ");
					resaleprivatelinecircuit12states
							.setFrrdlci_attr(attributes[33] != null && attributes[33] != "" ? attributes[33] : " ");
					;
					resaleprivatelinecircuit12states
							.setFrrdlci(attributes[34] != null && attributes[34] != "" ? attributes[34] : " ");
					;
					resaleprivatelinecircuit12states
							.setFrrcid_attr(attributes[35] != null && attributes[35] != "" ? attributes[35] : " ");
					;
					resaleprivatelinecircuit12states
							.setFrrcid(attributes[36] != null && attributes[36] != "" ? attributes[36] : " ");
					resaleprivatelinecircuit12states
							.setFrcir_attr(attributes[37] != null && attributes[37] != "" ? attributes[37] : " ");
					resaleprivatelinecircuit12states
							.setFrcir(attributes[38] != null && attributes[38] != "" ? attributes[38] : " ");
					resaleprivatelinecircuit12states
							.setFrbex_attr(attributes[39] != null && attributes[39] != "" ? attributes[39] : " ");
					;
					resaleprivatelinecircuit12states
							.setFrbex(attributes[40] != null && attributes[40] != "" ? attributes[40] : " ");
					;
					resaleprivatelinecircuit12states
							.setCkltype_attr(attributes[41] != null && attributes[41] != "" ? attributes[41] : " ");
					;
					resaleprivatelinecircuit12states
							.setCkltype(attributes[42] != null && attributes[42] != "" ? attributes[42] : " ");
					;
					resaleprivatelinecircuit12states
							.setLoc_seq_num(attributes[43] != null && attributes[43] != "" ? attributes[43] : " ");
					;

					treeViewList_500.add(resaleprivatelinecircuit12states);
				}
				session.setAttribute("treeViewList_500", treeViewList_500);
				selectRequestData.setSubHeader(receivedSubHeader);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}

			if (subData_510Recid != null && subData_510Recid.getSubHeader().getRecord_type().equals("510")) {

				SubHeader receivedSubHeader = subData_510Recid.getSubHeader();
				String[] subDataRows = subData_510Recid.getSubDataRows();
				List<Resaleprivatelineprimarylocation9states> treeViewList_510 = new ArrayList();
				treeViewList.add("510");
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 143);
					// System.out.println("attributes:=510======> " + Arrays.toString(attributes));
					Resaleprivatelineprimarylocation9states resaleprivatelineprimarylocation12states = new Resaleprivatelineprimarylocation9states();

					resaleprivatelineprimarylocation12states.setRequest_prod_id(attributes[0]);
					resaleprivatelineprimarylocation12states.setItem_num(attributes[1]);
					resaleprivatelineprimarylocation12states.setLnum_attr(attributes[2]);
					resaleprivatelineprimarylocation12states.setLnum(attributes[3]);
					resaleprivatelineprimarylocation12states.setLeg_itemnum_attr(attributes[4]);
					resaleprivatelineprimarylocation12states.setLeg_itemnum(attributes[5]);
					resaleprivatelineprimarylocation12states.setLegnum_attr(attributes[6]);
					resaleprivatelineprimarylocation12states.setLegnum(attributes[7]);
					resaleprivatelineprimarylocation12states.setPri_lna_attr(attributes[8]);
					resaleprivatelineprimarylocation12states.setPri_lna(attributes[9]);
					resaleprivatelineprimarylocation12states.setLit_attr(attributes[10]);
					resaleprivatelineprimarylocation12states.setLit(attributes[11]);
					resaleprivatelineprimarylocation12states.setPriloc_attr(attributes[12]);
					resaleprivatelineprimarylocation12states.setPriloc(attributes[13]);
					resaleprivatelineprimarylocation12states.setPriname_attr(attributes[14]);
					resaleprivatelineprimarylocation12states.setPriname(attributes[15]);
					resaleprivatelineprimarylocation12states.setCfa_attr(attributes[16]);
					resaleprivatelineprimarylocation12states.setCfa(attributes[17]);
					resaleprivatelineprimarylocation12states.setFic_attr(attributes[18]);
					resaleprivatelineprimarylocation12states.setFic(attributes[19]);
					resaleprivatelineprimarylocation12states.setSr_attr(attributes[20]);
					resaleprivatelineprimarylocation12states.setSr(attributes[21]);
					resaleprivatelineprimarylocation12states.setRpl_ncon_attr(attributes[22]);
					resaleprivatelineprimarylocation12states.setRpl_ncon(attributes[23]);
					resaleprivatelineprimarylocation12states.setAft_attr(attributes[24]);
					resaleprivatelineprimarylocation12states.setAft(attributes[25]);
					resaleprivatelineprimarylocation12states.setSapr_attr(attributes[26]);
					resaleprivatelineprimarylocation12states.setSapr(attributes[27]);
					resaleprivatelineprimarylocation12states.setSano_attr(attributes[28]);
					resaleprivatelineprimarylocation12states.setSano(attributes[29]);
					resaleprivatelineprimarylocation12states.setSasf_attr(attributes[30]);
					resaleprivatelineprimarylocation12states.setSasf(attributes[31]);
					resaleprivatelineprimarylocation12states.setSasd_attr(attributes[32]);
					resaleprivatelineprimarylocation12states.setSasd(attributes[33]);
					resaleprivatelineprimarylocation12states.setSasn_attr(attributes[34]);
					resaleprivatelineprimarylocation12states.setSasn(attributes[35]);
					resaleprivatelineprimarylocation12states.setSath_attr(attributes[36]);
					resaleprivatelineprimarylocation12states.setSath(attributes[37]);
					resaleprivatelineprimarylocation12states.setSass_attr(attributes[38]);
					resaleprivatelineprimarylocation12states.setSass(attributes[39]);
					resaleprivatelineprimarylocation12states.setLd1_attr(attributes[40]);
					resaleprivatelineprimarylocation12states.setLd1(attributes[41]);
					resaleprivatelineprimarylocation12states.setLv1_attr(attributes[42]);
					resaleprivatelineprimarylocation12states.setLv1(attributes[43]);
					resaleprivatelineprimarylocation12states.setLd2_attr(attributes[44]);
					resaleprivatelineprimarylocation12states.setLd2(attributes[45]);
					resaleprivatelineprimarylocation12states.setLv2_attr(attributes[46]);
					resaleprivatelineprimarylocation12states.setLv2(attributes[47]);
					resaleprivatelineprimarylocation12states.setLd3_attr(attributes[48]);
					resaleprivatelineprimarylocation12states.setLd3(attributes[49]);
					resaleprivatelineprimarylocation12states.setLv3_attr(attributes[50]);
					resaleprivatelineprimarylocation12states.setLv3(attributes[51]);
					resaleprivatelineprimarylocation12states.setAai_attr(attributes[52]);
					resaleprivatelineprimarylocation12states.setAai(attributes[53]);
					resaleprivatelineprimarylocation12states.setCity_attr(attributes[54]);
					resaleprivatelineprimarylocation12states.setCity(attributes[55]);
					resaleprivatelineprimarylocation12states.setState_attr(attributes[56]);
					resaleprivatelineprimarylocation12states.setState(attributes[57]);
					resaleprivatelineprimarylocation12states.setZip_attr(attributes[58]);
					resaleprivatelineprimarylocation12states.setZip(attributes[59]);
					resaleprivatelineprimarylocation12states.setAloc_attr(attributes[60]);
					resaleprivatelineprimarylocation12states.setAloc(attributes[61]);
					resaleprivatelineprimarylocation12states.setLcon_attr(attributes[62]);
					resaleprivatelineprimarylocation12states.setLcon(attributes[63]);
					resaleprivatelineprimarylocation12states.setActel_no_attr(attributes[64]);
					resaleprivatelineprimarylocation12states.setActel_no(attributes[65]);
					resaleprivatelineprimarylocation12states.setAcc_attr(attributes[66]);
					resaleprivatelineprimarylocation12states.setAcc(attributes[67]);
					resaleprivatelineprimarylocation12states.setJr_attr(attributes[68]);
					resaleprivatelineprimarylocation12states.setJr(attributes[69]);
					resaleprivatelineprimarylocation12states.setJk_code_attr(attributes[70]);
					resaleprivatelineprimarylocation12states.setJk_code(attributes[71]);
					resaleprivatelineprimarylocation12states.setJk_num_attr(attributes[72]);
					resaleprivatelineprimarylocation12states.setJk_num(attributes[73]);
					resaleprivatelineprimarylocation12states.setJk_pos_attr(attributes[74]);
					resaleprivatelineprimarylocation12states.setJk_pos(attributes[75]);
					resaleprivatelineprimarylocation12states.setIwo_attr(attributes[76]);
					resaleprivatelineprimarylocation12states.setIwo(attributes[77]);
					resaleprivatelineprimarylocation12states.setIwjq1_attr(attributes[78]);
					resaleprivatelineprimarylocation12states.setIwjq1(attributes[79]);
					resaleprivatelineprimarylocation12states.setIwjq2_attr(attributes[80]);
					resaleprivatelineprimarylocation12states.setIwjq2(attributes[81]);
					resaleprivatelineprimarylocation12states.setIwjq3_attr(attributes[82]);
					resaleprivatelineprimarylocation12states.setIwjq3(attributes[83]);
					resaleprivatelineprimarylocation12states.setIwjq4_attr(attributes[84]);
					resaleprivatelineprimarylocation12states.setIwjq4(attributes[85]);
					resaleprivatelineprimarylocation12states.setIwjq5_attr(attributes[86]);
					resaleprivatelineprimarylocation12states.setIwjq5(attributes[87]);
					resaleprivatelineprimarylocation12states.setIwjk1_attr(attributes[88]);
					resaleprivatelineprimarylocation12states.setIwjk1(attributes[89]);
					resaleprivatelineprimarylocation12states.setIwjk2_attr(attributes[90]);
					resaleprivatelineprimarylocation12states.setIwjk2(attributes[91]);
					resaleprivatelineprimarylocation12states.setIwjk3_attr(attributes[92]);
					resaleprivatelineprimarylocation12states.setIwjk3(attributes[93]);
					resaleprivatelineprimarylocation12states.setIwjk4_attr(attributes[94]);
					resaleprivatelineprimarylocation12states.setIwjk4(attributes[95]);
					resaleprivatelineprimarylocation12states.setIwjk5_attr(attributes[96]);
					resaleprivatelineprimarylocation12states.setIwjk5(attributes[97]);
					resaleprivatelineprimarylocation12states.setRlso_attr(attributes[98]);
					resaleprivatelineprimarylocation12states.setRlso(attributes[99]);

					resaleprivatelineprimarylocation12states.setScfa_attr(attributes[100]);
					resaleprivatelineprimarylocation12states.setScfa(attributes[101]);
					resaleprivatelineprimarylocation12states.setLcontelno_attr(attributes[102]);
					resaleprivatelineprimarylocation12states.setLcontelno(attributes[103]);
					resaleprivatelineprimarylocation12states.setFbi_attr(attributes[104]);
					resaleprivatelineprimarylocation12states.setFbi(attributes[105]);
					resaleprivatelineprimarylocation12states.setBillnm_attr(attributes[106]);
					resaleprivatelineprimarylocation12states.setBillnm(attributes[107]);
					resaleprivatelineprimarylocation12states.setSbillnm_attr(attributes[108]);
					resaleprivatelineprimarylocation12states.setSbillnm(attributes[109]);
					resaleprivatelineprimarylocation12states.setStreet_attr(attributes[110]);
					resaleprivatelineprimarylocation12states.setStreet(attributes[111]);
					resaleprivatelineprimarylocation12states.setScity_attr(attributes[112]);
					resaleprivatelineprimarylocation12states.setScity(attributes[113]);
					resaleprivatelineprimarylocation12states.setSstate_attr(attributes[114]);
					resaleprivatelineprimarylocation12states.setSstate(attributes[115]);
					resaleprivatelineprimarylocation12states.setSzip_attr(attributes[116]);
					resaleprivatelineprimarylocation12states.setSzip(attributes[117]);
					resaleprivatelineprimarylocation12states.setRmstop_attr(attributes[118]);
					resaleprivatelineprimarylocation12states.setRmstop(attributes[119]);
					resaleprivatelineprimarylocation12states.setBillcon_attr(attributes[120]);
					resaleprivatelineprimarylocation12states.setBillcon(attributes[121]);
					resaleprivatelineprimarylocation12states.setTelno_attr(attributes[122]);
					resaleprivatelineprimarylocation12states.setTelno(attributes[123]);
					resaleprivatelineprimarylocation12states.setAactel_attr(attributes[124]);
					resaleprivatelineprimarylocation12states.setAactel(attributes[125]);
					resaleprivatelineprimarylocation12states.setItc_attr(attributes[126]);
					resaleprivatelineprimarylocation12states.setItc(attributes[127]);
					resaleprivatelineprimarylocation12states.setItcnm_attr(attributes[128]);
					resaleprivatelineprimarylocation12states.setItcnm(attributes[129]);
					resaleprivatelineprimarylocation12states.setItctn_attr(attributes[130]);
					resaleprivatelineprimarylocation12states.setItctn(attributes[131]);
					resaleprivatelineprimarylocation12states.setItccc_attr(attributes[132]);
					resaleprivatelineprimarylocation12states.setItccc(attributes[133]);
					resaleprivatelineprimarylocation12states.setIwt_attr(attributes[134]);
					resaleprivatelineprimarylocation12states.setIwt(attributes[135]);
					resaleprivatelineprimarylocation12states.setIwcon_attr(attributes[136]);
					resaleprivatelineprimarylocation12states.setIwcon(attributes[137]);
					resaleprivatelineprimarylocation12states.setIwtq_attr(attributes[138]);
					resaleprivatelineprimarylocation12states.setIwtq(attributes[139]);
					resaleprivatelineprimarylocation12states.setMst_attr(attributes[140]);
					resaleprivatelineprimarylocation12states.setMst(attributes[141]);
					resaleprivatelineprimarylocation12states.setLoc_seq_num(attributes[142]);

					treeViewList_510.add(resaleprivatelineprimarylocation12states);
				}
				session.setAttribute("treeViewList_510", treeViewList_510);
				selectRequestData.setSubHeader(receivedSubHeader);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}
			if (subData_156Recid != null && subData_156Recid.getSubHeader().getRecord_type().equals("156")) {

				SubHeader receivedSubHeader = subData_156Recid.getSubHeader();
				String[] subDataRows = subData_156Recid.getSubDataRows();
				List<Resaleprivatelineprimarylocation_grid9states> treeViewList_156 = new ArrayList();
				// List treeViewList = new ArrayList();
				treeViewList.add("156");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 13);
					// System.out.println("attributes:==156=====> " + Arrays.toString(attributes));
					Resaleprivatelineprimarylocation_grid9states resaleprivatelineprimarylocation_grid12states = new Resaleprivatelineprimarylocation_grid9states();

					resaleprivatelineprimarylocation_grid12states.setRequest_prod_id(attributes[0]);
					resaleprivatelineprimarylocation_grid12states.setItem_num(attributes[1]);
					resaleprivatelineprimarylocation_grid12states.setLeg_itemnum(attributes[2]);
					resaleprivatelineprimarylocation_grid12states.setFa_attr(attributes[3]);
					resaleprivatelineprimarylocation_grid12states.setFa(attributes[4]);
					resaleprivatelineprimarylocation_grid12states.setFeature_attr(attributes[5]);
					resaleprivatelineprimarylocation_grid12states.setFeature(attributes[6]);
					resaleprivatelineprimarylocation_grid12states.setFeature_detail_attr(attributes[7]);
					resaleprivatelineprimarylocation_grid12states.setFeature_detail(attributes[8]);
					resaleprivatelineprimarylocation_grid12states.setLine_asgn_attr(attributes[9]);
					resaleprivatelineprimarylocation_grid12states.setLine_asgn(attributes[10]);
					resaleprivatelineprimarylocation_grid12states.setLocnum(attributes[11]);
					resaleprivatelineprimarylocation_grid12states.setLoc_seq_num(attributes[12]);

					// resaleprivatelineprimarylocation_grid12states.setEcckt_attr(attributes[9]);

					treeViewList_156.add(resaleprivatelineprimarylocation_grid12states);
				}
				session.setAttribute("treeViewList_156", treeViewList_156);
				selectRequestData.setSubHeader(receivedSubHeader);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}

			if (subData_511Recid != null && subData_511Recid.getSubHeader().getRecord_type().equals("511")) {

				SubHeader receivedSubHeader = subData_511Recid.getSubHeader();
				String[] subDataRows = subData_511Recid.getSubDataRows();
				List<Resaleprivatelinesecondarylocation9states> treeViewList_511 = new ArrayList();
				treeViewList.add("511");
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 131);
					// System.out.println("attributes:=511:Reqid======> " +
					// Arrays.toString(attributes));
					Resaleprivatelinesecondarylocation9states resaleprivatelinesecondarylocation12states = new Resaleprivatelinesecondarylocation9states();

					resaleprivatelinesecondarylocation12states.setRequest_prod_id(attributes[0]);
					resaleprivatelinesecondarylocation12states.setItem_num(attributes[1]);
					resaleprivatelinesecondarylocation12states.setLnum_attr(attributes[2]);
					resaleprivatelinesecondarylocation12states.setLnum(attributes[3]);
					resaleprivatelinesecondarylocation12states.setLeg_itemnum_attr(attributes[4]);
					resaleprivatelinesecondarylocation12states.setLeg_itemnum(attributes[5]);
					resaleprivatelinesecondarylocation12states.setLegnum_attr(attributes[6]);
					resaleprivatelinesecondarylocation12states.setLegnum(attributes[7]);
					resaleprivatelinesecondarylocation12states.setLegid_attr(attributes[8]);
					resaleprivatelinesecondarylocation12states.setLegid(attributes[9]);
					resaleprivatelinesecondarylocation12states.setSec_lna_attr(attributes[10]);
					resaleprivatelinesecondarylocation12states.setSec_lna(attributes[11]);
					resaleprivatelinesecondarylocation12states.setMl_attr(attributes[12]);
					resaleprivatelinesecondarylocation12states.setMl(attributes[13]);
					resaleprivatelinesecondarylocation12states.setLit_attr(attributes[14]);
					resaleprivatelinesecondarylocation12states.setLit(attributes[15]);
					resaleprivatelinesecondarylocation12states.setSecloc_attr(attributes[16]);
					resaleprivatelinesecondarylocation12states.setSecloc(attributes[17]);
					resaleprivatelinesecondarylocation12states.setSecname_attr(attributes[18]);
					resaleprivatelinesecondarylocation12states.setSecname(attributes[19]);
					resaleprivatelinesecondarylocation12states.setCfa_attr(attributes[20]);
					resaleprivatelinesecondarylocation12states.setCfa(attributes[21]);
					resaleprivatelinesecondarylocation12states.setFic_attr(attributes[22]);
					resaleprivatelinesecondarylocation12states.setFic(attributes[23]);
					resaleprivatelinesecondarylocation12states.setSr_attr(attributes[24]);
					resaleprivatelinesecondarylocation12states.setSr(attributes[25]);
					resaleprivatelinesecondarylocation12states.setRpl_ncon_attr(attributes[26]);
					resaleprivatelinesecondarylocation12states.setRpl_ncon(attributes[27]);
					resaleprivatelinesecondarylocation12states.setAft_attr(attributes[28]);
					resaleprivatelinesecondarylocation12states.setAft(attributes[29]);
					resaleprivatelinesecondarylocation12states.setSapr_attr(attributes[30]);
					resaleprivatelinesecondarylocation12states.setSapr(attributes[31]);
					resaleprivatelinesecondarylocation12states.setSano_attr(attributes[32]);
					resaleprivatelinesecondarylocation12states.setSano(attributes[33]);
					resaleprivatelinesecondarylocation12states.setSasf_attr(attributes[34]);
					resaleprivatelinesecondarylocation12states.setSasf(attributes[35]);
					resaleprivatelinesecondarylocation12states.setSasd_attr(attributes[36]);
					resaleprivatelinesecondarylocation12states.setSasd(attributes[37]);
					resaleprivatelinesecondarylocation12states.setSasn_attr(attributes[38]);
					resaleprivatelinesecondarylocation12states.setSasn(attributes[39]);
					resaleprivatelinesecondarylocation12states.setSath_attr(attributes[40]);
					resaleprivatelinesecondarylocation12states.setSath(attributes[41]);
					resaleprivatelinesecondarylocation12states.setSass_attr(attributes[42]);
					resaleprivatelinesecondarylocation12states.setSass(attributes[43]);
					resaleprivatelinesecondarylocation12states.setLd1_attr(attributes[44]);
					resaleprivatelinesecondarylocation12states.setLd1(attributes[45]);
					resaleprivatelinesecondarylocation12states.setLv1_attr(attributes[46]);
					resaleprivatelinesecondarylocation12states.setLv1(attributes[47]);
					resaleprivatelinesecondarylocation12states.setLd2_attr(attributes[48]);
					resaleprivatelinesecondarylocation12states.setLd2(attributes[49]);
					resaleprivatelinesecondarylocation12states.setLv2_attr(attributes[50]);
					resaleprivatelinesecondarylocation12states.setLv2(attributes[51]);
					resaleprivatelinesecondarylocation12states.setLd3_attr(attributes[52]);
					resaleprivatelinesecondarylocation12states.setLd3(attributes[53]);
					resaleprivatelinesecondarylocation12states.setLv3_attr(attributes[54]);
					resaleprivatelinesecondarylocation12states.setLv3(attributes[55]);
					resaleprivatelinesecondarylocation12states.setAai_attr(attributes[56]);
					resaleprivatelinesecondarylocation12states.setAai(attributes[57]);
					resaleprivatelinesecondarylocation12states.setCity_attr(attributes[58]);
					resaleprivatelinesecondarylocation12states.setCity(attributes[59]);
					resaleprivatelinesecondarylocation12states.setState_attr(attributes[60]);
					resaleprivatelinesecondarylocation12states.setState(attributes[61]);
					resaleprivatelinesecondarylocation12states.setZip_attr(attributes[62]);
					resaleprivatelinesecondarylocation12states.setZip(attributes[63]);
					resaleprivatelinesecondarylocation12states.setAloc_attr(attributes[64]);
					resaleprivatelinesecondarylocation12states.setAloc(attributes[65]);
					resaleprivatelinesecondarylocation12states.setLcon_attr(attributes[66]);
					resaleprivatelinesecondarylocation12states.setLcon(attributes[67]);
					resaleprivatelinesecondarylocation12states.setActel_no_attr(attributes[68]);
					resaleprivatelinesecondarylocation12states.setActel_no(attributes[69]);
					resaleprivatelinesecondarylocation12states.setAcc_attr(attributes[70]);
					resaleprivatelinesecondarylocation12states.setAcc(attributes[71]);
					resaleprivatelinesecondarylocation12states.setJr_attr(attributes[72]);
					resaleprivatelinesecondarylocation12states.setJr(attributes[73]);
					resaleprivatelinesecondarylocation12states.setJk_code_attr(attributes[74]);
					resaleprivatelinesecondarylocation12states.setJk_code(attributes[75]);
					resaleprivatelinesecondarylocation12states.setJk_num_attr(attributes[76]);
					resaleprivatelinesecondarylocation12states.setJk_num(attributes[77]);
					resaleprivatelinesecondarylocation12states.setJk_pos_attr(attributes[78]);
					resaleprivatelinesecondarylocation12states.setJk_pos(attributes[79]);
					resaleprivatelinesecondarylocation12states.setIwo_attr(attributes[80]);
					resaleprivatelinesecondarylocation12states.setIwo(attributes[81]);
					resaleprivatelinesecondarylocation12states.setIwjq1_attr(attributes[82]);
					resaleprivatelinesecondarylocation12states.setIwjq1(attributes[83]);
					resaleprivatelinesecondarylocation12states.setIwjq2_attr(attributes[84]);
					resaleprivatelinesecondarylocation12states.setIwjq2(attributes[85]);
					resaleprivatelinesecondarylocation12states.setIwjq3_attr(attributes[86]);
					resaleprivatelinesecondarylocation12states.setIwjq3(attributes[87]);
					resaleprivatelinesecondarylocation12states.setIwjq4_attr(attributes[88]);
					resaleprivatelinesecondarylocation12states.setIwjq4(attributes[89]);
					resaleprivatelinesecondarylocation12states.setIwjq5_attr(attributes[90]);
					resaleprivatelinesecondarylocation12states.setIwjq5(attributes[91]);
					resaleprivatelinesecondarylocation12states.setIwjk1_attr(attributes[92]);
					resaleprivatelinesecondarylocation12states.setIwjk1(attributes[93]);
					resaleprivatelinesecondarylocation12states.setIwjk2_attr(attributes[94]);
					resaleprivatelinesecondarylocation12states.setIwjk2(attributes[95]);
					resaleprivatelinesecondarylocation12states.setIwjk3_attr(attributes[96]);
					resaleprivatelinesecondarylocation12states.setIwjk3(attributes[97]);
					resaleprivatelinesecondarylocation12states.setIwjk4_attr(attributes[98]);
					resaleprivatelinesecondarylocation12states.setIwjk4(attributes[99]);
					resaleprivatelinesecondarylocation12states.setIwjk5_attr(attributes[100]);
					resaleprivatelinesecondarylocation12states.setIwjk5(attributes[101]);
					resaleprivatelinesecondarylocation12states.setCklt_attr(attributes[102]);
					resaleprivatelinesecondarylocation12states.setCklt(attributes[103]);
					resaleprivatelinesecondarylocation12states.setEcckt_attr(attributes[104]);
					resaleprivatelinesecondarylocation12states.setEcckt(attributes[105]);
					resaleprivatelinesecondarylocation12states.setRlso_attr(attributes[106]);
					resaleprivatelinesecondarylocation12states.setRlso(attributes[107]);
					resaleprivatelinesecondarylocation12states.setScfa_attr(attributes[108]);
					resaleprivatelinesecondarylocation12states.setScfa(attributes[109]);
					resaleprivatelinesecondarylocation12states.setNsl_attr(attributes[110]);
					resaleprivatelinesecondarylocation12states.setNsl(attributes[111]);
					resaleprivatelinesecondarylocation12states.setLconno_attr(attributes[112]);
					resaleprivatelinesecondarylocation12states.setLconno(attributes[113]);
					resaleprivatelinesecondarylocation12states.setItc_attr(attributes[114]);
					resaleprivatelinesecondarylocation12states.setItc(attributes[115]);
					resaleprivatelinesecondarylocation12states.setItcnm_attr(attributes[116]);
					resaleprivatelinesecondarylocation12states.setItcnm(attributes[117]);
					resaleprivatelinesecondarylocation12states.setItctn_attr(attributes[118]);
					resaleprivatelinesecondarylocation12states.setItctn(attributes[119]);
					resaleprivatelinesecondarylocation12states.setItccc_attr(attributes[120]);
					resaleprivatelinesecondarylocation12states.setItccc(attributes[121]);
					resaleprivatelinesecondarylocation12states.setAactel_attr(attributes[122]);
					resaleprivatelinesecondarylocation12states.setAactel(attributes[123]);
					resaleprivatelinesecondarylocation12states.setIwt_attr(attributes[124]);
					resaleprivatelinesecondarylocation12states.setIwt(attributes[125]);
					resaleprivatelinesecondarylocation12states.setIwcon_attr(attributes[126]);
					resaleprivatelinesecondarylocation12states.setIwcon(attributes[127]);
					resaleprivatelinesecondarylocation12states.setIwtq_attr(attributes[128]);
					resaleprivatelinesecondarylocation12states.setIwtq(attributes[129]);
					resaleprivatelinesecondarylocation12states.setLoc_seq_num(attributes[130]);

					treeViewList_511.add(resaleprivatelinesecondarylocation12states);
				}
				session.setAttribute("treeViewList_511", treeViewList_511);
				selectRequestData.setSubHeader(receivedSubHeader);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}
			if (subData_109Recid != null && subData_109Recid.getSubHeader().getRecord_type().equals("109")) {

				SubHeader receivedSubHeader = subData_109Recid.getSubHeader();
				String[] subDataRows = subData_109Recid.getSubDataRows();
				List<Resaleprivatelineprimarylocation_grid9states> treeViewList_109 = new ArrayList();
				treeViewList.add("109");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 13);
					// System.out.println("attributes:==109=====> " + Arrays.toString(attributes));
					Resaleprivatelineprimarylocation_grid9states resaleprivatelineprimarylocation_grid12states = new Resaleprivatelineprimarylocation_grid9states();
					resaleprivatelineprimarylocation_grid12states.setRequest_prod_id(attributes[0]);
					resaleprivatelineprimarylocation_grid12states.setItem_num(attributes[1]);
					resaleprivatelineprimarylocation_grid12states.setLeg_itemnum(attributes[2]);
					resaleprivatelineprimarylocation_grid12states.setFa_attr(attributes[3]);
					resaleprivatelineprimarylocation_grid12states.setFa(attributes[4]);
					resaleprivatelineprimarylocation_grid12states.setFeature_attr(attributes[5]);
					resaleprivatelineprimarylocation_grid12states.setFeature(attributes[6]);
					resaleprivatelineprimarylocation_grid12states.setFeature_detail_attr(attributes[7]);
					resaleprivatelineprimarylocation_grid12states.setFeature_detail(attributes[8]);
					resaleprivatelineprimarylocation_grid12states.setLine_asgn_attr(attributes[9]);
					resaleprivatelineprimarylocation_grid12states.setLine_asgn(attributes[10]);
					resaleprivatelineprimarylocation_grid12states.setLocnum(attributes[11]);
					resaleprivatelineprimarylocation_grid12states.setLoc_seq_num(attributes[12]);

					// resaleprivatelineprimarylocation_grid12states.setEcckt_attr(attributes[9]);

					treeViewList_109.add(resaleprivatelineprimarylocation_grid12states);
				}
				session.setAttribute("treeViewList_109", treeViewList_109);
				selectRequestData.setSubHeader(receivedSubHeader);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}
			// bharti shalu start

			if (subData_150Recid != null && subData_150Recid.getSubHeader().getRecord_type().equals("150")) {

				SubHeader receivedSubHeader = subData_150Recid.getSubHeader();
				String[] subDataRows = subData_150Recid.getSubDataRows();
				treeViewList.add("150");

				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 222);
					// System.out.println("attributes:=150:Reqid======> " +
					// Arrays.toString(attributes));
					Resale_9state_Data resale_9state_Data = new Resale_9state_Data();

					resale_9state_Data.setItem_num(attributes[0]);
					resale_9state_Data.setLnum_attr(attributes[1]);
					resale_9state_Data.setLnum(attributes[2]);
					resale_9state_Data.setLna_attr(attributes[3]);
					resale_9state_Data.setLna(attributes[4]);
					resale_9state_Data.setLmt_attr(attributes[5]);
					resale_9state_Data.setLmt(attributes[6]);
					resale_9state_Data.setEcckt_attr(attributes[7]);
					resale_9state_Data.setEcckt(attributes[8]);
					resale_9state_Data.setShared_nbr_attr(attributes[9]);
					resale_9state_Data.setShared_nbr(attributes[10]);
					resale_9state_Data.setDisc_nbr_attr(attributes[11]);
					resale_9state_Data.setDisc_nbr(attributes[12]);
					resale_9state_Data.setTers_attr(attributes[13]);
					resale_9state_Data.setTers(attributes[14]);
					resale_9state_Data.setCfa_attr(attributes[15]);
					resale_9state_Data.setCfa(attributes[16]);
					resale_9state_Data.setCcea_attr(attributes[17]);
					resale_9state_Data.setCcea(attributes[18]);
					resale_9state_Data.setSscfa_attr(attributes[19]);
					resale_9state_Data.setSscfa(attributes[20]);
					resale_9state_Data.setCableid_attr(attributes[21]);
					resale_9state_Data.setCableid(attributes[22]);
					resale_9state_Data.setChan_pair3_attr(attributes[23]);
					resale_9state_Data.setChan_pair3(attributes[24]);
					resale_9state_Data.setSystemid_attr(attributes[25]);
					resale_9state_Data.setSystemid(attributes[26]);
					resale_9state_Data.setCbcid_attr(attributes[27]);
					resale_9state_Data.setCbcid(attributes[28]);
					resale_9state_Data.setChan_pair_attr(attributes[29]);
					resale_9state_Data.setChan_pair(attributes[30]);
					resale_9state_Data.setCbcid2_attr(attributes[31]);
					resale_9state_Data.setCbcid2(attributes[32]);
					resale_9state_Data.setChan_pair2_attr(attributes[33]);
					resale_9state_Data.setChan_pair2(attributes[34]);
					resale_9state_Data.setCti_attr(attributes[35]);
					resale_9state_Data.setCti(attributes[36]);
					resale_9state_Data.setRelay_rack_attr(attributes[37]);
					resale_9state_Data.setRelay_rack(attributes[38]);
					resale_9state_Data.setShelf_attr(attributes[39]);
					resale_9state_Data.setShelf(attributes[40]);
					resale_9state_Data.setSlot_attr(attributes[41]);
					resale_9state_Data.setSlot(attributes[42]);
					resale_9state_Data.setCti2_attr(attributes[43]);
					resale_9state_Data.setCti2(attributes[44]);
					resale_9state_Data.setRelay_rack2_attr(attributes[45]);
					resale_9state_Data.setRelay_rack2(attributes[46]);
					resale_9state_Data.setShelf2_attr(attributes[47]);
					resale_9state_Data.setShelf2(attributes[48]);
					resale_9state_Data.setSlot2_attr(attributes[49]);
					resale_9state_Data.setSlot2(attributes[50]);
					resale_9state_Data.setCti3_attr(attributes[51]);
					resale_9state_Data.setCti3(attributes[52]);
					resale_9state_Data.setRelay_rack3_attr(attributes[53]);
					resale_9state_Data.setRelay_rack3(attributes[54]);
					resale_9state_Data.setShelf3_attr(attributes[55]);
					resale_9state_Data.setShelf3(attributes[56]);
					resale_9state_Data.setSlot3_attr(attributes[57]);
					resale_9state_Data.setSlot3(attributes[58]);
					resale_9state_Data.setCti4_attr(attributes[59]);
					resale_9state_Data.setCti4(attributes[60]);
					resale_9state_Data.setRelay_rack4_attr(attributes[61]);
					resale_9state_Data.setRelay_rack4(attributes[62]);
					resale_9state_Data.setShelf4_attr(attributes[63]);
					resale_9state_Data.setShelf4(attributes[64]);
					resale_9state_Data.setSlot4_attr(attributes[65]);
					resale_9state_Data.setSlot4(attributes[66]);
					resale_9state_Data.setVpi_attr(attributes[67]);
					resale_9state_Data.setVpi(attributes[68]);
					resale_9state_Data.setVci_attr(attributes[69]);
					resale_9state_Data.setVci(attributes[70]);
					resale_9state_Data.setCode_set_attr(attributes[71]);
					resale_9state_Data.setCode_set(attributes[72]);
					resale_9state_Data.setRecckt_attr(attributes[73]);
					resale_9state_Data.setRecckt(attributes[74]);
					resale_9state_Data.setCkr_attr(attributes[75]);
					resale_9state_Data.setCkr(attributes[76]);
					resale_9state_Data.setTsp_attr(attributes[77]);
					resale_9state_Data.setTsp(attributes[78]);
					resale_9state_Data.setPorted_nbr_attr(attributes[79]);
					resale_9state_Data.setPorted_nbr(attributes[80]);
					resale_9state_Data.setNpt_attr(attributes[81]);
					resale_9state_Data.setNpt(attributes[82]);
					resale_9state_Data.setRti_attr(attributes[83]);
					resale_9state_Data.setRti(attributes[84]);
					resale_9state_Data.setNptg_attr(attributes[85]);
					resale_9state_Data.setNptg(attributes[86]);
					resale_9state_Data.setNpi_attr(attributes[87]);
					resale_9state_Data.setNpi(attributes[88]);
					resale_9state_Data.setLst_attr(attributes[89]);
					resale_9state_Data.setLst(attributes[90]);
					resale_9state_Data.setTns_attr(attributes[91]);
					resale_9state_Data.setTns(attributes[92]);
					resale_9state_Data.setOtn_attr(attributes[93]);
					resale_9state_Data.setOtn(attributes[94]);
					resale_9state_Data.setIspid_attr(attributes[95]);
					resale_9state_Data.setIspid(attributes[96]);
					resale_9state_Data.setPic_attr(attributes[97]);
					resale_9state_Data.setPic(attributes[98]);
					resale_9state_Data.setLpic_attr(attributes[99]);
					resale_9state_Data.setLpic(attributes[100]);
					resale_9state_Data.setSsig_attr(attributes[101]);
					resale_9state_Data.setSsig(attributes[102]);
					resale_9state_Data.setBa_attr(attributes[103]);
					resale_9state_Data.setBa(attributes[104]);
					resale_9state_Data.setBlock_attr(attributes[105]);
					resale_9state_Data.setBlock(attributes[106]);
					resale_9state_Data.setJk_code_attr(attributes[107]);
					resale_9state_Data.setJk_code(attributes[108]);
					resale_9state_Data.setJk_num_attr(attributes[109]);
					resale_9state_Data.setJk_num(attributes[110]);
					resale_9state_Data.setJk_pos_attr(attributes[111]);
					resale_9state_Data.setJk_pos(attributes[112]);
					resale_9state_Data.setJr_attr(attributes[113]);
					resale_9state_Data.setJr(attributes[114]);
					resale_9state_Data.setNidr_attr(attributes[115]);
					resale_9state_Data.setNidr(attributes[116]);
					resale_9state_Data.setIwjk1_attr(attributes[117]);
					resale_9state_Data.setIwjk1(attributes[118]);
					resale_9state_Data.setIwjk2_attr(attributes[119]);
					resale_9state_Data.setIwjk2(attributes[120]);
					resale_9state_Data.setIwjk3_attr(attributes[121]);
					resale_9state_Data.setIwjk3(attributes[122]);
					resale_9state_Data.setIwjk4_attr(attributes[123]);
					resale_9state_Data.setIwjk4(attributes[124]);
					resale_9state_Data.setIwjk5_attr(attributes[125]);
					resale_9state_Data.setIwjk5(attributes[126]);
					resale_9state_Data.setIwjq1_attr(attributes[127]);
					resale_9state_Data.setIwjq1(attributes[128]);
					resale_9state_Data.setIwjq2_attr(attributes[129]);
					resale_9state_Data.setIwjq2(attributes[130]);
					resale_9state_Data.setIwjq3_attr(attributes[131]);
					resale_9state_Data.setIwjq3(attributes[132]);
					resale_9state_Data.setIwjq4_attr(attributes[133]);
					resale_9state_Data.setIwjq4(attributes[134]);
					resale_9state_Data.setIwjq5_attr(attributes[135]);
					resale_9state_Data.setIwjq5(attributes[136]);
					resale_9state_Data.setLidb_attr(attributes[137]);
					resale_9state_Data.setLidb(attributes[138]);
					resale_9state_Data.setS_attr(attributes[139]);
					resale_9state_Data.setS(attributes[140]);
					resale_9state_Data.setOecckt_attr(attributes[141]);
					resale_9state_Data.setOecckt(attributes[142]);
					resale_9state_Data.setPqty_attr(attributes[143]);
					resale_9state_Data.setPqty(attributes[144]);
					resale_9state_Data.setLocnum_attr(attributes[145]);
					resale_9state_Data.setLocnum(attributes[146]);
					resale_9state_Data.setLnex_attr(attributes[147]);
					resale_9state_Data.setLnex(attributes[148]);
					resale_9state_Data.setLneclssvc_attr(attributes[149]);
					resale_9state_Data.setLneclssvc(attributes[150]);
					resale_9state_Data.setFpi_attr(attributes[151]);
					resale_9state_Data.setFpi(attributes[152]);
					resale_9state_Data.setSdi_attr(attributes[153]);
					resale_9state_Data.setSdi(attributes[154]);
					resale_9state_Data.setMatn_attr(attributes[155]);
					resale_9state_Data.setMatn(attributes[156]);
					resale_9state_Data.setSgnl_attr(attributes[157]);
					resale_9state_Data.setSgnl(attributes[158]);
					resale_9state_Data.setPulse_attr(attributes[159]);
					resale_9state_Data.setPulse(attributes[160]);
					resale_9state_Data.setLean_attr(attributes[161]);
					resale_9state_Data.setLean(attributes[162]);
					resale_9state_Data.setLeatn_attr(attributes[163]);
					resale_9state_Data.setLeatn(attributes[164]);
					resale_9state_Data.setIwt_attr(attributes[165]);
					resale_9state_Data.setIwt(attributes[166]);
					resale_9state_Data.setIwtq_attr(attributes[167]);
					resale_9state_Data.setIwtq(attributes[168]);
					resale_9state_Data.setTli_attr(attributes[169]);
					resale_9state_Data.setTli(attributes[170]);
					resale_9state_Data.setLqty_attr(attributes[171]);
					resale_9state_Data.setLqty(attributes[172]);
					resale_9state_Data.setBtrl_attr(attributes[173]);
					resale_9state_Data.setBtrl(attributes[174]);
					resale_9state_Data.setCma_attr(attributes[175]);
					resale_9state_Data.setCma(attributes[176]);
					resale_9state_Data.setSan_attr(attributes[177]);
					resale_9state_Data.setSan(attributes[178]);
					resale_9state_Data.setCableid2_attr(attributes[179]);
					resale_9state_Data.setCableid2(attributes[180]);
					resale_9state_Data.setTnt_attr(attributes[181]);
					resale_9state_Data.setTnt(attributes[182]);
					resale_9state_Data.setNpqty_attr(attributes[183]);
					resale_9state_Data.setNpqty(attributes[184]);
					resale_9state_Data.setTnp_attr(attributes[185]);
					resale_9state_Data.setTnp(attributes[186]);
					resale_9state_Data.setCftn_attr(attributes[187]);
					resale_9state_Data.setCftn(attributes[188]);
					resale_9state_Data.setRsqty_attr(attributes[189]);
					resale_9state_Data.setRsqty(attributes[190]);
					resale_9state_Data.setCnam_attr(attributes[191]);
					resale_9state_Data.setCnam(attributes[192]);
					resale_9state_Data.setIwtq2_attr(attributes[193]);
					resale_9state_Data.setIwtq2(attributes[194]);
					resale_9state_Data.setIwtq3_attr(attributes[195]);
					resale_9state_Data.setIwtq3(attributes[196]);
					resale_9state_Data.setIwtq4_attr(attributes[197]);
					resale_9state_Data.setIwtq4(attributes[198]);
					resale_9state_Data.setIwtq5_attr(attributes[199]);
					resale_9state_Data.setIwtq5(attributes[200]);
					resale_9state_Data.setIwt2_attr(attributes[201]);
					resale_9state_Data.setIwt2(attributes[202]);
					resale_9state_Data.setIwt3_attr(attributes[203]);
					resale_9state_Data.setIwt3(attributes[204]);
					resale_9state_Data.setIwt4_attr(attributes[205]);
					resale_9state_Data.setIwt4(attributes[206]);
					resale_9state_Data.setIwt5_attr(attributes[207]);
					resale_9state_Data.setIwt5(attributes[208]);
					resale_9state_Data.setScfa_attr(attributes[209]);
					resale_9state_Data.setScfa(attributes[210]);
					resale_9state_Data.setBtrl2_attr(attributes[211]);
					resale_9state_Data.setBtrl2(attributes[212]);
					resale_9state_Data.setBtrl3_attr(attributes[213]);
					resale_9state_Data.setBtrl3(attributes[214]);
					resale_9state_Data.setBtrl4_attr(attributes[215]);
					resale_9state_Data.setBtrl4(attributes[216]);
					resale_9state_Data.setBa1_attr(attributes[217]);
					resale_9state_Data.setBa1(attributes[218]);
					resale_9state_Data.setBlocking2_attr(attributes[219]);
					resale_9state_Data.setBlocking2(attributes[220]);
					resale_9state_Data.setLoc_seq_num(attributes[221]);

					treeViewList_150.add(resale_9state_Data);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("++++treeViewList_150+++before session+++" +
				// treeViewList_150);
				session.setAttribute("treeViewList_150", treeViewList_150);
			}

			if (subData_155Recid != null && subData_155Recid.getSubHeader().getRecord_type().equals("155")) {

				SubHeader receivedSubHeader = subData_155Recid.getSubHeader();
				String[] subDataRows = subData_155Recid.getSubDataRows();
				treeViewList.add("155");

				// int i = 0;

				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 11);
					// System.out.println("attributes:=155:Reqid======> " +
					// Arrays.toString(attributes));
					Resale_Grid_9state_Data resale_Grid_9state_Data = new Resale_Grid_9state_Data();

					resale_Grid_9state_Data.setItem_num(attributes[0]);
					resale_Grid_9state_Data.setFa_attr(attributes[1]);
					resale_Grid_9state_Data.setFa(attributes[2]);
					resale_Grid_9state_Data.setFeature_attr(attributes[3]);
					resale_Grid_9state_Data.setFeature(attributes[4]);
					resale_Grid_9state_Data.setFeature_detail_attr(attributes[5]);
					resale_Grid_9state_Data.setFeature_detail(attributes[6]);
					resale_Grid_9state_Data.setLine_asgn_attr(attributes[7]);
					resale_Grid_9state_Data.setLine_asgn(attributes[8]);
					resale_Grid_9state_Data.setLocnum(attributes[9]);
					resale_Grid_9state_Data.setLoc_seq_num(attributes[10]);

					treeViewList_155.add(resale_Grid_9state_Data);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("++++treeViewList_155+++before session+++" +
				// treeViewList_155);
				session.setAttribute("treeViewList_155", treeViewList_155);
			}

			if (subData_107Recid != null && subData_107Recid.getSubHeader().getRecord_type().equals("107")) {

				SubHeader receivedSubHeader = subData_107Recid.getSubHeader();
				String[] subDataRows = subData_107Recid.getSubDataRows();
				treeViewList.add("107");

				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 25);
					// System.out.println("attributes:=107:Reqid======> " +
					// Arrays.toString(attributes));
					ResaleTC_9state_Data resaleTC_9state_Data = new ResaleTC_9state_Data();

					resaleTC_9state_Data.setItem_num(attributes[0]);
					resaleTC_9state_Data.setLnum_attr(attributes[1]);
					resaleTC_9state_Data.setLnum(attributes[2]);
					resaleTC_9state_Data.setDisc_nbr_attr(attributes[3]);
					resaleTC_9state_Data.setDisc_nbr(attributes[4]);
					resaleTC_9state_Data.setTers_attr(attributes[5]);
					resaleTC_9state_Data.setTers(attributes[6]);
					resaleTC_9state_Data.setTc_opt_attr(attributes[7]);
					resaleTC_9state_Data.setTc_opt(attributes[8]);
					resaleTC_9state_Data.setTc_per_attr(attributes[9]);
					resaleTC_9state_Data.setTc_per(attributes[10]);
					resaleTC_9state_Data.setTc_to_pri_attr(attributes[11]);
					resaleTC_9state_Data.setTc_to_pri(attributes[12]);
					resaleTC_9state_Data.setTc_name_pri_attr(attributes[13]);
					resaleTC_9state_Data.setTc_name_pri(attributes[14]);
					resaleTC_9state_Data.setTc_id_attr(attributes[15]);
					resaleTC_9state_Data.setTc_id(attributes[16]);
					resaleTC_9state_Data.setLocnum_attr(attributes[17]);
					resaleTC_9state_Data.setLocnum(attributes[18]);
					resaleTC_9state_Data.setDqty_attr(attributes[19]);
					resaleTC_9state_Data.setDqty(attributes[20]);
					resaleTC_9state_Data.setTcfr_attr(attributes[21]);
					resaleTC_9state_Data.setTcfr(attributes[22]);
					resaleTC_9state_Data.setLoc_seq_num(attributes[23]);

					treeViewList_107.add(resaleTC_9state_Data);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("++++treeViewList_107+++before session+++" +
				// treeViewList_107);
				session.setAttribute("treeViewList_107", treeViewList_107);
			}

			if (subData_108Recid != null && subData_108Recid.getSubHeader().getRecord_type().equals("108")) {

				SubHeader receivedSubHeader = subData_108Recid.getSubHeader();
				String[] subDataRows = subData_108Recid.getSubDataRows();
				treeViewList.add("108");
				// List treeViewList = new ArrayList();
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 9);
					// System.out.println("attributes:=108======> " + Arrays.toString(attributes));
					ResaleTC_Grid_9state_Data resaleTC_Grid_9state_Data = new ResaleTC_Grid_9state_Data();

					resaleTC_Grid_9state_Data.setItem_num(attributes[0]);
					resaleTC_Grid_9state_Data.setTc_id_sec_attr(attributes[1]);
					resaleTC_Grid_9state_Data.setTc_id_sec(attributes[2]);
					resaleTC_Grid_9state_Data.setTc_to_sec_attr(attributes[3]);
					resaleTC_Grid_9state_Data.setTc_to_sec(attributes[4]);
					resaleTC_Grid_9state_Data.setTc_name_sec_attr(attributes[5]);
					resaleTC_Grid_9state_Data.setTc_name_sec(attributes[6]);
					resaleTC_Grid_9state_Data.setLocnum(attributes[7]);
					resaleTC_Grid_9state_Data.setLoc_seq_num(attributes[8]);

					treeViewList_108.add(resaleTC_Grid_9state_Data);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("++++treeViewList_108+++before session+++" +
				// treeViewList_108);
				session.setAttribute("treeViewList_108", treeViewList_108);
			}

			if (subData_350Recid != null && subData_350Recid.getSubHeader().getRecord_type().equals("350")) {

				SubHeader receivedSubHeader = subData_350Recid.getSubHeader();
				String[] subDataRows = subData_350Recid.getSubDataRows();
				treeViewList.add("350");
				// List treeViewList = new ArrayList();
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 222);
					// System.out.println("attributes:=350======> " + Arrays.toString(attributes));
					Port_9state_Data port_9state_Data = new Port_9state_Data();

					port_9state_Data.setItem_num(attributes[0]);
					port_9state_Data.setLnum_attr(attributes[1]);
					port_9state_Data.setLnum(attributes[2]);
					port_9state_Data.setLna_attr(attributes[3]);
					port_9state_Data.setLna(attributes[4]);
					port_9state_Data.setLmt_attr(attributes[5]);
					port_9state_Data.setLmt(attributes[6]);
					port_9state_Data.setEcckt_attr(attributes[7]);
					port_9state_Data.setEcckt(attributes[8]);
					port_9state_Data.setShared_nbr_attr(attributes[9]);
					port_9state_Data.setShared_nbr(attributes[10]);
					port_9state_Data.setDisc_nbr_attr(attributes[11]);
					port_9state_Data.setDisc_nbr(attributes[12]);
					port_9state_Data.setTers_attr(attributes[13]);
					port_9state_Data.setTers(attributes[14]);
					port_9state_Data.setCfa_attr(attributes[15]);
					port_9state_Data.setCfa(attributes[16]);
					port_9state_Data.setCcea_attr(attributes[17]);
					port_9state_Data.setCcea(attributes[18]);
					port_9state_Data.setSscfa_attr(attributes[19]);
					port_9state_Data.setSscfa(attributes[20]);
					port_9state_Data.setCableid_attr(attributes[21]);
					port_9state_Data.setCableid(attributes[22]);
					port_9state_Data.setChan_pair3_attr(attributes[23]);
					port_9state_Data.setChan_pair3(attributes[24]);
					port_9state_Data.setSystemid_attr(attributes[25]);
					port_9state_Data.setSystemid(attributes[26]);
					port_9state_Data.setCbcid_attr(attributes[27]);
					port_9state_Data.setCbcid(attributes[28]);
					port_9state_Data.setChan_pair_attr(attributes[29]);
					port_9state_Data.setChan_pair(attributes[30]);
					port_9state_Data.setCbcid2_attr(attributes[31]);
					port_9state_Data.setCbcid2(attributes[32]);
					port_9state_Data.setChan_pair2_attr(attributes[33]);
					port_9state_Data.setChan_pair2(attributes[34]);
					port_9state_Data.setCti_attr(attributes[35]);
					port_9state_Data.setCti(attributes[36]);
					port_9state_Data.setRelay_rack_attr(attributes[37]);
					port_9state_Data.setRelay_rack(attributes[38]);
					port_9state_Data.setShelf_attr(attributes[39]);
					port_9state_Data.setShelf(attributes[40]);
					port_9state_Data.setSlot_attr(attributes[41]);
					port_9state_Data.setSlot(attributes[42]);
					port_9state_Data.setCti2_attr(attributes[43]);
					port_9state_Data.setCti2(attributes[44]);
					port_9state_Data.setRelay_rack2_attr(attributes[45]);
					port_9state_Data.setRelay_rack2(attributes[46]);
					port_9state_Data.setShelf2_attr(attributes[47]);
					port_9state_Data.setShelf2(attributes[48]);
					port_9state_Data.setSlot2_attr(attributes[49]);
					port_9state_Data.setSlot2(attributes[50]);
					port_9state_Data.setCti3_attr(attributes[51]);
					port_9state_Data.setCti3(attributes[52]);
					port_9state_Data.setRelay_rack3_attr(attributes[53]);
					port_9state_Data.setRelay_rack3(attributes[54]);
					port_9state_Data.setShelf3_attr(attributes[55]);
					port_9state_Data.setShelf3(attributes[56]);
					port_9state_Data.setSlot3_attr(attributes[57]);
					port_9state_Data.setSlot3(attributes[58]);
					port_9state_Data.setCti4_attr(attributes[59]);
					port_9state_Data.setCti4(attributes[60]);
					port_9state_Data.setRelay_rack4_attr(attributes[61]);
					port_9state_Data.setRelay_rack4(attributes[62]);
					port_9state_Data.setShelf4_attr(attributes[63]);
					port_9state_Data.setShelf4(attributes[64]);
					port_9state_Data.setSlot4_attr(attributes[65]);
					port_9state_Data.setSlot4(attributes[66]);
					port_9state_Data.setVpi_attr(attributes[67]);
					port_9state_Data.setVpi(attributes[68]);
					port_9state_Data.setVci_attr(attributes[69]);
					port_9state_Data.setVci(attributes[70]);
					port_9state_Data.setCode_set_attr(attributes[71]);
					port_9state_Data.setCode_set(attributes[72]);
					port_9state_Data.setRecckt_attr(attributes[73]);
					port_9state_Data.setRecckt(attributes[74]);
					port_9state_Data.setCkr_attr(attributes[75]);
					port_9state_Data.setCkr(attributes[76]);
					port_9state_Data.setTsp_attr(attributes[77]);
					port_9state_Data.setTsp(attributes[78]);
					port_9state_Data.setPorted_nbr_attr(attributes[79]);
					port_9state_Data.setPorted_nbr(attributes[80]);
					port_9state_Data.setNpt_attr(attributes[81]);
					port_9state_Data.setNpt(attributes[82]);
					port_9state_Data.setRti_attr(attributes[83]);
					port_9state_Data.setRti(attributes[84]);
					port_9state_Data.setNptg_attr(attributes[85]);
					port_9state_Data.setNptg(attributes[86]);
					port_9state_Data.setNpi_attr(attributes[87]);
					port_9state_Data.setNpi(attributes[88]);
					port_9state_Data.setLst_attr(attributes[89]);
					port_9state_Data.setLst(attributes[90]);
					port_9state_Data.setTns_attr(attributes[91]);
					port_9state_Data.setTns(attributes[92]);
					port_9state_Data.setOtn_attr(attributes[93]);
					port_9state_Data.setOtn(attributes[94]);
					port_9state_Data.setIspid_attr(attributes[95]);
					port_9state_Data.setIspid(attributes[96]);
					port_9state_Data.setPic_attr(attributes[97]);
					port_9state_Data.setPic(attributes[98]);
					port_9state_Data.setLpic_attr(attributes[99]);
					port_9state_Data.setLpic(attributes[100]);
					port_9state_Data.setSsig_attr(attributes[101]);
					port_9state_Data.setSsig(attributes[102]);
					port_9state_Data.setBa_attr(attributes[103]);
					port_9state_Data.setBa(attributes[104]);
					port_9state_Data.setBlock_attr(attributes[105]);
					port_9state_Data.setBlock(attributes[106]);
					port_9state_Data.setJk_code_attr(attributes[107]);
					port_9state_Data.setJk_code(attributes[108]);
					port_9state_Data.setJk_num_attr(attributes[109]);
					port_9state_Data.setJk_num(attributes[110]);
					port_9state_Data.setJk_pos_attr(attributes[111]);
					port_9state_Data.setJk_pos(attributes[112]);
					port_9state_Data.setJr_attr(attributes[113]);
					port_9state_Data.setJr(attributes[114]);
					port_9state_Data.setNidr_attr(attributes[115]);
					port_9state_Data.setNidr(attributes[116]);
					port_9state_Data.setIwjk1_attr(attributes[117]);
					port_9state_Data.setIwjk1(attributes[118]);
					port_9state_Data.setIwjk2_attr(attributes[119]);
					port_9state_Data.setIwjk2(attributes[120]);
					port_9state_Data.setIwjk3_attr(attributes[121]);
					port_9state_Data.setIwjk3(attributes[122]);
					port_9state_Data.setIwjk4_attr(attributes[123]);
					port_9state_Data.setIwjk4(attributes[124]);
					port_9state_Data.setIwjk5_attr(attributes[125]);
					port_9state_Data.setIwjk5(attributes[126]);
					port_9state_Data.setIwjq1_attr(attributes[127]);
					port_9state_Data.setIwjq1(attributes[128]);
					port_9state_Data.setIwjq2_attr(attributes[129]);
					port_9state_Data.setIwjq2(attributes[130]);
					port_9state_Data.setIwjq3_attr(attributes[131]);
					port_9state_Data.setIwjq3(attributes[132]);
					port_9state_Data.setIwjq4_attr(attributes[133]);
					port_9state_Data.setIwjq4(attributes[134]);
					port_9state_Data.setIwjq5_attr(attributes[135]);
					port_9state_Data.setIwjq5(attributes[136]);
					port_9state_Data.setLidb_attr(attributes[137]);
					port_9state_Data.setLidb(attributes[138]);
					port_9state_Data.setS_attr(attributes[139]);
					port_9state_Data.setS(attributes[140]);
					port_9state_Data.setOecckt_attr(attributes[141]);
					port_9state_Data.setOecckt(attributes[142]);
					port_9state_Data.setPqty_attr(attributes[143]);
					port_9state_Data.setPqty(attributes[144]);
					port_9state_Data.setLocnum_attr(attributes[145]);
					port_9state_Data.setLocnum(attributes[146]);
					port_9state_Data.setLnex_attr(attributes[147]);
					port_9state_Data.setLnex(attributes[148]);
					port_9state_Data.setLneclssvc_attr(attributes[149]);
					port_9state_Data.setLneclssvc(attributes[150]);
					port_9state_Data.setFpi_attr(attributes[151]);
					port_9state_Data.setFpi(attributes[152]);
					port_9state_Data.setSdi_attr(attributes[153]);
					port_9state_Data.setSdi(attributes[154]);
					port_9state_Data.setMatn_attr(attributes[155]);
					port_9state_Data.setMatn(attributes[156]);
					port_9state_Data.setSgnl_attr(attributes[157]);
					port_9state_Data.setSgnl(attributes[158]);
					port_9state_Data.setPulse_attr(attributes[159]);
					port_9state_Data.setPulse(attributes[160]);
					port_9state_Data.setLean_attr(attributes[161]);
					port_9state_Data.setLean(attributes[162]);
					port_9state_Data.setLeatn_attr(attributes[163]);
					port_9state_Data.setLeatn(attributes[164]);
					port_9state_Data.setIwt_attr(attributes[165]);
					port_9state_Data.setIwt(attributes[166]);
					port_9state_Data.setIwtq_attr(attributes[167]);
					port_9state_Data.setIwtq(attributes[168]);
					port_9state_Data.setTli_attr(attributes[169]);
					port_9state_Data.setTli(attributes[170]);
					port_9state_Data.setLqty_attr(attributes[171]);
					port_9state_Data.setLqty(attributes[172]);
					port_9state_Data.setBtrl_attr(attributes[173]);
					port_9state_Data.setBtrl(attributes[174]);
					port_9state_Data.setCma_attr(attributes[175]);
					port_9state_Data.setCma(attributes[176]);
					port_9state_Data.setSan_attr(attributes[177]);
					port_9state_Data.setSan(attributes[178]);
					port_9state_Data.setCableid2_attr(attributes[179]);
					port_9state_Data.setCableid2(attributes[180]);
					port_9state_Data.setTnt_attr(attributes[181]);
					port_9state_Data.setTnt(attributes[182]);
					port_9state_Data.setNpqty_attr(attributes[183]);
					port_9state_Data.setNpqty(attributes[184]);
					port_9state_Data.setTnp_attr(attributes[185]);
					port_9state_Data.setTnp(attributes[186]);
					port_9state_Data.setCftn_attr(attributes[187]);
					port_9state_Data.setCftn(attributes[188]);
					port_9state_Data.setRsqty_attr(attributes[189]);
					port_9state_Data.setRsqty(attributes[190]);
					port_9state_Data.setCnam_attr(attributes[191]);
					port_9state_Data.setCnam(attributes[192]);
					port_9state_Data.setIwtq2_attr(attributes[193]);
					port_9state_Data.setIwtq2(attributes[194]);
					port_9state_Data.setIwtq3_attr(attributes[195]);
					port_9state_Data.setIwtq3(attributes[196]);
					port_9state_Data.setIwtq4_attr(attributes[197]);
					port_9state_Data.setIwtq4(attributes[198]);
					port_9state_Data.setIwtq5_attr(attributes[199]);
					port_9state_Data.setIwtq5(attributes[200]);
					port_9state_Data.setIwt2_attr(attributes[201]);
					port_9state_Data.setIwt2(attributes[202]);
					port_9state_Data.setIwt3_attr(attributes[203]);
					port_9state_Data.setIwt3(attributes[204]);
					port_9state_Data.setIwt4_attr(attributes[205]);
					port_9state_Data.setIwt4(attributes[206]);
					port_9state_Data.setIwt5_attr(attributes[207]);
					port_9state_Data.setIwt5(attributes[208]);
					port_9state_Data.setScfa_attr(attributes[209]);
					port_9state_Data.setScfa(attributes[210]);
					port_9state_Data.setBtrl2_attr(attributes[211]);
					port_9state_Data.setBtrl2(attributes[212]);
					port_9state_Data.setBtrl3_attr(attributes[213]);
					port_9state_Data.setBtrl3(attributes[214]);
					port_9state_Data.setBtrl4_attr(attributes[215]);
					port_9state_Data.setBtrl4(attributes[216]);
					port_9state_Data.setBa1_attr(attributes[217]);
					port_9state_Data.setBa1(attributes[218]);
					port_9state_Data.setBlocking2_attr(attributes[219]);
					port_9state_Data.setBlocking2(attributes[220]);
					port_9state_Data.setLoc_seq_num(attributes[221]);

					treeViewList_350.add(port_9state_Data);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("++++treeViewList_350+++before session+++" +
				// treeViewList_350);
				session.setAttribute("treeViewList_350", treeViewList_350);
			}

			if (subData_275Recid != null && subData_275Recid.getSubHeader().getRecord_type().equals("275")) {

				SubHeader receivedSubHeader = subData_275Recid.getSubHeader();
				String[] subDataRows = subData_275Recid.getSubDataRows();
				treeViewList.add("275");
				// List treeViewList = new ArrayList();
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 222);
					// System.out.println("attributes:=275======> " + Arrays.toString(attributes));
					Loop_w_9state_Data loop_w_9state_Data = new Loop_w_9state_Data();

					loop_w_9state_Data.setItem_num(attributes[0]);
					loop_w_9state_Data.setLnum_attr(attributes[1]);
					loop_w_9state_Data.setLnum(attributes[2]);
					loop_w_9state_Data.setLna_attr(attributes[3]);
					loop_w_9state_Data.setLna(attributes[4]);
					loop_w_9state_Data.setLmt_attr(attributes[5]);
					loop_w_9state_Data.setLmt(attributes[6]);
					loop_w_9state_Data.setEcckt_attr(attributes[7]);
					loop_w_9state_Data.setEcckt(attributes[8]);
					loop_w_9state_Data.setShared_nbr_attr(attributes[9]);
					loop_w_9state_Data.setShared_nbr(attributes[10]);
					loop_w_9state_Data.setDisc_nbr_attr(attributes[11]);
					loop_w_9state_Data.setDisc_nbr(attributes[12]);
					loop_w_9state_Data.setTers_attr(attributes[13]);
					loop_w_9state_Data.setTers(attributes[14]);
					loop_w_9state_Data.setCfa_attr(attributes[15]);
					loop_w_9state_Data.setCfa(attributes[16]);
					loop_w_9state_Data.setCcea_attr(attributes[17]);
					loop_w_9state_Data.setCcea(attributes[18]);
					loop_w_9state_Data.setSscfa_attr(attributes[19]);
					loop_w_9state_Data.setSscfa(attributes[20]);
					loop_w_9state_Data.setCableid_attr(attributes[21]);
					loop_w_9state_Data.setCableid(attributes[22]);
					loop_w_9state_Data.setChan_pair3_attr(attributes[23]);
					loop_w_9state_Data.setChan_pair3(attributes[24]);
					loop_w_9state_Data.setSystemid_attr(attributes[25]);
					loop_w_9state_Data.setSystemid(attributes[26]);
					loop_w_9state_Data.setCbcid_attr(attributes[27]);
					loop_w_9state_Data.setCbcid(attributes[28]);
					loop_w_9state_Data.setChan_pair_attr(attributes[29]);
					loop_w_9state_Data.setChan_pair(attributes[30]);
					loop_w_9state_Data.setCbcid2_attr(attributes[31]);
					loop_w_9state_Data.setCbcid2(attributes[32]);
					loop_w_9state_Data.setChan_pair2_attr(attributes[33]);
					loop_w_9state_Data.setChan_pair2(attributes[34]);
					loop_w_9state_Data.setCti_attr(attributes[35]);
					loop_w_9state_Data.setCti(attributes[36]);
					loop_w_9state_Data.setRelay_rack_attr(attributes[37]);
					loop_w_9state_Data.setRelay_rack(attributes[38]);
					loop_w_9state_Data.setShelf_attr(attributes[39]);
					loop_w_9state_Data.setShelf(attributes[40]);
					loop_w_9state_Data.setSlot_attr(attributes[41]);
					loop_w_9state_Data.setSlot(attributes[42]);
					loop_w_9state_Data.setCti2_attr(attributes[43]);
					loop_w_9state_Data.setCti2(attributes[44]);
					loop_w_9state_Data.setRelay_rack2_attr(attributes[45]);
					loop_w_9state_Data.setRelay_rack2(attributes[46]);
					loop_w_9state_Data.setShelf2_attr(attributes[47]);
					loop_w_9state_Data.setShelf2(attributes[48]);
					loop_w_9state_Data.setSlot2_attr(attributes[49]);
					loop_w_9state_Data.setSlot2(attributes[50]);
					loop_w_9state_Data.setCti3_attr(attributes[51]);
					loop_w_9state_Data.setCti3(attributes[52]);
					loop_w_9state_Data.setRelay_rack3_attr(attributes[53]);
					loop_w_9state_Data.setRelay_rack3(attributes[54]);
					loop_w_9state_Data.setShelf3_attr(attributes[55]);
					loop_w_9state_Data.setShelf3(attributes[56]);
					loop_w_9state_Data.setSlot3_attr(attributes[57]);
					loop_w_9state_Data.setSlot3(attributes[58]);
					loop_w_9state_Data.setCti4_attr(attributes[59]);
					loop_w_9state_Data.setCti4(attributes[60]);
					loop_w_9state_Data.setRelay_rack4_attr(attributes[61]);
					loop_w_9state_Data.setRelay_rack4(attributes[62]);
					loop_w_9state_Data.setShelf4_attr(attributes[63]);
					loop_w_9state_Data.setShelf4(attributes[64]);
					loop_w_9state_Data.setSlot4_attr(attributes[65]);
					loop_w_9state_Data.setSlot4(attributes[66]);
					loop_w_9state_Data.setVpi_attr(attributes[67]);
					loop_w_9state_Data.setVpi(attributes[68]);
					loop_w_9state_Data.setVci_attr(attributes[69]);
					loop_w_9state_Data.setVci(attributes[70]);
					loop_w_9state_Data.setCode_set_attr(attributes[71]);
					loop_w_9state_Data.setCode_set(attributes[72]);
					loop_w_9state_Data.setRecckt_attr(attributes[73]);
					loop_w_9state_Data.setRecckt(attributes[74]);
					loop_w_9state_Data.setCkr_attr(attributes[75]);
					loop_w_9state_Data.setCkr(attributes[76]);
					loop_w_9state_Data.setTsp_attr(attributes[77]);
					loop_w_9state_Data.setTsp(attributes[78]);
					loop_w_9state_Data.setPorted_nbr_attr(attributes[79]);
					loop_w_9state_Data.setPorted_nbr(attributes[80]);
					loop_w_9state_Data.setNpt_attr(attributes[81]);
					loop_w_9state_Data.setNpt(attributes[82]);
					loop_w_9state_Data.setRti_attr(attributes[83]);
					loop_w_9state_Data.setRti(attributes[84]);
					loop_w_9state_Data.setNptg_attr(attributes[85]);
					loop_w_9state_Data.setNptg(attributes[86]);
					loop_w_9state_Data.setNpi_attr(attributes[87]);
					loop_w_9state_Data.setNpi(attributes[88]);
					loop_w_9state_Data.setLst_attr(attributes[89]);
					loop_w_9state_Data.setLst(attributes[90]);
					loop_w_9state_Data.setTns_attr(attributes[91]);
					loop_w_9state_Data.setTns(attributes[92]);
					loop_w_9state_Data.setOtn_attr(attributes[93]);
					loop_w_9state_Data.setOtn(attributes[94]);
					loop_w_9state_Data.setIspid_attr(attributes[95]);
					loop_w_9state_Data.setIspid(attributes[96]);
					loop_w_9state_Data.setPic_attr(attributes[97]);
					loop_w_9state_Data.setPic(attributes[98]);
					loop_w_9state_Data.setLpic_attr(attributes[99]);
					loop_w_9state_Data.setLpic(attributes[100]);
					loop_w_9state_Data.setSsig_attr(attributes[101]);
					loop_w_9state_Data.setSsig(attributes[102]);
					loop_w_9state_Data.setBa_attr(attributes[103]);
					loop_w_9state_Data.setBa(attributes[104]);
					loop_w_9state_Data.setBlock_attr(attributes[105]);
					loop_w_9state_Data.setBlock(attributes[106]);
					loop_w_9state_Data.setJk_code_attr(attributes[107]);
					loop_w_9state_Data.setJk_code(attributes[108]);
					loop_w_9state_Data.setJk_num_attr(attributes[109]);
					loop_w_9state_Data.setJk_num(attributes[110]);
					loop_w_9state_Data.setJk_pos_attr(attributes[111]);
					loop_w_9state_Data.setJk_pos(attributes[112]);
					loop_w_9state_Data.setJr_attr(attributes[113]);
					loop_w_9state_Data.setJr(attributes[114]);
					loop_w_9state_Data.setNidr_attr(attributes[115]);
					loop_w_9state_Data.setNidr(attributes[116]);
					loop_w_9state_Data.setIwjk1_attr(attributes[117]);
					loop_w_9state_Data.setIwjk1(attributes[118]);
					loop_w_9state_Data.setIwjk2_attr(attributes[119]);
					loop_w_9state_Data.setIwjk2(attributes[120]);
					loop_w_9state_Data.setIwjk3_attr(attributes[121]);
					loop_w_9state_Data.setIwjk3(attributes[122]);
					loop_w_9state_Data.setIwjk4_attr(attributes[123]);
					loop_w_9state_Data.setIwjk4(attributes[124]);
					loop_w_9state_Data.setIwjk5_attr(attributes[125]);
					loop_w_9state_Data.setIwjk5(attributes[126]);
					loop_w_9state_Data.setIwjq1_attr(attributes[127]);
					loop_w_9state_Data.setIwjq1(attributes[128]);
					loop_w_9state_Data.setIwjq2_attr(attributes[129]);
					loop_w_9state_Data.setIwjq2(attributes[130]);
					loop_w_9state_Data.setIwjq3_attr(attributes[131]);
					loop_w_9state_Data.setIwjq3(attributes[132]);
					loop_w_9state_Data.setIwjq4_attr(attributes[133]);
					loop_w_9state_Data.setIwjq4(attributes[134]);
					loop_w_9state_Data.setIwjq5_attr(attributes[135]);
					loop_w_9state_Data.setIwjq5(attributes[136]);
					loop_w_9state_Data.setLidb_attr(attributes[137]);
					loop_w_9state_Data.setLidb(attributes[138]);
					loop_w_9state_Data.setS_attr(attributes[139]);
					loop_w_9state_Data.setS(attributes[140]);
					loop_w_9state_Data.setOecckt_attr(attributes[141]);
					loop_w_9state_Data.setOecckt(attributes[142]);
					loop_w_9state_Data.setPqty_attr(attributes[143]);
					loop_w_9state_Data.setPqty(attributes[144]);
					loop_w_9state_Data.setLocnum_attr(attributes[145]);
					loop_w_9state_Data.setLocnum(attributes[146]);
					loop_w_9state_Data.setLnex_attr(attributes[147]);
					loop_w_9state_Data.setLnex(attributes[148]);
					loop_w_9state_Data.setLneclssvc_attr(attributes[149]);
					loop_w_9state_Data.setLneclssvc(attributes[150]);
					loop_w_9state_Data.setFpi_attr(attributes[151]);
					loop_w_9state_Data.setFpi(attributes[152]);
					loop_w_9state_Data.setSdi_attr(attributes[153]);
					loop_w_9state_Data.setSdi(attributes[154]);
					loop_w_9state_Data.setMatn_attr(attributes[155]);
					loop_w_9state_Data.setMatn(attributes[156]);
					loop_w_9state_Data.setSgnl_attr(attributes[157]);
					loop_w_9state_Data.setSgnl(attributes[158]);
					loop_w_9state_Data.setPulse_attr(attributes[159]);
					loop_w_9state_Data.setPulse(attributes[160]);
					loop_w_9state_Data.setLean_attr(attributes[161]);
					loop_w_9state_Data.setLean(attributes[162]);
					loop_w_9state_Data.setLeatn_attr(attributes[163]);
					loop_w_9state_Data.setLeatn(attributes[164]);
					loop_w_9state_Data.setIwt_attr(attributes[165]);
					loop_w_9state_Data.setIwt(attributes[166]);
					loop_w_9state_Data.setIwtq_attr(attributes[167]);
					loop_w_9state_Data.setIwtq(attributes[168]);
					loop_w_9state_Data.setTli_attr(attributes[169]);
					loop_w_9state_Data.setTli(attributes[170]);
					loop_w_9state_Data.setLqty_attr(attributes[171]);
					loop_w_9state_Data.setLqty(attributes[172]);
					loop_w_9state_Data.setBtrl_attr(attributes[173]);
					loop_w_9state_Data.setBtrl(attributes[174]);
					loop_w_9state_Data.setCma_attr(attributes[175]);
					loop_w_9state_Data.setCma(attributes[176]);
					loop_w_9state_Data.setSan_attr(attributes[177]);
					loop_w_9state_Data.setSan(attributes[178]);
					loop_w_9state_Data.setCableid2_attr(attributes[179]);
					loop_w_9state_Data.setCableid2(attributes[180]);
					loop_w_9state_Data.setTnt_attr(attributes[181]);
					loop_w_9state_Data.setTnt(attributes[182]);
					loop_w_9state_Data.setNpqty_attr(attributes[183]);
					loop_w_9state_Data.setNpqty(attributes[184]);
					loop_w_9state_Data.setTnp_attr(attributes[185]);
					loop_w_9state_Data.setTnp(attributes[186]);
					loop_w_9state_Data.setCftn_attr(attributes[187]);
					loop_w_9state_Data.setCftn(attributes[188]);
					loop_w_9state_Data.setRsqty_attr(attributes[189]);
					loop_w_9state_Data.setRsqty(attributes[190]);
					loop_w_9state_Data.setCnam_attr(attributes[191]);
					loop_w_9state_Data.setCnam(attributes[192]);
					loop_w_9state_Data.setIwtq2_attr(attributes[193]);
					loop_w_9state_Data.setIwtq2(attributes[194]);
					loop_w_9state_Data.setIwtq3_attr(attributes[195]);
					loop_w_9state_Data.setIwtq3(attributes[196]);
					loop_w_9state_Data.setIwtq4_attr(attributes[197]);
					loop_w_9state_Data.setIwtq4(attributes[198]);
					loop_w_9state_Data.setIwtq5_attr(attributes[199]);
					loop_w_9state_Data.setIwtq5(attributes[200]);
					loop_w_9state_Data.setIwt2_attr(attributes[201]);
					loop_w_9state_Data.setIwt2(attributes[202]);
					loop_w_9state_Data.setIwt3_attr(attributes[203]);
					loop_w_9state_Data.setIwt3(attributes[204]);
					loop_w_9state_Data.setIwt4_attr(attributes[205]);
					loop_w_9state_Data.setIwt4(attributes[206]);
					loop_w_9state_Data.setIwt5_attr(attributes[207]);
					loop_w_9state_Data.setIwt5(attributes[208]);
					loop_w_9state_Data.setScfa_attr(attributes[209]);
					loop_w_9state_Data.setScfa(attributes[210]);
					loop_w_9state_Data.setBtrl2_attr(attributes[211]);
					loop_w_9state_Data.setBtrl2(attributes[212]);
					loop_w_9state_Data.setBtrl3_attr(attributes[213]);
					loop_w_9state_Data.setBtrl3(attributes[214]);
					loop_w_9state_Data.setBtrl4_attr(attributes[215]);
					loop_w_9state_Data.setBtrl4(attributes[216]);
					loop_w_9state_Data.setBa1_attr(attributes[217]);
					loop_w_9state_Data.setBa1(attributes[218]);
					loop_w_9state_Data.setBlocking2_attr(attributes[219]);
					loop_w_9state_Data.setBlocking2(attributes[220]);
					loop_w_9state_Data.setLoc_seq_num(attributes[221]);

					treeViewList_275.add(loop_w_9state_Data);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("++++treeViewList_275+++before session+++" +
				// treeViewList_275);
				session.setAttribute("treeViewList_275", treeViewList_275);
			}

			// bharati code:-
			if (subData_200Recid != null && subData_200Recid.getSubHeader().getRecord_type().equals("200")) {

				SubHeader receivedSubHeader = subData_200Recid.getSubHeader();
				String[] subDataRows = subData_200Recid.getSubDataRows();
				treeViewList.add("200");

				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 222);
					// System.out.println("attributes:=200:Reqid======> " +
					// Arrays.toString(attributes));
					D_Record_Product_loopV6_9States d_Record_Product_loopV6_9States = new D_Record_Product_loopV6_9States();

					d_Record_Product_loopV6_9States.setItem_num(attributes[0]);
					d_Record_Product_loopV6_9States.setLnum_attr(attributes[1]);
					d_Record_Product_loopV6_9States.setLnum(attributes[2]);
					d_Record_Product_loopV6_9States.setLna_attr(attributes[3]);
					d_Record_Product_loopV6_9States.setLna(attributes[4]);
					d_Record_Product_loopV6_9States.setLmt_attr(attributes[5]);
					d_Record_Product_loopV6_9States.setLmt(attributes[6]);
					d_Record_Product_loopV6_9States.setEcckt_attr(attributes[7]);
					d_Record_Product_loopV6_9States.setEcckt(attributes[8]);
					d_Record_Product_loopV6_9States.setShared_nbr_attr(attributes[9]);
					d_Record_Product_loopV6_9States.setShared_nbr(attributes[10]);
					d_Record_Product_loopV6_9States.setDisc_nbr_attr(attributes[11]);
					d_Record_Product_loopV6_9States.setDisc_nbr(attributes[12]);
					d_Record_Product_loopV6_9States.setTers_attr(attributes[13]);
					d_Record_Product_loopV6_9States.setTers(attributes[14]);
					d_Record_Product_loopV6_9States.setCfa_attr(attributes[15]);
					d_Record_Product_loopV6_9States.setCfa(attributes[16]);
					d_Record_Product_loopV6_9States.setCcea_attr(attributes[17]);
					d_Record_Product_loopV6_9States.setCcea(attributes[18]);
					d_Record_Product_loopV6_9States.setSscfa_attr(attributes[19]);
					d_Record_Product_loopV6_9States.setSscfa(attributes[20]);
					d_Record_Product_loopV6_9States.setCableid_attr(attributes[21]);
					d_Record_Product_loopV6_9States.setCableid(attributes[22]);
					d_Record_Product_loopV6_9States.setChan_pair3_attr(attributes[23]);
					d_Record_Product_loopV6_9States.setChan_pair3(attributes[24]);
					d_Record_Product_loopV6_9States.setSystemid_attr(attributes[25]);
					d_Record_Product_loopV6_9States.setSystemid(attributes[26]);
					d_Record_Product_loopV6_9States.setCbcid_attr(attributes[27]);
					d_Record_Product_loopV6_9States.setCbcid(attributes[28]);
					d_Record_Product_loopV6_9States.setChan_pair_attr(attributes[29]);
					d_Record_Product_loopV6_9States.setChan_pair(attributes[30]);
					d_Record_Product_loopV6_9States.setCbcid2_attr(attributes[31]);
					d_Record_Product_loopV6_9States.setCbcid2(attributes[32]);
					d_Record_Product_loopV6_9States.setChan_pair2_attr(attributes[33]);
					d_Record_Product_loopV6_9States.setChan_pair2(attributes[34]);
					d_Record_Product_loopV6_9States.setCti_attr(attributes[35]);
					d_Record_Product_loopV6_9States.setCti(attributes[36]);
					d_Record_Product_loopV6_9States.setRelay_rack_attr(attributes[37]);
					d_Record_Product_loopV6_9States.setRelay_rack(attributes[38]);
					d_Record_Product_loopV6_9States.setShelf_attr(attributes[39]);
					d_Record_Product_loopV6_9States.setShelf(attributes[40]);
					d_Record_Product_loopV6_9States.setSlot_attr(attributes[41]);
					d_Record_Product_loopV6_9States.setSlot(attributes[42]);
					d_Record_Product_loopV6_9States.setCti2_attr(attributes[43]);
					d_Record_Product_loopV6_9States.setCti2(attributes[44]);
					d_Record_Product_loopV6_9States.setRelay_rack2_attr(attributes[45]);
					d_Record_Product_loopV6_9States.setRelay_rack2(attributes[46]);
					d_Record_Product_loopV6_9States.setShelf2_attr(attributes[47]);
					d_Record_Product_loopV6_9States.setShelf2(attributes[48]);
					d_Record_Product_loopV6_9States.setSlot2_attr(attributes[49]);
					d_Record_Product_loopV6_9States.setSlot2(attributes[50]);
					d_Record_Product_loopV6_9States.setCti3_attr(attributes[51]);
					d_Record_Product_loopV6_9States.setCti3(attributes[52]);
					d_Record_Product_loopV6_9States.setRelay_rack3_attr(attributes[53]);
					d_Record_Product_loopV6_9States.setRelay_rack3(attributes[54]);
					d_Record_Product_loopV6_9States.setShelf3_attr(attributes[55]);
					d_Record_Product_loopV6_9States.setShelf3(attributes[56]);
					d_Record_Product_loopV6_9States.setSlot3_attr(attributes[57]);
					d_Record_Product_loopV6_9States.setSlot3(attributes[58]);
					d_Record_Product_loopV6_9States.setCti4_attr(attributes[59]);
					d_Record_Product_loopV6_9States.setCti4(attributes[60]);
					d_Record_Product_loopV6_9States.setRelay_rack4_attr(attributes[61]);
					d_Record_Product_loopV6_9States.setRelay_rack4(attributes[62]);
					d_Record_Product_loopV6_9States.setShelf4_attr(attributes[63]);
					d_Record_Product_loopV6_9States.setShelf4(attributes[64]);
					d_Record_Product_loopV6_9States.setSlot4_attr(attributes[65]);
					d_Record_Product_loopV6_9States.setSlot4(attributes[66]);
					d_Record_Product_loopV6_9States.setVpi_attr(attributes[67]);
					d_Record_Product_loopV6_9States.setVpi(attributes[68]);
					d_Record_Product_loopV6_9States.setVci_attr(attributes[69]);
					d_Record_Product_loopV6_9States.setVci(attributes[70]);
					d_Record_Product_loopV6_9States.setCode_set_attr(attributes[71]);
					d_Record_Product_loopV6_9States.setCode_set(attributes[72]);
					d_Record_Product_loopV6_9States.setRecckt_attr(attributes[73]);
					d_Record_Product_loopV6_9States.setRecckt(attributes[74]);
					d_Record_Product_loopV6_9States.setCkr_attr(attributes[75]);
					d_Record_Product_loopV6_9States.setCkr(attributes[76]);
					d_Record_Product_loopV6_9States.setTsp_attr(attributes[77]);
					d_Record_Product_loopV6_9States.setTsp(attributes[78]);
					d_Record_Product_loopV6_9States.setPorted_nbr_attr(attributes[79]);
					d_Record_Product_loopV6_9States.setPorted_nbr(attributes[80]);
					d_Record_Product_loopV6_9States.setNpt_attr(attributes[81]);
					d_Record_Product_loopV6_9States.setNpt(attributes[82]);
					d_Record_Product_loopV6_9States.setRti_attr(attributes[83]);
					d_Record_Product_loopV6_9States.setRti(attributes[84]);
					d_Record_Product_loopV6_9States.setNptg_attr(attributes[85]);
					d_Record_Product_loopV6_9States.setNptg(attributes[86]);
					d_Record_Product_loopV6_9States.setNpi_attr(attributes[87]);
					d_Record_Product_loopV6_9States.setNpi(attributes[88]);
					d_Record_Product_loopV6_9States.setLst_attr(attributes[89]);
					d_Record_Product_loopV6_9States.setLst(attributes[90]);
					d_Record_Product_loopV6_9States.setTns_attr(attributes[91]);
					d_Record_Product_loopV6_9States.setTns(attributes[92]);
					d_Record_Product_loopV6_9States.setOtn_attr(attributes[93]);
					d_Record_Product_loopV6_9States.setOtn(attributes[94]);
					d_Record_Product_loopV6_9States.setIspid_attr(attributes[95]);
					d_Record_Product_loopV6_9States.setIspid(attributes[96]);
					d_Record_Product_loopV6_9States.setPic_attr(attributes[97]);
					d_Record_Product_loopV6_9States.setPic(attributes[98]);
					d_Record_Product_loopV6_9States.setLpic_attr(attributes[99]);
					d_Record_Product_loopV6_9States.setLpic(attributes[100]);
					d_Record_Product_loopV6_9States.setSsig_attr(attributes[101]);
					d_Record_Product_loopV6_9States.setSsig(attributes[102]);
					d_Record_Product_loopV6_9States.setBa_attr(attributes[103]);
					d_Record_Product_loopV6_9States.setBa(attributes[104]);
					d_Record_Product_loopV6_9States.setBlock_attr(attributes[105]);
					d_Record_Product_loopV6_9States.setBlock(attributes[106]);
					d_Record_Product_loopV6_9States.setJk_code_attr(attributes[107]);
					d_Record_Product_loopV6_9States.setJk_code(attributes[108]);
					d_Record_Product_loopV6_9States.setJk_num_attr(attributes[109]);
					d_Record_Product_loopV6_9States.setJk_num(attributes[110]);
					d_Record_Product_loopV6_9States.setJk_pos_attr(attributes[111]);
					d_Record_Product_loopV6_9States.setJk_pos(attributes[112]);
					d_Record_Product_loopV6_9States.setJr_attr(attributes[113]);
					d_Record_Product_loopV6_9States.setJr(attributes[114]);
					d_Record_Product_loopV6_9States.setNidr_attr(attributes[115]);
					d_Record_Product_loopV6_9States.setNidr(attributes[116]);
					d_Record_Product_loopV6_9States.setIwjk1_attr(attributes[117]);
					d_Record_Product_loopV6_9States.setIwjk1(attributes[118]);
					d_Record_Product_loopV6_9States.setIwjk2_attr(attributes[119]);
					d_Record_Product_loopV6_9States.setIwjk2(attributes[120]);
					d_Record_Product_loopV6_9States.setIwjk3_attr(attributes[121]);
					d_Record_Product_loopV6_9States.setIwjk3(attributes[122]);
					d_Record_Product_loopV6_9States.setIwjk4_attr(attributes[123]);
					d_Record_Product_loopV6_9States.setIwjk4(attributes[124]);
					d_Record_Product_loopV6_9States.setIwjk5_attr(attributes[125]);
					d_Record_Product_loopV6_9States.setIwjk5(attributes[126]);
					d_Record_Product_loopV6_9States.setIwjq1_attr(attributes[127]);
					d_Record_Product_loopV6_9States.setIwjq1(attributes[128]);
					d_Record_Product_loopV6_9States.setIwjq2_attr(attributes[129]);
					d_Record_Product_loopV6_9States.setIwjq2(attributes[130]);
					d_Record_Product_loopV6_9States.setIwjq3_attr(attributes[131]);
					d_Record_Product_loopV6_9States.setIwjq3(attributes[132]);
					d_Record_Product_loopV6_9States.setIwjq4_attr(attributes[133]);
					d_Record_Product_loopV6_9States.setIwjq4(attributes[134]);
					d_Record_Product_loopV6_9States.setIwjq5_attr(attributes[135]);
					d_Record_Product_loopV6_9States.setIwjq5(attributes[136]);
					d_Record_Product_loopV6_9States.setLidb_attr(attributes[137]);
					d_Record_Product_loopV6_9States.setLidb(attributes[138]);
					d_Record_Product_loopV6_9States.setS_attr(attributes[139]);
					d_Record_Product_loopV6_9States.setS(attributes[140]);
					d_Record_Product_loopV6_9States.setOecckt_attr(attributes[141]);
					d_Record_Product_loopV6_9States.setOecckt(attributes[142]);
					d_Record_Product_loopV6_9States.setPqty_attr(attributes[143]);
					d_Record_Product_loopV6_9States.setPqty(attributes[144]);
					d_Record_Product_loopV6_9States.setLocnum_attr(attributes[145]);
					d_Record_Product_loopV6_9States.setLocnum(attributes[146]);
					d_Record_Product_loopV6_9States.setLnex_attr(attributes[147]);
					d_Record_Product_loopV6_9States.setLnex(attributes[148]);
					d_Record_Product_loopV6_9States.setLneclssvc_attr(attributes[149]);
					d_Record_Product_loopV6_9States.setLneclssvc(attributes[150]);
					d_Record_Product_loopV6_9States.setFpi_attr(attributes[151]);
					d_Record_Product_loopV6_9States.setFpi(attributes[152]);
					d_Record_Product_loopV6_9States.setSdi_attr(attributes[153]);
					d_Record_Product_loopV6_9States.setSdi(attributes[154]);
					d_Record_Product_loopV6_9States.setMatn_attr(attributes[155]);
					d_Record_Product_loopV6_9States.setMatn(attributes[156]);
					d_Record_Product_loopV6_9States.setSgnl_attr(attributes[157]);
					d_Record_Product_loopV6_9States.setSgnl(attributes[158]);
					d_Record_Product_loopV6_9States.setPulse_attr(attributes[159]);
					d_Record_Product_loopV6_9States.setPulse(attributes[160]);
					d_Record_Product_loopV6_9States.setLean_attr(attributes[161]);
					d_Record_Product_loopV6_9States.setLean(attributes[162]);
					d_Record_Product_loopV6_9States.setLeatn_attr(attributes[163]);
					d_Record_Product_loopV6_9States.setLeatn(attributes[164]);
					d_Record_Product_loopV6_9States.setIwt_attr(attributes[165]);
					d_Record_Product_loopV6_9States.setIwt(attributes[166]);
					d_Record_Product_loopV6_9States.setIwtq_attr(attributes[167]);
					d_Record_Product_loopV6_9States.setIwtq(attributes[168]);
					d_Record_Product_loopV6_9States.setTli_attr(attributes[169]);
					d_Record_Product_loopV6_9States.setTli(attributes[170]);
					d_Record_Product_loopV6_9States.setLqty_attr(attributes[171]);
					d_Record_Product_loopV6_9States.setLqty(attributes[172]);
					d_Record_Product_loopV6_9States.setBtrl_attr(attributes[173]);
					d_Record_Product_loopV6_9States.setBtrl(attributes[174]);
					d_Record_Product_loopV6_9States.setCma_attr(attributes[175]);
					d_Record_Product_loopV6_9States.setCma(attributes[176]);
					d_Record_Product_loopV6_9States.setSan_attr(attributes[177]);
					d_Record_Product_loopV6_9States.setSan(attributes[178]);
					d_Record_Product_loopV6_9States.setCableid2_attr(attributes[179]);
					d_Record_Product_loopV6_9States.setCableid2(attributes[180]);
					d_Record_Product_loopV6_9States.setTnt_attr(attributes[181]);
					d_Record_Product_loopV6_9States.setTnt(attributes[182]);
					d_Record_Product_loopV6_9States.setNpqty_attr(attributes[183]);
					d_Record_Product_loopV6_9States.setNpqty(attributes[184]);
					d_Record_Product_loopV6_9States.setTnp_attr(attributes[185]);
					d_Record_Product_loopV6_9States.setTnp(attributes[186]);
					d_Record_Product_loopV6_9States.setCftn_attr(attributes[187]);
					d_Record_Product_loopV6_9States.setCftn(attributes[188]);
					d_Record_Product_loopV6_9States.setRsqty_attr(attributes[189]);
					d_Record_Product_loopV6_9States.setRsqty(attributes[190]);
					d_Record_Product_loopV6_9States.setCnam_attr(attributes[191]);
					d_Record_Product_loopV6_9States.setCnam(attributes[192]);
					d_Record_Product_loopV6_9States.setIwtq2_attr(attributes[193]);
					d_Record_Product_loopV6_9States.setIwtq2(attributes[194]);
					d_Record_Product_loopV6_9States.setIwtq3_attr(attributes[195]);
					d_Record_Product_loopV6_9States.setIwtq3(attributes[196]);
					d_Record_Product_loopV6_9States.setIwtq4_attr(attributes[197]);
					d_Record_Product_loopV6_9States.setIwtq4(attributes[198]);
					d_Record_Product_loopV6_9States.setIwtq5_attr(attributes[199]);
					d_Record_Product_loopV6_9States.setIwtq5(attributes[200]);
					d_Record_Product_loopV6_9States.setIwt2_attr(attributes[201]);
					d_Record_Product_loopV6_9States.setIwt2(attributes[202]);
					d_Record_Product_loopV6_9States.setIwt3_attr(attributes[203]);
					d_Record_Product_loopV6_9States.setIwt3(attributes[204]);
					d_Record_Product_loopV6_9States.setIwt4_attr(attributes[205]);
					d_Record_Product_loopV6_9States.setIwt4(attributes[206]);
					d_Record_Product_loopV6_9States.setIwt5_attr(attributes[207]);
					d_Record_Product_loopV6_9States.setIwt5(attributes[208]);
					d_Record_Product_loopV6_9States.setScfa_attr(attributes[209]);
					d_Record_Product_loopV6_9States.setScfa(attributes[210]);
					d_Record_Product_loopV6_9States.setBtrl2_attr(attributes[211]);
					d_Record_Product_loopV6_9States.setBtrl2(attributes[212]);
					d_Record_Product_loopV6_9States.setBtrl3_attr(attributes[213]);
					d_Record_Product_loopV6_9States.setBtrl3(attributes[214]);
					d_Record_Product_loopV6_9States.setBtrl4_attr(attributes[215]);
					d_Record_Product_loopV6_9States.setBtrl4(attributes[216]);
					d_Record_Product_loopV6_9States.setBa1_attr(attributes[217]);
					d_Record_Product_loopV6_9States.setBa1(attributes[218]);
					d_Record_Product_loopV6_9States.setBlocking2_attr(attributes[219]);
					d_Record_Product_loopV6_9States.setBlocking2(attributes[220]);
					d_Record_Product_loopV6_9States.setLoc_seq_num(attributes[221]);

					// d_Record_Product_loopV6_9States.setScreenName("Circut");

					treeViewList200.add(d_Record_Product_loopV6_9States);
				}
				session.setAttribute("treeViewList200", treeViewList200);
				selectRequestData.setSubHeader(receivedSubHeader);
			}

			if (subData_300Recid != null && subData_300Recid.getSubHeader().getRecord_type().equals("300")) {

				SubHeader receivedSubHeader = subData_300Recid.getSubHeader();
				String[] subDataRows = subData_300Recid.getSubDataRows();
				treeViewList.add("300");

				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 222);
					// System.out.println("attributes:=300:Reqid======> " +
					// Arrays.toString(attributes));
					D_Record_Product_loopNP_9States d_Record_Product_loopNP_9States = new D_Record_Product_loopNP_9States();

					d_Record_Product_loopNP_9States.setItem_num(attributes[0]);
					d_Record_Product_loopNP_9States.setLnum_attr(attributes[1]);
					d_Record_Product_loopNP_9States.setLnum(attributes[2]);
					d_Record_Product_loopNP_9States.setLna_attr(attributes[3]);
					d_Record_Product_loopNP_9States.setLna(attributes[4]);
					d_Record_Product_loopNP_9States.setLmt_attr(attributes[5]);
					d_Record_Product_loopNP_9States.setLmt(attributes[6]);
					d_Record_Product_loopNP_9States.setEcckt_attr(attributes[7]);
					d_Record_Product_loopNP_9States.setEcckt(attributes[8]);
					d_Record_Product_loopNP_9States.setShared_nbr_attr(attributes[9]);
					d_Record_Product_loopNP_9States.setShared_nbr(attributes[10]);

					d_Record_Product_loopNP_9States.setDisc_nbr_attr(attributes[11]);
					d_Record_Product_loopNP_9States.setDisc_nbr(attributes[12]);
					d_Record_Product_loopNP_9States.setTers_attr(attributes[13]);
					d_Record_Product_loopNP_9States.setTers(attributes[14]);
					d_Record_Product_loopNP_9States.setCfa_attr(attributes[15]);

					d_Record_Product_loopNP_9States.setCfa(attributes[16]);
					d_Record_Product_loopNP_9States.setCcea_attr(attributes[17]);
					d_Record_Product_loopNP_9States.setCcea(attributes[18]);
					d_Record_Product_loopNP_9States.setSscfa_attr(attributes[19]);
					d_Record_Product_loopNP_9States.setSscfa(attributes[20]);
					d_Record_Product_loopNP_9States.setCableid_attr(attributes[21]);
					d_Record_Product_loopNP_9States.setCableid(attributes[22]);
					d_Record_Product_loopNP_9States.setChan_pair3_attr(attributes[23]);
					d_Record_Product_loopNP_9States.setChan_pair3(attributes[24]);
					d_Record_Product_loopNP_9States.setSystemid_attr(attributes[25]);
					d_Record_Product_loopNP_9States.setSystemid(attributes[26]);
					d_Record_Product_loopNP_9States.setCbcid_attr(attributes[27]);
					d_Record_Product_loopNP_9States.setCbcid(attributes[28]);
					d_Record_Product_loopNP_9States.setChan_pair_attr(attributes[29]);
					d_Record_Product_loopNP_9States.setChan_pair(attributes[30]);
					d_Record_Product_loopNP_9States.setCbcid2_attr(attributes[31]);
					d_Record_Product_loopNP_9States.setCbcid2(attributes[32]);
					d_Record_Product_loopNP_9States.setChan_pair2_attr(attributes[33]);
					d_Record_Product_loopNP_9States.setChan_pair2(attributes[34]);
					d_Record_Product_loopNP_9States.setCti_attr(attributes[35]);
					d_Record_Product_loopNP_9States.setCti(attributes[36]);
					d_Record_Product_loopNP_9States.setRelay_rack_attr(attributes[37]);
					d_Record_Product_loopNP_9States.setRelay_rack(attributes[38]);
					d_Record_Product_loopNP_9States.setShelf_attr(attributes[39]);
					d_Record_Product_loopNP_9States.setShelf(attributes[40]);
					d_Record_Product_loopNP_9States.setSlot_attr(attributes[41]);
					d_Record_Product_loopNP_9States.setSlot(attributes[42]);
					d_Record_Product_loopNP_9States.setCti2_attr(attributes[43]);
					d_Record_Product_loopNP_9States.setCti2(attributes[44]);
					d_Record_Product_loopNP_9States.setRelay_rack2_attr(attributes[45]);
					d_Record_Product_loopNP_9States.setRelay_rack2(attributes[46]);
					d_Record_Product_loopNP_9States.setShelf2_attr(attributes[47]);
					d_Record_Product_loopNP_9States.setShelf2(attributes[48]);
					d_Record_Product_loopNP_9States.setSlot2_attr(attributes[49]);
					d_Record_Product_loopNP_9States.setSlot2(attributes[50]);
					d_Record_Product_loopNP_9States.setCti3_attr(attributes[51]);
					d_Record_Product_loopNP_9States.setCti3(attributes[52]);
					d_Record_Product_loopNP_9States.setRelay_rack3_attr(attributes[53]);
					d_Record_Product_loopNP_9States.setRelay_rack3(attributes[54]);
					d_Record_Product_loopNP_9States.setShelf3_attr(attributes[55]);
					d_Record_Product_loopNP_9States.setShelf3(attributes[56]);
					d_Record_Product_loopNP_9States.setSlot3_attr(attributes[57]);
					d_Record_Product_loopNP_9States.setSlot3(attributes[58]);
					d_Record_Product_loopNP_9States.setCti4_attr(attributes[59]);
					d_Record_Product_loopNP_9States.setCti4(attributes[60]);
					d_Record_Product_loopNP_9States.setRelay_rack4_attr(attributes[61]);
					d_Record_Product_loopNP_9States.setRelay_rack4(attributes[62]);
					d_Record_Product_loopNP_9States.setShelf4_attr(attributes[63]);
					d_Record_Product_loopNP_9States.setShelf4(attributes[64]);
					d_Record_Product_loopNP_9States.setSlot4_attr(attributes[65]);
					d_Record_Product_loopNP_9States.setSlot4(attributes[66]);
					d_Record_Product_loopNP_9States.setVpi_attr(attributes[67]);
					d_Record_Product_loopNP_9States.setVpi(attributes[68]);
					d_Record_Product_loopNP_9States.setVci_attr(attributes[69]);
					d_Record_Product_loopNP_9States.setVci(attributes[70]);
					d_Record_Product_loopNP_9States.setCode_set_attr(attributes[71]);
					d_Record_Product_loopNP_9States.setCode_set(attributes[72]);
					d_Record_Product_loopNP_9States.setRecckt_attr(attributes[73]);
					d_Record_Product_loopNP_9States.setRecckt(attributes[74]);
					d_Record_Product_loopNP_9States.setCkr_attr(attributes[75]);
					d_Record_Product_loopNP_9States.setCkr(attributes[76]);
					d_Record_Product_loopNP_9States.setTsp_attr(attributes[77]);
					d_Record_Product_loopNP_9States.setTsp(attributes[78]);
					d_Record_Product_loopNP_9States.setPorted_nbr_attr(attributes[79]);
					d_Record_Product_loopNP_9States.setPorted_nbr(attributes[80]);
					d_Record_Product_loopNP_9States.setNpt_attr(attributes[81]);
					d_Record_Product_loopNP_9States.setNpt(attributes[82]);
					d_Record_Product_loopNP_9States.setRti_attr(attributes[83]);
					d_Record_Product_loopNP_9States.setRti(attributes[84]);
					d_Record_Product_loopNP_9States.setNptg_attr(attributes[85]);
					d_Record_Product_loopNP_9States.setNptg(attributes[86]);
					d_Record_Product_loopNP_9States.setNpi_attr(attributes[87]);
					d_Record_Product_loopNP_9States.setNpi(attributes[88]);
					d_Record_Product_loopNP_9States.setLst_attr(attributes[89]);
					d_Record_Product_loopNP_9States.setLst(attributes[90]);
					d_Record_Product_loopNP_9States.setTns_attr(attributes[91]);
					d_Record_Product_loopNP_9States.setTns(attributes[92]);
					d_Record_Product_loopNP_9States.setOtn_attr(attributes[93]);
					d_Record_Product_loopNP_9States.setOtn(attributes[94]);
					d_Record_Product_loopNP_9States.setIspid_attr(attributes[95]);
					d_Record_Product_loopNP_9States.setIspid(attributes[96]);
					d_Record_Product_loopNP_9States.setPic_attr(attributes[97]);
					d_Record_Product_loopNP_9States.setPic(attributes[98]);
					d_Record_Product_loopNP_9States.setLpic_attr(attributes[99]);
					d_Record_Product_loopNP_9States.setLpic(attributes[100]);
					d_Record_Product_loopNP_9States.setSsig_attr(attributes[101]);
					d_Record_Product_loopNP_9States.setSsig(attributes[102]);
					d_Record_Product_loopNP_9States.setBa_attr(attributes[103]);
					d_Record_Product_loopNP_9States.setBa(attributes[104]);
					d_Record_Product_loopNP_9States.setBlock_attr(attributes[105]);
					d_Record_Product_loopNP_9States.setBlock(attributes[106]);
					d_Record_Product_loopNP_9States.setJk_code_attr(attributes[107]);
					d_Record_Product_loopNP_9States.setJk_code(attributes[108]);
					d_Record_Product_loopNP_9States.setJk_num_attr(attributes[109]);
					d_Record_Product_loopNP_9States.setJk_num(attributes[110]);
					d_Record_Product_loopNP_9States.setJk_pos_attr(attributes[111]);
					d_Record_Product_loopNP_9States.setJk_pos(attributes[112]);
					d_Record_Product_loopNP_9States.setJr_attr(attributes[113]);
					d_Record_Product_loopNP_9States.setJr(attributes[114]);
					d_Record_Product_loopNP_9States.setNidr_attr(attributes[115]);
					d_Record_Product_loopNP_9States.setNidr(attributes[116]);
					d_Record_Product_loopNP_9States.setIwjk1_attr(attributes[117]);
					d_Record_Product_loopNP_9States.setIwjk1(attributes[118]);
					d_Record_Product_loopNP_9States.setIwjk2_attr(attributes[119]);
					d_Record_Product_loopNP_9States.setIwjk2(attributes[120]);
					d_Record_Product_loopNP_9States.setIwjk3_attr(attributes[121]);
					d_Record_Product_loopNP_9States.setIwjk3(attributes[122]);
					d_Record_Product_loopNP_9States.setIwjk4_attr(attributes[123]);
					d_Record_Product_loopNP_9States.setIwjk4(attributes[124]);
					d_Record_Product_loopNP_9States.setIwjk5_attr(attributes[125]);
					d_Record_Product_loopNP_9States.setIwjk5(attributes[126]);
					d_Record_Product_loopNP_9States.setIwjq1_attr(attributes[127]);
					d_Record_Product_loopNP_9States.setIwjq1(attributes[128]);
					d_Record_Product_loopNP_9States.setIwjq2_attr(attributes[129]);
					d_Record_Product_loopNP_9States.setIwjq2(attributes[130]);
					d_Record_Product_loopNP_9States.setIwjq3_attr(attributes[131]);
					d_Record_Product_loopNP_9States.setIwjq3(attributes[132]);
					d_Record_Product_loopNP_9States.setIwjq4_attr(attributes[133]);
					d_Record_Product_loopNP_9States.setIwjq4(attributes[134]);
					d_Record_Product_loopNP_9States.setIwjq5_attr(attributes[135]);
					d_Record_Product_loopNP_9States.setIwjq5(attributes[136]);
					d_Record_Product_loopNP_9States.setLidb_attr(attributes[137]);
					d_Record_Product_loopNP_9States.setLidb(attributes[138]);
					d_Record_Product_loopNP_9States.setS_attr(attributes[139]);
					d_Record_Product_loopNP_9States.setS(attributes[140]);
					d_Record_Product_loopNP_9States.setOecckt_attr(attributes[141]);
					d_Record_Product_loopNP_9States.setOecckt(attributes[142]);
					d_Record_Product_loopNP_9States.setPqty_attr(attributes[143]);
					d_Record_Product_loopNP_9States.setPqty(attributes[144]);
					d_Record_Product_loopNP_9States.setLocnum_attr(attributes[145]);
					d_Record_Product_loopNP_9States.setLocnum(attributes[146]);
					d_Record_Product_loopNP_9States.setLnex_attr(attributes[147]);
					d_Record_Product_loopNP_9States.setLnex(attributes[148]);
					d_Record_Product_loopNP_9States.setLneclssvc_attr(attributes[149]);
					d_Record_Product_loopNP_9States.setLneclssvc(attributes[150]);
					d_Record_Product_loopNP_9States.setFpi_attr(attributes[151]);
					d_Record_Product_loopNP_9States.setFpi(attributes[152]);
					d_Record_Product_loopNP_9States.setSdi_attr(attributes[153]);
					d_Record_Product_loopNP_9States.setSdi(attributes[154]);
					d_Record_Product_loopNP_9States.setMatn_attr(attributes[155]);
					d_Record_Product_loopNP_9States.setMatn(attributes[156]);
					d_Record_Product_loopNP_9States.setSgnl_attr(attributes[157]);
					d_Record_Product_loopNP_9States.setSgnl(attributes[158]);
					d_Record_Product_loopNP_9States.setPulse_attr(attributes[159]);
					d_Record_Product_loopNP_9States.setPulse(attributes[160]);
					d_Record_Product_loopNP_9States.setLean_attr(attributes[161]);
					d_Record_Product_loopNP_9States.setLean(attributes[162]);
					d_Record_Product_loopNP_9States.setLeatn_attr(attributes[163]);
					d_Record_Product_loopNP_9States.setLeatn(attributes[164]);
					d_Record_Product_loopNP_9States.setIwt_attr(attributes[165]);
					d_Record_Product_loopNP_9States.setIwt(attributes[166]);
					d_Record_Product_loopNP_9States.setIwtq_attr(attributes[167]);
					d_Record_Product_loopNP_9States.setIwtq(attributes[168]);
					d_Record_Product_loopNP_9States.setTli_attr(attributes[169]);
					d_Record_Product_loopNP_9States.setTli(attributes[170]);
					d_Record_Product_loopNP_9States.setLqty_attr(attributes[171]);
					d_Record_Product_loopNP_9States.setLqty(attributes[172]);
					d_Record_Product_loopNP_9States.setBtrl_attr(attributes[173]);
					d_Record_Product_loopNP_9States.setBtrl(attributes[174]);
					d_Record_Product_loopNP_9States.setCma_attr(attributes[175]);
					d_Record_Product_loopNP_9States.setCma(attributes[176]);
					d_Record_Product_loopNP_9States.setSan_attr(attributes[177]);
					d_Record_Product_loopNP_9States.setSan(attributes[178]);
					d_Record_Product_loopNP_9States.setCableid2_attr(attributes[179]);
					d_Record_Product_loopNP_9States.setCableid2(attributes[180]);
					d_Record_Product_loopNP_9States.setTnt_attr(attributes[181]);
					d_Record_Product_loopNP_9States.setTnt(attributes[182]);
					d_Record_Product_loopNP_9States.setNpqty_attr(attributes[183]);
					d_Record_Product_loopNP_9States.setNpqty(attributes[184]);
					d_Record_Product_loopNP_9States.setTnp_attr(attributes[185]);
					d_Record_Product_loopNP_9States.setTnp(attributes[186]);
					d_Record_Product_loopNP_9States.setCftn_attr(attributes[187]);
					d_Record_Product_loopNP_9States.setCftn(attributes[188]);
					d_Record_Product_loopNP_9States.setRsqty_attr(attributes[189]);
					d_Record_Product_loopNP_9States.setRsqty(attributes[190]);
					d_Record_Product_loopNP_9States.setCnam_attr(attributes[191]);
					d_Record_Product_loopNP_9States.setCnam(attributes[192]);
					d_Record_Product_loopNP_9States.setIwtq2_attr(attributes[193]);
					d_Record_Product_loopNP_9States.setIwtq2(attributes[194]);
					d_Record_Product_loopNP_9States.setIwtq3_attr(attributes[195]);
					d_Record_Product_loopNP_9States.setIwtq3(attributes[196]);
					d_Record_Product_loopNP_9States.setIwtq4_attr(attributes[197]);
					d_Record_Product_loopNP_9States.setIwtq4(attributes[198]);
					d_Record_Product_loopNP_9States.setIwtq5_attr(attributes[199]);
					d_Record_Product_loopNP_9States.setIwtq5(attributes[200]);
					d_Record_Product_loopNP_9States.setIwt2_attr(attributes[201]);
					d_Record_Product_loopNP_9States.setIwt2(attributes[202]);
					d_Record_Product_loopNP_9States.setIwt3_attr(attributes[203]);
					d_Record_Product_loopNP_9States.setIwt3(attributes[204]);
					d_Record_Product_loopNP_9States.setIwt4_attr(attributes[205]);
					d_Record_Product_loopNP_9States.setIwt4(attributes[206]);
					d_Record_Product_loopNP_9States.setIwt5_attr(attributes[207]);
					d_Record_Product_loopNP_9States.setIwt5(attributes[208]);
					d_Record_Product_loopNP_9States.setScfa_attr(attributes[209]);
					d_Record_Product_loopNP_9States.setScfa(attributes[210]);
					d_Record_Product_loopNP_9States.setBtrl2_attr(attributes[211]);
					d_Record_Product_loopNP_9States.setBtrl2(attributes[212]);
					d_Record_Product_loopNP_9States.setBtrl3_attr(attributes[213]);
					d_Record_Product_loopNP_9States.setBtrl3(attributes[214]);
					d_Record_Product_loopNP_9States.setBtrl4_attr(attributes[215]);
					d_Record_Product_loopNP_9States.setBtrl4(attributes[216]);
					d_Record_Product_loopNP_9States.setBa1_attr(attributes[217]);
					d_Record_Product_loopNP_9States.setBa1(attributes[218]);
					d_Record_Product_loopNP_9States.setBlocking2_attr(attributes[219]);
					d_Record_Product_loopNP_9States.setBlocking2(attributes[220]);
					d_Record_Product_loopNP_9States.setLoc_seq_num(attributes[221]);

					// d_Record_Product_loopNP_9States.setScreenName("Circut");

					treeViewList300.add(d_Record_Product_loopNP_9States);
				}
				session.setAttribute("treeViewList300", treeViewList300);
				selectRequestData.setSubHeader(receivedSubHeader);
			}

			// bharti end
			// rupa

			// Hunting 9 States

			if (subData_160Recid != null && subData_160Recid.getSubHeader().getRecord_type().equals("160")) {

				SubHeader receivedSubHeader = subData_160Recid.getSubHeader();
				String[] subDataRows = subData_160Recid.getSubDataRows();
				treeViewList.add("160");

				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 13);
					// System.out.println("attributes:=160:Reqid======> " +
					// Arrays.toString(attributes));
					LSRHunting160_9States LSRHunting9 = new LSRHunting160_9States();

					LSRHunting9.setHunt_item_num(attributes[0]);
					LSRHunting9.setHnum_attr(attributes[1]);
					LSRHunting9.setHnum(attributes[2]);
					LSRHunting9.setHa_attr(attributes[3]);
					LSRHunting9.setHa(attributes[4]);
					LSRHunting9.setHid_attr(attributes[5]);
					LSRHunting9.setHid(attributes[6]);
					LSRHunting9.setHtli_attr(attributes[7]);
					LSRHunting9.setHtli(attributes[8]);
					LSRHunting9.setHntyp_attr(attributes[9]);
					LSRHunting9.setHntyp(attributes[10]);
					LSRHunting9.setLocnum(attributes[11]);
					LSRHunting9.setLoc_seq_num(attributes[12]);

					treeViewList160.add(LSRHunting9);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
			}

			if (subData_161Recid != null && subData_161Recid.getSubHeader().getRecord_type().equals("161")) {

				SubHeader receivedSubHeader = subData_161Recid.getSubHeader();
				String[] subDataRows = subData_161Recid.getSubDataRows();
				treeViewList.add("161");

				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 15);
					// System.out.println("attributes:=161:Reqid======> " +
					// Arrays.toString(attributes));
					LSRHunting161_9States LSRHunting9 = new LSRHunting161_9States();

					LSRHunting9.setHid_attr(attributes[0]);
					LSRHunting9.setHid(attributes[1]);
					LSRHunting9.setHla_attr(attributes[2]);
					LSRHunting9.setHla(attributes[3]);
					LSRHunting9.setHtseq_attr(attributes[4]);
					LSRHunting9.setHtseq(attributes[5]);
					LSRHunting9.setHt_attr(attributes[6]);
					LSRHunting9.setHt(attributes[7]);
					LSRHunting9.setHunt_item_num_attr(attributes[8]);
					LSRHunting9.setHunt_item_num(attributes[9]);
					LSRHunting9.setLocnum_attr(attributes[10]);
					LSRHunting9.setLocnum(attributes[11]);
					LSRHunting9.setNotyp_attr(attributes[12]);
					LSRHunting9.setNotyp(attributes[13]);
					LSRHunting9.setLoc_seq_num(attributes[14]);

					treeViewList161.add(LSRHunting9);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}

			// Bill and Contact 9 States
			if (subData_050Recid != null && subData_050Recid.getSubHeader().getRecord_type().equals("050")) {

				SubHeader receivedSubHeader = subData_050Recid.getSubHeader();
				String[] subDataRows = subData_050Recid.getSubDataRows();

				treeViewList.add("050");
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 180);
					// System.out.println("attributes:=050:Reqid1======> "
					// +Arrays.toString(attributes));
					LSR_BillContact_9States BillAndContact = new LSR_BillContact_9States();

					BillAndContact.setCver_attr(attributes[0]);
					BillAndContact.setCver(attributes[1]);
					BillAndContact.setSm(attributes[2]);
					BillAndContact.setDt_sent(attributes[3]);
					BillAndContact.setAdm_sc_attr(attributes[4]);
					BillAndContact.setAdm_sc(attributes[5]);
					BillAndContact.setDdd_attr(attributes[6]);
					BillAndContact.setDdd(attributes[7]);
					BillAndContact.setApptime_ddd_attr(attributes[8]);
					BillAndContact.setApptime_ddd(attributes[9]);
					BillAndContact.setResid_attr(attributes[10]);
					BillAndContact.setResid(attributes[11]);
					BillAndContact.setDfdt_attr(attributes[12]);
					BillAndContact.setDfdt(attributes[13]);
					BillAndContact.setDddo_attr(attributes[14]);
					BillAndContact.setDddo(attributes[15]);
					BillAndContact.setDfdto_attr(attributes[16]);
					BillAndContact.setDfdto(attributes[17]);
					BillAndContact.setChc_attr(attributes[18]);
					BillAndContact.setChc(attributes[19]);
					BillAndContact.setExp_attr(attributes[20]);
					BillAndContact.setExp(attributes[21]);
					BillAndContact.setExprsn_attr(attributes[22]);
					BillAndContact.setExprsn(attributes[23]);
					BillAndContact.setAct_attr(attributes[24]);
					BillAndContact.setAct(attributes[25]);
					BillAndContact.setSup_attr(attributes[26]);
					BillAndContact.setSup(attributes[27]);
					BillAndContact.setTos_attr(attributes[28]);
					BillAndContact.setTos(attributes[29]);
					BillAndContact.setAtn_attr(attributes[30]);
					BillAndContact.setAtn(attributes[31]);
					BillAndContact.setRtr_attr(attributes[32]);
					BillAndContact.setRtr(attributes[33]);
					BillAndContact.setOnsp_attr(attributes[34]);
					BillAndContact.setOnsp(attributes[35]);
					BillAndContact.setNnsp_attr(attributes[36]);
					BillAndContact.setNnsp(attributes[37]);
					BillAndContact.setNor_attr(attributes[38]);
					BillAndContact.setNor(attributes[39]);
					BillAndContact.setRpon_attr(attributes[40]);
					BillAndContact.setRpon(attributes[41]);
					BillAndContact.setRord_attr(attributes[42]);
					BillAndContact.setRord(attributes[43]);
					BillAndContact.setActl_attr(attributes[44]);
					BillAndContact.setActl(attributes[45]);
					BillAndContact.setLst_attr(attributes[46]);
					BillAndContact.setLst(attributes[47]);
					BillAndContact.setSpec_attr(attributes[48]);
					BillAndContact.setSpec(attributes[49]);
					BillAndContact.setAdm_nc_attr(attributes[50]);
					BillAndContact.setAdm_nc(attributes[51]);
					BillAndContact.setAdm_nci_attr(attributes[52]);
					BillAndContact.setAdm_nci(attributes[53]);
					BillAndContact.setSecnci_attr(attributes[54]);
					BillAndContact.setSecnci(attributes[55]);
					BillAndContact.setAtr_attr(attributes[56]);
					BillAndContact.setAtr(attributes[57]);
					BillAndContact.setNena_ecc_attr(attributes[58]);
					BillAndContact.setNena_ecc(attributes[59]);
					BillAndContact.setAlbr_attr(attributes[60]);
					BillAndContact.setAlbr(attributes[61]);
					BillAndContact.setProject_attr(attributes[62]);
					BillAndContact.setProject(attributes[63]);
					BillAndContact.setAgauth_attr(attributes[64]);
					BillAndContact.setAgauth(attributes[65]);
					BillAndContact.setBan1_attr(attributes[66]);
					BillAndContact.setBan1(attributes[67]);
					BillAndContact.setBan2_attr(attributes[68]);
					BillAndContact.setBan2(attributes[69]);
					BillAndContact.setEbp_attr(attributes[70]);
					BillAndContact.setEbp(attributes[71]);
					BillAndContact.setVta_attr(attributes[72]);
					BillAndContact.setVta(attributes[73]);
					BillAndContact.setInit_attr(attributes[74]);
					BillAndContact.setInit(attributes[75]);
					BillAndContact.setTel_no_attr(attributes[76]);
					BillAndContact.setTel_no(attributes[77]);
					BillAndContact.setFax_no(attributes[78]);
					BillAndContact.setImpcon_attr(attributes[79]);
					BillAndContact.setImpcon(attributes[80]);
					BillAndContact.setImpcon_telno_attr(attributes[81]);
					BillAndContact.setImpcon_telno(attributes[82]);
					BillAndContact.setDrc_attr(attributes[83]);
					BillAndContact.setDrc(attributes[84]);
					BillAndContact.setDsgcon(attributes[85]);
					BillAndContact.setDsgcon_telno_attr(attributes[86]);
					BillAndContact.setDsgcon_telno(attributes[87]);
					BillAndContact.setDsgcon_faxno_attr(attributes[88]);
					BillAndContact.setDsgcon_faxno(attributes[89]);
					BillAndContact.setActivity(attributes[90]);
					BillAndContact.setReq_type(attributes[91]);
					BillAndContact.setPb_sb_ind(attributes[92]);
					BillAndContact.setNpdi_attr(attributes[93]);
					BillAndContact.setNpdi(attributes[94]);
					BillAndContact.setScd_attr(attributes[95]);
					BillAndContact.setScd(attributes[96]);
					BillAndContact.setSli_attr(attributes[97]);
					BillAndContact.setSli(attributes[98]);
					BillAndContact.setQrynbr_attr(attributes[99]);
					BillAndContact.setQrynbr(attributes[100]);
					BillAndContact.setSactl_attr(attributes[101]);
					BillAndContact.setSactl(attributes[102]);
					BillAndContact.setAdet_attr(attributes[103]);
					BillAndContact.setAdet(attributes[104]);
					BillAndContact.setLocqty_attr(attributes[105]);
					BillAndContact.setLocqty(attributes[106]);
					BillAndContact.setHtqty_attr(attributes[107]);
					BillAndContact.setHtqty(attributes[108]);
					BillAndContact.setAn_attr(attributes[109]);
					BillAndContact.setAn(attributes[110]);
					BillAndContact.setBcs_attr(attributes[111]);
					BillAndContact.setBcs(attributes[112]);
					BillAndContact.setMi_attr(attributes[113]);
					BillAndContact.setMi(attributes[114]);
					BillAndContact.setMeu_attr(attributes[115]);
					BillAndContact.setMeu(attributes[116]);
					BillAndContact.setAan_attr(attributes[117]);
					BillAndContact.setAan(attributes[118]);
					BillAndContact.setNatn_attr(attributes[119]);
					BillAndContact.setNatn(attributes[120]);
					BillAndContact.setNan_attr(attributes[121]);
					BillAndContact.setNan(attributes[122]);
					BillAndContact.setRcc_attr(attributes[123]);
					BillAndContact.setRcc(attributes[124]);
					BillAndContact.setBopi_attr(attributes[125]);
					BillAndContact.setBopi(attributes[126]);
					BillAndContact.setCic_attr(attributes[127]);
					BillAndContact.setCic(attributes[128]);
					BillAndContact.setCust_attr(attributes[129]);
					BillAndContact.setCust(attributes[130]);
					BillAndContact.setPorttyp_attr(attributes[131]);
					BillAndContact.setPorttyp(attributes[132]);
					BillAndContact.setAi_attr(attributes[133]);
					BillAndContact.setAi(attributes[134]);
					BillAndContact.setApot_attr(attributes[135]);
					BillAndContact.setApot(attributes[136]);
					BillAndContact.setLso_attr(attributes[137]);
					BillAndContact.setLso(attributes[138]);
					BillAndContact.setPbt_attr(attributes[139]);
					BillAndContact.setPbt(attributes[140]);
					BillAndContact.setSca_attr(attributes[141]);
					BillAndContact.setSca(attributes[142]);
					BillAndContact.setProjindr_attr(attributes[143]);
					BillAndContact.setProjindr(attributes[144]);
					BillAndContact.setLscp_attr(attributes[145]);
					BillAndContact.setLscp(attributes[146]);
					BillAndContact.setLsp_auth_name_attr(attributes[147]);
					BillAndContact.setLsp_auth_name(attributes[148]);
					BillAndContact.setLsp_auth_date_attr(attributes[149]);
					BillAndContact.setLsp_auth_date(attributes[150]);
					BillAndContact.setCcna(attributes[151]);
					BillAndContact.setBi1_attr(attributes[152]);
					BillAndContact.setBi1(attributes[153]);
					BillAndContact.setBi2_attr(attributes[154]);
					BillAndContact.setBi2(attributes[155]);
					BillAndContact.setCno_attr(attributes[156]);
					BillAndContact.setCno(attributes[157]);
					BillAndContact.setAcna_attr(attributes[158]);
					BillAndContact.setAcna(attributes[159]);
					BillAndContact.setStreet_init_attr(attributes[160]);
					BillAndContact.setStreet_init(attributes[161]);
					BillAndContact.setAlt_impcon_attr(attributes[162]);
					BillAndContact.setAlt_impcon(attributes[163]);
					BillAndContact.setTelno_alt_impcon_attr(attributes[164]);
					BillAndContact.setTelno_alt_impcon(attributes[165]);
					BillAndContact.setStreet_dsgcon_attr(attributes[166]);
					BillAndContact.setStreet_dsgcon(attributes[167]);
					BillAndContact.setCity_dsgcon_attr(attributes[168]);
					BillAndContact.setCity_dsgcon(attributes[169]);
					BillAndContact.setState_dsgcon_attr(attributes[170]);
					BillAndContact.setState_dsgcon(attributes[171]);
					BillAndContact.setZip_dsgcon_attr(attributes[172]);
					BillAndContact.setZip_dsgcon(attributes[173]);
					BillAndContact.setRmstop_attr(attributes[174]);
					BillAndContact.setRmstop(attributes[175]);
					BillAndContact.setFloor_attr(attributes[176]);
					BillAndContact.setFloor(attributes[177]);
					BillAndContact.setState_attr(attributes[178]);
					BillAndContact.setState(attributes[179]);

					treeViewList050.add(BillAndContact);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}
			// EndUser_DISCTC 9 States

			if (subData_105Recid != null && subData_105Recid.getSubHeader().getRecord_type().equals("105")) {

				SubHeader receivedSubHeader = subData_105Recid.getSubHeader();
				String[] subDataRows = subData_105Recid.getSubDataRows();
				treeViewList.add("105");

				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 25);
					// System.out.println("attributes:=105:Reqid======> " +
					// Arrays.toString(attributes));
					EndUser_DISC_TC105_9States EndUserDiscTc = new EndUser_DISC_TC105_9States();

					EndUserDiscTc.setItem_num(attributes[0]);
					EndUserDiscTc.setDnum_attr(attributes[1]);
					EndUserDiscTc.setDnum(attributes[2]);
					EndUserDiscTc.setDisc_nbr_attr(attributes[3]);
					EndUserDiscTc.setDisc_nbr(attributes[4]);
					EndUserDiscTc.setDisc_ter_attr(attributes[5]);
					EndUserDiscTc.setDisc_ter(attributes[6]);
					EndUserDiscTc.setEu_tc_opt_attr(attributes[7]);
					EndUserDiscTc.setEu_tc_opt(attributes[8]);
					EndUserDiscTc.setEu_tc_per_attr(attributes[9]);
					EndUserDiscTc.setEu_tc_per(attributes[10]);
					EndUserDiscTc.setEu_tc_to_pri_attr(attributes[11]);
					EndUserDiscTc.setEu_tc_to_pri(attributes[12]);
					EndUserDiscTc.setEu_tc_name_pri_attr(attributes[13]);
					EndUserDiscTc.setEu_tc_name_pri(attributes[14]);
					EndUserDiscTc.setEu_tc_id_attr(attributes[15]);
					EndUserDiscTc.setEu_tc_id(attributes[16]);
					EndUserDiscTc.setLocnum_attr(attributes[17]);
					EndUserDiscTc.setLocnum(attributes[18]);
					EndUserDiscTc.setDqty_attr(attributes[19]);
					EndUserDiscTc.setDqty(attributes[20]);
					EndUserDiscTc.setTcfr_attr(attributes[21]);
					EndUserDiscTc.setTcfr(attributes[22]);
					EndUserDiscTc.setLoc_seq_num(attributes[23]);

					treeViewList105.add(EndUserDiscTc);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}

			if (subData_106Recid != null && subData_106Recid.getSubHeader().getRecord_type().equals("106")) {

				SubHeader receivedSubHeader = subData_106Recid.getSubHeader();
				String[] subDataRows = subData_106Recid.getSubDataRows();
				treeViewList.add("106");

				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 9);
					// System.out.println("attributes:=106:Reqid======> " +
					// Arrays.toString(attributes));
					EndUser_DISC_TC106_9States EndUserDiscTcGrid = new EndUser_DISC_TC106_9States();

					EndUserDiscTcGrid.setItem_num(attributes[0]);
					EndUserDiscTcGrid.setTc_id_sec_attr(attributes[1]);
					EndUserDiscTcGrid.setTc_id_sec(attributes[2]);
					EndUserDiscTcGrid.setTc_to_sec_attr(attributes[3]);
					EndUserDiscTcGrid.setTc_to_sec(attributes[4]);
					EndUserDiscTcGrid.setTc_name_sec_attr(attributes[5]);
					EndUserDiscTcGrid.setTc_name_sec(attributes[6]);
					EndUserDiscTcGrid.setLocnum(attributes[7]);
					EndUserDiscTcGrid.setLoc_seq_num(attributes[8]);

					treeViewList106.add(EndUserDiscTcGrid);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}

			// End User 9 states
			if (subData_100Recid != null && subData_100Recid.getSubHeader().getRecord_type().equals("100")) {

				SubHeader receivedSubHeader = subData_100Recid.getSubHeader();
				String[] subDataRows = subData_100Recid.getSubDataRows();
				treeViewList.add("100");

				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 122);
					// System.out.println("attributes:=100:Reqid======> "
					// +Arrays.toString(attributes));
					EndUser_9States EndUser = new EndUser_9States();

					EndUser.setItemnum_attr(attributes[0]);
					EndUser.setItemnum(attributes[1]);
					EndUser.setItemnum1_attr(attributes[2]);
					EndUser.setItemnum1(attributes[3]);
					EndUser.setLocnum_attr(attributes[4]);
					EndUser.setLocnum(attributes[5]);
					EndUser.setLocnum1_attr(attributes[6]);
					EndUser.setLocnum1(attributes[7]);
					EndUser.setEu_name_attr(attributes[8]);
					EndUser.setEu_name(attributes[9]);
					EndUser.setEu_eatn_attr(attributes[10]);
					EndUser.setEu_eatn(attributes[11]);
					EndUser.setElt_attr(attributes[12]);
					EndUser.setElt(attributes[13]);
					EndUser.setWsop_attr(attributes[14]);
					EndUser.setWsop(attributes[15]);
					EndUser.setEu_ncon_attr(attributes[16]);
					EndUser.setEu_ncon(attributes[17]);
					EndUser.setEu_aft_attr(attributes[18]);
					EndUser.setEu_aft(attributes[19]);
					EndUser.setEu_sapr_attr(attributes[20]);
					EndUser.setEu_sapr(attributes[21]);
					EndUser.setEu_sapr1_attr(attributes[22]);
					EndUser.setEu_sapr1(attributes[23]);
					EndUser.setEu_sano_attr(attributes[24]);
					EndUser.setEu_sano(attributes[25]);
					EndUser.setEu_sano1_attr(attributes[26]);
					EndUser.setEu_sano1(attributes[27]);
					EndUser.setEu_sasf_attr(attributes[28]);
					EndUser.setEu_sasf(attributes[29]);
					EndUser.setEu_sasf1_attr(attributes[30]);
					EndUser.setEu_sasf1(attributes[31]);
					EndUser.setEu_sasd_attr(attributes[32]);
					EndUser.setEu_sasd(attributes[33]);
					EndUser.setEu_sasd1_attr(attributes[34]);
					EndUser.setEu_sasd1(attributes[35]);
					EndUser.setEu_sasn_attr(attributes[36]);
					EndUser.setEu_sasn(attributes[37]);
					EndUser.setEu_sasn1_attr(attributes[38]);
					EndUser.setEu_sasn1(attributes[39]);
					EndUser.setEu_sath_attr(attributes[40]);
					EndUser.setEu_sath(attributes[41]);
					EndUser.setEu_sath1_attr(attributes[42]);
					EndUser.setEu_sath1(attributes[43]);
					EndUser.setEu_sass_attr(attributes[44]);
					EndUser.setEu_sass(attributes[45]);
					EndUser.setEu_sass1_attr(attributes[46]);
					EndUser.setEu_sass1(attributes[47]);
					EndUser.setEu_ld1_attr(attributes[48]);
					EndUser.setEu_ld1(attributes[49]);
					EndUser.setEu_ld11_attr(attributes[50]);
					EndUser.setEu_ld11(attributes[51]);
					EndUser.setEi_lv1_attr(attributes[52]);
					EndUser.setEu_lv1(attributes[53]);
					EndUser.setEu_lv11_attr(attributes[54]);
					EndUser.setEu_lv11(attributes[55]);
					EndUser.setEu_ld2_attr(attributes[56]);
					EndUser.setEu_ld2(attributes[57]);
					EndUser.setEu_ld22_attr(attributes[58]);
					EndUser.setEu_ld22(attributes[59]);
					EndUser.setEu_lv2_attr(attributes[60]);
					EndUser.setEu_lv2(attributes[61]);
					EndUser.setEu_lv22_attr(attributes[62]);
					EndUser.setEu_lv22(attributes[63]);
					EndUser.setEu_ld3_attr(attributes[64]);
					EndUser.setEu_ld3(attributes[65]);
					EndUser.setEu_ld33_attr(attributes[66]);
					EndUser.setEu_ld33(attributes[67]);
					EndUser.setEu_lv3_attr(attributes[68]);
					EndUser.setEu_lv3(attributes[69]);
					EndUser.setEu_lv33_attr(attributes[70]);
					EndUser.setEu_lv33(attributes[71]);
					EndUser.setEu_aai_attr(attributes[72]);
					EndUser.setEu_aai(attributes[73]);
					EndUser.setEu_aai1_attr(attributes[73]);
					EndUser.setEu_aai1(attributes[75]);
					EndUser.setEu_city_attr(attributes[76]);
					EndUser.setEu_city(attributes[77]);
					EndUser.setEu_city1_attr(attributes[78]);
					EndUser.setEu_city1(attributes[79]);
					EndUser.setEu_state_attr(attributes[80]);
					EndUser.setEu_state(attributes[81]);
					EndUser.setEu_state1_attr(attributes[82]);
					EndUser.setEu_state1(attributes[83]);
					EndUser.setEu_zip_attr(attributes[84]);
					EndUser.setEu_zip(attributes[85]);
					EndUser.setEu_zip1_attr(attributes[86]);
					EndUser.setEu_zip1(attributes[87]);
					EndUser.setEu_lcon_attr(attributes[88]);
					EndUser.setEu_lcon(attributes[89]);
					EndUser.setEu_telno_attr(attributes[90]);
					EndUser.setEu_telno(attributes[91]);
					EndUser.setEu_acc_attr(attributes[92]);
					EndUser.setEu_acc(attributes[93]);
					EndUser.setCpe_mfr_attr(attributes[94]);
					EndUser.setCpe_mfr(attributes[95]);
					EndUser.setCpe_mod_attr(attributes[96]);
					EndUser.setCpe_mod(attributes[97]);
					EndUser.setLocnum_detail_attr(attributes[98]);
					EndUser.setLocnum_detail(attributes[99]);
					EndUser.setLocnum_header_attr(attributes[100]);
					EndUser.setLocnum_header(attributes[101]);
					EndUser.setEua_attr(attributes[102]);
					EndUser.setEua(attributes[103]);
					EndUser.setEan_attr(attributes[104]);
					EndUser.setEan(attributes[105]);
					EndUser.setOrdn_attr(attributes[106]);
					EndUser.setOrdn(attributes[107]);
					EndUser.setEumi_attr(attributes[108]);
					EndUser.setEumi(attributes[109]);
					EndUser.setIbt_attr(attributes[110]);
					EndUser.setIbt(attributes[111]);
					EndUser.setIwo_attr(attributes[112]);
					EndUser.setIwo(attributes[113]);
					EndUser.setIwban_attr(attributes[114]);
					EndUser.setIwban(attributes[115]);
					EndUser.setIwcon_attr(attributes[116]);
					EndUser.setIwcon(attributes[117]);
					EndUser.setTelno_iwcon_attr(attributes[118]);
					EndUser.setTelno_iwcon(attributes[119]);
					EndUser.setLoc_seq_num(attributes[120]);

					treeViewList100.add(EndUser);
				}
				selectRequestData.setSubHeader(receivedSubHeader);

				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}

			// End User Bill

			if (subData_102Recid != null && subData_102Recid.getSubHeader().getRecord_type().equals("102")) {

				SubHeader receivedSubHeader = subData_102Recid.getSubHeader();
				String[] subDataRows = subData_102Recid.getSubDataRows();
				treeViewList.add("102");

				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 30);
					// System.out.println("attributes:=102:Reqid======> "
					// +Arrays.toString(attributes));
					EndUserBill_9States EndUser = new EndUserBill_9States();

					EndUser.setFbi_attr(attributes[0]);
					EndUser.setFbi(attributes[1]);
					EndUser.setBillnm_attr(attributes[2]);
					EndUser.setBillnm(attributes[3]);
					EndUser.setSbillnm_attr(attributes[4]);
					EndUser.setSbillnm(attributes[5]);
					EndUser.setStreet_attr(attributes[6]);
					EndUser.setStreet(attributes[7]);
					EndUser.setFloor_billnm_attr(attributes[8]);
					EndUser.setFloor_billnm(attributes[9]);
					EndUser.setRoom_mail_attr(attributes[10]);
					EndUser.setRoom_mail(attributes[11]);
					EndUser.setCity_attr(attributes[12]);
					EndUser.setBill_city(attributes[13]);
					EndUser.setState_attr(attributes[14]);
					EndUser.setBill_state(attributes[15]);
					EndUser.setZip_attr(attributes[16]);
					EndUser.setBill_zip(attributes[17]);
					EndUser.setBillcon_attr(attributes[18]);
					EndUser.setBillcon(attributes[19]);
					EndUser.setTel_no_attr(attributes[20]);
					EndUser.setBill_tel_no(attributes[21]);
					EndUser.setLocnum_attr(attributes[22]);
					EndUser.setLocnum(attributes[23]);
					EndUser.setEan_attr(attributes[24]);
					EndUser.setEan(attributes[25]);
					EndUser.setEatn_attr(attributes[26]);
					EndUser.setBill_eatn(attributes[27]);
					EndUser.setLoc_seq_num(attributes[28]);

					treeViewList102.add(EndUser);
				}
				selectRequestData.setSubHeader(receivedSubHeader);

				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}

			if (subData_154Recid != null && subData_154Recid.getSubHeader().getRecord_type().equals("154")) {

				SubHeader receivedSubHeader = subData_154Recid.getSubHeader();
				String[] subDataRows = subData_154Recid.getSubDataRows();
				treeViewList.add("154");

				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 7);
					// System.out.println("attributes:=154:Reqid======> "
					// +Arrays.toString(attributes));
					LSRAdmin_Grid LSRAdmin12_grid = new LSRAdmin_Grid();

					LSRAdmin12_grid.setItem_num(attributes[0]);
					LSRAdmin12_grid.setAfa_attr(attributes[1]);
					LSRAdmin12_grid.setAfa(attributes[2]);
					LSRAdmin12_grid.setAccount_feature_attr(attributes[3]);
					LSRAdmin12_grid.setAccount_feature(attributes[4]);
					LSRAdmin12_grid.setAccount_feature_detail_attr(attributes[5]);
					LSRAdmin12_grid.setAccount_feature_detail(attributes[6]);

					treeViewList154.add(LSRAdmin12_grid);
				}
				selectRequestData.setSubHeader(receivedSubHeader);

				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}
			// Rashmita

			if (subData_802Recid != null && subData_802Recid.getSubHeader().getRecord_type().equals("802")) {
				SubHeader receivedSubHeader = subData_802Recid.getSubHeader();
				String[] subDataRows = subData_802Recid.getSubDataRows();
				List<DigitalTrunkingLoopwportDtu9st> treeViewList_802 = new ArrayList();
				treeViewList.add("802");

				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 212);

					DigitalTrunkingLoopwportDtu9st digitalTrunkingLoopwportDtu9st = new DigitalTrunkingLoopwportDtu9st();

					digitalTrunkingLoopwportDtu9st.setItem_num(attributes[0]);
					digitalTrunkingLoopwportDtu9st.setFnum_attr(attributes[1]);
					digitalTrunkingLoopwportDtu9st.setFnum(attributes[2]);
					digitalTrunkingLoopwportDtu9st.setFlna_attr(attributes[3]);
					digitalTrunkingLoopwportDtu9st.setFlna(attributes[4]);
					digitalTrunkingLoopwportDtu9st.setFecckt_attr(attributes[5]);
					digitalTrunkingLoopwportDtu9st.setFecckt(attributes[6]);
					digitalTrunkingLoopwportDtu9st.setCkr_attr(attributes[7]);
					digitalTrunkingLoopwportDtu9st.setCkr(attributes[8]);
					digitalTrunkingLoopwportDtu9st.setPri_loc_attr(attributes[9]);
					digitalTrunkingLoopwportDtu9st.setPri_loc(attributes[10]);
					digitalTrunkingLoopwportDtu9st.setEulst_attr(attributes[11]);
					digitalTrunkingLoopwportDtu9st.setEulst(attributes[12]);
					digitalTrunkingLoopwportDtu9st.setActl_attr(attributes[13]);
					digitalTrunkingLoopwportDtu9st.setActl(attributes[14]);
					digitalTrunkingLoopwportDtu9st.setCcea_attr(attributes[15]);
					digitalTrunkingLoopwportDtu9st.setCcea(attributes[16]);
					digitalTrunkingLoopwportDtu9st.setCfa_attr(attributes[17]);
					digitalTrunkingLoopwportDtu9st.setCfa(attributes[18]);
					digitalTrunkingLoopwportDtu9st.setCfa_btn_attr(attributes[19]);
					digitalTrunkingLoopwportDtu9st.setCfa_btn(attributes[20]);
					digitalTrunkingLoopwportDtu9st.setNcon_attr(attributes[21]);
					digitalTrunkingLoopwportDtu9st.setNcon(attributes[22]);
					digitalTrunkingLoopwportDtu9st.setAft_attr(attributes[23]);
					digitalTrunkingLoopwportDtu9st.setAft(attributes[24]);
					digitalTrunkingLoopwportDtu9st.setSapr_attr(attributes[25]);
					digitalTrunkingLoopwportDtu9st.setSapr(attributes[26]);
					digitalTrunkingLoopwportDtu9st.setSano_attr(attributes[27]);
					digitalTrunkingLoopwportDtu9st.setSano(attributes[28]);
					digitalTrunkingLoopwportDtu9st.setSasf_attr(attributes[29]);
					digitalTrunkingLoopwportDtu9st.setSasf(attributes[30]);
					digitalTrunkingLoopwportDtu9st.setSasd_attr(attributes[31]);
					digitalTrunkingLoopwportDtu9st.setSasd(attributes[32]);
					digitalTrunkingLoopwportDtu9st.setSasn_attr(attributes[33]);
					digitalTrunkingLoopwportDtu9st.setSasn(attributes[34]);
					digitalTrunkingLoopwportDtu9st.setSath_attr(attributes[35]);
					digitalTrunkingLoopwportDtu9st.setSath(attributes[36]);
					digitalTrunkingLoopwportDtu9st.setSass_attr(attributes[37]);
					digitalTrunkingLoopwportDtu9st.setSass(attributes[38]);
					digitalTrunkingLoopwportDtu9st.setLd1_attr(attributes[39]);
					digitalTrunkingLoopwportDtu9st.setLd1(attributes[40]);
					digitalTrunkingLoopwportDtu9st.setLv1_attr(attributes[41]);
					digitalTrunkingLoopwportDtu9st.setLv1(attributes[42]);
					digitalTrunkingLoopwportDtu9st.setLd2_attr(attributes[43]);
					digitalTrunkingLoopwportDtu9st.setLd2(attributes[44]);
					digitalTrunkingLoopwportDtu9st.setLv2_attr(attributes[45]);
					digitalTrunkingLoopwportDtu9st.setLv2(attributes[46]);
					digitalTrunkingLoopwportDtu9st.setLd3_attr(attributes[47]);
					digitalTrunkingLoopwportDtu9st.setLd3(attributes[48]);
					digitalTrunkingLoopwportDtu9st.setLv3_attr(attributes[49]);
					digitalTrunkingLoopwportDtu9st.setLv3(attributes[50]);
					digitalTrunkingLoopwportDtu9st.setAai_attr(attributes[51]);
					digitalTrunkingLoopwportDtu9st.setAai(attributes[52]);
					digitalTrunkingLoopwportDtu9st.setCity_attr(attributes[53]);
					digitalTrunkingLoopwportDtu9st.setCity(attributes[54]);
					digitalTrunkingLoopwportDtu9st.setState_attr(attributes[55]);
					digitalTrunkingLoopwportDtu9st.setState(attributes[56]);
					digitalTrunkingLoopwportDtu9st.setZip_attr(attributes[57]);
					digitalTrunkingLoopwportDtu9st.setZip(attributes[58]);
					digitalTrunkingLoopwportDtu9st.setAloc_attr(attributes[59]);
					digitalTrunkingLoopwportDtu9st.setAloc(attributes[60]);
					digitalTrunkingLoopwportDtu9st.setNidr_attr(attributes[61]);
					digitalTrunkingLoopwportDtu9st.setNidr(attributes[62]);
					digitalTrunkingLoopwportDtu9st.setIwo_attr(attributes[63]);
					digitalTrunkingLoopwportDtu9st.setIwo(attributes[64]);
					digitalTrunkingLoopwportDtu9st.setLcon_attr(attributes[65]);
					digitalTrunkingLoopwportDtu9st.setLcon(attributes[66]);
					digitalTrunkingLoopwportDtu9st.setTelno_attr(attributes[67]);
					digitalTrunkingLoopwportDtu9st.setTelno(attributes[68]);
					digitalTrunkingLoopwportDtu9st.setSecloc_attr(attributes[69]);
					digitalTrunkingLoopwportDtu9st.setSecloc(attributes[70]);
					digitalTrunkingLoopwportDtu9st.setTglnum_attr(attributes[71]);
					digitalTrunkingLoopwportDtu9st.setTglnum(attributes[72]);
					digitalTrunkingLoopwportDtu9st.setTglna_attr(attributes[73]);
					digitalTrunkingLoopwportDtu9st.setTglna(attributes[74]);
					digitalTrunkingLoopwportDtu9st.setTgn1_attr(attributes[75]);
					digitalTrunkingLoopwportDtu9st.setTgn1(attributes[76]);
					digitalTrunkingLoopwportDtu9st.setTgn2_attr(attributes[77]);
					digitalTrunkingLoopwportDtu9st.setTgn2(attributes[78]);
					digitalTrunkingLoopwportDtu9st.setTgn3_attr(attributes[79]);
					digitalTrunkingLoopwportDtu9st.setTgn3(attributes[80]);
					digitalTrunkingLoopwportDtu9st.setTgtn_attr(attributes[81]);
					digitalTrunkingLoopwportDtu9st.setTgtn(attributes[82]);
					digitalTrunkingLoopwportDtu9st.setTgtli_attr(attributes[83]);
					digitalTrunkingLoopwportDtu9st.setTgtli(attributes[84]);
					digitalTrunkingLoopwportDtu9st.setTgrti_attr(attributes[85]);
					digitalTrunkingLoopwportDtu9st.setTgrti(attributes[86]);
					digitalTrunkingLoopwportDtu9st.setTgdir_attr(attributes[87]);
					digitalTrunkingLoopwportDtu9st.setTgdir(attributes[88]);
					digitalTrunkingLoopwportDtu9st.setTgnh_attr(attributes[89]);
					digitalTrunkingLoopwportDtu9st.setTgnh(attributes[90]);
					digitalTrunkingLoopwportDtu9st.setDgout_attr(attributes[91]);
					digitalTrunkingLoopwportDtu9st.setDgout(attributes[92]);
					digitalTrunkingLoopwportDtu9st.setPic_attr(attributes[93]);
					digitalTrunkingLoopwportDtu9st.setPic(attributes[94]);
					digitalTrunkingLoopwportDtu9st.setLpic_attr(attributes[95]);
					digitalTrunkingLoopwportDtu9st.setLpic(attributes[96]);
					digitalTrunkingLoopwportDtu9st.setGlare_attr(attributes[97]);
					digitalTrunkingLoopwportDtu9st.setGlare(attributes[98]);
					digitalTrunkingLoopwportDtu9st.setTgpulse_attr(attributes[99]);
					digitalTrunkingLoopwportDtu9st.setTgpulse(attributes[100]);
					digitalTrunkingLoopwportDtu9st.setTgsgnl_attr(attributes[101]);
					digitalTrunkingLoopwportDtu9st.setTgsgnl(attributes[102]);
					digitalTrunkingLoopwportDtu9st.setDidnum_attr(attributes[103]);
					digitalTrunkingLoopwportDtu9st.setDidnum(attributes[104]);
					digitalTrunkingLoopwportDtu9st.setDidind_attr(attributes[105]);
					digitalTrunkingLoopwportDtu9st.setDidind(attributes[106]);
					digitalTrunkingLoopwportDtu9st.setDtnract_attr(attributes[107]);
					digitalTrunkingLoopwportDtu9st.setDtnract(attributes[108]);
					digitalTrunkingLoopwportDtu9st.setDtnrq_attr(attributes[109]);
					digitalTrunkingLoopwportDtu9st.setDtnrq(attributes[110]);
					digitalTrunkingLoopwportDtu9st.setDtnr1_attr(attributes[111]);
					digitalTrunkingLoopwportDtu9st.setDtnr1(attributes[112]);
					digitalTrunkingLoopwportDtu9st.setDtnr2_attr(attributes[113]);
					digitalTrunkingLoopwportDtu9st.setDtnr2(attributes[114]);
					digitalTrunkingLoopwportDtu9st.setDtnr3_attr(attributes[115]);
					digitalTrunkingLoopwportDtu9st.setDtnr3(attributes[116]);
					digitalTrunkingLoopwportDtu9st.setNpi_attr(attributes[117]);
					digitalTrunkingLoopwportDtu9st.setNpi(attributes[118]);
					digitalTrunkingLoopwportDtu9st.setDidr_attr(attributes[119]);
					digitalTrunkingLoopwportDtu9st.setDidr(attributes[120]);
					digitalTrunkingLoopwportDtu9st.setDba_attr(attributes[121]);
					digitalTrunkingLoopwportDtu9st.setDba(attributes[122]);
					digitalTrunkingLoopwportDtu9st.setDblock_attr(attributes[123]);
					digitalTrunkingLoopwportDtu9st.setDblock(attributes[124]);
					digitalTrunkingLoopwportDtu9st.setNba_attr(attributes[125]);
					digitalTrunkingLoopwportDtu9st.setNba(attributes[126]);
					digitalTrunkingLoopwportDtu9st.setNbank1_attr(attributes[127]);
					digitalTrunkingLoopwportDtu9st.setNbank1(attributes[128]);
					digitalTrunkingLoopwportDtu9st.setNbank2_attr(attributes[129]);
					digitalTrunkingLoopwportDtu9st.setNbank2(attributes[130]);
					digitalTrunkingLoopwportDtu9st.setNbank3_attr(attributes[131]);
					digitalTrunkingLoopwportDtu9st.setNbank3(attributes[132]);
					digitalTrunkingLoopwportDtu9st.setNbank4_attr(attributes[133]);
					digitalTrunkingLoopwportDtu9st.setNbank4(attributes[134]);
					digitalTrunkingLoopwportDtu9st.setDstnact_attr(attributes[135]);
					digitalTrunkingLoopwportDtu9st.setDstnact(attributes[136]);
					digitalTrunkingLoopwportDtu9st.setDstnq_attr(attributes[137]);
					digitalTrunkingLoopwportDtu9st.setDstnq(attributes[138]);
					digitalTrunkingLoopwportDtu9st.setDstn1_attr(attributes[139]);
					digitalTrunkingLoopwportDtu9st.setDstn1(attributes[140]);
					digitalTrunkingLoopwportDtu9st.setDstn2_attr(attributes[141]);
					digitalTrunkingLoopwportDtu9st.setDstn2(attributes[142]);
					digitalTrunkingLoopwportDtu9st.setDstn3_attr(attributes[143]);
					digitalTrunkingLoopwportDtu9st.setDstn3(attributes[144]);
					digitalTrunkingLoopwportDtu9st.setDstn4_attr(attributes[145]);
					digitalTrunkingLoopwportDtu9st.setDstn4(attributes[146]);
					digitalTrunkingLoopwportDtu9st.setDstn5_attr(attributes[147]);
					digitalTrunkingLoopwportDtu9st.setDstn5(attributes[148]);
					digitalTrunkingLoopwportDtu9st.setLnum_attr(attributes[149]);
					digitalTrunkingLoopwportDtu9st.setLnum(attributes[150]);
					digitalTrunkingLoopwportDtu9st.setTkind_attr(attributes[151]);
					digitalTrunkingLoopwportDtu9st.setTkind(attributes[152]);
					digitalTrunkingLoopwportDtu9st.setLna_attr(attributes[153]);
					digitalTrunkingLoopwportDtu9st.setLna(attributes[154]);
					digitalTrunkingLoopwportDtu9st.setTns_attr(attributes[155]);
					digitalTrunkingLoopwportDtu9st.setTns(attributes[156]);
					digitalTrunkingLoopwportDtu9st.setTers_attr(attributes[157]);
					digitalTrunkingLoopwportDtu9st.setTers(attributes[158]);
					digitalTrunkingLoopwportDtu9st.setOtn_attr(attributes[159]);
					digitalTrunkingLoopwportDtu9st.setOtn(attributes[160]);
					digitalTrunkingLoopwportDtu9st.setLtgn_attr(attributes[161]);
					digitalTrunkingLoopwportDtu9st.setLtgn(attributes[162]);
					digitalTrunkingLoopwportDtu9st.setEcckt_attr(attributes[163]);
					digitalTrunkingLoopwportDtu9st.setEcckt(attributes[164]);
					digitalTrunkingLoopwportDtu9st.setSsig_attr(attributes[165]);
					digitalTrunkingLoopwportDtu9st.setSsig(attributes[166]);
					digitalTrunkingLoopwportDtu9st.setBa_attr(attributes[167]);
					digitalTrunkingLoopwportDtu9st.setBa(attributes[168]);
					digitalTrunkingLoopwportDtu9st.setBlock_attr(attributes[169]);
					digitalTrunkingLoopwportDtu9st.setBlock(attributes[170]);
					digitalTrunkingLoopwportDtu9st.setCfa_trnk_attr(attributes[171]);
					digitalTrunkingLoopwportDtu9st.setCfa_trnk(attributes[172]);
					digitalTrunkingLoopwportDtu9st.setPic_trnk_attr(attributes[173]);
					digitalTrunkingLoopwportDtu9st.setPic_trnk(attributes[174]);
					digitalTrunkingLoopwportDtu9st.setLpic_trnk_attr(attributes[175]);
					digitalTrunkingLoopwportDtu9st.setLpic_trnk(attributes[176]);
					digitalTrunkingLoopwportDtu9st.setNpi_trnk_attr(attributes[177]);
					digitalTrunkingLoopwportDtu9st.setNpi_trnk(attributes[178]);
					digitalTrunkingLoopwportDtu9st.setTgtli_trnk_attr(attributes[179]);
					digitalTrunkingLoopwportDtu9st.setTgtli_trnk(attributes[180]);
					digitalTrunkingLoopwportDtu9st.setLc_attr(attributes[181]);
					digitalTrunkingLoopwportDtu9st.setLc(attributes[182]);
					digitalTrunkingLoopwportDtu9st.setFrf_attr(attributes[183]);
					digitalTrunkingLoopwportDtu9st.setFrf(attributes[184]);
					digitalTrunkingLoopwportDtu9st.setFpi_attr(attributes[185]);
					digitalTrunkingLoopwportDtu9st.setFpi(attributes[186]);
					digitalTrunkingLoopwportDtu9st.setIwjk_attr(attributes[187]);
					digitalTrunkingLoopwportDtu9st.setIwjk(attributes[188]);
					digitalTrunkingLoopwportDtu9st.setIwtq_attr(attributes[189]);
					digitalTrunkingLoopwportDtu9st.setIwtq(attributes[190]);
					digitalTrunkingLoopwportDtu9st.setIwjq_attr(attributes[191]);
					digitalTrunkingLoopwportDtu9st.setIwjq(attributes[192]);
					digitalTrunkingLoopwportDtu9st.setJkcode_attr(attributes[193]);
					digitalTrunkingLoopwportDtu9st.setJkcode(attributes[194]);
					digitalTrunkingLoopwportDtu9st.setJknum_attr(attributes[195]);
					digitalTrunkingLoopwportDtu9st.setJknum(attributes[196]);
					digitalTrunkingLoopwportDtu9st.setJkpos_attr(attributes[197]);
					digitalTrunkingLoopwportDtu9st.setJkpos(attributes[198]);
					digitalTrunkingLoopwportDtu9st.setJr_attr(attributes[199]);
					digitalTrunkingLoopwportDtu9st.setJr(attributes[200]);
					digitalTrunkingLoopwportDtu9st.setIwt_attr(attributes[201]);
					digitalTrunkingLoopwportDtu9st.setIwt(attributes[202]);
					digitalTrunkingLoopwportDtu9st.setDin_attr(attributes[203]);
					digitalTrunkingLoopwportDtu9st.setDin(attributes[204]);
					digitalTrunkingLoopwportDtu9st.setTkid_attr(attributes[205]);
					digitalTrunkingLoopwportDtu9st.setTkid(attributes[206]);
					digitalTrunkingLoopwportDtu9st.setTtp_attr(attributes[207]);
					digitalTrunkingLoopwportDtu9st.setTtp(attributes[208]);
					digitalTrunkingLoopwportDtu9st.setCableid_attr(attributes[209]);
					digitalTrunkingLoopwportDtu9st.setCableid(attributes[210]);
					digitalTrunkingLoopwportDtu9st.setLoc_seq_num(attributes[211]);

					treeViewList_802.add(digitalTrunkingLoopwportDtu9st);
				}
				session.setAttribute("treeViewList_802", treeViewList_802);
				selectRequestData.setSubHeader(receivedSubHeader);
			}

			if (subData_801Recid != null && subData_801Recid.getSubHeader().getRecord_type().equals("801")) {

				SubHeader receivedSubHeader = subData_801Recid.getSubHeader();
				String[] subDataRows = subData_801Recid.getSubDataRows();
				List<DigitalTrunkingPortDtu9st> treeViewList_801 = new ArrayList();
				treeViewList.add("801");

				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 212);

					DigitalTrunkingPortDtu9st digitalTrunkingPortDtu9st = new DigitalTrunkingPortDtu9st();

					digitalTrunkingPortDtu9st.setItem_num(attributes[0]);
					digitalTrunkingPortDtu9st.setFnum_attr(attributes[1]);
					digitalTrunkingPortDtu9st.setFnum(attributes[2]);
					digitalTrunkingPortDtu9st.setFlna_attr(attributes[3]);
					digitalTrunkingPortDtu9st.setFlna(attributes[4]);
					digitalTrunkingPortDtu9st.setFecckt_attr(attributes[5]);
					digitalTrunkingPortDtu9st.setFecckt(attributes[6]);
					digitalTrunkingPortDtu9st.setCkr_attr(attributes[7]);
					digitalTrunkingPortDtu9st.setCkr(attributes[8]);
					digitalTrunkingPortDtu9st.setPri_loc_attr(attributes[9]);
					digitalTrunkingPortDtu9st.setPri_loc(attributes[10]);
					digitalTrunkingPortDtu9st.setEulst_attr(attributes[11]);
					digitalTrunkingPortDtu9st.setEulst(attributes[12]);
					digitalTrunkingPortDtu9st.setActl_attr(attributes[13]);
					digitalTrunkingPortDtu9st.setActl(attributes[14]);
					digitalTrunkingPortDtu9st.setCcea_attr(attributes[15]);
					digitalTrunkingPortDtu9st.setCcea(attributes[16]);
					digitalTrunkingPortDtu9st.setCfa_attr(attributes[17]);
					digitalTrunkingPortDtu9st.setCfa(attributes[18]);
					digitalTrunkingPortDtu9st.setCfa_btn_attr(attributes[19]);
					digitalTrunkingPortDtu9st.setCfa_btn(attributes[20]);
					digitalTrunkingPortDtu9st.setNcon_attr(attributes[21]);
					digitalTrunkingPortDtu9st.setNcon(attributes[22]);
					digitalTrunkingPortDtu9st.setAft_attr(attributes[23]);
					digitalTrunkingPortDtu9st.setAft(attributes[24]);
					digitalTrunkingPortDtu9st.setSapr_attr(attributes[25]);
					digitalTrunkingPortDtu9st.setSapr(attributes[26]);
					digitalTrunkingPortDtu9st.setSano_attr(attributes[27]);
					digitalTrunkingPortDtu9st.setSano(attributes[28]);
					digitalTrunkingPortDtu9st.setSasf_attr(attributes[29]);
					digitalTrunkingPortDtu9st.setSasf(attributes[30]);
					digitalTrunkingPortDtu9st.setSasd_attr(attributes[31]);
					digitalTrunkingPortDtu9st.setSasd(attributes[32]);
					digitalTrunkingPortDtu9st.setSasn_attr(attributes[33]);
					digitalTrunkingPortDtu9st.setSasn(attributes[34]);
					digitalTrunkingPortDtu9st.setSath_attr(attributes[35]);
					digitalTrunkingPortDtu9st.setSath(attributes[36]);
					digitalTrunkingPortDtu9st.setSass_attr(attributes[37]);
					digitalTrunkingPortDtu9st.setSass(attributes[38]);
					digitalTrunkingPortDtu9st.setLd1_attr(attributes[39]);
					digitalTrunkingPortDtu9st.setLd1(attributes[40]);
					digitalTrunkingPortDtu9st.setLv1_attr(attributes[41]);
					digitalTrunkingPortDtu9st.setLv1(attributes[42]);
					digitalTrunkingPortDtu9st.setLd2_attr(attributes[43]);
					digitalTrunkingPortDtu9st.setLd2(attributes[44]);
					digitalTrunkingPortDtu9st.setLv2_attr(attributes[45]);
					digitalTrunkingPortDtu9st.setLv2(attributes[46]);
					digitalTrunkingPortDtu9st.setLd3_attr(attributes[47]);
					digitalTrunkingPortDtu9st.setLd3(attributes[48]);
					digitalTrunkingPortDtu9st.setLv3_attr(attributes[49]);
					digitalTrunkingPortDtu9st.setLv3(attributes[50]);
					digitalTrunkingPortDtu9st.setAai_attr(attributes[51]);
					digitalTrunkingPortDtu9st.setAai(attributes[52]);
					digitalTrunkingPortDtu9st.setCity_attr(attributes[53]);
					digitalTrunkingPortDtu9st.setCity(attributes[54]);
					digitalTrunkingPortDtu9st.setState_attr(attributes[55]);
					digitalTrunkingPortDtu9st.setState(attributes[56]);
					digitalTrunkingPortDtu9st.setZip_attr(attributes[57]);
					digitalTrunkingPortDtu9st.setZip(attributes[58]);
					digitalTrunkingPortDtu9st.setAloc_attr(attributes[59]);
					digitalTrunkingPortDtu9st.setAloc(attributes[60]);
					digitalTrunkingPortDtu9st.setNidr_attr(attributes[61]);
					digitalTrunkingPortDtu9st.setNidr(attributes[62]);
					digitalTrunkingPortDtu9st.setIwo_attr(attributes[63]);
					digitalTrunkingPortDtu9st.setIwo(attributes[64]);
					digitalTrunkingPortDtu9st.setLcon_attr(attributes[65]);
					digitalTrunkingPortDtu9st.setLcon(attributes[66]);
					digitalTrunkingPortDtu9st.setTelno_attr(attributes[67]);
					digitalTrunkingPortDtu9st.setTelno(attributes[68]);
					digitalTrunkingPortDtu9st.setSecloc_attr(attributes[69]);
					digitalTrunkingPortDtu9st.setSecloc(attributes[70]);
					digitalTrunkingPortDtu9st.setTglnum_attr(attributes[71]);
					digitalTrunkingPortDtu9st.setTglnum(attributes[72]);
					digitalTrunkingPortDtu9st.setTglna_attr(attributes[73]);
					digitalTrunkingPortDtu9st.setTglna(attributes[74]);
					digitalTrunkingPortDtu9st.setTgn1_attr(attributes[75]);
					digitalTrunkingPortDtu9st.setTgn1(attributes[76]);
					digitalTrunkingPortDtu9st.setTgn2_attr(attributes[77]);
					digitalTrunkingPortDtu9st.setTgn2(attributes[78]);
					digitalTrunkingPortDtu9st.setTgn3_attr(attributes[79]);
					digitalTrunkingPortDtu9st.setTgn3(attributes[80]);
					digitalTrunkingPortDtu9st.setTgtn_attr(attributes[81]);
					digitalTrunkingPortDtu9st.setTgtn(attributes[82]);
					digitalTrunkingPortDtu9st.setTgtli_attr(attributes[83]);
					digitalTrunkingPortDtu9st.setTgtli(attributes[84]);
					digitalTrunkingPortDtu9st.setTgrti_attr(attributes[85]);
					digitalTrunkingPortDtu9st.setTgrti(attributes[86]);
					digitalTrunkingPortDtu9st.setTgdir_attr(attributes[87]);
					digitalTrunkingPortDtu9st.setTgdir(attributes[88]);
					digitalTrunkingPortDtu9st.setTgnh_attr(attributes[89]);
					digitalTrunkingPortDtu9st.setTgnh(attributes[90]);
					digitalTrunkingPortDtu9st.setDgout_attr(attributes[91]);
					digitalTrunkingPortDtu9st.setDgout(attributes[92]);
					digitalTrunkingPortDtu9st.setPic_attr(attributes[93]);
					digitalTrunkingPortDtu9st.setPic(attributes[94]);
					digitalTrunkingPortDtu9st.setLpic_attr(attributes[95]);
					digitalTrunkingPortDtu9st.setLpic(attributes[96]);
					digitalTrunkingPortDtu9st.setGlare_attr(attributes[97]);
					digitalTrunkingPortDtu9st.setGlare(attributes[98]);
					digitalTrunkingPortDtu9st.setTgpulse_attr(attributes[99]);
					digitalTrunkingPortDtu9st.setTgpulse(attributes[100]);
					digitalTrunkingPortDtu9st.setTgsgnl_attr(attributes[101]);
					digitalTrunkingPortDtu9st.setTgsgnl(attributes[102]);
					digitalTrunkingPortDtu9st.setDidnum_attr(attributes[103]);
					digitalTrunkingPortDtu9st.setDidnum(attributes[104]);
					digitalTrunkingPortDtu9st.setDidind_attr(attributes[105]);
					digitalTrunkingPortDtu9st.setDidind(attributes[106]);
					digitalTrunkingPortDtu9st.setDtnract_attr(attributes[107]);
					digitalTrunkingPortDtu9st.setDtnract(attributes[108]);
					digitalTrunkingPortDtu9st.setDtnrq_attr(attributes[109]);
					digitalTrunkingPortDtu9st.setDtnrq(attributes[110]);
					digitalTrunkingPortDtu9st.setDtnr1_attr(attributes[111]);
					digitalTrunkingPortDtu9st.setDtnr1(attributes[112]);
					digitalTrunkingPortDtu9st.setDtnr2_attr(attributes[113]);
					digitalTrunkingPortDtu9st.setDtnr2(attributes[114]);
					digitalTrunkingPortDtu9st.setDtnr3_attr(attributes[115]);
					digitalTrunkingPortDtu9st.setDtnr3(attributes[116]);
					digitalTrunkingPortDtu9st.setNpi_attr(attributes[117]);
					digitalTrunkingPortDtu9st.setNpi(attributes[118]);
					digitalTrunkingPortDtu9st.setDidr_attr(attributes[119]);
					digitalTrunkingPortDtu9st.setDidr(attributes[120]);
					digitalTrunkingPortDtu9st.setDba_attr(attributes[121]);
					digitalTrunkingPortDtu9st.setDba(attributes[122]);
					digitalTrunkingPortDtu9st.setDblock_attr(attributes[123]);
					digitalTrunkingPortDtu9st.setDblock(attributes[124]);
					digitalTrunkingPortDtu9st.setNba_attr(attributes[125]);
					digitalTrunkingPortDtu9st.setNba(attributes[126]);
					digitalTrunkingPortDtu9st.setNbank1_attr(attributes[127]);
					digitalTrunkingPortDtu9st.setNbank1(attributes[128]);
					digitalTrunkingPortDtu9st.setNbank2_attr(attributes[129]);
					digitalTrunkingPortDtu9st.setNbank2(attributes[130]);
					digitalTrunkingPortDtu9st.setNbank3_attr(attributes[131]);
					digitalTrunkingPortDtu9st.setNbank3(attributes[132]);
					digitalTrunkingPortDtu9st.setNbank4_attr(attributes[133]);
					digitalTrunkingPortDtu9st.setNbank4(attributes[134]);
					digitalTrunkingPortDtu9st.setDstnact_attr(attributes[135]);
					digitalTrunkingPortDtu9st.setDstnact(attributes[136]);
					digitalTrunkingPortDtu9st.setDstnq_attr(attributes[137]);
					digitalTrunkingPortDtu9st.setDstnq(attributes[138]);
					digitalTrunkingPortDtu9st.setDstn1_attr(attributes[139]);
					digitalTrunkingPortDtu9st.setDstn1(attributes[140]);
					digitalTrunkingPortDtu9st.setDstn2_attr(attributes[141]);
					digitalTrunkingPortDtu9st.setDstn2(attributes[142]);
					digitalTrunkingPortDtu9st.setDstn3_attr(attributes[143]);
					digitalTrunkingPortDtu9st.setDstn3(attributes[144]);
					digitalTrunkingPortDtu9st.setDstn4_attr(attributes[145]);
					digitalTrunkingPortDtu9st.setDstn4(attributes[146]);
					digitalTrunkingPortDtu9st.setDstn5_attr(attributes[147]);
					digitalTrunkingPortDtu9st.setDstn5(attributes[148]);
					digitalTrunkingPortDtu9st.setLnum_attr(attributes[149]);
					digitalTrunkingPortDtu9st.setLnum(attributes[150]);
					digitalTrunkingPortDtu9st.setTkind_attr(attributes[151]);
					digitalTrunkingPortDtu9st.setTkind(attributes[152]);
					digitalTrunkingPortDtu9st.setLna_attr(attributes[153]);
					digitalTrunkingPortDtu9st.setLna(attributes[154]);
					digitalTrunkingPortDtu9st.setTns_attr(attributes[155]);
					digitalTrunkingPortDtu9st.setTns(attributes[156]);
					digitalTrunkingPortDtu9st.setTers_attr(attributes[157]);
					digitalTrunkingPortDtu9st.setTers(attributes[158]);
					digitalTrunkingPortDtu9st.setOtn_attr(attributes[159]);
					digitalTrunkingPortDtu9st.setOtn(attributes[160]);
					digitalTrunkingPortDtu9st.setLtgn_attr(attributes[161]);
					digitalTrunkingPortDtu9st.setLtgn(attributes[162]);
					digitalTrunkingPortDtu9st.setEcckt_attr(attributes[163]);
					digitalTrunkingPortDtu9st.setEcckt(attributes[164]);
					digitalTrunkingPortDtu9st.setSsig_attr(attributes[165]);
					digitalTrunkingPortDtu9st.setSsig(attributes[166]);
					digitalTrunkingPortDtu9st.setBa_attr(attributes[167]);
					digitalTrunkingPortDtu9st.setBa(attributes[168]);
					digitalTrunkingPortDtu9st.setBlock_attr(attributes[169]);
					digitalTrunkingPortDtu9st.setBlock(attributes[170]);
					digitalTrunkingPortDtu9st.setCfa_trnk_attr(attributes[171]);
					digitalTrunkingPortDtu9st.setCfa_trnk(attributes[172]);
					digitalTrunkingPortDtu9st.setPic_trnk_attr(attributes[173]);
					digitalTrunkingPortDtu9st.setPic_trnk(attributes[174]);
					digitalTrunkingPortDtu9st.setLpic_trnk_attr(attributes[175]);
					digitalTrunkingPortDtu9st.setLpic_trnk(attributes[176]);
					digitalTrunkingPortDtu9st.setNpi_trnk_attr(attributes[177]);
					digitalTrunkingPortDtu9st.setNpi_trnk(attributes[178]);
					digitalTrunkingPortDtu9st.setTgtli_trnk_attr(attributes[179]);
					digitalTrunkingPortDtu9st.setTgtli_trnk(attributes[180]);
					digitalTrunkingPortDtu9st.setLc_attr(attributes[181]);
					digitalTrunkingPortDtu9st.setLc(attributes[182]);
					digitalTrunkingPortDtu9st.setFrf_attr(attributes[183]);
					digitalTrunkingPortDtu9st.setFrf(attributes[184]);
					digitalTrunkingPortDtu9st.setFpi_attr(attributes[185]);
					digitalTrunkingPortDtu9st.setFpi(attributes[186]);
					digitalTrunkingPortDtu9st.setIwjk_attr(attributes[187]);
					digitalTrunkingPortDtu9st.setIwjk(attributes[188]);
					digitalTrunkingPortDtu9st.setIwtq_attr(attributes[189]);
					digitalTrunkingPortDtu9st.setIwtq(attributes[190]);
					digitalTrunkingPortDtu9st.setIwjq_attr(attributes[191]);
					digitalTrunkingPortDtu9st.setIwjq(attributes[192]);
					digitalTrunkingPortDtu9st.setJkcode_attr(attributes[193]);
					digitalTrunkingPortDtu9st.setJkcode(attributes[194]);
					digitalTrunkingPortDtu9st.setJknum_attr(attributes[195]);
					digitalTrunkingPortDtu9st.setJknum(attributes[196]);
					digitalTrunkingPortDtu9st.setJkpos_attr(attributes[197]);
					digitalTrunkingPortDtu9st.setJkpos(attributes[198]);
					digitalTrunkingPortDtu9st.setJr_attr(attributes[199]);
					digitalTrunkingPortDtu9st.setJr(attributes[200]);
					digitalTrunkingPortDtu9st.setIwt_attr(attributes[201]);
					digitalTrunkingPortDtu9st.setIwt(attributes[202]);
					digitalTrunkingPortDtu9st.setDin_attr(attributes[203]);
					digitalTrunkingPortDtu9st.setDin(attributes[204]);
					digitalTrunkingPortDtu9st.setTkid_attr(attributes[205]);
					digitalTrunkingPortDtu9st.setTkid(attributes[206]);
					digitalTrunkingPortDtu9st.setTtp_attr(attributes[207]);
					digitalTrunkingPortDtu9st.setTtp(attributes[208]);
					digitalTrunkingPortDtu9st.setCableid_attr(attributes[209]);
					digitalTrunkingPortDtu9st.setCableid(attributes[210]);
					digitalTrunkingPortDtu9st.setLoc_seq_num(attributes[211]);

					treeViewList_801.add(digitalTrunkingPortDtu9st);
				}
				session.setAttribute("treeViewList_801", treeViewList_801);
				selectRequestData.setSubHeader(receivedSubHeader);
			}

//supriya

			if (subData_800Recid != null && subData_800Recid.getSubHeader().getRecord_type().equals("800")) {

				SubHeader receivedSubHeader = subData_800Recid.getSubHeader();
				String[] subDataRows = subData_800Recid.getSubDataRows();
				List<DigitalTrunkingResaleData9> treeViewList_800 = new ArrayList();
				treeViewList.add("800");

				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 212);
					// System.out.println("attributes:=800:Reqid======> " +
					// Arrays.toString(attributes));
					// DigitalTrunkingResaleData12 digitalTrunkingResaleData12= new
					// DigitalTrunkingResaleData12();

					DigitalTrunkingResaleData9 digitalTrunkingResaleData9 = new DigitalTrunkingResaleData9();

					digitalTrunkingResaleData9.setItem_num(attributes[0]);
					digitalTrunkingResaleData9.setFnum_attr(attributes[1]);
					digitalTrunkingResaleData9.setFnum(attributes[2]);
					digitalTrunkingResaleData9.setFlna_attr(attributes[3]);
					digitalTrunkingResaleData9.setFlna(attributes[4]);
					digitalTrunkingResaleData9.setFecckt_attr(attributes[5]);
					digitalTrunkingResaleData9.setFecckt(attributes[6]);
					digitalTrunkingResaleData9.setCkr_attr(attributes[7]);
					digitalTrunkingResaleData9.setCkr(attributes[8]);
					digitalTrunkingResaleData9.setPri_loc_attr(attributes[9]);
					digitalTrunkingResaleData9.setPri_loc(attributes[10]);
					digitalTrunkingResaleData9.setEulst_attr(attributes[11]);
					digitalTrunkingResaleData9.setEulst(attributes[12]);
					digitalTrunkingResaleData9.setActl_attr(attributes[13]);
					digitalTrunkingResaleData9.setActl(attributes[14]);
					digitalTrunkingResaleData9.setCcea_attr(attributes[15]);
					digitalTrunkingResaleData9.setCcea(attributes[16]);
					digitalTrunkingResaleData9.setCfa_attr(attributes[17]);
					digitalTrunkingResaleData9.setCfa(attributes[18]);
					digitalTrunkingResaleData9.setCfa_btn_attr(attributes[19]);
					digitalTrunkingResaleData9.setCfa_btn(attributes[20]);
					digitalTrunkingResaleData9.setNcon_attr(attributes[21]);
					digitalTrunkingResaleData9.setNcon(attributes[22]);
					digitalTrunkingResaleData9.setAft_attr(attributes[23]);
					digitalTrunkingResaleData9.setAft(attributes[24]);
					digitalTrunkingResaleData9.setSapr_attr(attributes[25]);
					digitalTrunkingResaleData9.setSapr(attributes[26]);
					digitalTrunkingResaleData9.setSano_attr(attributes[27]);
					digitalTrunkingResaleData9.setSano(attributes[28]);
					digitalTrunkingResaleData9.setSasf_attr(attributes[29]);
					digitalTrunkingResaleData9.setSasf(attributes[30]);
					digitalTrunkingResaleData9.setSasd_attr(attributes[31]);
					digitalTrunkingResaleData9.setSasd(attributes[32]);
					digitalTrunkingResaleData9.setSasn_attr(attributes[33]);
					digitalTrunkingResaleData9.setSasn(attributes[34]);
					digitalTrunkingResaleData9.setSath_attr(attributes[35]);
					digitalTrunkingResaleData9.setSath(attributes[36]);
					digitalTrunkingResaleData9.setSass_attr(attributes[37]);
					digitalTrunkingResaleData9.setSass(attributes[38]);
					digitalTrunkingResaleData9.setLd1_attr(attributes[39]);
					digitalTrunkingResaleData9.setLd1(attributes[40]);
					digitalTrunkingResaleData9.setLv1_attr(attributes[41]);
					digitalTrunkingResaleData9.setLv1(attributes[42]);
					digitalTrunkingResaleData9.setLd2_attr(attributes[43]);
					digitalTrunkingResaleData9.setLd2(attributes[44]);
					digitalTrunkingResaleData9.setLv2_attr(attributes[45]);
					digitalTrunkingResaleData9.setLv2(attributes[46]);
					digitalTrunkingResaleData9.setLd3_attr(attributes[47]);
					digitalTrunkingResaleData9.setLd3(attributes[48]);
					digitalTrunkingResaleData9.setLv3_attr(attributes[49]);
					digitalTrunkingResaleData9.setLv3(attributes[50]);
					digitalTrunkingResaleData9.setAai_attr(attributes[51]);
					digitalTrunkingResaleData9.setAai(attributes[52]);
					digitalTrunkingResaleData9.setCity_attr(attributes[53]);
					digitalTrunkingResaleData9.setCity(attributes[54]);
					digitalTrunkingResaleData9.setState_attr(attributes[55]);
					digitalTrunkingResaleData9.setState(attributes[56]);
					digitalTrunkingResaleData9.setZip_attr(attributes[57]);
					digitalTrunkingResaleData9.setZip(attributes[58]);
					digitalTrunkingResaleData9.setAloc_attr(attributes[59]);
					digitalTrunkingResaleData9.setAloc(attributes[60]);
					digitalTrunkingResaleData9.setNidr_attr(attributes[61]);
					digitalTrunkingResaleData9.setNidr(attributes[62]);
					digitalTrunkingResaleData9.setIwo_attr(attributes[63]);
					digitalTrunkingResaleData9.setIwo(attributes[64]);
					digitalTrunkingResaleData9.setLcon_attr(attributes[65]);
					digitalTrunkingResaleData9.setLcon(attributes[66]);
					digitalTrunkingResaleData9.setTelno_attr(attributes[67]);
					digitalTrunkingResaleData9.setTelno(attributes[68]);
					digitalTrunkingResaleData9.setSecloc_attr(attributes[69]);
					digitalTrunkingResaleData9.setSecloc(attributes[70]);
					digitalTrunkingResaleData9.setTglnum_attr(attributes[71]);
					digitalTrunkingResaleData9.setTglnum(attributes[72]);
					digitalTrunkingResaleData9.setTglna_attr(attributes[73]);
					digitalTrunkingResaleData9.setTglna(attributes[74]);
					digitalTrunkingResaleData9.setTgn1_attr(attributes[75]);
					digitalTrunkingResaleData9.setTgn1(attributes[76]);
					digitalTrunkingResaleData9.setTgn2_attr(attributes[77]);
					digitalTrunkingResaleData9.setTgn2(attributes[78]);
					digitalTrunkingResaleData9.setTgn3_attr(attributes[79]);
					digitalTrunkingResaleData9.setTgn3(attributes[80]);
					digitalTrunkingResaleData9.setTgtn_attr(attributes[81]);
					digitalTrunkingResaleData9.setTgtn(attributes[82]);
					digitalTrunkingResaleData9.setTgtli_attr(attributes[83]);
					digitalTrunkingResaleData9.setTgtli(attributes[84]);
					digitalTrunkingResaleData9.setTgrti_attr(attributes[85]);
					digitalTrunkingResaleData9.setTgrti(attributes[86]);
					digitalTrunkingResaleData9.setTgdir_attr(attributes[87]);
					digitalTrunkingResaleData9.setTgdir(attributes[88]);
					digitalTrunkingResaleData9.setTgnh_attr(attributes[89]);
					digitalTrunkingResaleData9.setTgnh(attributes[90]);
					digitalTrunkingResaleData9.setDgout_attr(attributes[91]);
					digitalTrunkingResaleData9.setDgout(attributes[92]);
					digitalTrunkingResaleData9.setPic_attr(attributes[93]);
					digitalTrunkingResaleData9.setPic(attributes[94]);
					digitalTrunkingResaleData9.setLpic_attr(attributes[95]);
					digitalTrunkingResaleData9.setLpic(attributes[96]);
					digitalTrunkingResaleData9.setGlare_attr(attributes[97]);
					digitalTrunkingResaleData9.setGlare(attributes[98]);
					digitalTrunkingResaleData9.setTgpulse_attr(attributes[99]);
					digitalTrunkingResaleData9.setTgpulse(attributes[100]);
					digitalTrunkingResaleData9.setTgsgnl_attr(attributes[101]);
					digitalTrunkingResaleData9.setTgsgnl(attributes[102]);
					digitalTrunkingResaleData9.setDidnum_attr(attributes[103]);
					digitalTrunkingResaleData9.setDidnum(attributes[104]);
					digitalTrunkingResaleData9.setDidind_attr(attributes[105]);
					digitalTrunkingResaleData9.setDidind(attributes[106]);
					digitalTrunkingResaleData9.setDtnract_attr(attributes[107]);
					digitalTrunkingResaleData9.setDtnract(attributes[108]);
					digitalTrunkingResaleData9.setDtnrq_attr(attributes[109]);
					digitalTrunkingResaleData9.setDtnrq(attributes[110]);
					digitalTrunkingResaleData9.setDtnr1_attr(attributes[111]);
					digitalTrunkingResaleData9.setDtnr1(attributes[112]);
					digitalTrunkingResaleData9.setDtnr2_attr(attributes[113]);
					digitalTrunkingResaleData9.setDtnr2(attributes[114]);
					digitalTrunkingResaleData9.setDtnr3_attr(attributes[115]);
					digitalTrunkingResaleData9.setDtnr3(attributes[116]);
					digitalTrunkingResaleData9.setNpi_attr(attributes[117]);
					digitalTrunkingResaleData9.setNpi(attributes[118]);
					digitalTrunkingResaleData9.setDidr_attr(attributes[119]);
					digitalTrunkingResaleData9.setDidr(attributes[120]);
					digitalTrunkingResaleData9.setDba_attr(attributes[121]);
					digitalTrunkingResaleData9.setDba(attributes[122]);
					digitalTrunkingResaleData9.setDblock_attr(attributes[123]);
					digitalTrunkingResaleData9.setDblock(attributes[124]);
					digitalTrunkingResaleData9.setNba_attr(attributes[125]);
					digitalTrunkingResaleData9.setNba(attributes[126]);
					digitalTrunkingResaleData9.setNbank1_attr(attributes[127]);
					digitalTrunkingResaleData9.setNbank1(attributes[128]);
					digitalTrunkingResaleData9.setNbank2_attr(attributes[129]);
					digitalTrunkingResaleData9.setNbank2(attributes[130]);
					digitalTrunkingResaleData9.setNbank3_attr(attributes[131]);
					digitalTrunkingResaleData9.setNbank3(attributes[132]);
					digitalTrunkingResaleData9.setNbank4_attr(attributes[133]);
					digitalTrunkingResaleData9.setNbank4(attributes[134]);
					digitalTrunkingResaleData9.setDstnact_attr(attributes[135]);
					digitalTrunkingResaleData9.setDstnact(attributes[136]);
					digitalTrunkingResaleData9.setDstnq_attr(attributes[137]);
					digitalTrunkingResaleData9.setDstnq(attributes[138]);
					digitalTrunkingResaleData9.setDstn1_attr(attributes[139]);
					digitalTrunkingResaleData9.setDstn1(attributes[140]);
					digitalTrunkingResaleData9.setDstn2_attr(attributes[141]);
					digitalTrunkingResaleData9.setDstn2(attributes[142]);
					digitalTrunkingResaleData9.setDstn3_attr(attributes[143]);
					digitalTrunkingResaleData9.setDstn3(attributes[144]);
					digitalTrunkingResaleData9.setDstn4_attr(attributes[145]);
					digitalTrunkingResaleData9.setDstn4(attributes[146]);
					digitalTrunkingResaleData9.setDstn5_attr(attributes[147]);
					digitalTrunkingResaleData9.setDstn5(attributes[148]);
					digitalTrunkingResaleData9.setLnum_attr(attributes[149]);
					digitalTrunkingResaleData9.setLnum(attributes[150]);
					digitalTrunkingResaleData9.setTkind_attr(attributes[151]);
					digitalTrunkingResaleData9.setTkind(attributes[152]);
					digitalTrunkingResaleData9.setLna_attr(attributes[153]);
					digitalTrunkingResaleData9.setLna(attributes[154]);
					digitalTrunkingResaleData9.setTns_attr(attributes[155]);
					digitalTrunkingResaleData9.setTns(attributes[156]);
					digitalTrunkingResaleData9.setTers_attr(attributes[157]);
					digitalTrunkingResaleData9.setTers(attributes[158]);
					digitalTrunkingResaleData9.setOtn_attr(attributes[159]);
					digitalTrunkingResaleData9.setOtn(attributes[160]);
					digitalTrunkingResaleData9.setLtgn_attr(attributes[161]);
					digitalTrunkingResaleData9.setLtgn(attributes[162]);
					digitalTrunkingResaleData9.setEcckt_attr(attributes[163]);
					digitalTrunkingResaleData9.setEcckt(attributes[164]);
					digitalTrunkingResaleData9.setSsig_attr(attributes[165]);
					digitalTrunkingResaleData9.setSsig(attributes[166]);
					digitalTrunkingResaleData9.setBa_attr(attributes[167]);
					digitalTrunkingResaleData9.setBa(attributes[168]);
					digitalTrunkingResaleData9.setBlock_attr(attributes[169]);
					digitalTrunkingResaleData9.setBlock(attributes[170]);
					digitalTrunkingResaleData9.setCfa_trnk_attr(attributes[171]);
					digitalTrunkingResaleData9.setCfa_trnk(attributes[172]);
					digitalTrunkingResaleData9.setPic_trnk_attr(attributes[173]);
					digitalTrunkingResaleData9.setPic_trnk(attributes[174]);
					digitalTrunkingResaleData9.setLpic_trnk_attr(attributes[175]);
					digitalTrunkingResaleData9.setLpic_trnk(attributes[176]);
					digitalTrunkingResaleData9.setNpi_trnk_attr(attributes[177]);
					digitalTrunkingResaleData9.setNpi_trnk(attributes[178]);
					digitalTrunkingResaleData9.setTgtli_trnk_attr(attributes[179]);
					digitalTrunkingResaleData9.setTgtli_trnk(attributes[180]);
					digitalTrunkingResaleData9.setLc_attr(attributes[181]);
					digitalTrunkingResaleData9.setLc(attributes[182]);
					digitalTrunkingResaleData9.setFrf_attr(attributes[183]);
					digitalTrunkingResaleData9.setFrf(attributes[184]);
					digitalTrunkingResaleData9.setFpi_attr(attributes[185]);
					digitalTrunkingResaleData9.setFpi(attributes[186]);
					digitalTrunkingResaleData9.setIwjk_attr(attributes[187]);
					digitalTrunkingResaleData9.setIwjk(attributes[188]);
					digitalTrunkingResaleData9.setIwtq_attr(attributes[189]);
					digitalTrunkingResaleData9.setIwtq(attributes[190]);
					digitalTrunkingResaleData9.setIwjq_attr(attributes[191]);
					digitalTrunkingResaleData9.setIwjq(attributes[192]);
					digitalTrunkingResaleData9.setJkcode_attr(attributes[193]);
					digitalTrunkingResaleData9.setJkcode(attributes[194]);
					digitalTrunkingResaleData9.setJknum_attr(attributes[195]);
					digitalTrunkingResaleData9.setJknum(attributes[196]);
					digitalTrunkingResaleData9.setJkpos_attr(attributes[197]);
					digitalTrunkingResaleData9.setJkpos(attributes[198]);
					digitalTrunkingResaleData9.setJr_attr(attributes[199]);
					digitalTrunkingResaleData9.setJr(attributes[200]);
					digitalTrunkingResaleData9.setIwt_attr(attributes[201]);
					digitalTrunkingResaleData9.setIwt(attributes[202]);
					digitalTrunkingResaleData9.setDin_attr(attributes[203]);
					digitalTrunkingResaleData9.setDin(attributes[204]);
					digitalTrunkingResaleData9.setTkid_attr(attributes[205]);
					digitalTrunkingResaleData9.setTkid(attributes[206]);
					digitalTrunkingResaleData9.setTtp_attr(attributes[207]);
					digitalTrunkingResaleData9.setTtp(attributes[208]);
					digitalTrunkingResaleData9.setCableid_attr(attributes[209]);
					digitalTrunkingResaleData9.setCableid(attributes[210]);
					digitalTrunkingResaleData9.setLoc_seq_num(attributes[211]);

					treeViewList_800.add(digitalTrunkingResaleData9);
				}
				session.setAttribute("treeViewList_800", treeViewList_800);
				selectRequestData.setSubHeader(receivedSubHeader);
			}
			// sneha
			if (subData9_585Recid != null && subData9_585Recid.getSubHeader().getRecord_type().equals("585")) {
				SubHeader receivedSubHeader = subData9_585Recid.getSubHeader();
				String[] subDataRows = subData9_585Recid.getSubDataRows();
				List<PostToBillTask_RecId585> treeViewList_585 = new ArrayList();
				treeViewList.add("585");
				String lsrNo = "";
				String status="";
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 12);
//					System.out.println("attributes:=585======> " + Arrays.toString(attributes));
					PostToBillTask_RecId585 noteFupData = new PostToBillTask_RecId585();
					noteFupData.setC_ver_attr(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
					noteFupData.setC_ver(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
					noteFupData.setRt_attr(attributes[2] != null && attributes[2] != "" ? attributes[2] : " "); //Not getting data...!
					noteFupData.setRt(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
					noteFupData.setEc_ver_attr(attributes[4] != null && attributes[4] != "" ? attributes[4] : " ");
					noteFupData.setEc_ver(attributes[5] != null && attributes[5] != "" ? attributes[5] : " ");
					noteFupData.setDt_sent_local_attr(attributes[6] != null && attributes[6] != "" ? attributes[6] : " ");
					noteFupData.setDt_sent_local(attributes[7] != null && attributes[7] != "" ? attributes[7] : " ");
					
					noteFupData.setResponse_dt_sent_attr(attributes[8] != null && attributes[8] != "" ? attributes[8] : " ");
					noteFupData.setResponse_dt_sent(attributes[9] != null && attributes[9] != "" ? attributes[9] : " ");
					noteFupData.setPd_attr(attributes[10] != null && attributes[10] != "" ? attributes[10] : " ");
					noteFupData.setPd(attributes[11] != null && attributes[11] != "" ? attributes[11] : " ");
					
					treeViewList_585.add(noteFupData);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				session.setAttribute("treeViewList_585", treeViewList_585);
			//	model.addAttribute("treeViewList_558", treeViewList_558);	
				System.out.println("Model get Attribute  " );
			}
			
			
			if (subData9_588Recid != null && subData9_588Recid.getSubHeader().getRecord_type().equals("588")) {
				SubHeader receivedSubHeader = subData9_588Recid.getSubHeader();
				String[] subDataRows = subData9_588Recid.getSubDataRows();
				List<PostToBillTaskLSCInfo_588> treeViewList_588 = new ArrayList();
				treeViewList.add("588");
				String lsrNo = "";
				String status="";
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);
//					System.out.println("attributes:=588======> " + Arrays.toString(attributes));
					PostToBillTaskLSCInfo_588 noteFupData = new PostToBillTaskLSCInfo_588();
					noteFupData.setOld_dtm(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
					noteFupData.setOld_ord(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
					noteFupData.setOrd_attr(attributes[2] != null && attributes[2] != "" ? attributes[2] : " "); //Not getting data...!
					noteFupData.setOrd(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
					noteFupData.setFdt_attr(attributes[4] != null && attributes[4] != "" ? attributes[4] : " ");
					noteFupData.setFdt(attributes[5] != null && attributes[5] != "" ? attributes[5] : " ");
					noteFupData.setDd_attr(attributes[6] != null && attributes[6] != "" ? attributes[6] : " ");
					noteFupData.setDd(attributes[7] != null && attributes[7] != "" ? attributes[7] : " ");
					
					noteFupData.setComp_dt_attr(attributes[8] != null && attributes[8] != "" ? attributes[8] : " ");
					noteFupData.setComp_dt(attributes[9] != null && attributes[9] != "" ? attributes[9] : " ");
					noteFupData.setPosted_date_attr(attributes[10] != null && attributes[10] != "" ? attributes[10] : " ");
					noteFupData.setPosted_date(attributes[11] != null && attributes[11] != "" ? attributes[11] : " ");
					noteFupData.setApptime_attr(attributes[12] != null && attributes[12] != "" ? attributes[12] : " ");
					noteFupData.setApptime(attributes[13] != null && attributes[13] != "" ? attributes[13] : " ");
					
					treeViewList_588.add(noteFupData);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				session.setAttribute("treeViewList_588", treeViewList_588);
			//	model.addAttribute("treeViewList_558", treeViewList_558);	
				System.out.println("Model get Attribute  " );
			}
			
			//=======================Sneha End======================================

			if (subData_683Recid != null && subData_683Recid.getSubHeader().getRecord_type().equals("683")) {

				SubHeader receivedSubHeader = subData_683Recid.getSubHeader();
				String[] subDataRows = subData_683Recid.getSubDataRows();
				List<CentrexResaleCommonBlockSectionDW1Data9> treeViewList9_683 = new ArrayList();
				treeViewList.add("683");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 2);
					// System.out.println("attributes9:=683:Reqid======> " +
					// Arrays.toString(attributes));
					CentrexResaleCommonBlockSectionDW1Data9 centrexResaleCommonBlockSection9 = new CentrexResaleCommonBlockSectionDW1Data9();

					centrexResaleCommonBlockSection9.setCb_attr(attributes[0]);
					centrexResaleCommonBlockSection9.setCb(attributes[1]);
					// System.out.println(centrexResaleCommonBlockSection9);

					treeViewList9_683.add(centrexResaleCommonBlockSection9);

					// treeViewList.add(centrexResaleCommonBlockSectionDW1DATA12);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				session.setAttribute("treeViewList9_683", treeViewList9_683);

			}

			if (subData_684Recid != null && subData_684Recid.getSubHeader().getRecord_type().equals("684")) {

				SubHeader receivedSubHeader = subData_684Recid.getSubHeader();
				String[] subDataRows = subData_684Recid.getSubDataRows();
				List<CentrexResaleCommonBlockSection_DW2Data9> treeViewList9_684 = new ArrayList();
				treeViewList.add("684");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 12);
					// System.out.println("attributes 9:=684:Reqid======> " +
					// Arrays.toString(attributes));
					CentrexResaleCommonBlockSection_DW2Data9 centrexResaleCommonBlockSection2 = new CentrexResaleCommonBlockSection_DW2Data9();

					centrexResaleCommonBlockSection2.setSna_attr(attributes[0]);

					centrexResaleCommonBlockSection2.setSna(attributes[1]);

					centrexResaleCommonBlockSection2.setSn_attr(attributes[2]);

					centrexResaleCommonBlockSection2.setSn(attributes[3]);
					centrexResaleCommonBlockSection2.setSt_attr(attributes[4]);
					centrexResaleCommonBlockSection2.setSt(attributes[5]);
					centrexResaleCommonBlockSection2.setCpgq_attr(attributes[6]);
					centrexResaleCommonBlockSection2.setCpgq(attributes[7]);
					centrexResaleCommonBlockSection2.setCpg_attr(attributes[8]);
					centrexResaleCommonBlockSection2.setCpg(attributes[9]);
					centrexResaleCommonBlockSection2.setCpgn_attr(attributes[10]);
					centrexResaleCommonBlockSection2.setCpgn(attributes[11]);

					treeViewList9_684.add(centrexResaleCommonBlockSection2);

					// treeViewList.add(centrexResaleCommonBlockSection_DW2Data12);
				}
				session.setAttribute("treeViewList_684", treeViewList9_684);
				selectRequestData.setSubHeader(receivedSubHeader);

			}

			if (subData_681Recid != null && subData_681Recid.getSubHeader().getRecord_type().equals("681")) {

				SubHeader receivedSubHeader = subData_681Recid.getSubHeader();
				String[] subDataRows = subData_681Recid.getSubDataRows();
				List<CentrexPort_CUS_Station_9StateData> treeViewList_681 = new ArrayList();
				treeViewList.add("681");

				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 128);
					// System.out.println("attributes 9:=681:Reqid======> " +
					// Arrays.toString(attributes));
					CentrexPort_CUS_Station_9StateData centrexPortStation9 = new CentrexPort_CUS_Station_9StateData();

					centrexPortStation9.setItem_num(attributes[0]);
					centrexPortStation9.setLnum_attr(attributes[1]);
					centrexPortStation9.setLnum(attributes[2]);
					centrexPortStation9.setLna_attr(attributes[3]);
					centrexPortStation9.setLna(attributes[4]);
					centrexPortStation9.setNpi_attr(attributes[5]);
					centrexPortStation9.setNpi(attributes[6]);
					centrexPortStation9.setLst_attr(attributes[7]);
					centrexPortStation9.setLst(attributes[8]);
					centrexPortStation9.setTns_attr(attributes[9]);
					centrexPortStation9.setTns(attributes[10]);
					centrexPortStation9.setTers_attr(attributes[11]);
					centrexPortStation9.setTers(attributes[12]);
					centrexPortStation9.setOtn_attr(attributes[13]);
					centrexPortStation9.setOtn(attributes[14]);
					centrexPortStation9.setIspid_attr(attributes[15]);
					centrexPortStation9.setIspid(attributes[16]);
					centrexPortStation9.setIsdnp_attr(attributes[17]);
					centrexPortStation9.setIsdnp(attributes[18]);
					centrexPortStation9.setEcckt_attr(attributes[19]);
					centrexPortStation9.setEcckt(attributes[20]);
					centrexPortStation9.setCfa_attr(attributes[21]);
					centrexPortStation9.setCfa(attributes[22]);
					centrexPortStation9.setCcea_attr(attributes[23]);
					centrexPortStation9.setCcea(attributes[24]);
					centrexPortStation9.setCkr_attr(attributes[25]);
					centrexPortStation9.setCkr(attributes[26]);
					centrexPortStation9.setPic_attr(attributes[27]);
					centrexPortStation9.setPic(attributes[28]);
					centrexPortStation9.setLpic_attr(attributes[29]);
					centrexPortStation9.setLpic(attributes[30]);
					centrexPortStation9.setSsig_attr(attributes[31]);
					centrexPortStation9.setSsig(attributes[32]);
					centrexPortStation9.setBa_attr(attributes[33]);
					centrexPortStation9.setBa(attributes[34]);
					centrexPortStation9.setBlock_attr(attributes[35]);
					centrexPortStation9.setBlock(attributes[36]);
					centrexPortStation9.setTsp_attr(attributes[37]);
					centrexPortStation9.setTsp(attributes[38]);
					centrexPortStation9.setJk_code_attr(attributes[39]);
					centrexPortStation9.setJk_code(attributes[40]);
					centrexPortStation9.setJk_num_attr(attributes[41]);
					centrexPortStation9.setJk_num(attributes[42]);
					centrexPortStation9.setJk_pos_attr(attributes[43]);
					centrexPortStation9.setJk_pos(attributes[44]);
					centrexPortStation9.setJr_attr(attributes[45]);
					centrexPortStation9.setJr(attributes[46]);
					centrexPortStation9.setNidr_attr(attributes[47]);
					centrexPortStation9.setNidr(attributes[48]);
					centrexPortStation9.setIwjk1_attr(attributes[49]);
					centrexPortStation9.setIwjk1(attributes[50]);
					centrexPortStation9.setIwjk2_attr(attributes[51]);
					centrexPortStation9.setIwjk2(attributes[52]);
					centrexPortStation9.setIwjk3_attr(attributes[53]);
					centrexPortStation9.setIwjk3(attributes[54]);
					centrexPortStation9.setIwjk4_attr(attributes[55]);
					centrexPortStation9.setIwjk4(attributes[56]);
					centrexPortStation9.setIwjk5_attr(attributes[57]);
					centrexPortStation9.setIwjk5(attributes[58]);
					centrexPortStation9.setIwjq1_attr(attributes[59]);
					centrexPortStation9.setIwjq1(attributes[60]);
					centrexPortStation9.setIwjq2_attr(attributes[61]);
					centrexPortStation9.setIwjq2(attributes[62]);
					centrexPortStation9.setIwjq3_attr(attributes[63]);
					centrexPortStation9.setIwjq3(attributes[64]);
					centrexPortStation9.setIwjq4_attr(attributes[65]);
					centrexPortStation9.setIwjq4(attributes[66]);
					centrexPortStation9.setIwjq5_attr(attributes[67]);
					centrexPortStation9.setIwjq5(attributes[68]);
					centrexPortStation9.setSai_attr(attributes[69]);
					centrexPortStation9.setSai(attributes[70]);
					centrexPortStation9.setName_attr(attributes[71]);
					centrexPortStation9.setName(attributes[72]);
					centrexPortStation9.setNcon_attr(attributes[73]);
					centrexPortStation9.setNcon(attributes[74]);
					centrexPortStation9.setAft_attr(attributes[75]);
					centrexPortStation9.setAft(attributes[76]);
					centrexPortStation9.setSapr_attr(attributes[77]);
					centrexPortStation9.setSapr(attributes[78]);
					centrexPortStation9.setSano_attr(attributes[79]);
					centrexPortStation9.setSano(attributes[80]);
					centrexPortStation9.setSasf_attr(attributes[81]);
					centrexPortStation9.setSasf(attributes[82]);
					centrexPortStation9.setSasd_attr(attributes[83]);
					centrexPortStation9.setSasd(attributes[84]);
					centrexPortStation9.setSasn_attr(attributes[85]);
					centrexPortStation9.setSasn(attributes[86]);
					centrexPortStation9.setSath_attr(attributes[87]);
					centrexPortStation9.setSath(attributes[88]);
					centrexPortStation9.setSass_attr(attributes[89]);
					centrexPortStation9.setSass(attributes[90]);
					centrexPortStation9.setLd1_attr(attributes[91]);
					centrexPortStation9.setLd1(attributes[92]);
					centrexPortStation9.setLv1_attr(attributes[93]);
					centrexPortStation9.setLv1(attributes[94]);
					centrexPortStation9.setLd2_attr(attributes[95]);
					centrexPortStation9.setLd2(attributes[96]);
					centrexPortStation9.setLv2_attr(attributes[97]);
					centrexPortStation9.setLv2(attributes[98]);
					centrexPortStation9.setLd3_attr(attributes[99]);
					centrexPortStation9.setLd3(attributes[100]);
					centrexPortStation9.setLv3_attr(attributes[101]);
					centrexPortStation9.setLv3(attributes[102]);
					centrexPortStation9.setAai_attr(attributes[103]);
					centrexPortStation9.setAai(attributes[104]);
					centrexPortStation9.setCity_attr(attributes[105]);
					centrexPortStation9.setCity(attributes[106]);
					centrexPortStation9.setState_attr(attributes[107]);
					centrexPortStation9.setState(attributes[108]);
					centrexPortStation9.setZip_attr(attributes[109]);
					centrexPortStation9.setZip(attributes[110]);
					centrexPortStation9.setLcon_attr(attributes[111]);
					centrexPortStation9.setLcon(attributes[112]);
					centrexPortStation9.setTelno_attr(attributes[113]);
					centrexPortStation9.setTelno(attributes[114]);
					centrexPortStation9.setLocnum_attr(attributes[115]);
					centrexPortStation9.setLocnum(attributes[116]);
					centrexPortStation9.setTli_attr(attributes[117]);
					centrexPortStation9.setTli(attributes[118]);
					centrexPortStation9.setIwt_attr(attributes[119]);
					centrexPortStation9.setIwt(attributes[120]);
					centrexPortStation9.setIwtq_attr(attributes[121]);
					centrexPortStation9.setIwtq(attributes[122]);
					centrexPortStation9.setFpi_attr(attributes[123]);
					centrexPortStation9.setFpi(attributes[124]);
					centrexPortStation9.setTns2_attr(attributes[125]);
					centrexPortStation9.setTns2(attributes[126]);
					centrexPortStation9.setLoc_seq_num(attributes[127]);

					// System.out.println(centrexPortStation9);

					treeViewList_681.add(centrexPortStation9);

				}
				session.setAttribute("treeViewList_681", treeViewList_681);
				selectRequestData.setSubHeader(receivedSubHeader);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}

			if (subData_682Recid != null && subData_682Recid.getSubHeader().getRecord_type().equals("682")) {

				SubHeader receivedSubHeader = subData_682Recid.getSubHeader();
				String[] subDataRows = subData_682Recid.getSubDataRows();
				List<CentrexLoop_CUS_StationLocation_9Data_ReqX> treeViewList_682 = new ArrayList();
				treeViewList.add("682");

				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 128);
					// System.out.println("attributes 9:=682:Reqid======> " +
					// Arrays.toString(attributes));
					CentrexLoop_CUS_StationLocation_9Data_ReqX centrexPortStationLocation9 = new CentrexLoop_CUS_StationLocation_9Data_ReqX();

					centrexPortStationLocation9.setItem_num(attributes[0]);
					centrexPortStationLocation9.setLnum_attr(attributes[1]);
					centrexPortStationLocation9.setLnum(attributes[2]);
					centrexPortStationLocation9.setLna_attr(attributes[3]);
					centrexPortStationLocation9.setLna(attributes[4]);
					centrexPortStationLocation9.setNpi_attr(attributes[5]);
					centrexPortStationLocation9.setNpi(attributes[6]);
					centrexPortStationLocation9.setLst_attr(attributes[7]);
					centrexPortStationLocation9.setLst(attributes[8]);
					centrexPortStationLocation9.setTns_attr(attributes[9]);
					centrexPortStationLocation9.setTns(attributes[10]);
					centrexPortStationLocation9.setTers_attr(attributes[11]);
					centrexPortStationLocation9.setTers(attributes[12]);
					centrexPortStationLocation9.setOtn_attr(attributes[13]);
					centrexPortStationLocation9.setOtn(attributes[14]);
					centrexPortStationLocation9.setIspid_attr(attributes[15]);
					centrexPortStationLocation9.setIspid(attributes[16]);
					centrexPortStationLocation9.setIsdnp_attr(attributes[17]);
					centrexPortStationLocation9.setIsdnp(attributes[18]);
					centrexPortStationLocation9.setEcckt_attr(attributes[19]);
					centrexPortStationLocation9.setEcckt(attributes[20]);
					centrexPortStationLocation9.setCfa_attr(attributes[21]);
					centrexPortStationLocation9.setCfa(attributes[22]);
					centrexPortStationLocation9.setCcea_attr(attributes[23]);
					centrexPortStationLocation9.setCcea(attributes[24]);
					centrexPortStationLocation9.setCkr_attr(attributes[25]);
					centrexPortStationLocation9.setCkr(attributes[26]);
					centrexPortStationLocation9.setPic_attr(attributes[27]);
					centrexPortStationLocation9.setPic(attributes[28]);
					centrexPortStationLocation9.setLpic_attr(attributes[29]);
					centrexPortStationLocation9.setLpic(attributes[30]);
					centrexPortStationLocation9.setSsig_attr(attributes[31]);
					centrexPortStationLocation9.setSsig(attributes[32]);
					centrexPortStationLocation9.setBa_attr(attributes[33]);
					centrexPortStationLocation9.setBa(attributes[34]);
					centrexPortStationLocation9.setBlock_attr(attributes[35]);
					centrexPortStationLocation9.setBlock(attributes[36]);
					centrexPortStationLocation9.setTsp_attr(attributes[37]);
					centrexPortStationLocation9.setTsp(attributes[38]);
					centrexPortStationLocation9.setJk_code_attr(attributes[39]);
					centrexPortStationLocation9.setJk_code(attributes[40]);
					centrexPortStationLocation9.setJk_num_attr(attributes[41]);
					centrexPortStationLocation9.setJk_num(attributes[42]);
					centrexPortStationLocation9.setJk_pos_attr(attributes[43]);
					centrexPortStationLocation9.setJk_pos(attributes[44]);
					centrexPortStationLocation9.setJr_attr(attributes[45]);
					centrexPortStationLocation9.setJr(attributes[46]);
					centrexPortStationLocation9.setNidr_attr(attributes[47]);
					centrexPortStationLocation9.setNidr(attributes[48]);
					centrexPortStationLocation9.setIwjk1_attr(attributes[49]);
					centrexPortStationLocation9.setIwjk1(attributes[50]);
					centrexPortStationLocation9.setIwjk2_attr(attributes[51]);
					centrexPortStationLocation9.setIwjk2(attributes[52]);
					centrexPortStationLocation9.setIwjk3_attr(attributes[53]);
					centrexPortStationLocation9.setIwjk3(attributes[54]);
					centrexPortStationLocation9.setIwjk4_attr(attributes[55]);
					centrexPortStationLocation9.setIwjk4(attributes[56]);
					centrexPortStationLocation9.setIwjk5_attr(attributes[57]);
					centrexPortStationLocation9.setIwjk5(attributes[58]);
					centrexPortStationLocation9.setIwjq1_attr(attributes[59]);
					centrexPortStationLocation9.setIwjq1(attributes[60]);
					centrexPortStationLocation9.setIwjq2_attr(attributes[61]);
					centrexPortStationLocation9.setIwjq2(attributes[62]);
					centrexPortStationLocation9.setIwjq3_attr(attributes[63]);
					centrexPortStationLocation9.setIwjq3(attributes[64]);
					centrexPortStationLocation9.setIwjq4_attr(attributes[65]);
					centrexPortStationLocation9.setIwjq4(attributes[66]);
					centrexPortStationLocation9.setIwjq5_attr(attributes[67]);
					centrexPortStationLocation9.setIwjq5(attributes[68]);
					centrexPortStationLocation9.setSai_attr(attributes[69]);
					centrexPortStationLocation9.setSai(attributes[70]);
					centrexPortStationLocation9.setName_attr(attributes[71]);
					centrexPortStationLocation9.setName(attributes[72]);
					centrexPortStationLocation9.setNcon_attr(attributes[73]);
					centrexPortStationLocation9.setNcon(attributes[74]);
					centrexPortStationLocation9.setAft_attr(attributes[75]);
					centrexPortStationLocation9.setAft(attributes[76]);
					centrexPortStationLocation9.setSapr_attr(attributes[77]);
					centrexPortStationLocation9.setSapr(attributes[78]);
					centrexPortStationLocation9.setSano_attr(attributes[79]);
					centrexPortStationLocation9.setSano(attributes[80]);
					centrexPortStationLocation9.setSasf_attr(attributes[81]);
					centrexPortStationLocation9.setSasf(attributes[82]);
					centrexPortStationLocation9.setSasd_attr(attributes[83]);
					centrexPortStationLocation9.setSasd(attributes[84]);
					centrexPortStationLocation9.setSasn_attr(attributes[85]);
					centrexPortStationLocation9.setSasn(attributes[86]);
					centrexPortStationLocation9.setSath_attr(attributes[87]);
					centrexPortStationLocation9.setSath(attributes[88]);
					centrexPortStationLocation9.setSass_attr(attributes[89]);
					centrexPortStationLocation9.setSass(attributes[90]);
					centrexPortStationLocation9.setLd1_attr(attributes[91]);
					centrexPortStationLocation9.setLd1(attributes[92]);
					centrexPortStationLocation9.setLv1_attr(attributes[93]);
					centrexPortStationLocation9.setLv1(attributes[94]);
					centrexPortStationLocation9.setLd2_attr(attributes[95]);
					centrexPortStationLocation9.setLd2(attributes[96]);
					centrexPortStationLocation9.setLv2_attr(attributes[97]);
					centrexPortStationLocation9.setLv2(attributes[98]);
					centrexPortStationLocation9.setLd3_attr(attributes[99]);
					centrexPortStationLocation9.setLd3(attributes[100]);
					centrexPortStationLocation9.setLv3_attr(attributes[101]);
					centrexPortStationLocation9.setLv3(attributes[102]);
					centrexPortStationLocation9.setAai_attr(attributes[103]);
					centrexPortStationLocation9.setAai(attributes[104]);
					centrexPortStationLocation9.setCity_attr(attributes[105]);
					centrexPortStationLocation9.setCity(attributes[106]);
					centrexPortStationLocation9.setState_attr(attributes[107]);
					centrexPortStationLocation9.setState(attributes[108]);
					centrexPortStationLocation9.setZip_attr(attributes[109]);
					centrexPortStationLocation9.setZip(attributes[110]);
					centrexPortStationLocation9.setLcon_attr(attributes[111]);
					centrexPortStationLocation9.setLcon(attributes[112]);
					centrexPortStationLocation9.setTelno_attr(attributes[113]);
					centrexPortStationLocation9.setTelno(attributes[114]);
					centrexPortStationLocation9.setLocnum_attr(attributes[115]);
					centrexPortStationLocation9.setLocnum(attributes[116]);
					centrexPortStationLocation9.setTli_attr(attributes[117]);
					centrexPortStationLocation9.setTli(attributes[118]);
					centrexPortStationLocation9.setIwt_attr(attributes[119]);
					centrexPortStationLocation9.setIwt(attributes[120]);
					centrexPortStationLocation9.setIwtq_attr(attributes[121]);
					centrexPortStationLocation9.setIwtq(attributes[122]);
					centrexPortStationLocation9.setFpi_attr(attributes[123]);
					centrexPortStationLocation9.setFpi(attributes[124]);
					centrexPortStationLocation9.setTns2_attr(attributes[125]);
					centrexPortStationLocation9.setTns2(attributes[126]);
					centrexPortStationLocation9.setLoc_seq_num(attributes[127]);

					treeViewList_682.add(centrexPortStationLocation9);

				}
				session.setAttribute("treeViewList_682", treeViewList_682);
				selectRequestData.setSubHeader(receivedSubHeader);
			}
			

			if (subData_211Recid != null && subData_211Recid.getSubHeader().getRecord_type().equals("211")) {

				SubHeader receivedSubHeader = subData_211Recid.getSubHeader();
				String[] subDataRows = subData_211Recid.getSubDataRows();
				List<CentrexResaleCRSStationDisconnectTC_DW1Data9> treeViewList_211 = new ArrayList();
				treeViewList.add("211");

				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 17);
					// System.out.println("attributes 9:=211:Reqid======> " +
					// Arrays.toString(attributes));
					CentrexResaleCRSStationDisconnectTC_DW1Data9 centrexResaleCRSStationDisconnect = new CentrexResaleCRSStationDisconnectTC_DW1Data9();

					centrexResaleCRSStationDisconnect.setItem_num(attributes[0]);
					centrexResaleCRSStationDisconnect.setLnum_attr(attributes[1]);
					centrexResaleCRSStationDisconnect.setLnum(attributes[2]);
					centrexResaleCRSStationDisconnect.setTc_opt_attr(attributes[3]);
					centrexResaleCRSStationDisconnect.setTc_opt(attributes[4]);
					centrexResaleCRSStationDisconnect.setTc_per_attr(attributes[5]);
					centrexResaleCRSStationDisconnect.setTc_per(attributes[6]);
					centrexResaleCRSStationDisconnect.setTc_to_pri_attr(attributes[7]);
					centrexResaleCRSStationDisconnect.setTc_to_pri(attributes[8]);
					centrexResaleCRSStationDisconnect.setTc_name_pri_attr(attributes[9]);
					centrexResaleCRSStationDisconnect.setTc_name_pri(attributes[10]);
					centrexResaleCRSStationDisconnect.setTc_id_attr(attributes[11]);
					centrexResaleCRSStationDisconnect.setTc_id(attributes[12]);
					centrexResaleCRSStationDisconnect.setTcfr_attr(attributes[13]);
					centrexResaleCRSStationDisconnect.setTcfr(attributes[14]);
					centrexResaleCRSStationDisconnect.setLocnum(attributes[15]);
					centrexResaleCRSStationDisconnect.setLoc_seq_num(attributes[16]);
					treeViewList_211.add(centrexResaleCRSStationDisconnect);
					// System.out.println(centrexResaleCRSStationDisconnect);
				}
				session.setAttribute("treeViewList_211", treeViewList_211);
				selectRequestData.setSubHeader(receivedSubHeader);
			}
			// ruby

			// 641
			if (subData_641Recid != null && subData_641Recid.getSubHeader().getRecord_type().equals("641")) {

				SubHeader receivedSubHeader = subData_641Recid.getSubHeader();
				String[] subDataRows = subData_641Recid.getSubDataRows();
				List<PortDPUTrunk_9State> treeViewList9_641 = new ArrayList();
				treeViewList.add("641");
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 154);
					// System.out.println("attributes:=641:Reqid======> " +
					// Arrays.toString(attributes));
					PortDPUTrunk_9State portDPUTrunk = new PortDPUTrunk_9State();
					portDPUTrunk.setItem_num(attributes[0]);
					portDPUTrunk.setDidnum_attr(attributes[1]);
					portDPUTrunk.setDidnum(attributes[2]);
					portDPUTrunk.setDidind_attr(attributes[3]);
					portDPUTrunk.setDidind(attributes[4]);
					portDPUTrunk.setDtnract_attr(attributes[5]);
					portDPUTrunk.setDtnract(attributes[6]);
					portDPUTrunk.setDtnrq_attr(attributes[7]);
					portDPUTrunk.setDtnrq(attributes[8]);
					portDPUTrunk.setDtnr1_attr(attributes[9]);
					portDPUTrunk.setDtnr1(attributes[10]);
					portDPUTrunk.setDtnr2_attr(attributes[11]);
					portDPUTrunk.setDtnr2(attributes[12]);
					portDPUTrunk.setDtnr3_attr(attributes[13]);
					portDPUTrunk.setDtnr3(attributes[14]);
					portDPUTrunk.setNpi_attr(attributes[15]);
					portDPUTrunk.setNpi(attributes[16]);
					portDPUTrunk.setDidr_attr(attributes[17]);
					portDPUTrunk.setDidr(attributes[18]);
					portDPUTrunk.setDtkact_attr(attributes[19]);
					portDPUTrunk.setDtkact(attributes[20]);
					portDPUTrunk.setDtgn_attr(attributes[21]);
					portDPUTrunk.setDtgn(attributes[22]);
					portDPUTrunk.setDtli_attr(attributes[23]);
					portDPUTrunk.setDtli(attributes[24]);
					portDPUTrunk.setDba_attr(attributes[25]);
					portDPUTrunk.setDba(attributes[26]);
					portDPUTrunk.setDblock_attr(attributes[27]);
					portDPUTrunk.setDblock(attributes[28]);
					portDPUTrunk.setDpic_attr(attributes[29]);
					portDPUTrunk.setDpic(attributes[30]);
					portDPUTrunk.setDlpic_attr(attributes[31]);
					portDPUTrunk.setDlpic(attributes[32]);
					portDPUTrunk.setDrti_attr(attributes[33]);
					portDPUTrunk.setDrti(attributes[34]);
					portDPUTrunk.setDgout_attr(attributes[35]);
					portDPUTrunk.setDgout(attributes[36]);
					portDPUTrunk.setDpulse_attr(attributes[37]);
					portDPUTrunk.setDpulse(attributes[38]);
					portDPUTrunk.setDsgnl_attr(attributes[39]);
					portDPUTrunk.setDsgnl(attributes[40]);
					portDPUTrunk.setNba_attr(attributes[41]);
					portDPUTrunk.setNba(attributes[42]);
					portDPUTrunk.setNbank1_attr(attributes[43]);
					portDPUTrunk.setNbank1(attributes[44]);
					portDPUTrunk.setNbank2_attr(attributes[45]);
					portDPUTrunk.setNbank2(attributes[46]);
					portDPUTrunk.setNbank3_attr(attributes[47]);
					portDPUTrunk.setNbank3(attributes[48]);
					portDPUTrunk.setNbank4_attr(attributes[49]);
					portDPUTrunk.setNbank4(attributes[50]);
					portDPUTrunk.setDstnact_attr(attributes[51]);
					portDPUTrunk.setDstnact(attributes[52]);
					portDPUTrunk.setDstnq_attr(attributes[53]);
					portDPUTrunk.setDstnq(attributes[54]);
					portDPUTrunk.setDstn1_attr(attributes[55]);
					portDPUTrunk.setDstn1(attributes[56]);
					portDPUTrunk.setDstn2_attr(attributes[57]);
					portDPUTrunk.setDstn2(attributes[58]);
					portDPUTrunk.setDstn3_attr(attributes[59]);
					portDPUTrunk.setDstn3(attributes[60]);
					portDPUTrunk.setDstn4_attr(attributes[61]);
					portDPUTrunk.setDstn4(attributes[62]);
					portDPUTrunk.setDstn5_attr(attributes[63]);
					portDPUTrunk.setDstn5(attributes[64]);
					;
					portDPUTrunk.setLnum_attr(attributes[65]);
					portDPUTrunk.setLnum(attributes[66]);
					portDPUTrunk.setLna_attr(attributes[67]);
					portDPUTrunk.setLna(attributes[68]);
					portDPUTrunk.setTns_attr(attributes[69]);
					portDPUTrunk.setTns(attributes[70]);
					portDPUTrunk.setTers_attr(attributes[71]);
					portDPUTrunk.setTers(attributes[72]);
					portDPUTrunk.setOtn_attr(attributes[73]);
					portDPUTrunk.setOtn(attributes[74]);
					portDPUTrunk.setLtgn_attr(attributes[75]);
					portDPUTrunk.setLtgn(attributes[76]);
					portDPUTrunk.setNc_attr(attributes[77]);
					portDPUTrunk.setNc(attributes[78]);
					portDPUTrunk.setNci_attr(attributes[79]);
					portDPUTrunk.setNci(attributes[80]);
					portDPUTrunk.setEcckt_attr(attributes[81]);
					portDPUTrunk.setEcckt(attributes[82]);
					portDPUTrunk.setCfa_attr(attributes[83]);
					portDPUTrunk.setCfa(attributes[84]);
					portDPUTrunk.setCcea_attr(attributes[85]);
					portDPUTrunk.setCcea(attributes[86]);
					portDPUTrunk.setCkr_attr(attributes[87]);
					portDPUTrunk.setCkr(attributes[88]);
					portDPUTrunk.setPic_attr(attributes[89]);
					portDPUTrunk.setPic(attributes[90]);
					portDPUTrunk.setLpic_attr(attributes[91]);
					portDPUTrunk.setLpic(attributes[92]);
					portDPUTrunk.setSsig_attr(attributes[93]);
					portDPUTrunk.setSsig(attributes[94]);
					portDPUTrunk.setBa_attr(attributes[95]);
					portDPUTrunk.setBa(attributes[96]);
					portDPUTrunk.setBlock_attr(attributes[97]);
					portDPUTrunk.setBlock(attributes[98]);
					portDPUTrunk.setTsp_attr(attributes[99]);
					portDPUTrunk.setTsp(attributes[100]);
					portDPUTrunk.setJk_code_attr(attributes[101]);
					portDPUTrunk.setJk_code(attributes[102]);
					portDPUTrunk.setJk_num_attr(attributes[103]);
					portDPUTrunk.setJk_num(attributes[104]);
					portDPUTrunk.setJk_pos_attr(attributes[105]);
					portDPUTrunk.setJk_pos(attributes[106]);
					portDPUTrunk.setJr_attr(attributes[107]);
					portDPUTrunk.setJr(attributes[108]);
					portDPUTrunk.setNidr_attr(attributes[109]);
					portDPUTrunk.setNidr(attributes[110]);
					portDPUTrunk.setIwjk1_attr(attributes[111]);
					portDPUTrunk.setIwjk1(attributes[112]);
					portDPUTrunk.setIwjk2_attr(attributes[113]);
					portDPUTrunk.setIwjk2(attributes[114]);
					portDPUTrunk.setIwjk3_attr(attributes[115]);
					portDPUTrunk.setIwjk3(attributes[116]);
					portDPUTrunk.setIwjk4_attr(attributes[117]);
					portDPUTrunk.setIwjk4(attributes[118]);
					portDPUTrunk.setIwjk5_attr(attributes[119]);
					portDPUTrunk.setIwjk5(attributes[120]);
					portDPUTrunk.setIwjq1_attr(attributes[121]);
					portDPUTrunk.setIwjq1(attributes[122]);
					portDPUTrunk.setIwjq2_attr(attributes[123]);
					portDPUTrunk.setIwjq2(attributes[124]);
					portDPUTrunk.setIwjq3_attr(attributes[125]);
					portDPUTrunk.setIwjq3(attributes[126]);
					portDPUTrunk.setIwjq4_attr(attributes[127]);
					portDPUTrunk.setIwjq4(attributes[128]);
					portDPUTrunk.setIwjq5_attr(attributes[129]);
					portDPUTrunk.setIwjq5(attributes[130]);
					portDPUTrunk.setNpi_trnk_attr(attributes[131]);
					portDPUTrunk.setNpi_trnk(attributes[132]);
					portDPUTrunk.setLocnum_attr(attributes[133]);
					portDPUTrunk.setLocnum(attributes[134]);
					portDPUTrunk.setTkid_attr(attributes[135]);
					portDPUTrunk.setTkid(attributes[136]);
					portDPUTrunk.setTtp_attr(attributes[137]);
					portDPUTrunk.setTtp(attributes[138]);
					portDPUTrunk.setIwt_attr(attributes[139]);
					portDPUTrunk.setIwt(attributes[140]);
					portDPUTrunk.setIwtq_attr(attributes[141]);
					portDPUTrunk.setIwtq(attributes[142]);
					portDPUTrunk.setDin_attr(attributes[143]);
					portDPUTrunk.setDin(attributes[144]);
					portDPUTrunk.setGlare_attr(attributes[145]);
					portDPUTrunk.setGlare(attributes[146]);
					portDPUTrunk.setCableid_attr(attributes[147]);
					portDPUTrunk.setCableid(attributes[148]);
					portDPUTrunk.setFpi_attr(attributes[149]);
					portDPUTrunk.setFpi(attributes[150]);
					portDPUTrunk.setQn_attr(attributes[151]);
					portDPUTrunk.setQn(attributes[152]);
					portDPUTrunk.setLoc_seq_num(attributes[153]);

					treeViewList9_641.add(portDPUTrunk);
				}
				session.setAttribute("treeViewList9_641", treeViewList9_641);
				selectRequestData.setSubHeader(receivedSubHeader);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}
			
			

			// 642

			if (subData_642Recid != null && subData_642Recid.getSubHeader().getRecord_type().equals("642")) {

				SubHeader receivedSubHeader = subData_642Recid.getSubHeader();
				String[] subDataRows = subData_642Recid.getSubDataRows();
				List<Loop_PortDPUTrunk_9State> treeViewList9_642 = new ArrayList();
				treeViewList.add("642");
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 154);
					// System.out.println("attributes:=642:Reqid======> " +
					// Arrays.toString(attributes));
					Loop_PortDPUTrunk_9State portDPUTrunk = new Loop_PortDPUTrunk_9State();
					portDPUTrunk.setItem_num(attributes[0]);
					portDPUTrunk.setDidnum_attr(attributes[1]);
					portDPUTrunk.setDidnum(attributes[2]);
					portDPUTrunk.setDidind_attr(attributes[3]);
					portDPUTrunk.setDidind(attributes[4]);
					portDPUTrunk.setDtnract_attr(attributes[5]);
					portDPUTrunk.setDtnract(attributes[6]);
					portDPUTrunk.setDtnrq_attr(attributes[7]);
					portDPUTrunk.setDtnrq(attributes[8]);
					portDPUTrunk.setDtnr1_attr(attributes[9]);
					portDPUTrunk.setDtnr1(attributes[10]);
					portDPUTrunk.setDtnr2_attr(attributes[11]);
					portDPUTrunk.setDtnr2(attributes[12]);
					portDPUTrunk.setDtnr3_attr(attributes[13]);
					portDPUTrunk.setDtnr3(attributes[14]);
					portDPUTrunk.setNpi_attr(attributes[15]);
					portDPUTrunk.setNpi(attributes[16]);
					portDPUTrunk.setDidr_attr(attributes[17]);
					portDPUTrunk.setDidr(attributes[18]);
					portDPUTrunk.setDtkact_attr(attributes[19]);
					portDPUTrunk.setDtkact(attributes[20]);
					portDPUTrunk.setDtgn_attr(attributes[21]);
					portDPUTrunk.setDtgn(attributes[22]);
					portDPUTrunk.setDtli_attr(attributes[23]);
					portDPUTrunk.setDtli(attributes[24]);
					portDPUTrunk.setDba_attr(attributes[25]);
					portDPUTrunk.setDba(attributes[26]);
					portDPUTrunk.setDblock_attr(attributes[27]);
					portDPUTrunk.setDblock(attributes[28]);
					portDPUTrunk.setDpic_attr(attributes[29]);
					portDPUTrunk.setDpic(attributes[30]);
					portDPUTrunk.setDlpic_attr(attributes[31]);
					portDPUTrunk.setDlpic(attributes[32]);
					portDPUTrunk.setDrti_attr(attributes[33]);
					portDPUTrunk.setDrti(attributes[34]);
					portDPUTrunk.setDgout_attr(attributes[35]);
					portDPUTrunk.setDgout(attributes[36]);
					portDPUTrunk.setDpulse_attr(attributes[37]);
					portDPUTrunk.setDpulse(attributes[38]);
					portDPUTrunk.setDsgnl_attr(attributes[39]);
					portDPUTrunk.setDsgnl(attributes[40]);
					portDPUTrunk.setNba_attr(attributes[41]);
					portDPUTrunk.setNba(attributes[42]);
					portDPUTrunk.setNbank1_attr(attributes[43]);
					portDPUTrunk.setNbank1(attributes[44]);
					portDPUTrunk.setNbank2_attr(attributes[45]);
					portDPUTrunk.setNbank2(attributes[46]);
					portDPUTrunk.setNbank3_attr(attributes[47]);
					portDPUTrunk.setNbank3(attributes[48]);
					portDPUTrunk.setNbank4_attr(attributes[49]);
					portDPUTrunk.setNbank4(attributes[50]);
					portDPUTrunk.setDstnact_attr(attributes[51]);
					portDPUTrunk.setDstnact(attributes[52]);
					portDPUTrunk.setDstnq_attr(attributes[53]);
					portDPUTrunk.setDstnq(attributes[54]);
					portDPUTrunk.setDstn1_attr(attributes[55]);
					portDPUTrunk.setDstn1(attributes[56]);
					portDPUTrunk.setDstn2_attr(attributes[57]);
					portDPUTrunk.setDstn2(attributes[58]);
					portDPUTrunk.setDstn3_attr(attributes[59]);
					portDPUTrunk.setDstn3(attributes[60]);
					portDPUTrunk.setDstn4_attr(attributes[61]);
					portDPUTrunk.setDstn4(attributes[62]);
					portDPUTrunk.setDstn5_attr(attributes[63]);
					portDPUTrunk.setDstn5(attributes[64]);
					;
					portDPUTrunk.setLnum_attr(attributes[65]);
					portDPUTrunk.setLnum(attributes[66]);
					portDPUTrunk.setLna_attr(attributes[67]);
					portDPUTrunk.setLna(attributes[68]);
					portDPUTrunk.setTns_attr(attributes[69]);
					portDPUTrunk.setTns(attributes[70]);
					portDPUTrunk.setTers_attr(attributes[71]);
					portDPUTrunk.setTers(attributes[72]);
					portDPUTrunk.setOtn_attr(attributes[73]);
					portDPUTrunk.setOtn(attributes[74]);
					portDPUTrunk.setLtgn_attr(attributes[75]);
					portDPUTrunk.setLtgn(attributes[76]);
					portDPUTrunk.setNc_attr(attributes[77]);
					portDPUTrunk.setNc(attributes[78]);
					portDPUTrunk.setNci_attr(attributes[79]);
					portDPUTrunk.setNci(attributes[80]);
					portDPUTrunk.setEcckt_attr(attributes[81]);
					portDPUTrunk.setEcckt(attributes[82]);
					portDPUTrunk.setCfa_attr(attributes[83]);
					portDPUTrunk.setCfa(attributes[84]);
					portDPUTrunk.setCcea_attr(attributes[85]);
					portDPUTrunk.setCcea(attributes[86]);
					portDPUTrunk.setCkr_attr(attributes[87]);
					portDPUTrunk.setCkr(attributes[88]);
					portDPUTrunk.setPic_attr(attributes[89]);
					portDPUTrunk.setPic(attributes[90]);
					portDPUTrunk.setLpic_attr(attributes[91]);
					portDPUTrunk.setLpic(attributes[92]);
					portDPUTrunk.setSsig_attr(attributes[93]);
					portDPUTrunk.setSsig(attributes[94]);
					portDPUTrunk.setBa_attr(attributes[95]);
					portDPUTrunk.setBa(attributes[96]);
					portDPUTrunk.setBlock_attr(attributes[97]);
					portDPUTrunk.setBlock(attributes[98]);
					portDPUTrunk.setTsp_attr(attributes[99]);
					portDPUTrunk.setTsp(attributes[100]);
					portDPUTrunk.setJk_code_attr(attributes[101]);
					portDPUTrunk.setJk_code(attributes[102]);
					portDPUTrunk.setJk_num_attr(attributes[103]);
					portDPUTrunk.setJk_num(attributes[104]);
					portDPUTrunk.setJk_pos_attr(attributes[105]);
					portDPUTrunk.setJk_pos(attributes[106]);
					portDPUTrunk.setJr_attr(attributes[107]);
					portDPUTrunk.setJr(attributes[108]);
					portDPUTrunk.setNidr_attr(attributes[109]);
					portDPUTrunk.setNidr(attributes[110]);
					portDPUTrunk.setIwjk1_attr(attributes[111]);
					portDPUTrunk.setIwjk1(attributes[112]);
					portDPUTrunk.setIwjk2_attr(attributes[113]);
					portDPUTrunk.setIwjk2(attributes[114]);
					portDPUTrunk.setIwjk3_attr(attributes[115]);
					portDPUTrunk.setIwjk3(attributes[116]);
					portDPUTrunk.setIwjk4_attr(attributes[117]);
					portDPUTrunk.setIwjk4(attributes[118]);
					portDPUTrunk.setIwjk5_attr(attributes[119]);
					portDPUTrunk.setIwjk5(attributes[120]);
					portDPUTrunk.setIwjq1_attr(attributes[121]);
					portDPUTrunk.setIwjq1(attributes[122]);
					portDPUTrunk.setIwjq2_attr(attributes[123]);
					portDPUTrunk.setIwjq2(attributes[124]);
					portDPUTrunk.setIwjq3_attr(attributes[125]);
					portDPUTrunk.setIwjq3(attributes[126]);
					portDPUTrunk.setIwjq4_attr(attributes[127]);
					portDPUTrunk.setIwjq4(attributes[128]);
					portDPUTrunk.setIwjq5_attr(attributes[129]);
					portDPUTrunk.setIwjq5(attributes[130]);
					portDPUTrunk.setNpi_trnk_attr(attributes[131]);
					portDPUTrunk.setNpi_trnk(attributes[132]);
					portDPUTrunk.setLocnum_attr(attributes[133]);
					portDPUTrunk.setLocnum(attributes[134]);
					portDPUTrunk.setTkid_attr(attributes[135]);
					portDPUTrunk.setTkid(attributes[136]);
					portDPUTrunk.setTtp_attr(attributes[137]);
					portDPUTrunk.setTtp(attributes[138]);
					portDPUTrunk.setIwt_attr(attributes[139]);
					portDPUTrunk.setIwt(attributes[140]);
					portDPUTrunk.setIwtq_attr(attributes[141]);
					portDPUTrunk.setIwtq(attributes[142]);
					portDPUTrunk.setDin_attr(attributes[143]);
					portDPUTrunk.setDin(attributes[144]);
					portDPUTrunk.setGlare_attr(attributes[145]);
					portDPUTrunk.setGlare(attributes[146]);
					portDPUTrunk.setCableid_attr(attributes[147]);
					portDPUTrunk.setCableid(attributes[148]);
					portDPUTrunk.setFpi_attr(attributes[149]);
					portDPUTrunk.setFpi(attributes[150]);
					portDPUTrunk.setQn_attr(attributes[151]);
					portDPUTrunk.setQn(attributes[152]);
					portDPUTrunk.setLoc_seq_num(attributes[153]);

					treeViewList9_642.add(portDPUTrunk);
				}
				session.setAttribute("treeViewList9_642", treeViewList9_642);
				selectRequestData.setSubHeader(receivedSubHeader);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}

			// 212
			if (subData_212Recid != null && subData_212Recid.getSubHeader().getRecord_type().equals("212")) {

				SubHeader receivedSubHeader = subData_212Recid.getSubHeader();
				String[] subDataRows = subData_212Recid.getSubDataRows();
				List<PortDPUTrunkGroupTGRPDisc_9state> treeViewList9_212 = new ArrayList<>();
				treeViewList.add("212");
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 17);
					// System.out.println("attributes 212:=======> " + Arrays.toString(attributes));
					PortDPUTrunkGroupTGRPDisc_9state portDPUTrunkGroupTGRPDisc = new PortDPUTrunkGroupTGRPDisc_9state();
					portDPUTrunkGroupTGRPDisc.setItem_num(attributes[0]);
					portDPUTrunkGroupTGRPDisc.setDidnum_attr(attributes[1]);
					portDPUTrunkGroupTGRPDisc.setDidnum(attributes[2]);
					portDPUTrunkGroupTGRPDisc.setTg_tc_opt_attr(attributes[3]);
					portDPUTrunkGroupTGRPDisc.setTg_tc_opt(attributes[4]);
					portDPUTrunkGroupTGRPDisc.setTg_tc_per_attr(attributes[5]);
					portDPUTrunkGroupTGRPDisc.setTg_tc_per(attributes[6]);
					portDPUTrunkGroupTGRPDisc.setTg_tc_to_pri_attr(attributes[7]);
					portDPUTrunkGroupTGRPDisc.setTg_tc_to_pri(attributes[8]);
					portDPUTrunkGroupTGRPDisc.setTg_tc_name_pri_attr(attributes[9]);
					portDPUTrunkGroupTGRPDisc.setTg_tc_name_pri(attributes[10]);
					portDPUTrunkGroupTGRPDisc.setTg_tc_id_attr(attributes[11]);
					portDPUTrunkGroupTGRPDisc.setTg_tc_id_pri(attributes[12]);
					portDPUTrunkGroupTGRPDisc.setTg_tc_fr_attr(attributes[13]);
					portDPUTrunkGroupTGRPDisc.setTg_tc_fr(attributes[14]);
					portDPUTrunkGroupTGRPDisc.setLocnum(attributes[15]);
					portDPUTrunkGroupTGRPDisc.setLoc_sec_num(attributes[16]);

					treeViewList9_212.add(portDPUTrunkGroupTGRPDisc);
				}
				session.setAttribute("treeViewList9_212", treeViewList9_212);
				selectRequestData.setSubHeader(receivedSubHeader);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}

			// 9-StateDID/PBX Loop w/ Port DPU Trunk Group TGRP Disc/TC - 213 (right Screen)
			if (subData_213Recid != null && subData_213Recid.getSubHeader().getRecord_type().equals("213")) {

				SubHeader receivedSubHeader = subData_213Recid.getSubHeader();
				String[] subDataRows = subData_213Recid.getSubDataRows();
				List<PortDPUTrunkGroupTGRPDiscTable_9state> treeViewList9_213 = new ArrayList<>();
				treeViewList.add("213");
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 13);
					// System.out.println("attributes 213:=======> " + Arrays.toString(attributes));
					PortDPUTrunkGroupTGRPDiscTable_9state portDPUTrunkGroupTGRPDiscTable = new PortDPUTrunkGroupTGRPDiscTable_9state();
					portDPUTrunkGroupTGRPDiscTable.setItem_num(attributes[0]);
					portDPUTrunkGroupTGRPDiscTable.setTg_tc_id_sec_attr(attributes[1]);
					portDPUTrunkGroupTGRPDiscTable.setTg_tc_id_sec(attributes[2]);
					portDPUTrunkGroupTGRPDiscTable.setTg_tc_to_sec_attr(attributes[3]);
					portDPUTrunkGroupTGRPDiscTable.setTg_tc_to_sec(attributes[4]);
					portDPUTrunkGroupTGRPDiscTable.setTg_tc_name_sec_attr(attributes[5]);
					portDPUTrunkGroupTGRPDiscTable.setTg_tc_name_sec(attributes[6]);

					// resaleprivatelinecircuit12states.setScreenName("Circut");

					treeViewList9_213.add(portDPUTrunkGroupTGRPDiscTable);

					// System.out.println("TGRPDiscTable " + portDPUTrunkGroupTGRPDiscTable);
				}
				session.setAttribute("treeViewList9_213", treeViewList9_213);
				selectRequestData.setSubHeader(receivedSubHeader);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}
//aprajita

			if (subData_210Recid != null && subData_210Recid.getSubHeader().getRecord_type().equals("210")) {

				SubHeader receivedSubHeader = subData_210Recid.getSubHeader();
				String[] subDataRows = subData_210Recid.getSubDataRows();

				// List treeViewList = new ArrayList();
				// int i = 0;
				treeViewList.add("210");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 17);
					// System.out.println("attributes:=210=======> " + Arrays.toString(attributes));
					ISDNPort_IUS_PRI_DISC_TN_9States isdnPort_IUS_PRI_DISC_TN_9States = new ISDNPort_IUS_PRI_DISC_TN_9States();

					isdnPort_IUS_PRI_DISC_TN_9States.setItem_num(attributes[0]);
					isdnPort_IUS_PRI_DISC_TN_9States.setTnnum_attr(attributes[1]);
					isdnPort_IUS_PRI_DISC_TN_9States.setTnnum(attributes[2]);
					isdnPort_IUS_PRI_DISC_TN_9States.setTc_opt_attr(attributes[3]);
					isdnPort_IUS_PRI_DISC_TN_9States.setTc_opt(attributes[4]);
					isdnPort_IUS_PRI_DISC_TN_9States.setTc_per_attr(attributes[5]);
					isdnPort_IUS_PRI_DISC_TN_9States.setTc_per(attributes[6]);
					isdnPort_IUS_PRI_DISC_TN_9States.setTc_to_pri_attr(attributes[7]);
					isdnPort_IUS_PRI_DISC_TN_9States.setTc_to_pri(attributes[8]);
					isdnPort_IUS_PRI_DISC_TN_9States.setTc_name_pri_attr(attributes[9]);
					isdnPort_IUS_PRI_DISC_TN_9States.setTc_name_pri(attributes[10]);
					isdnPort_IUS_PRI_DISC_TN_9States.setTc_id_attr(attributes[11]);
					isdnPort_IUS_PRI_DISC_TN_9States.setTc_id(attributes[12]);
					isdnPort_IUS_PRI_DISC_TN_9States.setTcfr_attr(attributes[13]);
					isdnPort_IUS_PRI_DISC_TN_9States.setTcfr(attributes[14]);
					isdnPort_IUS_PRI_DISC_TN_9States.setLocnum(attributes[15]);
					isdnPort_IUS_PRI_DISC_TN_9States.setLoc_seq_num(attributes[16]);

					treeViewList9_210.add(isdnPort_IUS_PRI_DISC_TN_9States);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
			}

			if (subData_158Recid != null && subData_158Recid.getSubHeader().getRecord_type().equals("158")) {

				SubHeader receivedSubHeader = subData_158Recid.getSubHeader();
				String[] subDataRows = subData_158Recid.getSubDataRows();

				// List treeViewList = new ArrayList();
				// int i = 0;
				treeViewList.add("158");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 11);
					// System.out.println("attributes:=158=======> " + Arrays.toString(attributes));
					ISDNPort_IUS_TrunkGroup_TG_FeaturesGrid_9States isdnPort_IUS_TrunkGroup_TG_FeaturesGrid_9States = new ISDNPort_IUS_TrunkGroup_TG_FeaturesGrid_9States();

					isdnPort_IUS_TrunkGroup_TG_FeaturesGrid_9States.setItem_num(attributes[0]);
					isdnPort_IUS_TrunkGroup_TG_FeaturesGrid_9States.setTgfa_attr(attributes[1]);
					isdnPort_IUS_TrunkGroup_TG_FeaturesGrid_9States.setTgfa(attributes[2]);
					isdnPort_IUS_TrunkGroup_TG_FeaturesGrid_9States.setTgfeature_attr(attributes[3]);
					isdnPort_IUS_TrunkGroup_TG_FeaturesGrid_9States.setTgfeature(attributes[4]);
					isdnPort_IUS_TrunkGroup_TG_FeaturesGrid_9States.setTgfeature_detail_attr(attributes[5]);
					isdnPort_IUS_TrunkGroup_TG_FeaturesGrid_9States.setTgfeature_detail(attributes[6]);
					isdnPort_IUS_TrunkGroup_TG_FeaturesGrid_9States.setLine_asgn_attr(attributes[7]);
					isdnPort_IUS_TrunkGroup_TG_FeaturesGrid_9States.setLine_asgn(attributes[8]);
					isdnPort_IUS_TrunkGroup_TG_FeaturesGrid_9States.setLocnum(attributes[9]);
					isdnPort_IUS_TrunkGroup_TG_FeaturesGrid_9States.setLoc_seq_num(attributes[10]);

					treeViewList9_158.add(isdnPort_IUS_TrunkGroup_TG_FeaturesGrid_9States);
				}
				selectRequestData.setSubHeader(receivedSubHeader);

			}
			if (subData_159Recid != null && subData_159Recid.getSubHeader().getRecord_type().equals("159")) {

				SubHeader receivedSubHeader = subData_159Recid.getSubHeader();
				String[] subDataRows = subData_159Recid.getSubDataRows();

				// List treeViewList = new ArrayList();
				// int i = 0;
				treeViewList.add("159");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 11);
					// System.out.println("attributes:=159=======> " + Arrays.toString(attributes));
					ISDNPort_IUS_ChannelFeaturesGrid_9States isdnPort_IUS_ChannelFeaturesGrid_9States = new ISDNPort_IUS_ChannelFeaturesGrid_9States();

					isdnPort_IUS_ChannelFeaturesGrid_9States.setItem_num(attributes[0]);
					isdnPort_IUS_ChannelFeaturesGrid_9States.setChannel_fa_attr(attributes[1]);
					isdnPort_IUS_ChannelFeaturesGrid_9States.setChannel_fa(attributes[2]);
					isdnPort_IUS_ChannelFeaturesGrid_9States.setChannel_feature_attr(attributes[3]);
					isdnPort_IUS_ChannelFeaturesGrid_9States.setChannel_feature(attributes[4]);
					isdnPort_IUS_ChannelFeaturesGrid_9States.setChannel_feature_detail_attr(attributes[5]);
					isdnPort_IUS_ChannelFeaturesGrid_9States.setChannel_feature_detail(attributes[6]);
					isdnPort_IUS_ChannelFeaturesGrid_9States.setLine_asgn_attr(attributes[7]);
					isdnPort_IUS_ChannelFeaturesGrid_9States.setLine_asgn(attributes[8]);
					isdnPort_IUS_ChannelFeaturesGrid_9States.setLocnum(attributes[9]);
					isdnPort_IUS_ChannelFeaturesGrid_9States.setLoc_seq_num(attributes[10]);

					treeViewList9_159.add(isdnPort_IUS_ChannelFeaturesGrid_9States);
				}
				selectRequestData.setSubHeader(receivedSubHeader);

			}
			if (subData_157Recid != null && subData_157Recid.getSubHeader().getRecord_type().equals("157")) {

				SubHeader receivedSubHeader = subData_157Recid.getSubHeader();
				String[] subDataRows = subData_157Recid.getSubDataRows();

				// List treeViewList = new ArrayList();
				// int i = 0;
				treeViewList.add("157");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 11);
					// System.out.println("attributes:=157=======> " + Arrays.toString(attributes));
					ISDNPort_IUS_Location_f_features_9States isdnPort_IUS_Location_f_features_9States = new ISDNPort_IUS_Location_f_features_9States();

					isdnPort_IUS_Location_f_features_9States.setItem_num(attributes[0]);
					isdnPort_IUS_Location_f_features_9States.setF_fa_attr(attributes[1]);
					isdnPort_IUS_Location_f_features_9States.setF_fa(attributes[2]);
					isdnPort_IUS_Location_f_features_9States.setF_feature_attr(attributes[3]);
					isdnPort_IUS_Location_f_features_9States.setF_feature(attributes[4]);
					isdnPort_IUS_Location_f_features_9States.setF_feature_detail_attr(attributes[5]);
					isdnPort_IUS_Location_f_features_9States.setF_feature_detail(attributes[6]);
					isdnPort_IUS_Location_f_features_9States.setLine_asgn_attr(attributes[7]);
					isdnPort_IUS_Location_f_features_9States.setLine_asgn(attributes[8]);
					isdnPort_IUS_Location_f_features_9States.setLocnum(attributes[9]);
					isdnPort_IUS_Location_f_features_9States.setLoc_seq_num(attributes[10]);

					treeViewList9_157.add(isdnPort_IUS_Location_f_features_9States);
				}
				selectRequestData.setSubHeader(receivedSubHeader);

			}

			if (subData_841Recid != null && subData_841Recid.getSubHeader().getRecord_type().equals("841")) {

				SubHeader receivedSubHeader = subData_841Recid.getSubHeader();
				String[] subDataRows = subData_841Recid.getSubDataRows();

				// List treeViewList = new ArrayList();
				// int i = 0;
				treeViewList.add("841");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 218);
					// System.out.println("attributes:=841:Reqid=======> " +
					// Arrays.toString(attributes));
					ISDNPort_IUS_Channel_9States isdnPort_IUS_Channel_9States = new ISDNPort_IUS_Channel_9States();

					isdnPort_IUS_Channel_9States.setItem_num(attributes[0]);
					isdnPort_IUS_Channel_9States.setCnum_attr(attributes[1]);
					isdnPort_IUS_Channel_9States.setCnum(attributes[2]);
					isdnPort_IUS_Channel_9States.setFnum_attr(attributes[3]);
					isdnPort_IUS_Channel_9States.setFnum(attributes[4]);
					isdnPort_IUS_Channel_9States.setTnnum_attr(attributes[5]);
					isdnPort_IUS_Channel_9States.setTnnum(attributes[6]);
					isdnPort_IUS_Channel_9States.setTglnum_attr(attributes[7]);
					isdnPort_IUS_Channel_9States.setTglnum(attributes[8]);
					isdnPort_IUS_Channel_9States.setEcckt_attr(attributes[9]);
					isdnPort_IUS_Channel_9States.setEcckt(attributes[10]);
					isdnPort_IUS_Channel_9States.setCfa_attr(attributes[11]);
					isdnPort_IUS_Channel_9States.setCfa(attributes[12]);
					isdnPort_IUS_Channel_9States.setLtgn_attr(attributes[13]);
					isdnPort_IUS_Channel_9States.setLtgn(attributes[14]);
					isdnPort_IUS_Channel_9States.setIid_attr(attributes[15]);
					isdnPort_IUS_Channel_9States.setIid(attributes[16]);
					isdnPort_IUS_Channel_9States.setCord_attr(attributes[17]);
					isdnPort_IUS_Channel_9States.setCord(attributes[18]);
					isdnPort_IUS_Channel_9States.setIsdnp_attr(attributes[19]);
					isdnPort_IUS_Channel_9States.setIsdnp(attributes[20]);
					isdnPort_IUS_Channel_9States.setFlna_attr(attributes[21]);
					isdnPort_IUS_Channel_9States.setFlna(attributes[22]);
					isdnPort_IUS_Channel_9States.setCkttyp_attr(attributes[23]);
					isdnPort_IUS_Channel_9States.setCkttyp(attributes[24]);
					isdnPort_IUS_Channel_9States.setFecckt_attr(attributes[25]);
					isdnPort_IUS_Channel_9States.setFecckt(attributes[26]);
					isdnPort_IUS_Channel_9States.setPlst_attr(attributes[27]);
					isdnPort_IUS_Channel_9States.setPlst(attributes[28]);
					isdnPort_IUS_Channel_9States.setAuth_num_attr(attributes[29]);
					isdnPort_IUS_Channel_9States.setAuth_num(attributes[30]);
					isdnPort_IUS_Channel_9States.setPri_loc_attr(attributes[31]);
					isdnPort_IUS_Channel_9States.setPri_loc(attributes[32]);
					isdnPort_IUS_Channel_9States.setEulst_attr(attributes[33]);
					isdnPort_IUS_Channel_9States.setEulst(attributes[34]);
					isdnPort_IUS_Channel_9States.setCcea_attr(attributes[35]);
					isdnPort_IUS_Channel_9States.setCcea(attributes[36]);
					isdnPort_IUS_Channel_9States.setCfa_btn_attr(attributes[37]);
					isdnPort_IUS_Channel_9States.setCfa_btn(attributes[38]);
					isdnPort_IUS_Channel_9States.setCb_attr(attributes[39]);
					isdnPort_IUS_Channel_9States.setCb(attributes[40]);
					isdnPort_IUS_Channel_9States.setCbbtn_attr(attributes[41]);
					isdnPort_IUS_Channel_9States.setCbbtn(attributes[42]);
					isdnPort_IUS_Channel_9States.setNcon_attr(attributes[43]);
					isdnPort_IUS_Channel_9States.setNcon(attributes[44]);
					isdnPort_IUS_Channel_9States.setAft_attr(attributes[45]);
					isdnPort_IUS_Channel_9States.setAft(attributes[46]);
					isdnPort_IUS_Channel_9States.setSapr_attr(attributes[47]);
					isdnPort_IUS_Channel_9States.setSapr(attributes[48]);
					isdnPort_IUS_Channel_9States.setSano_attr(attributes[49]);
					isdnPort_IUS_Channel_9States.setSano(attributes[50]);
					isdnPort_IUS_Channel_9States.setSasf_attr(attributes[51]);
					isdnPort_IUS_Channel_9States.setSasf(attributes[52]);
					isdnPort_IUS_Channel_9States.setSasd_attr(attributes[53]);
					isdnPort_IUS_Channel_9States.setSasd(attributes[54]);
					isdnPort_IUS_Channel_9States.setSasn_attr(attributes[55]);
					isdnPort_IUS_Channel_9States.setSasn(attributes[56]);
					isdnPort_IUS_Channel_9States.setSath_attr(attributes[57]);
					isdnPort_IUS_Channel_9States.setSath(attributes[58]);
					isdnPort_IUS_Channel_9States.setSass_attr(attributes[59]);
					isdnPort_IUS_Channel_9States.setSass(attributes[60]);
					isdnPort_IUS_Channel_9States.setLd1_attr(attributes[61]);
					isdnPort_IUS_Channel_9States.setLd1(attributes[62]);
					isdnPort_IUS_Channel_9States.setLv1_attr(attributes[63]);
					isdnPort_IUS_Channel_9States.setLv1(attributes[64]);
					isdnPort_IUS_Channel_9States.setLd2_attr(attributes[65]);
					isdnPort_IUS_Channel_9States.setLd2(attributes[66]);
					isdnPort_IUS_Channel_9States.setLv2_attr(attributes[67]);
					isdnPort_IUS_Channel_9States.setLv2(attributes[68]);
					isdnPort_IUS_Channel_9States.setLd3_attr(attributes[69]);
					isdnPort_IUS_Channel_9States.setLd3(attributes[70]);
					isdnPort_IUS_Channel_9States.setLv3_attr(attributes[71]);
					isdnPort_IUS_Channel_9States.setLv3(attributes[72]);
					isdnPort_IUS_Channel_9States.setAai_attr(attributes[73]);
					isdnPort_IUS_Channel_9States.setAai(attributes[74]);
					isdnPort_IUS_Channel_9States.setCity_attr(attributes[75]);
					isdnPort_IUS_Channel_9States.setCity(attributes[76]);
					isdnPort_IUS_Channel_9States.setState_attr(attributes[77]);
					isdnPort_IUS_Channel_9States.setState(attributes[78]);
					isdnPort_IUS_Channel_9States.setZip_attr(attributes[79]);
					isdnPort_IUS_Channel_9States.setZip(attributes[80]);
					isdnPort_IUS_Channel_9States.setNidr_attr(attributes[81]);
					isdnPort_IUS_Channel_9States.setNidr(attributes[82]);
					isdnPort_IUS_Channel_9States.setIwo_attr(attributes[83]);
					isdnPort_IUS_Channel_9States.setIwo(attributes[84]);
					isdnPort_IUS_Channel_9States.setAloc_attr(attributes[85]);
					isdnPort_IUS_Channel_9States.setAloc(attributes[86]);
					isdnPort_IUS_Channel_9States.setLcon_attr(attributes[87]);
					isdnPort_IUS_Channel_9States.setLcon(attributes[88]);
					isdnPort_IUS_Channel_9States.setTelno_attr(attributes[89]);
					isdnPort_IUS_Channel_9States.setTelno(attributes[90]);
					isdnPort_IUS_Channel_9States.setPtnract_attr(attributes[91]);
					isdnPort_IUS_Channel_9States.setPtnract(attributes[92]);
					isdnPort_IUS_Channel_9States.setPtnrq_attr(attributes[93]);
					isdnPort_IUS_Channel_9States.setPtnrq(attributes[94]);
					isdnPort_IUS_Channel_9States.setPtnr1_attr(attributes[95]);
					isdnPort_IUS_Channel_9States.setPtnr1(attributes[96]);
					isdnPort_IUS_Channel_9States.setPtnr2_attr(attributes[97]);
					isdnPort_IUS_Channel_9States.setPtnr2(attributes[98]);
					isdnPort_IUS_Channel_9States.setPtnr3_attr(attributes[99]);
					isdnPort_IUS_Channel_9States.setPtnr3(attributes[100]);
					isdnPort_IUS_Channel_9States.setNpi_attr(attributes[101]);
					isdnPort_IUS_Channel_9States.setNpi(attributes[102]);
					isdnPort_IUS_Channel_9States.setDidr_attr(attributes[103]);
					isdnPort_IUS_Channel_9States.setDidr(attributes[104]);
					isdnPort_IUS_Channel_9States.setTgtli_attr(attributes[105]);
					isdnPort_IUS_Channel_9States.setTgtli(attributes[106]);
					isdnPort_IUS_Channel_9States.setDba1_attr(attributes[107]);
					isdnPort_IUS_Channel_9States.setDba1(attributes[108]);
					isdnPort_IUS_Channel_9States.setDba2_attr(attributes[109]);
					isdnPort_IUS_Channel_9States.setDba2(attributes[110]);
					isdnPort_IUS_Channel_9States.setDblock1_attr(attributes[111]);
					isdnPort_IUS_Channel_9States.setDblock1(attributes[112]);
					isdnPort_IUS_Channel_9States.setDblock2_attr(attributes[113]);
					isdnPort_IUS_Channel_9States.setDblock2(attributes[114]);
					isdnPort_IUS_Channel_9States.setNba_attr(attributes[115]);
					isdnPort_IUS_Channel_9States.setNba(attributes[116]);
					isdnPort_IUS_Channel_9States.setNbank1_attr(attributes[117]);
					isdnPort_IUS_Channel_9States.setNbank1(attributes[118]);
					isdnPort_IUS_Channel_9States.setNbank2_attr(attributes[119]);
					isdnPort_IUS_Channel_9States.setNbank2(attributes[120]);
					isdnPort_IUS_Channel_9States.setNbank3_attr(attributes[121]);
					isdnPort_IUS_Channel_9States.setNbank3(attributes[122]);
					isdnPort_IUS_Channel_9States.setNbank4_attr(attributes[123]);
					isdnPort_IUS_Channel_9States.setNbank4(attributes[124]);
					isdnPort_IUS_Channel_9States.setDstnact_attr(attributes[125]);
					isdnPort_IUS_Channel_9States.setDstnact(attributes[126]);
					isdnPort_IUS_Channel_9States.setDstnq_attr(attributes[127]);
					isdnPort_IUS_Channel_9States.setDstnq(attributes[128]);
					isdnPort_IUS_Channel_9States.setDstn1_attr(attributes[129]);
					isdnPort_IUS_Channel_9States.setDstn1(attributes[130]);
					isdnPort_IUS_Channel_9States.setDstn2_attr(attributes[131]);
					isdnPort_IUS_Channel_9States.setDstn2(attributes[132]);
					isdnPort_IUS_Channel_9States.setDstn3_attr(attributes[133]);
					isdnPort_IUS_Channel_9States.setDstn3(attributes[134]);
					isdnPort_IUS_Channel_9States.setDstn4_attr(attributes[135]);
					isdnPort_IUS_Channel_9States.setDstn4(attributes[136]);
					isdnPort_IUS_Channel_9States.setDstn5_attr(attributes[137]);
					isdnPort_IUS_Channel_9States.setDstn5(attributes[138]);
					isdnPort_IUS_Channel_9States.setTglna_attr(attributes[139]);
					isdnPort_IUS_Channel_9States.setTglna(attributes[140]);
					isdnPort_IUS_Channel_9States.setTgn_attr(attributes[141]);
					isdnPort_IUS_Channel_9States.setTgn(attributes[142]);
					isdnPort_IUS_Channel_9States.setPtgn_of_attr(attributes[143]);
					isdnPort_IUS_Channel_9States.setPtgn_of(attributes[144]);
					isdnPort_IUS_Channel_9States.setTgtli01_attr(attributes[145]);
					isdnPort_IUS_Channel_9States.setTgtli01(attributes[146]);
					isdnPort_IUS_Channel_9States.setTgrti_attr(attributes[147]);
					isdnPort_IUS_Channel_9States.setTgrti(attributes[148]);
					isdnPort_IUS_Channel_9States.setTgdir_attr(attributes[149]);
					isdnPort_IUS_Channel_9States.setTgdir(attributes[150]);
					isdnPort_IUS_Channel_9States.setPtgnh_attr(attributes[151]);
					isdnPort_IUS_Channel_9States.setPtgnh(attributes[152]);
					isdnPort_IUS_Channel_9States.setDgout_attr(attributes[153]);
					isdnPort_IUS_Channel_9States.setDgout(attributes[154]);
					isdnPort_IUS_Channel_9States.setDg_rcvd_attr(attributes[155]);
					isdnPort_IUS_Channel_9States.setDg_rcvd(attributes[156]);
					isdnPort_IUS_Channel_9States.setPdod_attr(attributes[157]);
					isdnPort_IUS_Channel_9States.setPdod(attributes[158]);
					isdnPort_IUS_Channel_9States.setPic_attr(attributes[159]);
					isdnPort_IUS_Channel_9States.setPic(attributes[160]);
					isdnPort_IUS_Channel_9States.setLpic_attr(attributes[161]);
					isdnPort_IUS_Channel_9States.setLpic(attributes[162]);
					isdnPort_IUS_Channel_9States.setGlare_attr(attributes[163]);
					isdnPort_IUS_Channel_9States.setGlare(attributes[164]);
					isdnPort_IUS_Channel_9States.setPbxid_attr(attributes[165]);
					isdnPort_IUS_Channel_9States.setPbxid(attributes[166]);
					isdnPort_IUS_Channel_9States.setCid_attr(attributes[167]);
					isdnPort_IUS_Channel_9States.setCid(attributes[168]);
					isdnPort_IUS_Channel_9States.setTot_attr(attributes[169]);
					isdnPort_IUS_Channel_9States.setTot(attributes[170]);
					isdnPort_IUS_Channel_9States.setGsind1_attr(attributes[171]);
					isdnPort_IUS_Channel_9States.setGsind1(attributes[172]);
					isdnPort_IUS_Channel_9States.setGsind2_attr(attributes[173]);
					isdnPort_IUS_Channel_9States.setGsind2(attributes[174]);
					isdnPort_IUS_Channel_9States.setGsind3_attr(attributes[175]);
					isdnPort_IUS_Channel_9States.setGsind3(attributes[176]);
					isdnPort_IUS_Channel_9States.setGsind4_attr(attributes[177]);
					isdnPort_IUS_Channel_9States.setGsind4(attributes[178]);
					isdnPort_IUS_Channel_9States.setGsind5_attr(attributes[179]);
					isdnPort_IUS_Channel_9States.setGsind5(attributes[180]);
					isdnPort_IUS_Channel_9States.setGsqty1_attr(attributes[181]);
					isdnPort_IUS_Channel_9States.setGsqty1(attributes[182]);
					isdnPort_IUS_Channel_9States.setGsqty2_attr(attributes[183]);
					isdnPort_IUS_Channel_9States.setGsqty2(attributes[184]);
					isdnPort_IUS_Channel_9States.setGsqty3_attr(attributes[185]);
					isdnPort_IUS_Channel_9States.setGsqty3(attributes[186]);
					isdnPort_IUS_Channel_9States.setGsqty4_attr(attributes[187]);
					isdnPort_IUS_Channel_9States.setGsqty4(attributes[188]);
					isdnPort_IUS_Channel_9States.setGsqty5_attr(attributes[189]);
					isdnPort_IUS_Channel_9States.setGsqty5(attributes[190]);
					isdnPort_IUS_Channel_9States.setGind1_attr(attributes[191]);
					isdnPort_IUS_Channel_9States.setGind1(attributes[192]);
					isdnPort_IUS_Channel_9States.setGind2_attr(attributes[193]);
					isdnPort_IUS_Channel_9States.setGind2(attributes[194]);
					isdnPort_IUS_Channel_9States.setGind3_attr(attributes[195]);
					isdnPort_IUS_Channel_9States.setGind3(attributes[196]);
					isdnPort_IUS_Channel_9States.setGind4_attr(attributes[197]);
					isdnPort_IUS_Channel_9States.setGind4(attributes[198]);
					isdnPort_IUS_Channel_9States.setGqty1_attr(attributes[199]);
					isdnPort_IUS_Channel_9States.setGqty1(attributes[200]);
					isdnPort_IUS_Channel_9States.setGqty2_attr(attributes[201]);
					isdnPort_IUS_Channel_9States.setGqty2(attributes[202]);
					isdnPort_IUS_Channel_9States.setGqty3_attr(attributes[203]);
					isdnPort_IUS_Channel_9States.setGqty3(attributes[204]);
					isdnPort_IUS_Channel_9States.setGqty4_attr(attributes[205]);
					isdnPort_IUS_Channel_9States.setGqty4(attributes[206]);
					isdnPort_IUS_Channel_9States.setSec_loc_attr(attributes[207]);
					isdnPort_IUS_Channel_9States.setSec_loc(attributes[208]);
					isdnPort_IUS_Channel_9States.setCb_sec_attr(attributes[209]);
					isdnPort_IUS_Channel_9States.setCb_sec(attributes[210]);
					isdnPort_IUS_Channel_9States.setCbbtn_sec_attr(attributes[211]);
					isdnPort_IUS_Channel_9States.setCbbtn_sec(attributes[212]);
					isdnPort_IUS_Channel_9States.setActl_attr(attributes[213]);
					isdnPort_IUS_Channel_9States.setActl(attributes[214]);
					isdnPort_IUS_Channel_9States.setCfa_ckt_attr(attributes[215]);
					isdnPort_IUS_Channel_9States.setCfa_ckt(attributes[216]);
					isdnPort_IUS_Channel_9States.setLoc_seq_num(attributes[217]);

					treeViewList9_841.add(isdnPort_IUS_Channel_9States);
				}
				selectRequestData.setSubHeader(receivedSubHeader);

			}

			if (subData_842Recid != null && subData_842Recid.getSubHeader().getRecord_type().equals("842")) {

				SubHeader receivedSubHeader = subData_842Recid.getSubHeader();
				String[] subDataRows = subData_842Recid.getSubDataRows();

				// List treeViewList = new ArrayList();
				// int i = 0;
				treeViewList.add("842");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 218);
					// System.out.println("attributes:=842:Reqid=======> " +
					// Arrays.toString(attributes));
					ISDN_LoopPort_IUS_Channel_9States isdn_LoopPort_IUS_Channel_9States = new ISDN_LoopPort_IUS_Channel_9States();

					isdn_LoopPort_IUS_Channel_9States.setItem_num(attributes[0]);
					isdn_LoopPort_IUS_Channel_9States.setCnum_attr(attributes[1]);
					isdn_LoopPort_IUS_Channel_9States.setCnum(attributes[2]);
					isdn_LoopPort_IUS_Channel_9States.setFnum_attr(attributes[3]);
					isdn_LoopPort_IUS_Channel_9States.setFnum(attributes[4]);
					isdn_LoopPort_IUS_Channel_9States.setTnnum_attr(attributes[5]);
					isdn_LoopPort_IUS_Channel_9States.setTnnum(attributes[6]);
					isdn_LoopPort_IUS_Channel_9States.setTglnum_attr(attributes[7]);
					isdn_LoopPort_IUS_Channel_9States.setTglnum(attributes[8]);
					isdn_LoopPort_IUS_Channel_9States.setEcckt_attr(attributes[9]);
					isdn_LoopPort_IUS_Channel_9States.setEcckt(attributes[10]);
					isdn_LoopPort_IUS_Channel_9States.setCfa_attr(attributes[11]);
					isdn_LoopPort_IUS_Channel_9States.setCfa(attributes[12]);
					isdn_LoopPort_IUS_Channel_9States.setLtgn_attr(attributes[13]);
					isdn_LoopPort_IUS_Channel_9States.setLtgn(attributes[14]);
					isdn_LoopPort_IUS_Channel_9States.setIid_attr(attributes[15]);
					isdn_LoopPort_IUS_Channel_9States.setIid(attributes[16]);
					isdn_LoopPort_IUS_Channel_9States.setCord_attr(attributes[17]);
					isdn_LoopPort_IUS_Channel_9States.setCord(attributes[18]);
					isdn_LoopPort_IUS_Channel_9States.setIsdnp_attr(attributes[19]);
					isdn_LoopPort_IUS_Channel_9States.setIsdnp(attributes[20]);
					isdn_LoopPort_IUS_Channel_9States.setFlna_attr(attributes[21]);
					isdn_LoopPort_IUS_Channel_9States.setFlna(attributes[22]);
					isdn_LoopPort_IUS_Channel_9States.setCkttyp_attr(attributes[23]);
					isdn_LoopPort_IUS_Channel_9States.setCkttyp(attributes[24]);
					isdn_LoopPort_IUS_Channel_9States.setFecckt_attr(attributes[25]);
					isdn_LoopPort_IUS_Channel_9States.setFecckt(attributes[26]);
					isdn_LoopPort_IUS_Channel_9States.setPlst_attr(attributes[27]);
					isdn_LoopPort_IUS_Channel_9States.setPlst(attributes[28]);
					isdn_LoopPort_IUS_Channel_9States.setAuth_num_attr(attributes[29]);
					isdn_LoopPort_IUS_Channel_9States.setAuth_num(attributes[30]);
					isdn_LoopPort_IUS_Channel_9States.setPri_loc_attr(attributes[31]);
					isdn_LoopPort_IUS_Channel_9States.setPri_loc(attributes[32]);
					isdn_LoopPort_IUS_Channel_9States.setEulst_attr(attributes[33]);
					isdn_LoopPort_IUS_Channel_9States.setEulst(attributes[34]);
					isdn_LoopPort_IUS_Channel_9States.setCcea_attr(attributes[35]);
					isdn_LoopPort_IUS_Channel_9States.setCcea(attributes[36]);
					isdn_LoopPort_IUS_Channel_9States.setCfa_btn_attr(attributes[37]);
					isdn_LoopPort_IUS_Channel_9States.setCfa_btn(attributes[38]);
					isdn_LoopPort_IUS_Channel_9States.setCb_attr(attributes[39]);
					isdn_LoopPort_IUS_Channel_9States.setCb(attributes[40]);
					isdn_LoopPort_IUS_Channel_9States.setCbbtn_attr(attributes[41]);
					isdn_LoopPort_IUS_Channel_9States.setCbbtn(attributes[42]);
					isdn_LoopPort_IUS_Channel_9States.setNcon_attr(attributes[43]);
					isdn_LoopPort_IUS_Channel_9States.setNcon(attributes[44]);
					isdn_LoopPort_IUS_Channel_9States.setAft_attr(attributes[45]);
					isdn_LoopPort_IUS_Channel_9States.setAft(attributes[46]);
					isdn_LoopPort_IUS_Channel_9States.setSapr_attr(attributes[47]);
					isdn_LoopPort_IUS_Channel_9States.setSapr(attributes[48]);
					isdn_LoopPort_IUS_Channel_9States.setSano_attr(attributes[49]);
					isdn_LoopPort_IUS_Channel_9States.setSano(attributes[50]);
					isdn_LoopPort_IUS_Channel_9States.setSasf_attr(attributes[51]);
					isdn_LoopPort_IUS_Channel_9States.setSasf(attributes[52]);
					isdn_LoopPort_IUS_Channel_9States.setSasd_attr(attributes[53]);
					isdn_LoopPort_IUS_Channel_9States.setSasd(attributes[54]);
					isdn_LoopPort_IUS_Channel_9States.setSasn_attr(attributes[55]);
					isdn_LoopPort_IUS_Channel_9States.setSasn(attributes[56]);
					isdn_LoopPort_IUS_Channel_9States.setSath_attr(attributes[57]);
					isdn_LoopPort_IUS_Channel_9States.setSath(attributes[58]);
					isdn_LoopPort_IUS_Channel_9States.setSass_attr(attributes[59]);
					isdn_LoopPort_IUS_Channel_9States.setSass(attributes[60]);
					isdn_LoopPort_IUS_Channel_9States.setLd1_attr(attributes[61]);
					isdn_LoopPort_IUS_Channel_9States.setLd1(attributes[62]);
					isdn_LoopPort_IUS_Channel_9States.setLv1_attr(attributes[63]);
					isdn_LoopPort_IUS_Channel_9States.setLv1(attributes[64]);
					isdn_LoopPort_IUS_Channel_9States.setLd2_attr(attributes[65]);
					isdn_LoopPort_IUS_Channel_9States.setLd2(attributes[66]);
					isdn_LoopPort_IUS_Channel_9States.setLv2_attr(attributes[67]);
					isdn_LoopPort_IUS_Channel_9States.setLv2(attributes[68]);
					isdn_LoopPort_IUS_Channel_9States.setLd3_attr(attributes[69]);
					isdn_LoopPort_IUS_Channel_9States.setLd3(attributes[70]);
					isdn_LoopPort_IUS_Channel_9States.setLv3_attr(attributes[71]);
					isdn_LoopPort_IUS_Channel_9States.setLv3(attributes[72]);
					isdn_LoopPort_IUS_Channel_9States.setAai_attr(attributes[73]);
					isdn_LoopPort_IUS_Channel_9States.setAai(attributes[74]);
					isdn_LoopPort_IUS_Channel_9States.setCity_attr(attributes[75]);
					isdn_LoopPort_IUS_Channel_9States.setCity(attributes[76]);
					isdn_LoopPort_IUS_Channel_9States.setState_attr(attributes[77]);
					isdn_LoopPort_IUS_Channel_9States.setState(attributes[78]);
					isdn_LoopPort_IUS_Channel_9States.setZip_attr(attributes[79]);
					isdn_LoopPort_IUS_Channel_9States.setZip(attributes[80]);
					isdn_LoopPort_IUS_Channel_9States.setNidr_attr(attributes[81]);
					isdn_LoopPort_IUS_Channel_9States.setNidr(attributes[82]);
					isdn_LoopPort_IUS_Channel_9States.setIwo_attr(attributes[83]);
					isdn_LoopPort_IUS_Channel_9States.setIwo(attributes[84]);
					isdn_LoopPort_IUS_Channel_9States.setAloc_attr(attributes[85]);
					isdn_LoopPort_IUS_Channel_9States.setAloc(attributes[86]);
					isdn_LoopPort_IUS_Channel_9States.setLcon_attr(attributes[87]);
					isdn_LoopPort_IUS_Channel_9States.setLcon(attributes[88]);
					isdn_LoopPort_IUS_Channel_9States.setTelno_attr(attributes[89]);
					isdn_LoopPort_IUS_Channel_9States.setTelno(attributes[90]);
					isdn_LoopPort_IUS_Channel_9States.setPtnract_attr(attributes[91]);
					isdn_LoopPort_IUS_Channel_9States.setPtnract(attributes[92]);
					isdn_LoopPort_IUS_Channel_9States.setPtnrq_attr(attributes[93]);
					isdn_LoopPort_IUS_Channel_9States.setPtnrq(attributes[94]);
					isdn_LoopPort_IUS_Channel_9States.setPtnr1_attr(attributes[95]);
					isdn_LoopPort_IUS_Channel_9States.setPtnr1(attributes[96]);
					isdn_LoopPort_IUS_Channel_9States.setPtnr2_attr(attributes[97]);
					isdn_LoopPort_IUS_Channel_9States.setPtnr2(attributes[98]);
					isdn_LoopPort_IUS_Channel_9States.setPtnr3_attr(attributes[99]);
					isdn_LoopPort_IUS_Channel_9States.setPtnr3(attributes[100]);
					isdn_LoopPort_IUS_Channel_9States.setNpi_attr(attributes[101]);
					isdn_LoopPort_IUS_Channel_9States.setNpi(attributes[102]);
					isdn_LoopPort_IUS_Channel_9States.setDidr_attr(attributes[103]);
					isdn_LoopPort_IUS_Channel_9States.setDidr(attributes[104]);
					isdn_LoopPort_IUS_Channel_9States.setTgtli_attr(attributes[105]);
					isdn_LoopPort_IUS_Channel_9States.setTgtli(attributes[106]);
					isdn_LoopPort_IUS_Channel_9States.setDba1_attr(attributes[107]);
					isdn_LoopPort_IUS_Channel_9States.setDba1(attributes[108]);
					isdn_LoopPort_IUS_Channel_9States.setDba2_attr(attributes[109]);
					isdn_LoopPort_IUS_Channel_9States.setDba2(attributes[110]);
					isdn_LoopPort_IUS_Channel_9States.setDblock1_attr(attributes[111]);
					isdn_LoopPort_IUS_Channel_9States.setDblock1(attributes[112]);
					isdn_LoopPort_IUS_Channel_9States.setDblock2_attr(attributes[113]);
					isdn_LoopPort_IUS_Channel_9States.setDblock2(attributes[114]);
					isdn_LoopPort_IUS_Channel_9States.setNba_attr(attributes[115]);
					isdn_LoopPort_IUS_Channel_9States.setNba(attributes[116]);
					isdn_LoopPort_IUS_Channel_9States.setNbank1_attr(attributes[117]);
					isdn_LoopPort_IUS_Channel_9States.setNbank1(attributes[118]);
					isdn_LoopPort_IUS_Channel_9States.setNbank2_attr(attributes[119]);
					isdn_LoopPort_IUS_Channel_9States.setNbank2(attributes[120]);
					isdn_LoopPort_IUS_Channel_9States.setNbank3_attr(attributes[121]);
					isdn_LoopPort_IUS_Channel_9States.setNbank3(attributes[122]);
					isdn_LoopPort_IUS_Channel_9States.setNbank4_attr(attributes[123]);
					isdn_LoopPort_IUS_Channel_9States.setNbank4(attributes[124]);
					isdn_LoopPort_IUS_Channel_9States.setDstnact_attr(attributes[125]);
					isdn_LoopPort_IUS_Channel_9States.setDstnact(attributes[126]);
					isdn_LoopPort_IUS_Channel_9States.setDstnq_attr(attributes[127]);
					isdn_LoopPort_IUS_Channel_9States.setDstnq(attributes[128]);
					isdn_LoopPort_IUS_Channel_9States.setDstn1_attr(attributes[129]);
					isdn_LoopPort_IUS_Channel_9States.setDstn1(attributes[130]);
					isdn_LoopPort_IUS_Channel_9States.setDstn2_attr(attributes[131]);
					isdn_LoopPort_IUS_Channel_9States.setDstn2(attributes[132]);
					isdn_LoopPort_IUS_Channel_9States.setDstn3_attr(attributes[133]);
					isdn_LoopPort_IUS_Channel_9States.setDstn3(attributes[134]);
					isdn_LoopPort_IUS_Channel_9States.setDstn4_attr(attributes[135]);
					isdn_LoopPort_IUS_Channel_9States.setDstn4(attributes[136]);
					isdn_LoopPort_IUS_Channel_9States.setDstn5_attr(attributes[137]);
					isdn_LoopPort_IUS_Channel_9States.setDstn5(attributes[138]);
					isdn_LoopPort_IUS_Channel_9States.setTglna_attr(attributes[139]);
					isdn_LoopPort_IUS_Channel_9States.setTglna(attributes[140]);
					isdn_LoopPort_IUS_Channel_9States.setTgn_attr(attributes[141]);
					isdn_LoopPort_IUS_Channel_9States.setTgn(attributes[142]);
					isdn_LoopPort_IUS_Channel_9States.setPtgn_of_attr(attributes[143]);
					isdn_LoopPort_IUS_Channel_9States.setPtgn_of(attributes[144]);
					isdn_LoopPort_IUS_Channel_9States.setTgtli01_attr(attributes[145]);
					isdn_LoopPort_IUS_Channel_9States.setTgtli01(attributes[146]);
					isdn_LoopPort_IUS_Channel_9States.setTgrti_attr(attributes[147]);
					isdn_LoopPort_IUS_Channel_9States.setTgrti(attributes[148]);
					isdn_LoopPort_IUS_Channel_9States.setTgdir_attr(attributes[149]);
					isdn_LoopPort_IUS_Channel_9States.setTgdir(attributes[150]);
					isdn_LoopPort_IUS_Channel_9States.setPtgnh_attr(attributes[151]);
					isdn_LoopPort_IUS_Channel_9States.setPtgnh(attributes[152]);
					isdn_LoopPort_IUS_Channel_9States.setDgout_attr(attributes[153]);
					isdn_LoopPort_IUS_Channel_9States.setDgout(attributes[154]);
					isdn_LoopPort_IUS_Channel_9States.setDg_rcvd_attr(attributes[155]);
					isdn_LoopPort_IUS_Channel_9States.setDg_rcvd(attributes[156]);
					isdn_LoopPort_IUS_Channel_9States.setPdod_attr(attributes[157]);
					isdn_LoopPort_IUS_Channel_9States.setPdod(attributes[158]);
					isdn_LoopPort_IUS_Channel_9States.setPic_attr(attributes[159]);
					isdn_LoopPort_IUS_Channel_9States.setPic(attributes[160]);
					isdn_LoopPort_IUS_Channel_9States.setLpic_attr(attributes[161]);
					isdn_LoopPort_IUS_Channel_9States.setLpic(attributes[162]);
					isdn_LoopPort_IUS_Channel_9States.setGlare_attr(attributes[163]);
					isdn_LoopPort_IUS_Channel_9States.setGlare(attributes[164]);
					isdn_LoopPort_IUS_Channel_9States.setPbxid_attr(attributes[165]);
					isdn_LoopPort_IUS_Channel_9States.setPbxid(attributes[166]);
					isdn_LoopPort_IUS_Channel_9States.setCid_attr(attributes[167]);
					isdn_LoopPort_IUS_Channel_9States.setCid(attributes[168]);
					isdn_LoopPort_IUS_Channel_9States.setTot_attr(attributes[169]);
					isdn_LoopPort_IUS_Channel_9States.setTot(attributes[170]);
					isdn_LoopPort_IUS_Channel_9States.setGsind1_attr(attributes[171]);
					isdn_LoopPort_IUS_Channel_9States.setGsind1(attributes[172]);
					isdn_LoopPort_IUS_Channel_9States.setGsind2_attr(attributes[173]);
					isdn_LoopPort_IUS_Channel_9States.setGsind2(attributes[174]);
					isdn_LoopPort_IUS_Channel_9States.setGsind3_attr(attributes[175]);
					isdn_LoopPort_IUS_Channel_9States.setGsind3(attributes[176]);
					isdn_LoopPort_IUS_Channel_9States.setGsind4_attr(attributes[177]);
					isdn_LoopPort_IUS_Channel_9States.setGsind4(attributes[178]);
					isdn_LoopPort_IUS_Channel_9States.setGsind5_attr(attributes[179]);
					isdn_LoopPort_IUS_Channel_9States.setGsind5(attributes[180]);
					isdn_LoopPort_IUS_Channel_9States.setGsqty1_attr(attributes[181]);
					isdn_LoopPort_IUS_Channel_9States.setGsqty1(attributes[182]);
					isdn_LoopPort_IUS_Channel_9States.setGsqty2_attr(attributes[183]);
					isdn_LoopPort_IUS_Channel_9States.setGsqty2(attributes[184]);
					isdn_LoopPort_IUS_Channel_9States.setGsqty3_attr(attributes[185]);
					isdn_LoopPort_IUS_Channel_9States.setGsqty3(attributes[186]);
					isdn_LoopPort_IUS_Channel_9States.setGsqty4_attr(attributes[187]);
					isdn_LoopPort_IUS_Channel_9States.setGsqty4(attributes[188]);
					isdn_LoopPort_IUS_Channel_9States.setGsqty5_attr(attributes[189]);
					isdn_LoopPort_IUS_Channel_9States.setGsqty5(attributes[190]);
					isdn_LoopPort_IUS_Channel_9States.setGind1_attr(attributes[191]);
					isdn_LoopPort_IUS_Channel_9States.setGind1(attributes[192]);
					isdn_LoopPort_IUS_Channel_9States.setGind2_attr(attributes[193]);
					isdn_LoopPort_IUS_Channel_9States.setGind2(attributes[194]);
					isdn_LoopPort_IUS_Channel_9States.setGind3_attr(attributes[195]);
					isdn_LoopPort_IUS_Channel_9States.setGind3(attributes[196]);
					isdn_LoopPort_IUS_Channel_9States.setGind4_attr(attributes[197]);
					isdn_LoopPort_IUS_Channel_9States.setGind4(attributes[198]);
					isdn_LoopPort_IUS_Channel_9States.setGqty1_attr(attributes[199]);
					isdn_LoopPort_IUS_Channel_9States.setGqty1(attributes[200]);
					isdn_LoopPort_IUS_Channel_9States.setGqty2_attr(attributes[201]);
					isdn_LoopPort_IUS_Channel_9States.setGqty2(attributes[202]);
					isdn_LoopPort_IUS_Channel_9States.setGqty3_attr(attributes[203]);
					isdn_LoopPort_IUS_Channel_9States.setGqty3(attributes[204]);
					isdn_LoopPort_IUS_Channel_9States.setGqty4_attr(attributes[205]);
					isdn_LoopPort_IUS_Channel_9States.setGqty4(attributes[206]);
					isdn_LoopPort_IUS_Channel_9States.setSec_loc_attr(attributes[207]);
					isdn_LoopPort_IUS_Channel_9States.setSec_loc(attributes[208]);
					isdn_LoopPort_IUS_Channel_9States.setCb_sec_attr(attributes[209]);
					isdn_LoopPort_IUS_Channel_9States.setCb_sec(attributes[210]);
					isdn_LoopPort_IUS_Channel_9States.setCbbtn_sec_attr(attributes[211]);
					isdn_LoopPort_IUS_Channel_9States.setCbbtn_sec(attributes[212]);
					isdn_LoopPort_IUS_Channel_9States.setActl_attr(attributes[213]);
					isdn_LoopPort_IUS_Channel_9States.setActl(attributes[214]);
					isdn_LoopPort_IUS_Channel_9States.setCfa_ckt_attr(attributes[215]);
					isdn_LoopPort_IUS_Channel_9States.setCfa_ckt(attributes[216]);
					isdn_LoopPort_IUS_Channel_9States.setLoc_seq_num(attributes[217]);

					treeViewList9_842.add(isdn_LoopPort_IUS_Channel_9States);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
			}


			session.setAttribute("treeViewList9_842", treeViewList9_842);
			session.setAttribute("treeViewList9_159", treeViewList9_159);
			session.setAttribute("treeViewList9_157", treeViewList9_157);
			session.setAttribute("treeViewList9_158", treeViewList9_158);
			session.setAttribute("treeViewList9_841", treeViewList9_841);
			session.setAttribute("treeViewList9_210", treeViewList9_210);

			
			// Divya

			if (subData_880Recid != null && subData_880Recid.getSubHeader().getRecord_type().equals("880")) {
				SubHeader receivedSubHeader = subData_880Recid.getSubHeader();
				String[] subDataRows = subData_880Recid.getSubDataRows();
				List<ConfirmationReqtypBandC9StatesRowDW1> treeview880 = new ArrayList();
				treeViewList.add("880");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 27);
					// System.out.println("subData_880Recid:=======> " + Arrays.toString(attributes));
					ConfirmationReqtypBandC9StatesRowDW1 confirmationReqtypBandC9StatesRowDW1 = new ConfirmationReqtypBandC9StatesRowDW1();

					confirmationReqtypBandC9StatesRowDW1.setA_cver(attributes[0]);
					confirmationReqtypBandC9StatesRowDW1.setA_atn_attr(attributes[1]);
					confirmationReqtypBandC9StatesRowDW1.setA_atn(attributes[2]);
					confirmationReqtypBandC9StatesRowDW1.setA_init_attr(attributes[3]);
					confirmationReqtypBandC9StatesRowDW1.setA_init(attributes[4]);
					confirmationReqtypBandC9StatesRowDW1.setA_rep(attributes[5]);
					confirmationReqtypBandC9StatesRowDW1.setA_tel_no(attributes[6]);
					confirmationReqtypBandC9StatesRowDW1.setA_rt(attributes[7]);
					confirmationReqtypBandC9StatesRowDW1.setA_ecver(attributes[8]);

					confirmationReqtypBandC9StatesRowDW1.setA_d_t_sent_local(attributes[9]);
					confirmationReqtypBandC9StatesRowDW1.setA_response_d_t_sent_cent_time(attributes[10]);
					confirmationReqtypBandC9StatesRowDW1.setA_pia(attributes[11]);
					confirmationReqtypBandC9StatesRowDW1.setA_chc(attributes[12]);
					confirmationReqtypBandC9StatesRowDW1.setA_fdt_attr(attributes[13]);
					confirmationReqtypBandC9StatesRowDW1.setA_fdt(attributes[14]);
					confirmationReqtypBandC9StatesRowDW1.setA_dd_attr(attributes[15]);
					confirmationReqtypBandC9StatesRowDW1.setA_dd(attributes[16]);
					confirmationReqtypBandC9StatesRowDW1.setApptime_attr(attributes[17]);
					confirmationReqtypBandC9StatesRowDW1.setApptime(attributes[18]);
					confirmationReqtypBandC9StatesRowDW1.setEbd_attr(attributes[19]);
					confirmationReqtypBandC9StatesRowDW1.setEbd(attributes[20]);
					confirmationReqtypBandC9StatesRowDW1.setBan1_attr(attributes[21]);
					confirmationReqtypBandC9StatesRowDW1.setBan1(attributes[22]);
					confirmationReqtypBandC9StatesRowDW1.setBan2_attr(attributes[23]);
					confirmationReqtypBandC9StatesRowDW1.setBan2(attributes[24]);
					confirmationReqtypBandC9StatesRowDW1.setA_an_attr(attributes[25]);
					confirmationReqtypBandC9StatesRowDW1.setA_an(attributes[26]);

					treeview880.add(confirmationReqtypBandC9StatesRowDW1);

				}

				session.setAttribute("treeview880", treeview880);
				selectRequestData.setSubHeader(receivedSubHeader);

			}

			if (subData_882Recid != null && subData_882Recid.getSubHeader().getRecord_type().equals("882")) {
				SubHeader receivedSubHeader = subData_882Recid.getSubHeader();
				String[] subDataRows = subData_882Recid.getSubDataRows();
				List<ConfirmationReqtypBandC9StatesRowDW5> treeview882 = new ArrayList();

				treeViewList.add("882");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 43);
					// System.out.println("attributes:=882======> " + Arrays.toString(attributes));
					ConfirmationReqtypBandC9StatesRowDW5 confirmationReqtypBandC9StatesRowDW5 = new ConfirmationReqtypBandC9StatesRowDW5();

					confirmationReqtypBandC9StatesRowDW5.setItemnum(attributes[0]);
					confirmationReqtypBandC9StatesRowDW5.setLnum(attributes[1]);
					confirmationReqtypBandC9StatesRowDW5.setNumname(attributes[2]);
					confirmationReqtypBandC9StatesRowDW5.setNum_nbr(attributes[3]);
					confirmationReqtypBandC9StatesRowDW5.setOrd_attr(attributes[4]);
					confirmationReqtypBandC9StatesRowDW5.setOrd(attributes[5]);
					confirmationReqtypBandC9StatesRowDW5.setLord_attr(attributes[6]);
					confirmationReqtypBandC9StatesRowDW5.setLord(attributes[7]);
					confirmationReqtypBandC9StatesRowDW5.setFdt_attr(attributes[8]);
					confirmationReqtypBandC9StatesRowDW5.setFdt(attributes[9]);
					confirmationReqtypBandC9StatesRowDW5.setDd_attr(attributes[10]);
					confirmationReqtypBandC9StatesRowDW5.setDd(attributes[11]);
					confirmationReqtypBandC9StatesRowDW5.setEcckt_attr(attributes[12]);
					confirmationReqtypBandC9StatesRowDW5.setEcckt(attributes[13]);
					confirmationReqtypBandC9StatesRowDW5.setCkr(attributes[14]);
					confirmationReqtypBandC9StatesRowDW5.setShared_nbr(attributes[15]);
					confirmationReqtypBandC9StatesRowDW5.setDisc_nbr(attributes[16]);
					confirmationReqtypBandC9StatesRowDW5.setRecckt(attributes[17]);
					confirmationReqtypBandC9StatesRowDW5.setTns_attr(attributes[18]);
					confirmationReqtypBandC9StatesRowDW5.setTns(attributes[19]);
					confirmationReqtypBandC9StatesRowDW5.setTers_attr(attributes[20]);
					confirmationReqtypBandC9StatesRowDW5.setTers(attributes[21]);
					confirmationReqtypBandC9StatesRowDW5.setCfa(attributes[22]);
					confirmationReqtypBandC9StatesRowDW5.setCcea(attributes[23]);
					confirmationReqtypBandC9StatesRowDW5.setIspid_attr(attributes[24]);
					confirmationReqtypBandC9StatesRowDW5.setIspid(attributes[25]);
					confirmationReqtypBandC9StatesRowDW5.setFecckt_attr(attributes[26]);
					confirmationReqtypBandC9StatesRowDW5.setFecckt(attributes[27]);
					confirmationReqtypBandC9StatesRowDW5.setNpord_attr(attributes[28]);
					confirmationReqtypBandC9StatesRowDW5.setNpord(attributes[29]);
					confirmationReqtypBandC9StatesRowDW5.setPorted_nbr(attributes[30]);
					confirmationReqtypBandC9StatesRowDW5.setRti_attr(attributes[31]);
					confirmationReqtypBandC9StatesRowDW5.setRti(attributes[32]);
					confirmationReqtypBandC9StatesRowDW5.setCbcid_attr(attributes[33]);
					confirmationReqtypBandC9StatesRowDW5.setCbcid(attributes[34]);
					confirmationReqtypBandC9StatesRowDW5.setCableid_attr(attributes[35]);
					confirmationReqtypBandC9StatesRowDW5.setCableid(attributes[36]);
					confirmationReqtypBandC9StatesRowDW5.setChan_pair_attr(attributes[37]);
					confirmationReqtypBandC9StatesRowDW5.setChain_pair(attributes[38]);
					confirmationReqtypBandC9StatesRowDW5.setOld_ord(attributes[39]);
					confirmationReqtypBandC9StatesRowDW5.setOld_lord(attributes[40]);
					confirmationReqtypBandC9StatesRowDW5.setOld_npord(attributes[41]);
					;

					confirmationReqtypBandC9StatesRowDW5.setLoc_seq_num(attributes[42]);
					treeview882.add(confirmationReqtypBandC9StatesRowDW5);

				}
				session.setAttribute("treeview882", treeview882);
				selectRequestData.setSubHeader(receivedSubHeader);

			}

			if (subData_888Recid != null && subData_888Recid.getSubHeader().getRecord_type().equals("888")) {
				SubHeader receivedSubHeader = subData_888Recid.getSubHeader();
				String[] subDataRows = subData_888Recid.getSubDataRows();
				List<ConfirmationLS0G6DW2Row> treeview888 = new ArrayList();
				treeViewList.add("888");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);
					// System.out.println("attributes:=888======> " + Arrays.toString(attributes));
					ConfirmationLS0G6DW2Row confirmationLS0G6DW2Row = new ConfirmationLS0G6DW2Row();

					confirmationLS0G6DW2Row.setOld_dtm(attributes[0]);
					confirmationLS0G6DW2Row.setOld_ord(attributes[1]);
					confirmationLS0G6DW2Row.setOrd_attr(attributes[2]);
					confirmationLS0G6DW2Row.setOrd(attributes[3]);
					confirmationLS0G6DW2Row.setFdt_attr(attributes[4]);
					confirmationLS0G6DW2Row.setFdt(attributes[5]);
					confirmationLS0G6DW2Row.setDd_attr(attributes[6]);
					confirmationLS0G6DW2Row.setDd(attributes[7]);
					confirmationLS0G6DW2Row.setComp_dt_attr(attributes[8]);
					confirmationLS0G6DW2Row.setComp_dt(attributes[9]);
					confirmationLS0G6DW2Row.setPosted_date_attr(attributes[10]);
					confirmationLS0G6DW2Row.setPosted_date(attributes[11]);
					confirmationLS0G6DW2Row.setApptime_attr(attributes[12]);
					confirmationLS0G6DW2Row.setApptime(attributes[13]);

					treeview888.add(confirmationLS0G6DW2Row);

				}
				System.out.println("==========treeview888=========================");
				treeview888.forEach(x-> System.out.println(x));
				session.setAttribute("treeview888", treeview888);
				selectRequestData.setSubHeader(receivedSubHeader);
			}

			if (subData_886Recid != null && subData_886Recid.getSubHeader().getRecord_type().equals("886")) {
				SubHeader receivedSubHeader = subData_886Recid.getSubHeader();
				String[] subDataRows = subData_886Recid.getSubDataRows();
				treeViewList.add("886");

				List<ConfirmationNonProdLSOG6Row> treeview_886 = new ArrayList();
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);
					// System.out.println("attributes:=886======> " + Arrays.toString(attributes));
					ConfirmationNonProdLSOG6Row confirmationNonProdLSOG6Row = new ConfirmationNonProdLSOG6Row();

					confirmationNonProdLSOG6Row.setCver(attributes[0]);
					confirmationNonProdLSOG6Row.setSvc_rep_tn(attributes[1]);
					confirmationNonProdLSOG6Row.setSvc_rep(attributes[2]);
					confirmationNonProdLSOG6Row.setAtn_attr(attributes[3]);
					confirmationNonProdLSOG6Row.setAtn(attributes[4]);
					confirmationNonProdLSOG6Row.setRt(attributes[5]);
					confirmationNonProdLSOG6Row.setEcver(attributes[6]);
					confirmationNonProdLSOG6Row.setD_t_sent_local(attributes[7]);
					confirmationNonProdLSOG6Row.setResponse_d_t_sent_central_time(attributes[8]);
					confirmationNonProdLSOG6Row.setDd_attr(attributes[9]);
					confirmationNonProdLSOG6Row.setDd(attributes[10]);
					confirmationNonProdLSOG6Row.setPia(attributes[11]);
					confirmationNonProdLSOG6Row.setAn_attr(attributes[12]);
					confirmationNonProdLSOG6Row.setAn(attributes[13]);

					treeview_886.add(confirmationNonProdLSOG6Row);

				}
				session.setAttribute("treeview_886", treeview_886);
				selectRequestData.setSubHeader(receivedSubHeader);

			}

			/*
			 * if (subData_488Recid != null &&
			 * subData_488Recid.getSubHeader().getRecord_type().equals("488")) { SubHeader
			 * receivedSubHeader = subData_488Recid.getSubHeader(); String[] subDataRows =
			 * subData_488Recid.getSubDataRows(); List<ConfirmationReqtypBandC9StatesRowDW3>
			 * treeview488 = new ArrayList(); treeViewList.add("488"); for (String
			 * subDataRow : subDataRows) { String[] attributes =
			 * mqReadUtil.getAttributes(subDataRow, 5); //
			 * System.out.println("attributes:=488======> " + Arrays.toString(attributes));
			 * ConfirmationReqtypBandC9StatesRowDW3 confirmationReqtypBandC9StatesRowDW3 =
			 * new ConfirmationReqtypBandC9StatesRowDW3();
			 * 
			 * confirmationReqtypBandC9StatesRowDW3.setOrd(attributes[0]);
			 * confirmationReqtypBandC9StatesRowDW3.setNpord(attributes[1]); ;
			 * confirmationReqtypBandC9StatesRowDW3.setDiscord(attributes[2]);
			 * confirmationReqtypBandC9StatesRowDW3.setDd(attributes[3]); ;
			 * confirmationReqtypBandC9StatesRowDW3.setFdt(attributes[4]); ;
			 * 
			 * treeview488.add(confirmationReqtypBandC9StatesRowDW3);
			 * 
			 * } session.setAttribute("treeview488", treeview488);
			 * selectRequestData.setSubHeader(receivedSubHeader);
			 * 
			 * }
			 */
			if (subData_928Recid != null && subData_928Recid.getSubHeader().getRecord_type().equals("928")) {
				SubHeader receivedSubHeader = subData_928Recid.getSubHeader();
				String[] subDataRows = subData_928Recid.getSubDataRows();
				List<ConfirmationViewNonEmailCoreXMLGWServiceSection9StatesRow> treeview928 = new ArrayList();
				treeViewList.add("928");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 69);
					// System.out.println("attributes:=928======> " + Arrays.toString(attributes));
					ConfirmationViewNonEmailCoreXMLGWServiceSection9StatesRow service = new ConfirmationViewNonEmailCoreXMLGWServiceSection9StatesRow();
					service.setLocnum_attr(attributes[0]);
					service.setLocnum(attributes[1]);
					service.setLnum_attr(attributes[2]);
					service.setLnum(attributes[3]);

					service.setLnex_attr(attributes[4]);

					service.setLnex(attributes[5]);
					service.setEcckt_attr(attributes[6]);
					service.setEcckt(attributes[7]);
					service.setNotyp_attr(attributes[8]);
					service.setNotyp(attributes[9]);
					service.setLean_attr(attributes[10]);
					service.setLean(attributes[11]);
					service.setLeatn_attr(attributes[12]);
					service.setLeatn(attributes[13]);
					service.setTns_attr(attributes[14]);
					service.setTns(attributes[15]);
					service.setRti_attr(attributes[16]);
					service.setRti(attributes[17]);
					;
					service.setTers_attr(attributes[18]);
					service.setTers(attributes[19]);
					service.setOtn_attr(attributes[20]);
					service.setOtn(attributes[21]);
					service.setMatn_attr(attributes[22]);
					service.setMatn(attributes[23]);
					service.setIspid_attr(attributes[24]);
					service.setIspid(attributes[25]);
					service.setLst_attr(attributes[26]);
					service.setLst(attributes[27]);
					service.setCkr_attr(attributes[28]);
					service.setCkr(attributes[29]);
					service.setLord_attr(attributes[30]);
					service.setLord(attributes[31]);
					service.setShelf_attr(attributes[32]);
					service.setShelf(attributes[33]);
					service.setPorted_nbr_attr(attributes[34]);
					service.setPorted_nbr(attributes[35]);
					service.setDisc_nbr_attr(attributes[36]);
					service.setDisc_nbr(attributes[37]);
					service.setChan_pair_attr(attributes[38]);
					service.setChan_pair(attributes[39]);
					service.setSlot_attr(attributes[40]);
					service.setSlot(attributes[41]);
					service.setCable_id_attr(attributes[42]);
					service.setCable_id(attributes[43]);
					service.setCable_id2_attr(attributes[44]);
					service.setCable_id2(attributes[45]);
					service.setSltn_attr(attributes[46]);
					service.setSltn(attributes[47]);
					service.setChan_pair2_attr(attributes[48]);
					service.setChan_pair2(attributes[49]);
					service.setRelay_rack_attr(attributes[50]);
					service.setRelay_rack(attributes[51]);
					service.setSystemid_attr(attributes[52]);
					service.setSystemid(attributes[53]);

					service.setPid_attr(attributes[54]);
					service.setPid(attributes[55]);
					service.setResid_attr(attributes[56]);
					;
					service.setResid(attributes[57]);
					service.setDnum_attr(attributes[58]);
					service.setDnum(attributes[59]);
					service.setSat_attr(attributes[60]);
					service.setSat(attributes[61]);
					service.setNpord_attr(attributes[62]);
					service.setNpord(attributes[63]);
					service.setTer_attr(attributes[64]);
					service.setTer(attributes[65]);
					service.setCfa(attributes[66]);
					service.setScfa(attributes[67]);

				}
				session.setAttribute("treeview928", treeview928);

				selectRequestData.setSubHeader(receivedSubHeader);

			}
			//

			if (subData_926Recid != null && subData_926Recid.getSubHeader().getRecord_type().equals("926")) {
				SubHeader receivedSubHeader = subData_926Recid.getSubHeader();
				String[] subDataRows = subData_926Recid.getSubDataRows();
				List<ConfirmationViewNonEmailCoreXMLGWLSREURow9States> treeview926 = new ArrayList();
				treeViewList.add("926");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 51);
					// System.out.println("attributes:=926======> " + Arrays.toString(attributes));
					ConfirmationViewNonEmailCoreXMLGWLSREURow9States confirmationViewNonEmailCoreXMLGWLSREU9StatesRow = new ConfirmationViewNonEmailCoreXMLGWLSREURow9States();
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setEcver(attributes[0]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setCver(attributes[1]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setTran_ack_type(attributes[2]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setDt_sent(attributes[3]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setTest_prod_ind(attributes[4]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setInit(attributes[5]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setInit_tel_no(attributes[6]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setRep(attributes[7]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setRep_tel_no(attributes[8]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setChc(attributes[9]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setCcna(attributes[10]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setIsid(attributes[11]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setIbt(attributes[12]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setEbd_attr(attributes[13]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setEbd(attributes[14]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setBi1(attributes[15]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setBan1(attributes[16]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setBan1_attr(attributes[17]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setBan2(attributes[18]);

					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setBi2(attributes[19]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setBan2_attr(attributes[20]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setFdt_attr(attributes[21]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setFdt(attributes[22]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setNnsp(attributes[23]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setDsgcon(attributes[24]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setDsgcon_tel_no(attributes[25]);

					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setEan(attributes[26]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setEatn(attributes[27]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setIwban(attributes[28]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setDisc_nbr(attributes[29]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setBopi(attributes[30]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setNor(attributes[31]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setTran_set_id(attributes[32]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setTran_set_purpose(attributes[33]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setDlord(attributes[34]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setPonkey(attributes[35]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setStaus_code(attributes[36]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setStatus_msg(attributes[37]);

					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setDdcd_attr(attributes[38]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setDdcd(attributes[39]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setGsid(attributes[40]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setAan(attributes[41]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setAtn(attributes[42]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setNatn(attributes[43]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setNan(attributes[44]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setAn(attributes[45]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setError_code(attributes[46]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setRt(attributes[47]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setDt_sent_local(attributes[48]);
					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setRemarks_attr(attributes[49]);

					confirmationViewNonEmailCoreXMLGWLSREU9StatesRow.setRemarks(attributes[50]);

					treeview926.add(confirmationViewNonEmailCoreXMLGWLSREU9StatesRow);

				}
				session.setAttribute("treeview926", treeview926);
				// System.out.println(treeview926.get(0).getAtn());
				// System.out.println(treeview926.get(0).getBan1());
				selectRequestData.setSubHeader(receivedSubHeader);

			}

			if (subData_927Recid != null && subData_927Recid.getSubHeader().getRecord_type().equals("927")) {

				SubHeader receivedSubHeader = subData_927Recid.getSubHeader();
				String[] subDataRows = subData_927Recid.getSubDataRows();

				List<ConfirmationReqtypBandC9StatesRowDW3> treeview927 = new ArrayList();
				treeViewList.add("927");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 5);
					// System.out.println("attributes:=927======> " + Arrays.toString(attributes));
					ConfirmationReqtypBandC9StatesRowDW3 confirmationReqtypBandC9StatesRowDW3 = new ConfirmationReqtypBandC9StatesRowDW3();
					confirmationReqtypBandC9StatesRowDW3.setOrd(attributes[0]);
					confirmationReqtypBandC9StatesRowDW3.setNpord(attributes[1]);
					;
					confirmationReqtypBandC9StatesRowDW3.setDiscord(attributes[2]);
					confirmationReqtypBandC9StatesRowDW3.setDd(attributes[3]);
					confirmationReqtypBandC9StatesRowDW3.setFdt(attributes[4]);

					treeview927.add(confirmationReqtypBandC9StatesRowDW3);

				}
				session.setAttribute("treeview927", treeview927);
				// System.out.println(treeview927.get(0).getOrd());
				// System.out.println(treeview927.get(0).getNpord());
				selectRequestData.setSubHeader(receivedSubHeader);
			}

			if (subData_930Recid != null && subData_930Recid.getSubHeader().getRecord_type().equals("930")) {
				SubHeader receivedSubHeader = subData_930Recid.getSubHeader();
				String[] subDataRows = subData_930Recid.getSubDataRows();
				List<ConfirmationViewNonEmailCoreXMLGWHuntingDW29StatesRow> treeview930 = new ArrayList();
				treeViewList.add("930");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 6);
					// System.out.println("attributes:=930======> " + Arrays.toString(attributes));
					ConfirmationViewNonEmailCoreXMLGWHuntingDW29StatesRow confirmationViewNonEmailCoreXMLGWHuntingDW29StatesRow = new ConfirmationViewNonEmailCoreXMLGWHuntingDW29StatesRow();

					confirmationViewNonEmailCoreXMLGWHuntingDW29StatesRow.setHtseq_Attr(attributes[0]);
					confirmationViewNonEmailCoreXMLGWHuntingDW29StatesRow.setHtseq(attributes[1]);
					confirmationViewNonEmailCoreXMLGWHuntingDW29StatesRow.setHt_attr(attributes[2]);
					confirmationViewNonEmailCoreXMLGWHuntingDW29StatesRow.setHt(attributes[3]);
					confirmationViewNonEmailCoreXMLGWHuntingDW29StatesRow.setLoc_attr(attributes[4]);
					confirmationViewNonEmailCoreXMLGWHuntingDW29StatesRow.setLoc(attributes[5]);

					treeview930.add(confirmationViewNonEmailCoreXMLGWHuntingDW29StatesRow);

				}
				session.setAttribute("treeview930", treeview930);
				selectRequestData.setSubHeader(receivedSubHeader);

			}

			if (subData_929Recid != null && subData_929Recid.getSubHeader().getRecord_type().equals("929")) {
				SubHeader receivedSubHeader = subData_929Recid.getSubHeader();
				String[] subDataRows = subData_929Recid.getSubDataRows();
				List<ConfirmationViewNonEmailCoreXMLGWHunting9StatesRow> treeview929 = new ArrayList();
				treeViewList.add("929");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 9);
					// System.out.println("attributes:=925======> " + Arrays.toString(attributes));
					ConfirmationViewNonEmailCoreXMLGWHunting9StatesRow confirmationViewNonEmailCoreXMLGWHunting9StatesRow = new ConfirmationViewNonEmailCoreXMLGWHunting9StatesRow();

					confirmationViewNonEmailCoreXMLGWHunting9StatesRow.setHnum_attr(attributes[0]);
					confirmationViewNonEmailCoreXMLGWHunting9StatesRow.setHnum(attributes[1]);
					confirmationViewNonEmailCoreXMLGWHunting9StatesRow.setHa_attr(attributes[2]);
					confirmationViewNonEmailCoreXMLGWHunting9StatesRow.setHa(attributes[3]);
					confirmationViewNonEmailCoreXMLGWHunting9StatesRow.setHid_attr(attributes[4]);
					confirmationViewNonEmailCoreXMLGWHunting9StatesRow.setHid(attributes[5]);
					confirmationViewNonEmailCoreXMLGWHunting9StatesRow.setHtli_attr(attributes[0]);
					confirmationViewNonEmailCoreXMLGWHunting9StatesRow.setHtli(attributes[7]);
					confirmationViewNonEmailCoreXMLGWHunting9StatesRow.setLocnum(attributes[8]);

					treeview929.add(confirmationViewNonEmailCoreXMLGWHunting9StatesRow);

				}
				session.setAttribute("treeview929", treeview929);
				selectRequestData.setSubHeader(receivedSubHeader);

			}

			if (subData_895Recid != null && subData_895Recid.getSubHeader().getRecord_type().equals("895")) {
				SubHeader receivedSubHeader = subData_895Recid.getSubHeader();
				String[] subDataRows = subData_895Recid.getSubDataRows();
				List<ConfirmationViewNonEmailCoreXMLGWDirectoryRow9states> treeview895 = new ArrayList();
				treeViewList.add("895");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 23);
					// System.out.println("attributes:=895======> " + Arrays.toString(attributes));
					ConfirmationViewNonEmailCoreXMLGWDirectoryRow9states confirmationViewNonEmailCoreXMLGWDirectoryRow9states = new ConfirmationViewNonEmailCoreXMLGWDirectoryRow9states();

					confirmationViewNonEmailCoreXMLGWDirectoryRow9states.setDlnum(attributes[0]);
					confirmationViewNonEmailCoreXMLGWDirectoryRow9states.setAli_attr(attributes[1]);
					confirmationViewNonEmailCoreXMLGWDirectoryRow9states.setAli(attributes[2]);
					confirmationViewNonEmailCoreXMLGWDirectoryRow9states.setLtn_attr(attributes[3]);
					confirmationViewNonEmailCoreXMLGWDirectoryRow9states.setLtn(attributes[4]);
					confirmationViewNonEmailCoreXMLGWDirectoryRow9states.setNstn_attr(attributes[5]);
					confirmationViewNonEmailCoreXMLGWDirectoryRow9states.setNstn(attributes[6]);
					confirmationViewNonEmailCoreXMLGWDirectoryRow9states.setLact_attr(attributes[7]);
					confirmationViewNonEmailCoreXMLGWDirectoryRow9states.setLact(attributes[8]);
					confirmationViewNonEmailCoreXMLGWDirectoryRow9states.setLty_att(attributes[9]);
					confirmationViewNonEmailCoreXMLGWDirectoryRow9states.setLty(attributes[10]);
					confirmationViewNonEmailCoreXMLGWDirectoryRow9states.setStyc_attr(attributes[11]);
					confirmationViewNonEmailCoreXMLGWDirectoryRow9states.setStyc(attributes[12]);
					confirmationViewNonEmailCoreXMLGWDirectoryRow9states.setDoi_attr(attributes[13]);
					confirmationViewNonEmailCoreXMLGWDirectoryRow9states.setDoi(attributes[14]);
					confirmationViewNonEmailCoreXMLGWDirectoryRow9states.setToa_attr(attributes[15]);
					confirmationViewNonEmailCoreXMLGWDirectoryRow9states.setToa(attributes[16]);
					confirmationViewNonEmailCoreXMLGWDirectoryRow9states.setWpp_attr(attributes[17]);
					confirmationViewNonEmailCoreXMLGWDirectoryRow9states.setWpp(attributes[18]);
					confirmationViewNonEmailCoreXMLGWDirectoryRow9states.setListnm__attr(attributes[19]);
					confirmationViewNonEmailCoreXMLGWDirectoryRow9states.setLtn(attributes[20]);
					confirmationViewNonEmailCoreXMLGWDirectoryRow9states.setListadr_attr(attributes[21]);
					confirmationViewNonEmailCoreXMLGWDirectoryRow9states.setListadr(attributes[22]);

					treeview895.add(confirmationViewNonEmailCoreXMLGWDirectoryRow9states);

				}
				session.setAttribute("treeview895", treeview895);
				selectRequestData.setSubHeader(receivedSubHeader);

			}

			if (subData_925Recid != null && subData_925Recid.getSubHeader().getRecord_type().equals("925")) {
				SubHeader receivedSubHeader = subData_925Recid.getSubHeader();
				String[] subDataRows = subData_925Recid.getSubDataRows();
				List<ConfirmationViewNonEmailCoreXMLGWDirectoryDW2Row9States> treeview925 = new ArrayList();
				treeViewList.add("925");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 8);
					// System.out.println("attributes:=925======> " + Arrays.toString(attributes));
					ConfirmationViewNonEmailCoreXMLGWDirectoryDW2Row9States confirmationViewNonEmailCoreXMLGWDirectoryDW2Row9States = new ConfirmationViewNonEmailCoreXMLGWDirectoryDW2Row9States();

					confirmationViewNonEmailCoreXMLGWDirectoryDW2Row9States.setLtxty_attr(attributes[0]);
					confirmationViewNonEmailCoreXMLGWDirectoryDW2Row9States.setLtxty(attributes[1]);
					confirmationViewNonEmailCoreXMLGWDirectoryDW2Row9States.setLtetx_attr(attributes[2]);
					confirmationViewNonEmailCoreXMLGWDirectoryDW2Row9States.setLtext(attributes[3]);
					confirmationViewNonEmailCoreXMLGWDirectoryDW2Row9States.setLtxtnum_attr(attributes[4]);
					confirmationViewNonEmailCoreXMLGWDirectoryDW2Row9States.setLtxt_num(attributes[5]);
					confirmationViewNonEmailCoreXMLGWDirectoryDW2Row9States.setLphrase_attr(attributes[6]);
					confirmationViewNonEmailCoreXMLGWDirectoryDW2Row9States.setLphrase(attributes[7]);

					treeview925.add(confirmationViewNonEmailCoreXMLGWDirectoryDW2Row9States);

				}
				session.setAttribute("treeview925", treeview925);
				selectRequestData.setSubHeader(receivedSubHeader);

			}

			// ************************** Nitin Kumar Code start
			// ********************************

			SubData subData_538Recid = subDatas.get(RecIdFor9State.CS_RECID_HISTORY_EXCEPTION.getRecIdValue());

			SubData subData_535Recid = subDatas.get(RecIdFor9State.CS_RECID_HISTORY.getRecIdValue());
			SubData subData_537Recid = subDatas.get(RecIdFor9State.CS_RECID_HISTORY_SORD.getRecIdValue());
			SubData subData_536Recid = subDatas.get(RecIdFor9State.CS_RECID_HISTORY_INTERFACE.getRecIdValue());
			SubData subData_539Recid = subDatas.get(RecIdFor9State.CS_RECID_HISTORY_DERIVED_DATA.getRecIdValue());
			SubData subData_583Recid = subDatas.get(RecIdFor9State.CS_RECID_JEOPARDY_DETAIL.getRecIdValue());
			SubData subData_584Recid = subDatas.get(RecIdFor9State.CS_RECID_JEOPARDY_VIEW.getRecIdValue());
			SubData subData_548Recid = subDatas.get(RecIdFor9State.CS_RECID_HISTORY_AUDIT_MSG.getRecIdValue());
			// System.out.println("++++subData_538Recid++++++" + subData_538Recid);

			// System.out.println("++++subData_535Recid++++++" + subData_535Recid);
			// System.out.println("++++subData_537Recid++++++" + subData_537Recid);
			// System.out.println("++++subData_536Recid++++++" + subData_536Recid);
			// System.out.println("++++subData_539Recid++++++" + subData_539Recid);
			// System.out.println("++++subData_583Recid++++++" + subData_583Recid);
			// System.out.println("++++subData_584Recid++++++" + subData_584Recid);

			if (subData_538Recid != null && subData_538Recid.getSubHeader().getRecord_type().equals("538")) {

				SubHeader receivedSubHeader = subData_538Recid.getSubHeader();
				String[] subDataRows = subData_538Recid.getSubDataRows();
				List<ExceptionHistoryData9State> treeViewList_538 = new ArrayList();
				treeViewList.add("538");

				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 4);
					// System.out.println("attributes:=538:Reqid======> " +
					// Arrays.toString(attributes));
					ExceptionHistoryData9State exceptionHistoryData9State = new ExceptionHistoryData9State();

					exceptionHistoryData9State.setSupp(attributes[0]);
					exceptionHistoryData9State.setDttm_exception_msg(attributes[1]);
					exceptionHistoryData9State.setException_code(attributes[2]);
					exceptionHistoryData9State.setText_msg(attributes[3]);
					treeViewList_538.add(exceptionHistoryData9State);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				session.setAttribute("treeViewList_538", treeViewList_538);

			}

			if (subData_536Recid != null && subData_536Recid.getSubHeader().getRecord_type().equals("536")) {

				SubHeader receivedSubHeader = subData_536Recid.getSubHeader();
				String[] subDataRows = subData_536Recid.getSubDataRows();
				List<InterfaceMessagesData9State> treeViewList_536 = new ArrayList();
				treeViewList.add("536");

				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 5);
					// System.out.println("attributes:=536:Reqid======> " +
					// Arrays.toString(attributes));
					InterfaceMessagesData9State interfaceMessagesData9State = new InterfaceMessagesData9State();

					interfaceMessagesData9State.setSupp(attributes[0]);
					interfaceMessagesData9State.setDttm_message(attributes[1]);
					interfaceMessagesData9State.setItem_num(attributes[2]);
					interfaceMessagesData9State.setInter_face(attributes[3]);
					interfaceMessagesData9State.setInterface_status(attributes[4]);

					treeViewList_536.add(interfaceMessagesData9State);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				session.setAttribute("treeViewList_536", treeViewList_536);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}

			if (subData_537Recid != null && subData_537Recid.getSubHeader().getRecord_type().equals("537")) {

				SubHeader receivedSubHeader = subData_537Recid.getSubHeader();
				String[] subDataRows = subData_537Recid.getSubDataRows();
				List<ServiceOrderHistoryData9States> treeViewList_537 = new ArrayList();
				treeViewList.add("537");
				// List treeViewList = new ArrayList();
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 7);
					// System.out.println("attributes:=537======> " + Arrays.toString(attributes));
					ServiceOrderHistoryData9States serviceOrderHistoryData9States = new ServiceOrderHistoryData9States();

					serviceOrderHistoryData9States.setSupp(attributes[0]);
					serviceOrderHistoryData9States.setDttm_entered(attributes[1]);
					serviceOrderHistoryData9States.setOrd(attributes[2]);
					serviceOrderHistoryData9States.setLoc(attributes[3]);
					serviceOrderHistoryData9States.setOrd_stat(attributes[4]);
					serviceOrderHistoryData9States.setDate(attributes[5]);
					serviceOrderHistoryData9States.setOrd_dist_dttm(attributes[6]);

					treeViewList_537.add(serviceOrderHistoryData9States);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				session.setAttribute("treeViewList_537", treeViewList_537);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}
			if (subData_539Recid != null && subData_539Recid.getSubHeader().getRecord_type().equals("539")) {

				SubHeader receivedSubHeader = subData_539Recid.getSubHeader();
				String[] subDataRows = subData_539Recid.getSubDataRows();
				List<AddIInfoData9State> treeViewList_539 = new ArrayList();
				treeViewList.add("539");

				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 5);
					// System.out.println("attributes:=539:Reqid======> " +
					// Arrays.toString(attributes));
					AddIInfoData9State addIInfoData9State = new AddIInfoData9State();

					addIInfoData9State.setLasrver(attributes[0]);
					addIInfoData9State.setDt_enter(attributes[1]);
					addIInfoData9State.setItem_num(attributes[2]);
					addIInfoData9State.setField_name(attributes[3]);
					addIInfoData9State.setField_data(attributes[4]);

					treeViewList_539.add(addIInfoData9State);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				session.setAttribute("treeViewList_539", treeViewList_539);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}

			if (subData_583Recid != null && subData_583Recid.getSubHeader().getRecord_type().equals("583")) {

				SubHeader receivedSubHeader = subData_583Recid.getSubHeader();
				String[] subDataRows = subData_583Recid.getSubDataRows();
				treeViewList.add("583");

				List<JeopardyViewTableData9State> treeViewList_583 = new ArrayList();
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 7);
					// System.out.println("attributes:=583======> " + Arrays.toString(attributes));
					JeopardyViewTableData9State jeopardyViewTableData9State = new JeopardyViewTableData9State();

					jeopardyViewTableData9State.setJep_ecckt(attributes[0]);
					jeopardyViewTableData9State.setJep_tns(attributes[1]);
					jeopardyViewTableData9State.setJep_cfa(attributes[2]);
					jeopardyViewTableData9State.setJep_ccea(attributes[3]);
					jeopardyViewTableData9State.setCbcid(attributes[4]);
					jeopardyViewTableData9State.setCableid(attributes[5]);
					jeopardyViewTableData9State.setChan_pair(attributes[6]);

					treeViewList_583.add(jeopardyViewTableData9State);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				session.setAttribute("treeViewList_583", treeViewList_583);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}
			// kirans

			// kiran
			List treeViewList905 = new ArrayList();
			List treeViewList906 = new ArrayList();
			SubData subData_905Recid = subDatas.get(RecIdFor9State.CS_RECID_SE_CONFIRM.getRecIdValue());
			SubData subData_906Recid = subDatas.get(RecIdFor9State.CS_RECID_SE_CONFIRM_ORDS.getRecIdValue());

			if (subData_905Recid != null && subData_905Recid.getSubHeader().getRecord_type().equals("905")) {

				SubHeader receivedSubHeader = subData_905Recid.getSubHeader();
				String[] subDataRows = subData_905Recid.getSubDataRows();
				treeViewList.add("905");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 16);
					ConfirmationTaskNEmailXMLGW9RecId905 confirmationTaskNEmailXMLGW9RecId905 = new ConfirmationTaskNEmailXMLGW9RecId905();

					confirmationTaskNEmailXMLGW9RecId905
							.setEc_ver(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
					confirmationTaskNEmailXMLGW9RecId905
							.setCver(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
					confirmationTaskNEmailXMLGW9RecId905
							.setTran_ack_type(attributes[2] != null && attributes[2] != "" ? attributes[2] : " ");
					confirmationTaskNEmailXMLGW9RecId905.setDt_sent(attributes[3]);
					confirmationTaskNEmailXMLGW9RecId905.setInit(attributes[4]);
					confirmationTaskNEmailXMLGW9RecId905.setInit_tel_no(attributes[5]);
					confirmationTaskNEmailXMLGW9RecId905.setRep(attributes[6]);
					confirmationTaskNEmailXMLGW9RecId905.setRep_tel_no(attributes[7]);
					confirmationTaskNEmailXMLGW9RecId905.setBan1(attributes[8]);
					confirmationTaskNEmailXMLGW9RecId905.setBan2(attributes[9]);
					confirmationTaskNEmailXMLGW9RecId905.setTran_set_id_code(attributes[10]);
					confirmationTaskNEmailXMLGW9RecId905.setTran_set_purpose_code(attributes[11]);
					confirmationTaskNEmailXMLGW9RecId905.setPonkey(attributes[12]);
					confirmationTaskNEmailXMLGW9RecId905.setStatus_code_attr(attributes[13]);
					confirmationTaskNEmailXMLGW9RecId905.setStatus_code(attributes[14]);
					confirmationTaskNEmailXMLGW9RecId905.setStatus_msg(attributes[15]);

					treeViewList905.add(confirmationTaskNEmailXMLGW9RecId905);

				}
				session.setAttribute("treeViewList_905", treeViewList905);
				selectRequestData.setSubHeader(receivedSubHeader);
			}

			if (subData_906Recid != null && subData_906Recid.getSubHeader().getRecord_type().equals("906")) {

				SubHeader receivedSubHeader = subData_906Recid.getSubHeader();
				String[] subDataRows = subData_906Recid.getSubDataRows();
				treeViewList.add("906");
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);
					ConfirmationTaskNEmailXMLGW9RecId906 confirmationTaskNEmailXMLGW9RecId906 = new ConfirmationTaskNEmailXMLGW9RecId906();

					confirmationTaskNEmailXMLGW9RecId906.setOrd_attr(attributes[0]);
					confirmationTaskNEmailXMLGW9RecId906.setOrd(attributes[1]);
					confirmationTaskNEmailXMLGW9RecId906.setNprod_attr(attributes[2]);
					confirmationTaskNEmailXMLGW9RecId906.setNprod(attributes[3]);
					confirmationTaskNEmailXMLGW9RecId906.setLord_attr(attributes[4]);
					confirmationTaskNEmailXMLGW9RecId906.setLord(attributes[5]);
					confirmationTaskNEmailXMLGW9RecId906.setDlord_attr(attributes[6]);
					confirmationTaskNEmailXMLGW9RecId906.setDlord(attributes[7]);
					confirmationTaskNEmailXMLGW9RecId906.setDdcd_attr(attributes[8]);
					confirmationTaskNEmailXMLGW9RecId906.setDdcd(attributes[9]);
					confirmationTaskNEmailXMLGW9RecId906.setOld_ord(attributes[10]);
					confirmationTaskNEmailXMLGW9RecId906.setOld_npord(attributes[11]);
					confirmationTaskNEmailXMLGW9RecId906.setOld_lord(attributes[12]);
					confirmationTaskNEmailXMLGW9RecId906.setOld_dlord(attributes[13]);

					treeViewList906.add(confirmationTaskNEmailXMLGW9RecId906);

				}
				session.setAttribute("treeViewList_906", treeViewList906);
				selectRequestData.setSubHeader(receivedSubHeader);
			}

			//
			if (subData_584Recid != null && subData_584Recid.getSubHeader().getRecord_type().equals("584")) {

				SubHeader receivedSubHeader = subData_584Recid.getSubHeader();
				String[] subDataRows = subData_584Recid.getSubDataRows();

				List<JeopardyViewData9State> treeViewList_584 = new ArrayList();
				treeViewList.add("584");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 30);
//					//System.out.println("attributes:=584======> " + Arrays.toString(attributes));
					JeopardyViewData9State jeopardyViewData9State = new JeopardyViewData9State();

					jeopardyViewData9State.setCver_attr(attributes[0]);
					jeopardyViewData9State.setCver(attributes[1]);
					jeopardyViewData9State.setRt_attr(attributes[2]);
					jeopardyViewData9State.setRt(attributes[3]);
					jeopardyViewData9State.setEc_ver_attr(attributes[4]);
					jeopardyViewData9State.setEc_ver(attributes[5]);
					jeopardyViewData9State.setDt_sent_attr(attributes[6]);
					jeopardyViewData9State.setDt_sent(attributes[7]);
					jeopardyViewData9State.setResponse_dt_sent_attr(attributes[8]);
					jeopardyViewData9State.setResponse_dt_sent(attributes[9]);
					jeopardyViewData9State.setOrd_attr(attributes[10]);
					jeopardyViewData9State.setOrd(attributes[11]);
					jeopardyViewData9State.setLord_attr(attributes[12]);
					jeopardyViewData9State.setLord(attributes[13]);
					jeopardyViewData9State.setJcode_attr(attributes[14]);
					jeopardyViewData9State.setJcode(attributes[15]);
					jeopardyViewData9State.setRcode_attr(attributes[16]);
					jeopardyViewData9State.setRcode(attributes[17]);
					jeopardyViewData9State.setRdet_attr(attributes[18]);
					jeopardyViewData9State.setRdet(attributes[19]);
					jeopardyViewData9State.setEsdd_attr(attributes[20]);
					jeopardyViewData9State.setEsdd(attributes[21]);
					jeopardyViewData9State.setSent_by_attr(attributes[22]);
					jeopardyViewData9State.setSent_by(attributes[23]);
					jeopardyViewData9State.setNpord_attr(attributes[24]);
					jeopardyViewData9State.setNpord(attributes[25]);
					jeopardyViewData9State.setSpec_code(attributes[26]);
					jeopardyViewData9State.setApptime_attr(attributes[27]);
					jeopardyViewData9State.setApptime(attributes[28]);

					treeViewList_584.add(jeopardyViewData9State);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				session.setAttribute("treeViewList_584", treeViewList_584);
				//System.out.println("treeViewList_584  size() "+treeViewList_584.size());
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}
			//
			if (subData_535Recid != null && subData_535Recid.getSubHeader().getRecord_type().equals("535")) {

				SubHeader receivedSubHeader = subData_535Recid.getSubHeader();
				String[] subDataRows = subData_535Recid.getSubDataRows();
				treeViewList.add("535");

				List<FieldDataChangesData9State> treeViewList_535 = new ArrayList();
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 12);
					FieldDataChangesData9State fieldDataChangesData9State = new FieldDataChangesData9State();

					fieldDataChangesData9State.setSupp(attributes[0]);
					fieldDataChangesData9State.setChanged_dttm(attributes[1]);
					fieldDataChangesData9State.setOrder_num(attributes[2]);
					fieldDataChangesData9State.setField_name(attributes[3]);
					fieldDataChangesData9State.setHunt_item_num(attributes[4]);
					fieldDataChangesData9State.setItem_num(attributes[5]);
					fieldDataChangesData9State.setLnum(attributes[6]);
					fieldDataChangesData9State.setNumname(attributes[7]);
					fieldDataChangesData9State.setNumnbr(attributes[8]);
					fieldDataChangesData9State.setChanged_from(attributes[9]);
					fieldDataChangesData9State.setChanged_to(attributes[10]);
					fieldDataChangesData9State.setChanged_by(attributes[11]);

					treeViewList_535.add(fieldDataChangesData9State);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				session.setAttribute("treeViewList_535", treeViewList_535);
			}
			
			//Nitin changes audit message 02_Nov start
			if (subData_548Recid != null && subData_548Recid.getSubHeader().getRecord_type().equals("548")) {

				SubHeader receivedSubHeader = subData_548Recid.getSubHeader();
				String[] subDataRows = subData_548Recid.getSubDataRows();
				List<AuditMessage9> treeViewList_548 = new ArrayList();
				treeViewList.add("548");

				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 6);
					// System.out.println("attributes:=548:Reqid======> " +
					// Arrays.toString(attributes));
					AuditMessage9 auditMessage9 = new AuditMessage9();

					auditMessage9.setVer(attributes[0]);
					auditMessage9.setError_date(attributes[1]);
					auditMessage9.setError_type(attributes[2]);
					auditMessage9.setError_num(attributes[3]);
					auditMessage9.setXref(attributes[4]);
					auditMessage9.setHistory_line(attributes[5]);

					treeViewList_548.add(auditMessage9);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				session.setAttribute("treeViewList_548", treeViewList_548);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}



			
			
			
			
			//Nitin changes audit message 02_Nov end
			// ************************** Nitin Kumar Code End
			// ********************************

			// ************************** Saurabh Pandey Code start
			// ********************************

			// Request Type T - Resale DPR Trunk Group / DPR Trunk RecId =640
			SubData subData_640Recid = subDatas.get(RecIdFor9State.CS_RECID_DIDPBX_RESALE.getRecIdValue());

			if (subData_640Recid != null && subData_640Recid.getSubHeader().getRecord_type().equals("640")) {
				SubHeader receivedSubHeader = subData_640Recid.getSubHeader();
				String[] subDataRows = subData_640Recid.getSubDataRows();
				treeViewList.add("640");
				List<DPR_Trunk_9State> treeViewList_640_9state = new ArrayList<DPR_Trunk_9State>();
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 154);
					// System.out.println("subData_640Recid attributes:=======> " +
					// Arrays.toString(attributes));
					DPR_Trunk_9State dpr_Trunk_9State = new DPR_Trunk_9State();

					dpr_Trunk_9State.setItem_num(attributes[0] != null || attributes[0] != "" ? attributes[0] : " ");
					dpr_Trunk_9State.setDidnum_attr(attributes[1] != null || attributes[1] != "" ? attributes[1] : " ");
					dpr_Trunk_9State.setDidnum(attributes[2] != null || attributes[2] != "" ? attributes[2] : " ");
					dpr_Trunk_9State.setDidind_attr(attributes[3] != null || attributes[3] != "" ? attributes[3] : " ");
					dpr_Trunk_9State.setDidind(attributes[4] != null || attributes[4] != "" ? attributes[4] : " ");
					dpr_Trunk_9State
							.setDtnract_attr(attributes[5] != null || attributes[5] != "" ? attributes[5] : " ");
					dpr_Trunk_9State.setDtnract(attributes[6] != null || attributes[6] != "" ? attributes[6] : " ");
					dpr_Trunk_9State.setDtnrq_attr(attributes[7] != null || attributes[7] != "" ? attributes[7] : " ");
					dpr_Trunk_9State.setDtnrq(attributes[8] != null || attributes[8] != "" ? attributes[8] : " ");
					dpr_Trunk_9State.setDtnr1_attr(attributes[9] != null || attributes[9] != "" ? attributes[9] : " ");
					dpr_Trunk_9State.setDtnr1(attributes[10] != null || attributes[10] != "" ? attributes[10] : " ");
					dpr_Trunk_9State
							.setDtnr2_attr(attributes[11] != null || attributes[11] != "" ? attributes[11] : " ");
					dpr_Trunk_9State.setDtnr2(attributes[12] != null || attributes[12] != "" ? attributes[12] : " ");
					dpr_Trunk_9State
							.setDtnr3_attr(attributes[13] != null || attributes[13] != "" ? attributes[13] : " ");
					dpr_Trunk_9State.setDtnr3(attributes[14] != null || attributes[14] != "" ? attributes[14] : " ");
					dpr_Trunk_9State.setNpi_attr(attributes[15] != null || attributes[15] != "" ? attributes[15] : " ");
					dpr_Trunk_9State.setNpi(attributes[16] != null || attributes[16] != "" ? attributes[16] : " ");
					dpr_Trunk_9State
							.setDidr_attr(attributes[17] != null || attributes[17] != "" ? attributes[17] : " ");
					dpr_Trunk_9State.setDidr(attributes[18] != null || attributes[18] != "" ? attributes[18] : " ");
					dpr_Trunk_9State
							.setDtkact_attr(attributes[19] != null || attributes[19] != "" ? attributes[19] : " ");
					dpr_Trunk_9State.setDtkact(attributes[20] != null || attributes[20] != "" ? attributes[20] : " ");
					dpr_Trunk_9State
							.setDtgn_attr(attributes[21] != null || attributes[21] != "" ? attributes[21] : " ");
					dpr_Trunk_9State.setDtgn(attributes[22] != null || attributes[22] != "" ? attributes[22] : " ");
					dpr_Trunk_9State
							.setDtli_attr(attributes[23] != null || attributes[23] != "" ? attributes[23] : " ");
					dpr_Trunk_9State.setDtli(attributes[24] != null || attributes[24] != "" ? attributes[24] : " ");
					dpr_Trunk_9State.setDba_attr(attributes[25] != null || attributes[25] != "" ? attributes[25] : " ");
					dpr_Trunk_9State.setDba(attributes[26] != null || attributes[26] != "" ? attributes[26] : " ");
					dpr_Trunk_9State
							.setDblock_attr(attributes[27] != null || attributes[27] != "" ? attributes[27] : " ");
					dpr_Trunk_9State.setDblock(attributes[28] != null || attributes[28] != "" ? attributes[28] : " ");
					dpr_Trunk_9State
							.setDpic_attr(attributes[29] != null || attributes[29] != "" ? attributes[29] : " ");
					dpr_Trunk_9State.setDpic(attributes[30] != null || attributes[30] != "" ? attributes[30] : " ");
					dpr_Trunk_9State
							.setDlpic_attr(attributes[31] != null || attributes[31] != "" ? attributes[31] : " ");
					dpr_Trunk_9State.setDlpic(attributes[32] != null || attributes[32] != "" ? attributes[32] : " ");
					dpr_Trunk_9State
							.setDrti_attr(attributes[33] != null || attributes[33] != "" ? attributes[33] : " ");
					dpr_Trunk_9State.setDrti(attributes[34] != null || attributes[34] != "" ? attributes[34] : " ");
					dpr_Trunk_9State
							.setDgout_attr(attributes[35] != null || attributes[35] != "" ? attributes[35] : " ");
					dpr_Trunk_9State.setDgout(attributes[36] != null || attributes[36] != "" ? attributes[36] : " ");
					dpr_Trunk_9State
							.setDpulse_attr(attributes[37] != null || attributes[37] != "" ? attributes[37] : " ");
					dpr_Trunk_9State.setDpulse(attributes[38] != null || attributes[38] != "" ? attributes[38] : " ");
					dpr_Trunk_9State
							.setDsgnl_attr(attributes[39] != null || attributes[39] != "" ? attributes[39] : " ");
					dpr_Trunk_9State.setDsgnl(attributes[40] != null || attributes[40] != "" ? attributes[40] : " ");
					dpr_Trunk_9State.setNba_attr(attributes[41] != null || attributes[41] != "" ? attributes[41] : " ");
					dpr_Trunk_9State.setNba(attributes[42] != null || attributes[42] != "" ? attributes[42] : " ");
					dpr_Trunk_9State
							.setNbank1_attr(attributes[43] != null || attributes[43] != "" ? attributes[43] : " ");
					dpr_Trunk_9State.setNbank1(attributes[44] != null || attributes[44] != "" ? attributes[44] : " ");
					dpr_Trunk_9State
							.setNbank2_attr(attributes[45] != null || attributes[45] != "" ? attributes[45] : " ");
					dpr_Trunk_9State.setNbank2(attributes[46] != null || attributes[46] != "" ? attributes[46] : " ");
					dpr_Trunk_9State
							.setNbank3_attr(attributes[47] != null || attributes[47] != "" ? attributes[47] : " ");
					dpr_Trunk_9State.setNbank3(attributes[48] != null || attributes[48] != "" ? attributes[48] : " ");
					dpr_Trunk_9State
							.setNbank4_attr(attributes[49] != null || attributes[49] != "" ? attributes[49] : " ");
					dpr_Trunk_9State.setNbank4(attributes[50] != null || attributes[50] != "" ? attributes[50] : " ");
					dpr_Trunk_9State
							.setDstnact_attr(attributes[51] != null || attributes[51] != "" ? attributes[51] : " ");
					dpr_Trunk_9State.setDstnact(attributes[52] != null || attributes[52] != "" ? attributes[52] : " ");
					dpr_Trunk_9State
							.setDstnq_attr(attributes[53] != null || attributes[53] != "" ? attributes[53] : " ");
					dpr_Trunk_9State.setDstnq(attributes[54] != null || attributes[54] != "" ? attributes[54] : " ");
					dpr_Trunk_9State
							.setDstn1_attr(attributes[55] != null || attributes[55] != "" ? attributes[55] : " ");
					dpr_Trunk_9State.setDstn1(attributes[56] != null || attributes[56] != "" ? attributes[56] : " ");
					dpr_Trunk_9State
							.setDstn2_attr(attributes[57] != null || attributes[57] != "" ? attributes[57] : " ");
					dpr_Trunk_9State.setDstn2(attributes[58] != null || attributes[58] != "" ? attributes[58] : " ");
					dpr_Trunk_9State
							.setDstn3_attr(attributes[59] != null || attributes[59] != "" ? attributes[59] : " ");
					dpr_Trunk_9State.setDstn3(attributes[60] != null || attributes[60] != "" ? attributes[60] : " ");
					dpr_Trunk_9State
							.setDstn4_attr(attributes[61] != null || attributes[61] != "" ? attributes[61] : " ");
					dpr_Trunk_9State.setDstn4(attributes[62] != null || attributes[62] != "" ? attributes[62] : " ");
					dpr_Trunk_9State
							.setDstn5_attr(attributes[63] != null || attributes[63] != "" ? attributes[63] : " ");
					dpr_Trunk_9State.setDstn5(attributes[64] != null || attributes[64] != "" ? attributes[64] : " ");
					dpr_Trunk_9State
							.setLnum_attr(attributes[65] != null || attributes[65] != "" ? attributes[65] : " ");
					dpr_Trunk_9State.setLnum(attributes[66] != null || attributes[66] != "" ? attributes[66] : " ");
					dpr_Trunk_9State.setLna_attr(attributes[67] != null || attributes[67] != "" ? attributes[67] : " ");
					dpr_Trunk_9State.setLna(attributes[68] != null || attributes[68] != "" ? attributes[68] : " ");
					dpr_Trunk_9State.setTns_attr(attributes[69] != null || attributes[69] != "" ? attributes[69] : " ");
					dpr_Trunk_9State.setTns(attributes[70] != null || attributes[70] != "" ? attributes[70] : " ");
					dpr_Trunk_9State
							.setTers_attr(attributes[71] != null || attributes[71] != "" ? attributes[71] : " ");
					dpr_Trunk_9State.setTers(attributes[72] != null || attributes[72] != "" ? attributes[72] : " ");
					dpr_Trunk_9State.setOtn_attr(attributes[73] != null || attributes[73] != "" ? attributes[73] : " ");
					dpr_Trunk_9State.setOtn(attributes[74] != null || attributes[74] != "" ? attributes[74] : " ");
					dpr_Trunk_9State
							.setLtgn_attr(attributes[75] != null || attributes[75] != "" ? attributes[75] : " ");
					dpr_Trunk_9State.setLtgn(attributes[76] != null || attributes[76] != "" ? attributes[76] : " ");
					dpr_Trunk_9State.setNc_attr(attributes[77] != null || attributes[77] != "" ? attributes[77] : " ");
					dpr_Trunk_9State.setNc(attributes[78] != null || attributes[78] != "" ? attributes[78] : " ");
					dpr_Trunk_9State.setNci_attr(attributes[79] != null || attributes[79] != "" ? attributes[79] : " ");
					dpr_Trunk_9State.setNci(attributes[80] != null || attributes[80] != "" ? attributes[80] : " ");
					dpr_Trunk_9State
							.setEcckt_attr(attributes[81] != null || attributes[81] != "" ? attributes[81] : " ");
					dpr_Trunk_9State.setEcckt(attributes[82] != null || attributes[82] != "" ? attributes[82] : " ");
					dpr_Trunk_9State.setCfa_attr(attributes[83] != null || attributes[83] != "" ? attributes[83] : " ");
					dpr_Trunk_9State.setCfa(attributes[84] != null || attributes[84] != "" ? attributes[84] : " ");
					dpr_Trunk_9State
							.setCcea_attr(attributes[85] != null || attributes[85] != "" ? attributes[85] : " ");
					dpr_Trunk_9State.setCcea(attributes[86] != null || attributes[86] != "" ? attributes[86] : " ");
					dpr_Trunk_9State.setCkr_attr(attributes[87] != null || attributes[87] != "" ? attributes[87] : " ");
					dpr_Trunk_9State.setCkr(attributes[88] != null || attributes[88] != "" ? attributes[88] : " ");
					dpr_Trunk_9State.setPic_attr(attributes[89] != null || attributes[89] != "" ? attributes[89] : " ");
					dpr_Trunk_9State.setPic(attributes[90] != null || attributes[90] != "" ? attributes[90] : " ");
					dpr_Trunk_9State
							.setLpic_attr(attributes[91] != null || attributes[91] != "" ? attributes[91] : " ");
					dpr_Trunk_9State.setLpic(attributes[92] != null || attributes[92] != "" ? attributes[92] : " ");
					dpr_Trunk_9State
							.setSsig_attr(attributes[93] != null || attributes[93] != "" ? attributes[93] : " ");
					dpr_Trunk_9State.setSsig(attributes[94] != null || attributes[94] != "" ? attributes[94] : " ");
					dpr_Trunk_9State.setBa_attr(attributes[95] != null || attributes[95] != "" ? attributes[95] : " ");
					dpr_Trunk_9State.setBa(attributes[96] != null || attributes[96] != "" ? attributes[96] : " ");
					dpr_Trunk_9State
							.setBlock_attr(attributes[97] != null || attributes[97] != "" ? attributes[97] : " ");
					dpr_Trunk_9State.setBlock(attributes[98] != null || attributes[98] != "" ? attributes[98] : " ");
					dpr_Trunk_9State.setTsp_attr(attributes[99] != null || attributes[99] != "" ? attributes[99] : " ");
					dpr_Trunk_9State.setTsp(attributes[100] != null || attributes[100] != "" ? attributes[100] : " ");
					dpr_Trunk_9State
							.setJk_code_attr(attributes[101] != null || attributes[101] != "" ? attributes[101] : " ");
					dpr_Trunk_9State
							.setJk_code(attributes[102] != null || attributes[102] != "" ? attributes[102] : " ");
					dpr_Trunk_9State
							.setJk_num_attr(attributes[103] != null || attributes[103] != "" ? attributes[103] : " ");
					dpr_Trunk_9State
							.setJk_num(attributes[104] != null || attributes[104] != "" ? attributes[104] : " ");
					dpr_Trunk_9State
							.setJk_pos_attr(attributes[105] != null || attributes[105] != "" ? attributes[105] : " ");
					dpr_Trunk_9State
							.setJk_pos(attributes[106] != null || attributes[106] != "" ? attributes[106] : " ");
					dpr_Trunk_9State
							.setJr_attr(attributes[107] != null || attributes[107] != "" ? attributes[107] : " ");
					dpr_Trunk_9State.setJr(attributes[108] != null || attributes[108] != "" ? attributes[108] : " ");
					dpr_Trunk_9State
							.setNidr_attr(attributes[109] != null || attributes[109] != "" ? attributes[109] : " ");
					dpr_Trunk_9State.setNidr(attributes[110] != null || attributes[110] != "" ? attributes[110] : " ");
					dpr_Trunk_9State
							.setIwjk1_attr(attributes[111] != null || attributes[111] != "" ? attributes[111] : " ");
					dpr_Trunk_9State.setIwjk1(attributes[112] != null || attributes[112] != "" ? attributes[112] : " ");
					dpr_Trunk_9State
							.setIwjk2_attr(attributes[113] != null || attributes[113] != "" ? attributes[113] : " ");
					dpr_Trunk_9State.setIwjk2(attributes[114] != null || attributes[114] != "" ? attributes[114] : " ");
					dpr_Trunk_9State
							.setIwjk3_attr(attributes[115] != null || attributes[115] != "" ? attributes[115] : " ");
					dpr_Trunk_9State.setIwjk3(attributes[116] != null || attributes[116] != "" ? attributes[116] : " ");
					dpr_Trunk_9State
							.setIwjk4_attr(attributes[117] != null || attributes[117] != "" ? attributes[117] : " ");
					dpr_Trunk_9State.setIwjk4(attributes[118] != null || attributes[118] != "" ? attributes[118] : " ");
					dpr_Trunk_9State
							.setIwjk5_attr(attributes[119] != null || attributes[119] != "" ? attributes[119] : " ");
					dpr_Trunk_9State.setIwjk5(attributes[120] != null || attributes[120] != "" ? attributes[120] : " ");
					dpr_Trunk_9State
							.setIwjq1_attr(attributes[121] != null || attributes[121] != "" ? attributes[121] : " ");
					dpr_Trunk_9State.setIwjq1(attributes[122] != null || attributes[122] != "" ? attributes[122] : " ");
					dpr_Trunk_9State
							.setIwjq2_attr(attributes[123] != null || attributes[123] != "" ? attributes[123] : " ");
					dpr_Trunk_9State.setIwjq2(attributes[124] != null || attributes[124] != "" ? attributes[124] : " ");
					dpr_Trunk_9State
							.setIwjq3_attr(attributes[125] != null || attributes[125] != "" ? attributes[125] : " ");
					dpr_Trunk_9State.setIwjq3(attributes[126] != null || attributes[126] != "" ? attributes[126] : " ");
					dpr_Trunk_9State
							.setIwjq4_attr(attributes[127] != null || attributes[127] != "" ? attributes[127] : " ");
					dpr_Trunk_9State.setIwjq4(attributes[128] != null || attributes[128] != "" ? attributes[128] : " ");
					dpr_Trunk_9State
							.setIwjq5_attr(attributes[129] != null || attributes[129] != "" ? attributes[129] : " ");
					dpr_Trunk_9State.setIwjq5(attributes[130] != null || attributes[130] != "" ? attributes[130] : " ");
					dpr_Trunk_9State
							.setNpi_trnk_attr(attributes[131] != null || attributes[131] != "" ? attributes[131] : " ");
					dpr_Trunk_9State
							.setNpi_trnk(attributes[132] != null || attributes[132] != "" ? attributes[132] : " ");
					dpr_Trunk_9State
							.setLocnum_attr(attributes[133] != null || attributes[133] != "" ? attributes[133] : " ");
					dpr_Trunk_9State
							.setLocnum(attributes[134] != null || attributes[134] != "" ? attributes[134] : " ");
					dpr_Trunk_9State
							.setTkid_attr(attributes[135] != null || attributes[135] != "" ? attributes[135] : " ");
					dpr_Trunk_9State.setTkid(attributes[136] != null || attributes[136] != "" ? attributes[136] : " ");
					dpr_Trunk_9State
							.setTtp_attr(attributes[137] != null || attributes[137] != "" ? attributes[137] : " ");
					dpr_Trunk_9State.setTtp(attributes[138] != null || attributes[138] != "" ? attributes[138] : " ");
					dpr_Trunk_9State
							.setIwt_attr(attributes[139] != null || attributes[139] != "" ? attributes[139] : " ");
					dpr_Trunk_9State.setIwt(attributes[140] != null || attributes[140] != "" ? attributes[140] : " ");
					dpr_Trunk_9State
							.setIwtq_attr(attributes[141] != null || attributes[141] != "" ? attributes[141] : " ");
					dpr_Trunk_9State.setIwtq(attributes[142] != null || attributes[142] != "" ? attributes[142] : " ");
					dpr_Trunk_9State
							.setDin_attr(attributes[143] != null || attributes[143] != "" ? attributes[143] : " ");
					dpr_Trunk_9State.setDin(attributes[144] != null || attributes[144] != "" ? attributes[144] : " ");
					dpr_Trunk_9State
							.setGlare_attr(attributes[145] != null || attributes[145] != "" ? attributes[145] : " ");
					dpr_Trunk_9State.setGlare(attributes[146] != null || attributes[146] != "" ? attributes[146] : " ");
					dpr_Trunk_9State
							.setCableid_attr(attributes[147] != null || attributes[147] != "" ? attributes[147] : " ");
					dpr_Trunk_9State
							.setCableid(attributes[148] != null || attributes[148] != "" ? attributes[148] : " ");
					dpr_Trunk_9State
							.setFpi_attr(attributes[149] != null || attributes[149] != "" ? attributes[149] : " ");
					dpr_Trunk_9State.setFpi(attributes[150] != null || attributes[150] != "" ? attributes[150] : " ");
					dpr_Trunk_9State
							.setQn_attr(attributes[151] != null || attributes[151] != "" ? attributes[151] : " ");
					dpr_Trunk_9State.setQn(attributes[152] != null || attributes[152] != "" ? attributes[152] : " ");
					dpr_Trunk_9State
							.setLoc_seq_num(attributes[153] != null || attributes[153] != "" ? attributes[153] : " ");

					treeViewList_640_9state.add(dpr_Trunk_9State);
				}
				session.setAttribute("treeViewList_640_9state", treeViewList_640_9state);
				selectRequestData.setSubHeader(receivedSubHeader);
			}
			session.setAttribute("treeViewList160", treeViewList160);
			session.setAttribute("treeViewList161", treeViewList161);
			session.setAttribute("treeViewList105", treeViewList105);
			session.setAttribute("treeViewList106", treeViewList106);
			session.setAttribute("treeViewList102", treeViewList102);
			session.setAttribute("treeViewList100", treeViewList100);
			session.setAttribute("treeViewList050", treeViewList050);
			session.setAttribute("treeViewList154", treeViewList154);
			session.setAttribute("treeViewList", treeViewList);
		}
		 if(treeViewList.contains("570")){
			session.setAttribute("manRejButton", "inline");
			
			}else {
				session.setAttribute("manRejButton", "none");
				}

		return treeViewList;

	}

	private void getSubData_680RecidData(SubData subData_680Recid, List treeViewList,
			SelectRequestData selectRequestData, HttpSession session) {
		
		
		SubHeader receivedSubHeader = subData_680Recid.getSubHeader();
		String[] subDataRows = subData_680Recid.getSubDataRows();
		List<CentrexResaleCRSStationDW1Data9> treeViewList_680 = new ArrayList();
		treeViewList.add("680");
		// int i = 0;
		for (String subDataRow : subDataRows) {
			String[] attributes = mqReadUtil.getAttributes(subDataRow, 128);
			// System.out.println("attributes:=680:Reqid======> " +
			// Arrays.toString(attributes));
			CentrexResaleCRSStationDW1Data9 centrexResaleCRSStationDW1Data12 = new CentrexResaleCRSStationDW1Data9();

			centrexResaleCRSStationDW1Data12
					.setItem_num(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
			centrexResaleCRSStationDW1Data12
					.setLnum_attr(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
			centrexResaleCRSStationDW1Data12
					.setLnum(attributes[2] != null && attributes[2] != "" ? attributes[2] : " ");
			centrexResaleCRSStationDW1Data12.setLna_attr(attributes[3]);
			centrexResaleCRSStationDW1Data12.setLna(attributes[4]);
			centrexResaleCRSStationDW1Data12.setNpi_attr(attributes[5]);
			centrexResaleCRSStationDW1Data12.setNpi(attributes[6]);
			centrexResaleCRSStationDW1Data12.setLst_attr(attributes[7]);
			centrexResaleCRSStationDW1Data12.setLst(attributes[8]);
			centrexResaleCRSStationDW1Data12.setTns_attr(attributes[9]);
			centrexResaleCRSStationDW1Data12.setTns(attributes[10]);
			centrexResaleCRSStationDW1Data12.setTers_attr(attributes[11]);
			centrexResaleCRSStationDW1Data12.setTers(attributes[12]);
			centrexResaleCRSStationDW1Data12.setOtn_attr(attributes[13]);
			centrexResaleCRSStationDW1Data12.setOtn(attributes[14]);
			centrexResaleCRSStationDW1Data12.setIspid_attr(attributes[15]);
			centrexResaleCRSStationDW1Data12.setIspid(attributes[16]);
			centrexResaleCRSStationDW1Data12.setIsdnp_attr(attributes[17]);
			centrexResaleCRSStationDW1Data12.setIsdnp(attributes[18]);
			centrexResaleCRSStationDW1Data12.setEcckt_attr(attributes[19]);
			centrexResaleCRSStationDW1Data12.setEcckt(attributes[20]);
			centrexResaleCRSStationDW1Data12.setCfa_attr(attributes[21]);
			centrexResaleCRSStationDW1Data12.setCfa(attributes[22]);
			centrexResaleCRSStationDW1Data12.setCcea_attr(attributes[23]);
			centrexResaleCRSStationDW1Data12.setCcea(attributes[24]);
			centrexResaleCRSStationDW1Data12.setCkr_attr(attributes[25]);
			centrexResaleCRSStationDW1Data12.setCkr(attributes[26]);
			centrexResaleCRSStationDW1Data12.setPic_attr(attributes[27]);
			centrexResaleCRSStationDW1Data12.setPic(attributes[28]);
			centrexResaleCRSStationDW1Data12.setLpic_attr(attributes[29]);
			centrexResaleCRSStationDW1Data12.setLpic(attributes[30]);
			centrexResaleCRSStationDW1Data12.setSsig_attr(attributes[31]);
			centrexResaleCRSStationDW1Data12.setSsig(attributes[32]);
			centrexResaleCRSStationDW1Data12.setBa_attr(attributes[33]);
			centrexResaleCRSStationDW1Data12.setBa(attributes[34]);
			centrexResaleCRSStationDW1Data12.setBlock_attr(attributes[35]);
			centrexResaleCRSStationDW1Data12.setBlock(attributes[36]);
			centrexResaleCRSStationDW1Data12.setTsp_attr(attributes[37]);
			centrexResaleCRSStationDW1Data12.setTsp(attributes[38]);
			centrexResaleCRSStationDW1Data12.setJk_code_attr(attributes[39]);
			centrexResaleCRSStationDW1Data12.setJk_code(attributes[40]);
			centrexResaleCRSStationDW1Data12.setJk_num_attr(attributes[41]);
			centrexResaleCRSStationDW1Data12.setJk_num(attributes[42]);
			centrexResaleCRSStationDW1Data12.setJk_pos_attr(attributes[43]);
			centrexResaleCRSStationDW1Data12.setJk_pos(attributes[44]);
			centrexResaleCRSStationDW1Data12.setJr_attr(attributes[45]);
			centrexResaleCRSStationDW1Data12.setJr(attributes[46]);
			centrexResaleCRSStationDW1Data12.setNidr_attr(attributes[47]);
			centrexResaleCRSStationDW1Data12.setNidr(attributes[48]);
			centrexResaleCRSStationDW1Data12.setIwjk1_attr(attributes[49]);
			centrexResaleCRSStationDW1Data12.setIwjk1(attributes[50]);
			centrexResaleCRSStationDW1Data12.setIwjk2_attr(attributes[51]);
			centrexResaleCRSStationDW1Data12.setIwjk2(attributes[52]);
			centrexResaleCRSStationDW1Data12.setIwjk3_attr(attributes[53]);
			centrexResaleCRSStationDW1Data12.setIwjk3(attributes[54]);
			centrexResaleCRSStationDW1Data12.setIwjk4_attr(attributes[55]);
			centrexResaleCRSStationDW1Data12.setIwjk4(attributes[56]);
			centrexResaleCRSStationDW1Data12.setIwjk5_attr(attributes[57]);
			centrexResaleCRSStationDW1Data12.setIwjk5(attributes[58]);
			centrexResaleCRSStationDW1Data12.setIwjq1_attr(attributes[59]);
			centrexResaleCRSStationDW1Data12.setIwjq1(attributes[60]);
			centrexResaleCRSStationDW1Data12.setIwjq2_attr(attributes[61]);
			centrexResaleCRSStationDW1Data12.setIwjq2(attributes[62]);
			centrexResaleCRSStationDW1Data12.setIwjq3_attr(attributes[63]);
			centrexResaleCRSStationDW1Data12.setIwjq3(attributes[64]);
			centrexResaleCRSStationDW1Data12.setIwjq4_attr(attributes[65]);
			centrexResaleCRSStationDW1Data12.setIwjq4(attributes[66]);
			centrexResaleCRSStationDW1Data12.setIwjq5_attr(attributes[67]);
			centrexResaleCRSStationDW1Data12.setIwjq5(attributes[68]);
			centrexResaleCRSStationDW1Data12.setSai_attr(attributes[69]);
			centrexResaleCRSStationDW1Data12.setSai(attributes[70]);
			centrexResaleCRSStationDW1Data12.setName_attr(attributes[71]);
			centrexResaleCRSStationDW1Data12.setName(attributes[72]);
			centrexResaleCRSStationDW1Data12.setNcon_attr(attributes[73]);
			centrexResaleCRSStationDW1Data12.setNcon(attributes[74]);
			centrexResaleCRSStationDW1Data12.setAft_attr(attributes[75]);
			centrexResaleCRSStationDW1Data12.setAft(attributes[76]);
			centrexResaleCRSStationDW1Data12.setSapr_attr(attributes[77]);
			centrexResaleCRSStationDW1Data12.setSapr(attributes[78]);
			centrexResaleCRSStationDW1Data12.setSano_attr(attributes[79]);
			centrexResaleCRSStationDW1Data12.setSano(attributes[80]);
			centrexResaleCRSStationDW1Data12.setSasf_attr(attributes[81]);
			centrexResaleCRSStationDW1Data12.setSasf(attributes[82]);
			centrexResaleCRSStationDW1Data12.setSasd_attr(attributes[83]);
			centrexResaleCRSStationDW1Data12.setSasd(attributes[84]);
			centrexResaleCRSStationDW1Data12.setSasn_attr(attributes[85]);
			centrexResaleCRSStationDW1Data12.setSasn(attributes[86]);
			centrexResaleCRSStationDW1Data12.setSath_attr(attributes[87]);
			centrexResaleCRSStationDW1Data12.setSath(attributes[88]);
			centrexResaleCRSStationDW1Data12.setSass_attr(attributes[89]);
			centrexResaleCRSStationDW1Data12.setSass(attributes[90]);
			centrexResaleCRSStationDW1Data12.setLd1_attr(attributes[91]);
			centrexResaleCRSStationDW1Data12.setLd1(attributes[92]);
			centrexResaleCRSStationDW1Data12.setLv1_attr(attributes[93]);
			centrexResaleCRSStationDW1Data12.setLv1(attributes[94]);
			centrexResaleCRSStationDW1Data12.setLd2_attr(attributes[95]);
			centrexResaleCRSStationDW1Data12.setLd2(attributes[96]);
			centrexResaleCRSStationDW1Data12.setLv2_attr(attributes[97]);
			centrexResaleCRSStationDW1Data12.setLv2(attributes[98]);
			centrexResaleCRSStationDW1Data12.setLd3_attr(attributes[99]);
			centrexResaleCRSStationDW1Data12.setLd3(attributes[100]);
			centrexResaleCRSStationDW1Data12.setLv3_attr(attributes[101]);
			centrexResaleCRSStationDW1Data12.setLv3(attributes[102]);
			centrexResaleCRSStationDW1Data12.setAai_attr(attributes[103]);
			centrexResaleCRSStationDW1Data12.setAai(attributes[104]);
			centrexResaleCRSStationDW1Data12.setCity_attr(attributes[105]);
			centrexResaleCRSStationDW1Data12.setCity(attributes[106]);
			centrexResaleCRSStationDW1Data12.setState_attr(attributes[107]);
			centrexResaleCRSStationDW1Data12.setState(attributes[108]);
			centrexResaleCRSStationDW1Data12.setZip_attr(attributes[109]);
			centrexResaleCRSStationDW1Data12.setZip(attributes[110]);
			centrexResaleCRSStationDW1Data12.setLcon_attr(attributes[111]);
			centrexResaleCRSStationDW1Data12.setLcon(attributes[112]);
			centrexResaleCRSStationDW1Data12.setTelno_attr(attributes[113]);
			centrexResaleCRSStationDW1Data12.setTelno(attributes[114]);
			centrexResaleCRSStationDW1Data12.setLocnum_attr(attributes[115]);
			centrexResaleCRSStationDW1Data12.setLocnum(attributes[116]);
			centrexResaleCRSStationDW1Data12.setTli_attr(attributes[117]);
			centrexResaleCRSStationDW1Data12.setTli(attributes[118]);
			centrexResaleCRSStationDW1Data12.setIwt_attr(attributes[119]);
			centrexResaleCRSStationDW1Data12.setIwt(attributes[120]);
			centrexResaleCRSStationDW1Data12.setIwtq_attr(attributes[121]);
			centrexResaleCRSStationDW1Data12.setIwtq(attributes[122]);
			centrexResaleCRSStationDW1Data12.setFpi_attr(attributes[123]);
			centrexResaleCRSStationDW1Data12.setFpi(attributes[124]);
			centrexResaleCRSStationDW1Data12.setTns2_attr(attributes[125]);
			centrexResaleCRSStationDW1Data12.setTns2(attributes[126]);
			centrexResaleCRSStationDW1Data12.setLoc_seq_num(attributes[127]);

			treeViewList_680.add(centrexResaleCRSStationDW1Data12);

		}
		session.setAttribute("treeViewList_680", treeViewList_680);
		selectRequestData.setSubHeader(receivedSubHeader);
		// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
	}



	private void getSubData_049RecidData(SubData subData_049Recid, List treeViewList, SelectRequestData selectRequestData, HttpSession session,Header receivedHeader) {

		SubHeader receivedSubHeader = subData_049Recid.getSubHeader();
		String[] subDataRows = subData_049Recid.getSubDataRows();
		List<NotesFupBindingData12States> treeViewList_049 = new ArrayList();
		String lsrNo = "";
		String status = "";
		treeViewList.add("049");
		for (String subDataRow : subDataRows) {
			String[] attributes = mqReadUtil.getAttributes(subDataRow, 15);
//		System.out.println("attributes:=049======> " + Arrays.toString(attributes));
			NotesFupBindingData12States noteFupData9 = new NotesFupBindingData12States();
			noteFupData9.setCompany_code(attributes[0]);
			noteFupData9.setDate_time_received(attributes[1]); // (attributes[8].isEmpty() || attributes[8] ==
																// null ? " " : attributes[8]); //Not getting
																// data...!
			noteFupData9.setPon(attributes[2]);
			noteFupData9.setRver(attributes[3]);
			noteFupData9.setRequest_id(attributes[4]);
			noteFupData9.setReqtype(attributes[5]);
			noteFupData9.setStatus(attributes[6]);
			noteFupData9.setLspauth_attr(attributes[7]);
			noteFupData9.setLspauth(attributes[8].isEmpty() || attributes[8] == null ? " " : attributes[8]);
			noteFupData9.setCvoip(attributes[9]);
			noteFupData9.setAan(attributes[10]);
			noteFupData9.setAtn(attributes[11]);
			noteFupData9.setNatn(attributes[12]);
			noteFupData9.setNan(attributes[13]);
			noteFupData9.setAn(attributes[14]);
			lsrNo = attributes[4];
			status = attributes[6];

			treeViewList_049.add(noteFupData9);
		}
		selectRequestData.setSubHeader(receivedSubHeader);
//		System.out.println("attributes:=049==response====> " + treeViewList_049);
		session.setAttribute("treeViewList_049", treeViewList_049);
		String readOnlyIndicator = receivedHeader.getRead_only_ind();
		session.setAttribute("readOnlyIndictaor", readOnlyIndicator);
		if(receivedHeader.getRead_only_ind().equals("Y"))	{	
			
			session.setAttribute("LrsNo", lsrNo);
			String Readonly_userid= receivedHeader.getRead_only_user_id();
	session.setAttribute("status", status.concat("***Read Only - Opened by " + Readonly_userid +"***"));}
	else {
		session.setAttribute("LrsNo", lsrNo);
		session.setAttribute("status", status);
		
	}
	}



	private List setSortErrorsData(SelectRequestData selectRequestData, Map<String, SubData> subDatas,
			HttpSession session, List treeViewList) {
		
		SubData subData_603Recid = subDatas.get(RecIdFor9State.CS_RECID_SORT_ERROR.getRecIdValue());
		
		if (subData_603Recid != null && subData_603Recid.getSubHeader().getRecord_type().equals("603")) {
			List<SortErrors> treeViewList_603 = new ArrayList();
			SubHeader receivedSubHeader = subData_603Recid.getSubHeader();
			String[] subDataRows = subData_603Recid.getSubDataRows();
			String recIdStr = "R";

			// int i = 0;
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 11);
				// System.out.println("attributes:=603:Reqid======> " +
				// Arrays.toString(attributes));
				SortErrors sortError = new SortErrors();
				sortError.setOrder_attr(attributes[0]);
				sortError.setService_order(attributes[1]);
				sortError.setRule_attr(attributes[2]);
				sortError.setRule_name(attributes[3]);
				sortError.setError_attr(attributes[4]);
				sortError.setError_message(attributes[5]);
				sortError.setAction_attr(attributes[6]);
				if(recIdStr.equals("R")&&attributes[6].equals("U")){
					recIdStr = "U";
				}
				sortError.setAction(attributes[7]);
				sortError.setComment_attr(attributes[8]);
				sortError.setComment(attributes[9]);
				sortError.setSo_msg(attributes[10]);
				treeViewList_603.add(sortError);

			}
			selectRequestData.setSubHeader(receivedSubHeader);
			treeViewList.add("603"+recIdStr);
			// System.out.println("++++treeViewList+++before session+++"+treeViewList_543);
			session.setAttribute("treeViewList_603", treeViewList_603);
			// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
		}
		return treeViewList;
	}
	
	public ConformationTaskMain writeSelectedRequestConformationData(ConformationTaskMain conformationTaskMain,
			String user_id, String object_handle, HttpSession session) {

		Header header = null;
		SubHeader subHeader = null;
		StringBuilder subHeaderandData = new StringBuilder();
		System.out.println("Service:::111:inside:user_id::user_id::::" + user_id);
		String dataString049 = "";
		String dataString558 = "";
		String dataString551 = "";
		String dataString552 = "";
		String dataString905 = "";
		String dataString906 = "";
		int count = 0000;
		focError.clear();  
		
		List<ConfirmationTask_RecId_558> conformationList_558 = conformationTaskMain.getTreeViewList_558();
		List<ConfirmationTask_RecId_558> oldList_558 = (List<ConfirmationTask_RecId_558>) session.getAttribute("treeViewList_558");
		
		List<ConfirmationTask_RecId_552> conformationList_552 = conformationTaskMain
				.getConfirmationTask_RecId_552List();
		List<ConfirmationTask_RecId_552> oldList_552 = (List<ConfirmationTask_RecId_552>) session.getAttribute("treeViewList_552");
		
		
		List<NotesFupBindingData9States> conformationList_049 = conformationTaskMain.getNotesFupBindingData9States();
		List<ConfirmationTask_RecId_550> conformationList_550 = conformationTaskMain.getConfirmationTask_RecId_550();
		
		List<ConfirmationTask_RecId_551> conformationList_551 = conformationTaskMain.getConfirmationTask_RecId_551();
		List<ConfirmationTask_RecId_551> oldList_551 = (List<ConfirmationTask_RecId_551>) (session
				.getAttribute("treeViewList_551"));
		
		List<NotesFupBindingData12States> conformationList_12States = (List<NotesFupBindingData12States>) session
				.getAttribute("treeViewList_049");
		List<ConfirmationTaskNEmailXMLGW9RecId905> confirmationTaskNEmailXMLGW9RecId905 = conformationTaskMain
				.getConfirmationTaskNEmailXMLGW9RecId905();
		List<ConfirmationTaskNEmailXMLGW9RecId906> confirmationTaskNEmailXMLGW9RecId906 = conformationTaskMain
				.getConfirmationTaskNEmailXMLGW9RecId906();

		List filterRecidList = (ArrayList) session.getAttribute("treeViewList");
		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();
		String statesIdentity = (String) session.getAttribute("States");
		if (filterRecidList.contains("049")) {

			if (statesIdentity.equalsIgnoreCase("Y")) {
				for (NotesFupBindingData12States notesFupBindingData9States : conformationList_12States) {
					count++;
					session.setAttribute("Lrs_No", notesFupBindingData9States.getRequest_id().substring(0, 17).trim());
					dataString049 = notesFupBindingData9States.getNotesFupBindingData12String();

				}
			} else {

				for (NotesFupBindingData12States notesFupBindingData9States : conformationList_12States) {
					count++;
					session.setAttribute("Lrs_No", notesFupBindingData9States.getRequest_id().substring(0, 17).trim());
					dataString049 = notesFupBindingData9States.getNotesFupBindingData9String();
//					System.out.println("::::::dataString: confirmationTask_RecId_049_new for::::" + dataString049);

				}
			}
		}
		if (filterRecidList.contains("551")) {
			if (CollectionUtils.isNotEmpty(conformationList_551)) {
				for (ConfirmationTask_RecId_551 confirmationTask_RecId_551_new : conformationList_551) {
					count++;
				}
			}
		}
		if (filterRecidList.contains("552")) {

			for (ConfirmationTask_RecId_552 confirmationTask_RecId_552_new : conformationList_552) {
				count++;
			}
		}
		if (filterRecidList.contains("552")) {

			for (ConfirmationTask_RecId_558 confirmationTask_RecId_558_new : conformationList_558) {
				count++;
			}
		}

		//// kiran
		if (filterRecidList.contains("905")) {

			for (ConfirmationTaskNEmailXMLGW9RecId905 confirmationTaskNEmailXMLGW9RecId905_New : confirmationTaskNEmailXMLGW9RecId905) {
				count++;
			}
		}
		if (filterRecidList.contains("906")) {

			for (ConfirmationTaskNEmailXMLGW9RecId906 confirmationTaskNEmailXMLGW9RecId906_New : confirmationTaskNEmailXMLGW9RecId906) {
				count++;
			}
		}

		// kiran end
		if (filterRecidList.contains("049")) {
			String countVal = "";

			System.out.println("Count:::" + count);
			if (count < 10) {
				System.out.println("less:::");
				countVal = "000" + count;
			}
			if (count >= 10) {
				System.out.println("greater:::");
				countVal = "00" + count;
			}
			header = prepareHeader(user_id, object_handle, countVal);
			subHeader = prepareSubHeader(RecIdFor9State.CS_RECID_HEADER.getRecIdValue());
			subHeaderandData.append(mqMessageStringBuilder.addHeader(header));
			subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString049.toString()));
		}
		if (filterRecidList.contains("551")) {
			List<ConfirmationTask_RecId_551> updatedList= getUpdatedRows_551(conformationList_551,oldList_551);
			System.err.println("updatedList551 N Logic: " + updatedList.toString());
			
			for (ConfirmationTask_RecId_551 confirmationTask_RecId_551_new : updatedList) {
				if (statesIdentity.equalsIgnoreCase("N")) {
					if(confirmationTask_RecId_551_new.getHid_attr().contains("U")) {
						confirmationTask_RecId_551_new.setHid_attr("Y");
					}
					if(confirmationTask_RecId_551_new.getHunt_tli_attr().contains("U")) {
						confirmationTask_RecId_551_new.setHunt_tli_attr("Y");
					}
					dataString551 = confirmationTask_RecId_551_new.getSelectRequest551DataString();
				}else {
					if(confirmationTask_RecId_551_new.getHid_attr().contains("U")) {
						confirmationTask_RecId_551_new.setHid_attr("Y");
					}
					if(confirmationTask_RecId_551_new.getHunt_tli_attr().contains("U")) {
						confirmationTask_RecId_551_new.setHunt_tli_attr("Y");
					}
					
				dataString551 = confirmationTask_RecId_551_new.getSelectRequest551DataString12();
				}
//				System.out.println("::::::dataString: confirmationTask_RecId_551_new for::::" + dataString551);
//				System.out.println("::::::header9999 for::::" + header);
//				System.out.println("::::::subHeade999r for::::" + subHeader);

				// mqMessageStringBuilder.addHeaderSubHeaderAndData(header,subHeader,
				// dataString);
				subHeader = prepareSubHeader(RecIdFor9State.CS_RECID_CONFIRM_HNUM.getRecIdValue());
				subHeaderandData
						.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString551.toString()));
			}

		}
		if (filterRecidList.contains("552")) {
			List<ConfirmationTask_RecId_552> updatedList= getUpdatedRows_552(conformationList_552,oldList_552);
			System.err.println("updatedList552 N Logic : "+updatedList.toString());
			
			for (ConfirmationTask_RecId_552 confirmationTask_RecId_552_new : updatedList) {

				confirmationTask_RecId_552_new.setDd(FormatUtil.getMqDateToString(confirmationTask_RecId_552_new.getDd()));
				if (statesIdentity.equalsIgnoreCase("N")) {
				
					if (confirmationTask_RecId_552_new.getOrd_attr().contains("U")) {
						confirmationTask_RecId_552_new.setOrd_attr("Y");
					}
					if (confirmationTask_RecId_552_new.getLord_attr().contains("U")) {
						confirmationTask_RecId_552_new.setLord_attr("Y");
					}
					if (confirmationTask_RecId_552_new.getFdt_attr().contains("U")) {
						confirmationTask_RecId_552_new.setFdt_attr("Y");
					}
					if (confirmationTask_RecId_552_new.getDd_attr().contains("U")) {
						confirmationTask_RecId_552_new.setDd_attr("Y");
					}
					if(confirmationTask_RecId_552_new.getEcckt_attr().contains("U")) {
						confirmationTask_RecId_552_new.setEcckt_attr("Y");
					}
					if(confirmationTask_RecId_552_new.getTns_attr().contains("U")) {
						confirmationTask_RecId_552_new.setTns_attr("Y");
					}
					if(confirmationTask_RecId_552_new.getTers_attr().contains("U")) {
						confirmationTask_RecId_552_new.setTers_attr("Y");
					}
					if(confirmationTask_RecId_552_new.getIspid_attr().contains("U")) {
						confirmationTask_RecId_552_new.setIspid_attr("Y");
					}
					if(confirmationTask_RecId_552_new.getFecckt_attr().contains("U")) {
						confirmationTask_RecId_552_new.setFecckt_attr("Y");
					}
					if(confirmationTask_RecId_552_new.getNpord_attr().contains("U")) {
						confirmationTask_RecId_552_new.setNpord_attr("Y");
					}
					if(confirmationTask_RecId_552_new.getRti_attr().contains("U")) {
						confirmationTask_RecId_552_new.setRti_attr("Y");
					}
					if(confirmationTask_RecId_552_new.getCbcid_attr().contains("U")) {
						confirmationTask_RecId_552_new.setCbcid_attr("Y");
					}
					if(confirmationTask_RecId_552_new.getCableid_attr().contains("U")) {
						confirmationTask_RecId_552_new.setCableid_attr("Y");
					}
					if(confirmationTask_RecId_552_new.getChan_pair_attr().contains("U")) {
						confirmationTask_RecId_552_new.setChan_pair_attr("Y");
					}
					
				dataString552 = confirmationTask_RecId_552_new.getSelectRequest552DataString();
				}else {
					
					if (confirmationTask_RecId_552_new.getOrd_attr().contains("U")) {
						confirmationTask_RecId_552_new.setOrd_attr("Y");
					}
					if (confirmationTask_RecId_552_new.getLord_attr().contains("U")) {
						confirmationTask_RecId_552_new.setLord_attr("Y");
					}
					if (confirmationTask_RecId_552_new.getFdt_attr().contains("U")) {
						confirmationTask_RecId_552_new.setFdt_attr("Y");
					}
					if (confirmationTask_RecId_552_new.getDd_attr().contains("U")) {
						confirmationTask_RecId_552_new.setDd_attr("Y");
					}
					if(confirmationTask_RecId_552_new.getEcckt_attr().contains("U")) {
						confirmationTask_RecId_552_new.setEcckt_attr("Y");
					}
					if(confirmationTask_RecId_552_new.getTns_attr().contains("U")) {
						confirmationTask_RecId_552_new.setTns_attr("Y");
					}
					if(confirmationTask_RecId_552_new.getTers_attr().contains("U")) {
						confirmationTask_RecId_552_new.setTers_attr("Y");
					}
					if(confirmationTask_RecId_552_new.getIspid_attr().contains("U")) {
						confirmationTask_RecId_552_new.setIspid_attr("Y");
					}
					if(confirmationTask_RecId_552_new.getFecckt_attr().contains("U")) {
						confirmationTask_RecId_552_new.setFecckt_attr("Y");
					}
					if(confirmationTask_RecId_552_new.getNpord_attr().contains("U")) {
						confirmationTask_RecId_552_new.setNpord_attr("Y");
					}
					if(confirmationTask_RecId_552_new.getRti_attr().contains("U")) {
						confirmationTask_RecId_552_new.setRti_attr("Y");
					}
					if(confirmationTask_RecId_552_new.getCbcid_attr().contains("U")) {
						confirmationTask_RecId_552_new.setCbcid_attr("Y");
					}
					if(confirmationTask_RecId_552_new.getCableid_attr().contains("U")) {
						confirmationTask_RecId_552_new.setCableid_attr("Y");
					}
					if(confirmationTask_RecId_552_new.getChan_pair_attr().contains("U")) {
						confirmationTask_RecId_552_new.setChan_pair_attr("Y");
					}
					dataString552 = confirmationTask_RecId_552_new.getSelectRequest552DataString12();
				}			
//					System.out.println("::::::dataString: confirmationTask_RecId_552_new for::::" + dataString552);

				// mqMessageStringBuilder.addHeaderSubHeaderAndData(header,subHeader,
				// dataString);
				subHeader = prepareSubHeader(RecIdFor9State.CS_RECID_CONFIRM_REFNUM.getRecIdValue());
				subHeaderandData
						.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString552.toString()));
			}

		}
		if (filterRecidList.contains("558")) {
			List<ConfirmationTask_RecId_558> updatedList= getUpdatedRows_558(conformationList_558,oldList_558);
			System.err.println("updatedList558 N Logic : "+updatedList.toString());
			
			for (ConfirmationTask_RecId_558 confirmationTask_RecId_558_new : updatedList) {
				confirmationTask_RecId_558_new.setDd(FormatUtil.getMqDateToString(confirmationTask_RecId_558_new.getDd()));
				if (statesIdentity.equalsIgnoreCase("N")) {
				if (confirmationTask_RecId_558_new.getApptime_attr().contains("U")) {
					confirmationTask_RecId_558_new.setApptime_attr("Y");
				}
				if (confirmationTask_RecId_558_new.getOrd_attr().contains("U")) {
					confirmationTask_RecId_558_new.setOrd_attr("Y");
				}
				if (confirmationTask_RecId_558_new.getFdt_attr().contains("U")) {
					confirmationTask_RecId_558_new.setFdt_attr("Y");
				}
				if (confirmationTask_RecId_558_new.getDd_attr().contains("U")) {
					confirmationTask_RecId_558_new.setDd_attr("Y");
				}
				if (confirmationTask_RecId_558_new.getComt_dt_attr().contains("U")) {
					confirmationTask_RecId_558_new.setComt_dt_attr("Y");
				}
				if (confirmationTask_RecId_558_new.getPosted_date_attr().contains("U")) {
					confirmationTask_RecId_558_new.setPosted_date_attr("Y");
				}
				dataString558 = confirmationTask_RecId_558_new.getSelectRequest558DataString();
				}else {
					if (confirmationTask_RecId_558_new.getApptime_attr().contains("U")) {
						confirmationTask_RecId_558_new.setApptime_attr("Y");
					}
					if (confirmationTask_RecId_558_new.getOrd_attr().contains("U")) {
						confirmationTask_RecId_558_new.setOrd_attr("Y");
					}
					if (confirmationTask_RecId_558_new.getFdt_attr().contains("U")) {
						confirmationTask_RecId_558_new.setFdt_attr("Y");
					}
					if (confirmationTask_RecId_558_new.getDd_attr().contains("U")) {
						confirmationTask_RecId_558_new.setDd_attr("Y");
					}
					if (confirmationTask_RecId_558_new.getComt_dt_attr().contains("U")) {
						confirmationTask_RecId_558_new.setComt_dt_attr("Y");
					}
					if (confirmationTask_RecId_558_new.getPosted_date_attr().contains("U")) {
						confirmationTask_RecId_558_new.setPosted_date_attr("Y");
					}
					
					dataString558 = confirmationTask_RecId_558_new.getSelectRequest558DataString();
				}
//				System.out.println("::::::dataString: confirmationTask_RecId_558_new for::::" + dataString558);

				subHeader = prepareSubHeader(RecIdFor9State.CS_RECID_CONFIRM_REQORD.getRecIdValue());
				subHeaderandData
						.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString558.toString()));
			}
		}

		// Kiran
		// kiran
		if (filterRecidList.contains("905")) {
			for (ConfirmationTaskNEmailXMLGW9RecId905 confirmationTaskNEmailXMLGW9RecId905_New : confirmationTaskNEmailXMLGW9RecId905) {
				count++;
				if (confirmationTaskNEmailXMLGW9RecId905_New.getStatus_code_attr().contains("U")) {
					confirmationTaskNEmailXMLGW9RecId905_New.setStatus_code_attr("Y");
				}

				dataString905 = confirmationTaskNEmailXMLGW9RecId905_New.getSelectRequest905DataString();
				subHeader = prepareSubHeader(RecIdFor9State.CS_RECID_SE_CONFIRM.getRecIdValue());
				subHeaderandData
						.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString905.toString()));
			}
		}
		if (filterRecidList.contains("906")) {
			for (ConfirmationTaskNEmailXMLGW9RecId906 confirmationTaskNEmailXMLGW9RecId906_New : confirmationTaskNEmailXMLGW9RecId906) {
				count++;
				if (confirmationTaskNEmailXMLGW9RecId906_New.getOrd_attr().contains("U")) {
					confirmationTaskNEmailXMLGW9RecId906_New.setOrd_attr("Y");
				}
				if (confirmationTaskNEmailXMLGW9RecId906_New.getDdcd_attr().contains("U")) {
					confirmationTaskNEmailXMLGW9RecId906_New.setDdcd_attr("Y");
				}
				if (confirmationTaskNEmailXMLGW9RecId906_New.getLord_attr().contains("U")) {
					confirmationTaskNEmailXMLGW9RecId906_New.setLord_attr("Y");
				}

				dataString906 = confirmationTaskNEmailXMLGW9RecId906_New.getSelectRequest906DataString();
//					System.out.println("::::::dataString: confirmationTaskNEmailXMLGW9RecId906_New for::::"+dataString906);
				subHeader = prepareSubHeader(RecIdFor9State.CS_RECID_SE_CONFIRM_ORDS.getRecIdValue());
				subHeaderandData
						.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString906.toString()));

			}
		}
//		System.out.println("::::::subHeaderandData:::: for::::" + subHeaderandData.toString());
		String mqMessageString = mqMessageStringBuilder.getMqMessageString();
//		System.out.println("::::::58144444 formqMessageString::::" + mqMessageString);
		boolean isWritten = mqWriteUtil.writeDataToMQString(mqMessageString,session);
		//boolean isWritten = false;
		// String reg= (String) session.getAttribute("myReg");
		MQReceivedData mqReceivedData;
		if (isWritten) {
			try {

			mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
			 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
			  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
		//	  Header receivedHeader = mqReceivedData.getHeader(); 
			  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
					System.out.println("*************inside if*************** "); 
					mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
				} 
			  
			  
//			  System.out.println(mqReceivedData.getHeader().toString()); 
		} catch (Exception e) { 
			// TODO Auto-generated catch block 
			 mqReceivedData = mqReadUtil.readDataFromMQ(session); 
			e.printStackTrace(); 


		}
		
			// mqReceivedData = mqReadUtil.readDataFromMQ(session);
//			System.out.println("::::::mqReceivedData for::::" + mqReceivedData);
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
//			System.out.println("::::::subDatas for::::" + subDatas);
			Header receivedHeader = mqReceivedData.getHeader();
			conformationTaskMain.setHeader(receivedHeader);
		//	System.out.println("::::::receivedHeader for::::returncode::::" + receivedHeader.getReturn_code());
			SubData subData = subDatas.get(RecIdFor12State.CS_RECID_ERROR.getRecIdValue());
			SubData subData550 = subDatas.get(RecIdFor9State.CS_RECID_CONFIRM.getRecIdValue());
			SubData subData551 = subDatas.get(RecIdFor9State.CS_RECID_CONFIRM_HNUM.getRecIdValue());
			SubData subData552 = subDatas.get(RecIdFor9State.CS_RECID_CONFIRM_REFNUM.getRecIdValue());
			SubData subData558 = subDatas.get(RecIdFor9State.CS_RECID_CONFIRM_REQORD.getRecIdValue());
			SubData subData50 = subDatas.get(RecIdFor9State.CS_RECID_LSR.getRecIdValue());
			SubData subData905 = subDatas.get(RecIdFor9State.CS_RECID_SE_CONFIRM.getRecIdValue());
			SubData subData906 = subDatas.get(RecIdFor9State.CS_RECID_SE_CONFIRM_ORDS.getRecIdValue());
//			System.out.println("subData: " + subData);
//			System.out.println("subData: " + subData);
			if (subData != null) {
			
				String[] subDataRows = subData.getSubDataRows();
				if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
				/*for (String subDataRow : subDataRows) {
					
					String[] sentData = subDataRow.split(",");
					System.out.println("sentData after separation" + sentData);
					for (String a : sentData) {
					System.out.println("*Recv. Data :"+a);
					ShowErrorService showErrorService = new ShowErrorService();
					ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
					String uon_msg = readErrorMsgsJson.getErrorMsg(a.substring(0, 6).trim());
					System.err.println("UON:"+ uon_msg);
					
					focError = showErrorService.getErrorListMultiple(a.substring(0, 6).trim(), uon_msg, "", "U",focError);
					
					//focMulipleError.add(focError);
					//session.setAttribute("showError", focError);
					System.err.println("ERRORS *600*****" + focError.toString());
				}}*/
					for (String subDataRow : subDataRows) {
//						System.err.println("Sub data row is: "+subDataRow.toString());
							String[] attributes = mqReadUtil.getAttributes(subDataRow, 4);
							//For greater LSR versions exist error message
							if(attributes[0].equals("LG0118"))
							{
								String lsr_no = (String) session.getAttribute("Lrs_No");
								focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2], lsr_no, "", focError);
							}
							else{
								focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2], "","U", focError);
							}
						}
				}
			}
			
			if(subData550 != null) {
				String[] subDataRows550 = subData550.getSubDataRows();
				if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
					/*for (String subDataRow : subDataRows550) {
						
						String[] sentData = subDataRow.split(",");
						System.out.println("sentData after separation" + sentData);
						for (String a : sentData) {
						
							ShowErrorService showErrorService = new ShowErrorService();
						ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
						String uon_msg = readErrorMsgsJson.getErrorMsg(a.substring(0, 6).trim());
						String Lsr_no = (String) session.getAttribute("Lrs_No");
						System.out.println("LSR no==="+Lsr_no);
						
						focError = showErrorService.getErrorListMultiple(a.substring(0, 6).trim(), uon_msg, "", "lsrn=" +Lsr_no+" "+"unknown",focError);
						
						
						//focMulipleError.add(focError);
						//session.setAttribute("showError", focError);
						System.err.println("ERRORS *550*****" + focError.toString());
					}
						}*/
					for (String subDataRow : subDataRows550) {
//						System.err.println("Sub data row is: "+subDataRow.toString());
							String[] attributes = mqReadUtil.getAttributes(subDataRow, 4);
							//For greater LSR versions exist error message
							if(attributes[0].equals("LG0118"))
							{
								String lsr_no = (String) session.getAttribute("Lrs_No");
								focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2], lsr_no, "", focError);
							}
							else{
								focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2], "","U", focError);
							}
							
							System.err.println("ERRORS *550*****" + focError.toString());
						}
				}
				}
				if(subData551 != null) {
					String[] subDataRows551 = subData551.getSubDataRows();
					if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
						for (String subDataRow : subDataRows551) {
//							System.err.println("Sub data row is: "+subDataRow.toString());
								String[] attributes = mqReadUtil.getAttributes(subDataRow, 4);
								//For greater LSR versions exist error message
								if(attributes[0].equals("LG0118"))
								{
									String lsr_no = (String) session.getAttribute("Lrs_No");
									focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2], lsr_no, "", focError);
								}
								else{
									focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2], "","U", focError);
								}
								
								System.err.println("ERRORS *551*****" + focError.toString());
							}
					}}
				if(subData552 != null) {
					String[] subDataRows552 = subData552.getSubDataRows();
					if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
						for (String subDataRow : subDataRows552) {
//							System.err.println("Sub data row is: "+subDataRow.toString());
								String[] attributes = mqReadUtil.getAttributes(subDataRow, 4);
								//For greater LSR versions exist error message
								if(attributes[0].equals("LG0118"))
								{
									String lsr_no = (String) session.getAttribute("Lrs_No");
									focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2], lsr_no, "", focError);
								}
								else{
									focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2], "","U", focError);
								}
								
								System.err.println("ERRORS *552*****" + focError.toString());
							}
					}
				}
				if(subData558 != null) {
					String[] subDataRows558 = subData558.getSubDataRows();
					if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
						for (String subDataRow : subDataRows558) {
//							System.err.println("Sub data row is: "+subDataRow.toString());
								String[] attributes = mqReadUtil.getAttributes(subDataRow, 4);
								//For greater LSR versions exist error message
								if(attributes[0].equals("LG0118"))
								{
									String lsr_no = (String) session.getAttribute("Lrs_No");
									focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2], lsr_no, "", focError);
								}
								else{
									focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2], "","U", focError);
								}
								
								System.err.println("ERRORS *558*****" + focError.toString());
							}
					}
				}
				if(subData905 != null) {
					String[] subDataRows905 = subData905.getSubDataRows();
					if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
						for (String subDataRow : subDataRows905) {
//								System.err.println("Sub data row is: "+subDataRow.toString());
									String[] attributes = mqReadUtil.getAttributes(subDataRow, 4);
									//For greater LSR versions exist error message
									if(attributes[0].equals("LG0118"))
									{
										String lsr_no = (String) session.getAttribute("Lrs_No");
										focError = showErrorService.getShowErrorList(subDataRow.substring(0,6), attributes[2], lsr_no, "", focError);
									}
									else{
										focError = showErrorService.getShowErrorList(subDataRow.substring(0,6), attributes[2], "","U", focError);
									}
								}
					}}
				if(subData906 != null) {
					String[] subDataRows906 = subData906.getSubDataRows();
					if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
						for (String subDataRow : subDataRows906) {
//							System.err.println("Sub data row is: "+subDataRow.toString());
								String[] attributes = mqReadUtil.getAttributes(subDataRow, 4);
								//For greater LSR versions exist error message
								if(attributes[0].equals("LG0118"))
								{
									String lsr_no = (String) session.getAttribute("Lrs_No");
									focError = showErrorService.getShowErrorList(subDataRow.substring(0,6), attributes[2], lsr_no, "", focError);
								}
								else{
									focError = showErrorService.getShowErrorList(subDataRow.substring(0,6), attributes[2], "","U", focError);
								}
							}
				}
				}
				if(subData50 != null) {
					String[] subDataRows50 = subData50.getSubDataRows();
					if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
					for (String subDataRow : subDataRows50) {

					String[] sentData = subDataRow.split(",");
					System.out.println("sentData after separation" + sentData);
					for (String a : sentData) {

					ShowErrorService showErrorService = new ShowErrorService();
					ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
					String uon_msg = readErrorMsgsJson.getErrorMsg(a.substring(0, 6).trim());
					String Lsr_no = (String) session.getAttribute("Lrs_No");
//					System.out.println("LSR no==="+Lsr_no);

					focError = showErrorService.getErrorListMultiple(a.substring(0, 6).trim(), uon_msg, "", "lsrn=" +Lsr_no+" "+"unknown",focError);

					System.err.println("ERRORS *50*****" + focError.toString());


					}}
					}
					}
				session.setAttribute("showError", focError);
			
			
		}
		return conformationTaskMain;

	}

	private List<ConfirmationTask_RecId_558> getUpdatedListFor558RecID() {
		// TODO Auto-generated method stub
		return null;
	}
	public FollowUpData9States writeSelectedRequestNotesData(List<FollowUpData9States> followUpData9StatesList,
			String user_id, String object_handle, HttpSession session, String notes) {

		Header header = null;
		SubHeader subHeader = null;
		StringBuilder subHeaderandDataNotes = new StringBuilder();
		System.out.println("Service:::111:inside:user_id::user_id::::" + user_id);
		String dataString049 = "";
		String dataString531 = "";
		int count = 0;
		FollowUpData9States followUpData9States = null;
		List<NotesFupBindingData12States> conformationList_049 = (List<NotesFupBindingData12States>) session
				.getAttribute("treeViewList_049");

		List filterRecidList = (ArrayList) session.getAttribute("treeViewList");
//		System.out.println("::::::dataString: followUpData9States for::::" + followUpData9StatesList);
		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();
		if (filterRecidList.contains("049")) {

			for (NotesFupBindingData12States notesFupBindingData9States : conformationList_049) {
				count++;
				session.setAttribute("Lrs_No", notesFupBindingData9States.getRequest_id().substring(0, 17).trim());
				dataString049 = notesFupBindingData9States.getNotesFupBindingData9String();
//				System.out.println("::::::dataString: confirmationTask_RecId_049_new for::::" + dataString049);

			}
		}
		if (filterRecidList.contains("531")) {
			String Lsr_number = (String) session.getAttribute("Lrs_No");
			for (FollowUpData9States followUpData9subStates : followUpData9StatesList) {
				count++;
				followUpData9subStates.setLasr_ver(Lsr_number.substring(15, 17));// dynamic
				followUpData9subStates.setUser_id(user_id);
				followUpData9subStates.setUser_id_attr("Y");
				followUpData9subStates.setLasr_ver_attr("Y");
				followUpData9subStates.setFollow_up_date_attr("Y");
				followUpData9subStates.setNotes_attr("Y");
				followUpData9subStates.setNotes(notes);
				followUpData9States = followUpData9subStates;
				dataString531 = followUpData9subStates.getSelectRequestNotesDataString();
//				System.out.println("::::::dataString: confirmationTask_RecId_531_new for::::" + dataString531);

			}
		}
		if (filterRecidList.contains("049")) {
			String countVal = "";

			System.out.println("Count:::" + count);
			if (count < 10) {
				System.out.println("less:::");
				countVal = "000" + count;
			}
			if (count >= 10) {
				System.out.println("greater:::");
				countVal = "00" + count;
			}
			header = prepareNotesHeader(user_id, object_handle, countVal);
			subHeader = prepareNotesSubHeader(RecIdFor9State.CS_RECID_HEADER.getRecIdValue(),
					ProcessMode.CS_SPECIAL.getProcessModeCode());
			subHeaderandDataNotes.append(mqMessageStringBuilder.addHeader(header));
			subHeaderandDataNotes
					.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString049).toString());
		}
		if (filterRecidList.contains("531")) {
			// subHeader =
			// prepareSubHeader(RecIdFor9State.CS_RECID_CONFIRM_HNUM.getRecIdValue());
			subHeader = prepareNotesSubHeader(RecIdFor9State.CS_RECID_NOTES_INPUT.getRecIdValue(),
					ProcessMode.CS_ADD.getProcessModeCode());
			subHeaderandDataNotes.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString531));
		}
		MQMessageStringBuilder mqMessageStringBuilder_recid = new MQMessageStringBuilder()
				.appendHeaderAndSubData(header, subHeaderandDataNotes.toString());
		// MQMessageStringBuilder mqMessageStringBuilder_recid = new
		// MQMessageStringBuilder().addHeaderSubHeaderAndData(header,subHeader,
		// dataString);
//		System.out.println("::::::58144444 notesfor::::" + mqMessageStringBuilder_recid);
		String mqMessageString = mqMessageStringBuilder.getMqMessageString();
//		System.out.println("::::::58144444notes formqMessageString::::" + mqMessageString);
		boolean isWritten = mqWriteUtil.writeDataToMQString(mqMessageString,session);
		// boolean isWritten = false;
		// String reg= (String) session.getAttribute("myReg");

		if (isWritten) {

			MQReceivedData mqReceivedData;
			
			try {

			mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
			 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
			  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
		//	  Header receivedHeader = mqReceivedData.getHeader(); 
			  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
					System.out.println("*************inside if*************** "); 
					mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
				} 
			  
			  
//			  System.out.println(mqReceivedData.getHeader().toString()); 
		} catch (Exception e) { 
			// TODO Auto-generated catch block 
			 mqReceivedData = mqReadUtil.readDataFromMQ(session); 
			e.printStackTrace(); 


		}
//			System.out.println("::::::mqReceivedData for:notes:::" + mqReceivedData);
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
//			System.out.println("::::::subDatas for::::" + subDatas);
			Header receivedHeader = mqReceivedData.getHeader();
			followUpData9States.setHeader(receivedHeader);
			// System.out.println("::::::receivedHeader
			// for::notes::returncode::::"+receivedHeader.getReturn_code());

		}
		return followUpData9States;
	}

	// Setp 4

	public String writeSelectedRequestPopup(SelectRequestData selectRequestData, String user_id, HttpSession session,
			String object_handle) {

		Header header = prepareRefreshHeader(user_id, object_handle, Process.CS_SELECT_REF.getProcessCode());
		SubHeader subHeader = prepareTreeSubHeader();
		String status = "";
		selectRequestData.setPrevnext_cde("R");

		List<SelectRequestTableRow9> selectedRequestTableRow9 = selectRequestData.getSelectRequestTableRows9();
		List<SelectRequestTableRow> selectedRequestTableRow12 = selectRequestData.getSelectRequestTableRows();
		System.out.println("::::::selectedRequestTableRow12: popup 4th for::ifff::" + selectedRequestTableRow12.size());
		String dataString = "";
		String statesIdentity = (String) session.getAttribute("States");
		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();
		if (statesIdentity.equalsIgnoreCase("N")) {
			for (SelectRequestTableRow9 selectRequestTableRow : selectedRequestTableRow9) {
				String tabValue = "Y";
				dataString = selectRequestTableRow.getSelectRequestTreeDataString(tabValue);
//				System.out.println("::::::dataString: popup 4th for::ifff::" + dataString);

				mqMessageStringBuilder.addHeaderSubHeaderAndData(header, subHeader, dataString);

			}
		} else {

			for (SelectRequestTableRow selectRequestTableRow : selectedRequestTableRow12) {
				String tabValue = "N";
				dataString = selectRequestTableRow.getSelectRequestTreeDataString(tabValue);
//				System.out.println("::::::dataString: popup 4th for::elseee::" + dataString);
				mqMessageStringBuilder.addHeaderSubHeaderAndData(header, subHeader, dataString);

			}
		}
		// boolean isWritten = false;
		boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder,session);

		if (isWritten) {

			MQReceivedData mqReceivedData;
			
			try {

			mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
			 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
			  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
		//	  Header receivedHeader = mqReceivedData.getHeader(); 
			  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
					System.out.println("*************inside if*************** "); 
					mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
				} 
			  
			  
//			  System.out.println(mqReceivedData.getHeader().toString()); 
		} catch (Exception e) { 
			// TODO Auto-generated catch block 
			 mqReceivedData = mqReadUtil.readDataFromMQ(session); 
			e.printStackTrace(); 


		}
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
			Header receivedHeader = mqReceivedData.getHeader();
			selectRequestData.setHeader(receivedHeader);
			status = receivedHeader.getReturn_code();
			// System.out.println("::::::receivedHeader.getReturn_code: popup 4th
			// for::::"+receivedHeader.getReturn_code());
		}
		return status;
	}

	private Header preparePopUpHeader(String user_id, String object_handle, String process_Group) {

		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_CLOSE_REQUEST.getProcessCode());
		header.setTab_ind(TabInd.SAVE.getTabIndCode());
		header.setProcess_group_ind(process_Group);
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail("0001");
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}

	private SubHeader preparePopUpSubHeader(String recid) {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_UPDATE.getProcessModeCode());
		subHeader.setRecord_type(recid);
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private SubHeader prepareSubHeader(String recid) {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_UPDATE.getProcessModeCode());
		subHeader.setRecord_type(recid);
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private Header prepareHeader(String user_id, String object_handle, String count) {

		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_REQUEST.getProcessCode());
		header.setTab_ind(TabInd.FOC.getTabIndCode());
		header.setProcess_group_ind(ProcessGroupInd.ISSUE_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail(count);
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}
//====================Sneha=============================
	private Header preparePostToBillHeader(String user_id, String object_handle, String count) {
		
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_REQUEST.getProcessCode());
		header.setTab_ind(TabInd.PostTOBill.getTabIndCode());
		header.setProcess_group_ind(ProcessGroupInd.ISSUE_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail(count);		
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}
	
	//===================Sneha end Code ===================
	
	private Header prepareHeader1(String user_id, String object_handle, String count) {

		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_REQUEST.getProcessCode());
		header.setTab_ind(TabInd.TASK.getTabIndCode());
		header.setProcess_group_ind(ProcessGroupInd.ISSUE_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail(count);
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}

	private Header prepareNotesHeader(String user_id, String object_handle, String count) {

		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_REQUEST.getProcessCode());
		header.setTab_ind(TabInd.SAVE.getTabIndCode());
		header.setProcess_group_ind(ProcessGroupInd.SAVE_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail(count);
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}

	private SubHeader prepareNotesSubHeader(String recid, String mode) {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(mode);
		subHeader.setRecord_type(recid);
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private SubHeader prepareTreeSubHeader() {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_RETRIEVE.getProcessModeCode());
		subHeader.setRecord_type(null);
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private Header prepareTreeHeader(String user_id, String object_handle, String process) {
		// Prepare Header
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(process);
		header.setTab_ind(null);
		header.setProcess_group_ind(ProcessGroupInd.RETRIEVE_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail("0001");
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}

	private Header prepareRefreshHeader(String user_id, String object_handle, String process) {
		// Prepare Header
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(process);
		header.setTab_ind(null);
		header.setProcess_group_ind(ProcessGroupInd.RETRIEVE_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind("N");
		header.setNum_detail("1");
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}

	private List requestTypeC_Z_9State(SelectRequestData selectRequestData, Map<String, SubData> subDatas,
			HttpSession session, List treeViewList) {
		// ***************************************RajaShekhar code
		// start******************************
		SubData subData9state_065Recid = subDatas.get(RecIdFor9State.CS_RECID_REMARKS.getRecIdValue());
		SubData subData9_586Recid = subDatas.get(RecIdFor9State.CS_RECID_POST_TO_BILL_VIEW.getRecIdValue());
		SubData subData9_602Recid = subDatas.get(RecIdFor9State.CS_RECID_LASR_ERRORS.getRecIdValue());
		SubData subData9_250Recid = subDatas.get(RecIdFor9State.CS_RECID_NP.getRecIdValue());
		SubData subData9_530Recid = subDatas.get(RecIdFor9State.CS_RECID_NOTES.getRecIdValue());
		SubData subData9_534Recid = subDatas.get(RecIdFor9State.CS_RECID_RESPONSE_SUMMARY.getRecIdValue());
		SubData subData9_601Recid = subDatas.get(RecIdFor12State.CS_RECID_ERRORS_MOGAOG.getRecIdValue());

		if (subData9state_065Recid != null && subData9state_065Recid.getSubHeader().getRecord_type().equals("065")) {

			List<Remarks9state> treeViewList9_065 = new ArrayList<>();

			SubHeader receivedSubHeader = subData9state_065Recid.getSubHeader();
			String[] subDataRows = subData9state_065Recid.getSubDataRows();
			treeViewList.add("065");
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 4);
				// System.out.println("attributes:=065:Reqid======> " +
				// Arrays.toString(attributes));
				Remarks9state remarks9states = new Remarks9state();
				remarks9states.setRemark_attr(attributes[0]);
				remarks9states.setRemark(attributes[1]);
				remarks9states.setRemark_type_attr(attributes[2]);
				remarks9states.setRemark_type(attributes[3]);
				treeViewList9_065.add(remarks9states);
			}
			selectRequestData.setSubHeader(receivedSubHeader);
			// System.out.println("++++treeViewList_065+++before session+++" +
			// treeViewList9_065);
			session.setAttribute("treeViewList9_065", treeViewList9_065);
			// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);

		}

		if (subData9_601Recid != null && subData9_601Recid.getSubHeader().getRecord_type().equals("601")) {

			List<OGerrors9state> treeViewList9_601 = new ArrayList<>();
			SubHeader receivedSubHeader = subData9_601Recid.getSubHeader();
			String[] subDataRows = subData9_601Recid.getSubDataRows();
			treeViewList.add("601");
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 4);
				// System.out.println("attributes:=601:Reqid======> " +
				// Arrays.toString(attributes));
				OGerrors9state ogErrors9State = new OGerrors9state();
				ogErrors9State.setOrder_num(attributes[0]);
				ogErrors9State.setLocation(attributes[1]);
				ogErrors9State.setError_code(attributes[2]);
				ogErrors9State.setError_msg(attributes[3]);

				treeViewList9_601.add(ogErrors9State);
			}
			selectRequestData.setSubHeader(receivedSubHeader);
			// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			// System.out.println("++++treeViewList_601+++before session+++" +
			// treeViewList9_601);
			session.setAttribute("treeViewList9_601", treeViewList9_601);

		}
		if (subData9_534Recid != null && subData9_534Recid.getSubHeader().getRecord_type().equals("534")) {

			List<ResponseSummary9state> treeViewList9_534 = new ArrayList<>();
			SubHeader receivedSubHeader = subData9_534Recid.getSubHeader();
			String[] subDataRows = subData9_534Recid.getSubDataRows();
			treeViewList.add("534");
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 7);
				// System.out.println("attributes:=534:Reqid======> " +
				// Arrays.toString(attributes));
				ResponseSummary9state responseSummary9state = new ResponseSummary9state();
				responseSummary9state.setEcver(attributes[0]);
				responseSummary9state.setLsrver(attributes[1]);
				responseSummary9state.setType(attributes[2]);
				responseSummary9state.setPia(attributes[3]);
				responseSummary9state.setD_t_sent_local(attributes[4]);
				responseSummary9state.setD_t_sent_central(attributes[5]);
				responseSummary9state.setUserid(attributes[6]);
				treeViewList9_534.add(responseSummary9state);
			}
			selectRequestData.setSubHeader(receivedSubHeader);
			// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			// System.out.println("++++treeViewList_534+++before session+++" +
			// treeViewList9_534);
			session.setAttribute("treeViewList9_534", treeViewList9_534);
		}

		if (subData9_586Recid != null && subData9_586Recid.getSubHeader().getRecord_type().equals("586")) {

			List<PostToBillView9states> treeViewList9_586 = new ArrayList<>();
			SubHeader receivedSubHeader = subData9_586Recid.getSubHeader();
			String[] subDataRows = subData9_586Recid.getSubDataRows();
			treeViewList.add("586");
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 12);
				// System.out.println("attributes:=586:Reqid======> " +
				// Arrays.toString(attributes));
				PostToBillView9states postToBillView9tates = new PostToBillView9states();
				postToBillView9tates.setC_ver_attr(attributes[0]);
				postToBillView9tates.setC_ver(attributes[1]);
				postToBillView9tates.setRt_attr(attributes[2]);
				postToBillView9tates.setRt(attributes[3]);
				postToBillView9tates.setEc_ver_attr(attributes[4]);
				postToBillView9tates.setEc_ver(attributes[5]);
				postToBillView9tates.setDt_sent_local_attr(attributes[6]);
				postToBillView9tates.setDt_sent_local(attributes[7]);
				postToBillView9tates.setResponse_dt_sent_attr(attributes[8]);
				postToBillView9tates.setResponse_dt_sent(attributes[9]);
				postToBillView9tates.setPd_attr(attributes[10]);
				postToBillView9tates.setPd(attributes[11]);

				treeViewList9_586.add(postToBillView9tates);
			}
			selectRequestData.setSubHeader(receivedSubHeader);
			// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			// System.out.println("++++treeViewList_586+++before session+++" +
			// treeViewList9_586);
			session.setAttribute("treeViewList9_586", treeViewList9_586);
		}
		if (subData9_602Recid != null && subData9_602Recid.getSubHeader().getRecord_type().equals("602")) {

			List<FatalErrors9state> treeViewList9_602 = new ArrayList<>();
			SubHeader receivedSubHeader = subData9_602Recid.getSubHeader();
			String[] subDataRows = subData9_602Recid.getSubDataRows();
			treeViewList.add("602");
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 15);
				// System.out.println("attributes:=602:Reqid======> " +
				// Arrays.toString(attributes));
				FatalErrors9state fatalErrors9state = new FatalErrors9state();
				fatalErrors9state.setCver(attributes[0]);
				fatalErrors9state.setResponse_type(attributes[1]);
				fatalErrors9state.setEcver(attributes[2]);
				fatalErrors9state.setDt_sent_local(attributes[3]);
				fatalErrors9state.setResponse_dt_sent_central_time(attributes[4]);
				fatalErrors9state.setField_name(attributes[5]);
				fatalErrors9state.setItem_num(attributes[6]);
				fatalErrors9state.setLnum(attributes[7]);
				fatalErrors9state.setNum_name(attributes[8]);
				fatalErrors9state.setNum_nbr(attributes[9]);
				fatalErrors9state.setLeg_num(attributes[10]);
				fatalErrors9state.setError_code(attributes[11]);
				fatalErrors9state.setError_message(attributes[12]);

				treeViewList9_602.add(fatalErrors9state);
			}
			selectRequestData.setSubHeader(receivedSubHeader);
			// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			// System.out.println("++++treeViewList_602+++before session+++" +
			// treeViewList9_602);
			session.setAttribute("treeViewList9_602", treeViewList9_602);
		}

		if (subData9_250Recid != null && subData9_250Recid.getSubHeader().getRecord_type().equals("250")) {

			List<NP9states> treeViewList9_250 = new ArrayList<>();
			SubHeader receivedSubHeader = subData9_250Recid.getSubHeader();
			String[] subDataRows = subData9_250Recid.getSubDataRows();
			treeViewList.add("250");
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 222);
				// System.out.println("attributes:=250:Reqid======> " +
				// Arrays.toString(attributes));
				NP9states np9states = new NP9states();
				np9states.setItem_num(attributes[0]);
				np9states.setLnum_attr(attributes[1]);
				np9states.setLnum(attributes[2]);
				np9states.setLna_attr(attributes[3]);
				np9states.setLna(attributes[4]);
				np9states.setLmt_attr(attributes[5]);
				np9states.setLmt(attributes[6]);
				np9states.setEcckt_attr(attributes[7]);
				np9states.setEcckt(attributes[8]);
				np9states.setShared_nbr_attr(attributes[9]);
				np9states.setShared_nbr(attributes[10]);
				np9states.setDisc_nbr_attr(attributes[11]);
				np9states.setDisc_nbr(attributes[12]);
				np9states.setTers_attr(attributes[13]);
				np9states.setTers(attributes[14]);
				np9states.setCfa_attr(attributes[15]);
				np9states.setCfa(attributes[16]);
				np9states.setCcea_attr(attributes[17]);
				np9states.setCcea(attributes[18]);
				np9states.setSscfa_attr(attributes[19]);
				np9states.setSscfa(attributes[20]);
				np9states.setCableid_attr(attributes[21]);
				np9states.setCableid(attributes[22]);
				np9states.setChan_pair3_attr(attributes[23]);
				np9states.setChan_pair3(attributes[24]);
				np9states.setSystemid_attr(attributes[25]);
				np9states.setSystemid(attributes[26]);
				np9states.setCbcid_attr(attributes[27]);
				np9states.setCbcid(attributes[28]);
				np9states.setChan_pair_attr(attributes[29]);
				np9states.setChan_pair(attributes[30]);
				np9states.setCbcid2_attr(attributes[31]);
				np9states.setCbcid2(attributes[32]);
				np9states.setChan_pair2_attr(attributes[33]);
				np9states.setChan_pair2(attributes[34]);
				np9states.setCti_attr(attributes[35]);
				np9states.setCti(attributes[36]);
				np9states.setRelay_rack_attr(attributes[37]);
				np9states.setRelay_rack(attributes[38]);
				np9states.setShelf_attr(attributes[39]);
				np9states.setShelf(attributes[40]);
				np9states.setSlot_attr(attributes[41]);
				np9states.setSlot(attributes[42]);
				np9states.setCti2_attr(attributes[43]);
				np9states.setCti2(attributes[44]);
				np9states.setRelay_rack2_attr(attributes[45]);
				np9states.setRelay_rack2(attributes[46]);
				np9states.setShelf2_attr(attributes[47]);
				np9states.setShelf2(attributes[48]);
				np9states.setSlot2_attr(attributes[49]);
				np9states.setSlot2(attributes[50]);
				np9states.setCti3_attr(attributes[51]);
				np9states.setCti3(attributes[52]);
				np9states.setRelay_rack3_attr(attributes[53]);
				np9states.setRelay_rack3(attributes[54]);
				np9states.setShelf3_attr(attributes[55]);
				np9states.setShelf3(attributes[56]);
				np9states.setSlot3_attr(attributes[57]);
				np9states.setSlot3(attributes[58]);
				np9states.setCti4_attr(attributes[59]);
				np9states.setCti(attributes[60]);
				np9states.setRelay_rack4_attr(attributes[61]);
				np9states.setRelay_rack4(attributes[62]);
				np9states.setShelf4_attr(attributes[63]);
				np9states.setShelf4(attributes[64]);
				np9states.setSlot4_attr(attributes[65]);
				np9states.setSlot4(attributes[66]);
				np9states.setVpi_attr(attributes[67]);
				np9states.setVpi(attributes[68]);
				np9states.setVci_attr(attributes[69]);
				np9states.setVci(attributes[70]);
				np9states.setCode_set_attr(attributes[71]);
				np9states.setCode_set(attributes[72]);
				np9states.setRecckt_attr(attributes[73]);
				np9states.setRecckt(attributes[74]);
				np9states.setCkr_attr(attributes[75]);
				np9states.setCkr(attributes[76]);
				np9states.setTsp_attr(attributes[77]);
				np9states.setTsp(attributes[78]);
				np9states.setPorted_nbr_attr(attributes[79]);
				np9states.setPorted_nbr(attributes[80]);
				np9states.setNpt_attr(attributes[81]);
				np9states.setNpt(attributes[82]);
				np9states.setRti_attr(attributes[83]);
				np9states.setRti(attributes[84]);
				np9states.setNptg_attr(attributes[85]);
				np9states.setNptg(attributes[86]);
				np9states.setNpi_attr(attributes[87]);
				np9states.setNpi(attributes[88]);
				np9states.setLst_attr(attributes[89]);
				np9states.setLst(attributes[90]);
				np9states.setTns_attr(attributes[91]);
				np9states.setTns(attributes[92]);
				np9states.setOtn_attr(attributes[93]);
				np9states.setOtn(attributes[94]);
				np9states.setIspid_attr(attributes[95]);
				np9states.setIspid(attributes[96]);
				np9states.setPic_attr(attributes[97]);
				np9states.setPic(attributes[98]);
				np9states.setLpic_attr(attributes[99]);
				np9states.setLpic(attributes[100]);
				np9states.setSsig_attr(attributes[101]);
				np9states.setSsig(attributes[102]);
				np9states.setBa_attr(attributes[103]);
				np9states.setBa(attributes[104]);
				np9states.setBlock_attr(attributes[105]);
				np9states.setBlock(attributes[106]);
				np9states.setJk_code_attr(attributes[107]);
				np9states.setJk_code(attributes[108]);
				np9states.setJk_num_attr(attributes[109]);
				np9states.setJk_num(attributes[110]);
				np9states.setJk_pos_attr(attributes[111]);
				np9states.setJk_pos(attributes[112]);
				np9states.setJr_attr(attributes[113]);
				np9states.setJr(attributes[114]);
				np9states.setNidr_attr(attributes[115]);
				np9states.setNidr(attributes[116]);
				np9states.setIwjk1_attr(attributes[117]);
				np9states.setIwjk1(attributes[118]);
				np9states.setIwjk2_attr(attributes[119]);
				np9states.setIwjk2(attributes[120]);
				np9states.setIwjk3_attr(attributes[121]);
				np9states.setIwjk3(attributes[122]);
				np9states.setIwjk4_attr(attributes[123]);
				np9states.setIwjk4(attributes[124]);
				np9states.setIwjk5_attr(attributes[125]);
				np9states.setIwjk5(attributes[126]);
				np9states.setIwjq1_attr(attributes[127]);
				np9states.setIwjq1(attributes[128]);
				np9states.setIwjq2_attr(attributes[129]);
				np9states.setIwjq2(attributes[130]);
				np9states.setIwjq3_attr(attributes[131]);
				np9states.setIwjq3(attributes[132]);
				np9states.setIwjq4_attr(attributes[133]);
				np9states.setIwjq4(attributes[134]);
				np9states.setIwjq5_attr(attributes[135]);
				np9states.setIwjq5(attributes[136]);
				np9states.setLidb_attr(attributes[137]);
				np9states.setLidb(attributes[138]);
				np9states.setS_attr(attributes[139]);
				np9states.setS(attributes[140]);
				np9states.setOecckt_attr(attributes[141]);
				np9states.setOecckt(attributes[142]);
				np9states.setPqty_attr(attributes[143]);
				np9states.setPqty(attributes[144]);
				np9states.setLocnum_attr(attributes[145]);
				np9states.setLocnum(attributes[146]);
				np9states.setLnex_attr(attributes[147]);
				np9states.setLnex(attributes[148]);
				np9states.setLneclssvc_attr(attributes[149]);
				np9states.setLneclssvc(attributes[150]);
				np9states.setFpi_attr(attributes[151]);
				np9states.setFpi(attributes[152]);
				np9states.setSdi_attr(attributes[153]);
				np9states.setSdi(attributes[154]);
				np9states.setMatn_attr(attributes[155]);
				np9states.setMatn(attributes[156]);
				np9states.setSgnl_attr(attributes[157]);
				np9states.setSgnl(attributes[158]);
				np9states.setPulse_attr(attributes[159]);
				np9states.setPulse(attributes[160]);
				np9states.setLean_attr(attributes[161]);
				np9states.setLean(attributes[162]);
				np9states.setLeatn_attr(attributes[163]);
				np9states.setLeatn(attributes[164]);
				np9states.setIwt_attr(attributes[165]);
				np9states.setIwt(attributes[166]);
				np9states.setIwtq_attr(attributes[167]);
				np9states.setIwtq(attributes[168]);
				np9states.setTli_attr(attributes[169]);
				np9states.setTli(attributes[170]);
				np9states.setLqty_attr(attributes[171]);
				np9states.setLqty(attributes[172]);
				np9states.setBtrl_attr(attributes[173]);
				np9states.setBtrl(attributes[174]);
				np9states.setCma_attr(attributes[175]);
				np9states.setCma(attributes[176]);
				np9states.setSan_attr(attributes[177]);
				np9states.setSan(attributes[178]);
				np9states.setCableid2_attr(attributes[179]);
				np9states.setCableid2(attributes[180]);
				np9states.setTnt_attr(attributes[181]);
				np9states.setTnt(attributes[182]);
				np9states.setNpqty_attr(attributes[183]);
				np9states.setNpqty(attributes[184]);
				np9states.setTnp_attr(attributes[185]);
				np9states.setTnp(attributes[186]);
				np9states.setCftn_attr(attributes[187]);
				np9states.setCftn(attributes[188]);
				np9states.setRsqty_attr(attributes[189]);
				np9states.setRsqty(attributes[190]);
				np9states.setCnam_attr(attributes[191]);
				np9states.setCnam(attributes[192]);
				np9states.setIwtq2_attr(attributes[193]);
				np9states.setIwtq2(attributes[194]);
				np9states.setIwtq3_attr(attributes[195]);
				np9states.setIwtq3(attributes[196]);
				np9states.setIwtq4_attr(attributes[197]);
				np9states.setIwtq4(attributes[198]);
				np9states.setIwtq5_attr(attributes[199]);
				np9states.setIwtq5(attributes[200]);
				np9states.setIwt2_attr(attributes[201]);
				np9states.setIwt2(attributes[202]);
				np9states.setIwt3_attr(attributes[203]);
				np9states.setIwt3(attributes[204]);
				np9states.setIwt4_attr(attributes[205]);
				np9states.setIwt4(attributes[206]);
				np9states.setIwt5_attr(attributes[207]);
				np9states.setIwt5(attributes[208]);
				np9states.setScfa_attr(attributes[209]);
				np9states.setScfa(attributes[210]);
				np9states.setBtrl2_attr(attributes[211]);
				np9states.setBtrl2(attributes[212]);
				np9states.setBtrl3_attr(attributes[213]);
				np9states.setBtrl3(attributes[214]);
				np9states.setBtrl4_attr(attributes[215]);
				np9states.setBtrl4(attributes[216]);
				np9states.setBa1_attr(attributes[217]);
				np9states.setBa1(attributes[218]);
				np9states.setBlocking2_attr(attributes[219]);
				np9states.setBlocking2(attributes[220]);
				np9states.setLoc_sec_num(attributes[221]);

				treeViewList9_250.add(np9states);
			}
			selectRequestData.setSubHeader(receivedSubHeader);
			// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			// System.out.println("++++treeViewList_250+++before session+++" +
			// treeViewList9_250);
			session.setAttribute("treeViewList9_250", treeViewList9_250);
		}
		/* Notes-fup 9 state recid-530 */
		if (subData9_530Recid != null && subData9_530Recid.getSubHeader().getRecord_type().equals("530")) {

			List<NotesFup> treeViewList_530 = new ArrayList<>();
			SubHeader receivedSubHeader = subData9_530Recid.getSubHeader();
			String[] subDataRows = subData9_530Recid.getSubDataRows();
			treeViewList.add("530");
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 17);
				// System.out.println("attributes:=530:Reqid======> " +
				// Arrays.toString(attributes));
				NotesFup notesFup = new NotesFup();
				notesFup.setWorked_ind_attr(attributes[0]);
				notesFup.setWorked_ind(attributes[1]);
				notesFup.setCancel_ind_attr(attributes[2]);
				notesFup.setCancel_ind(attributes[3]);
				notesFup.setNotes_datetime(attributes[4]);
				notesFup.setUser_id_attr(attributes[5]);
				notesFup.setUser_id(attributes[6]);
				notesFup.setLasr_ver_attr(attributes[7]);
				notesFup.setLasr_ver(attributes[8]);
				notesFup.setFollow_up_date_attr(attributes[9]);
				notesFup.setFollow_up_date(attributes[10]);
				notesFup.setFup_worked_date_attr(attributes[11]);
				notesFup.setFup_worked_date(attributes[12]);
				notesFup.setFup_end_date_attr(attributes[13]);
				notesFup.setFup_end_date(attributes[14]);
				notesFup.setNotes_attr(attributes[15]);
				notesFup.setNotes(attributes[16]);

				treeViewList_530.add(notesFup);

			}
			session.setAttribute("treeViewList_530", treeViewList_530);
			selectRequestData.setSubHeader(receivedSubHeader);
		}
		// ***********************************Rajashekhar code
		// End***********************

		// ***********************************Sadasiva code Start***********************
		SubData subData_840Recid = subDatas.get(RecIdFor9State.CS_RECID_ISDN_RESALE.getRecIdValue());

		if (subData_840Recid != null && subData_840Recid.getSubHeader().getRecord_type().equals("840")) {
			SubHeader receivedSubHeader = subData_840Recid.getSubHeader();
			String[] subDataRows = subData_840Recid.getSubDataRows();
			List<ISDN_Resale_IRS_Channel_9State> treeViewList_840_9State = new ArrayList<ISDN_Resale_IRS_Channel_9State>();
			treeViewList.add("840");
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 218);
				// System.out.println("subData_840Recid attributes:=======> " +
				// Arrays.toString(attributes));
				ISDN_Resale_IRS_Channel_9State iric9s = new ISDN_Resale_IRS_Channel_9State();

				iric9s.setItem_num(attributes[0]);
				iric9s.setCnum_attr(attributes[1]);
				iric9s.setCnum(attributes[2]);
				iric9s.setFnum_attr(attributes[3]);
				iric9s.setFnum(attributes[4]);
				iric9s.setTnnum_attr(attributes[5]);
				iric9s.setTnnum(attributes[6]);
				iric9s.setTglnum_attr(attributes[7]);
				iric9s.setTglnum(attributes[8]);
				iric9s.setEcckt_attr(attributes[9]);
				iric9s.setEcckt(attributes[10]);
				iric9s.setCfa_attr(attributes[11]);
				iric9s.setCfa(attributes[12]);
				iric9s.setLtgn_attr(attributes[13]);
				iric9s.setLtgn(attributes[14]);
				iric9s.setIid_attr(attributes[15]);
				iric9s.setIid(attributes[16]);
				iric9s.setCord_attr(attributes[17]);
				iric9s.setCord(attributes[18]);
				iric9s.setIsdnp_attr(attributes[19]);
				iric9s.setIsdnp(attributes[20]);
				iric9s.setFlna_attr(attributes[21]);
				iric9s.setFlna(attributes[22]);
				iric9s.setCkttyp_attr(attributes[23]);
				iric9s.setCkttyp(attributes[24]);
				iric9s.setFecckt_attr(attributes[25]);
				iric9s.setFecckt(attributes[26]);
				iric9s.setPlst_attr(attributes[27]);
				iric9s.setPlst(attributes[28]);
				iric9s.setAuth_num_attr(attributes[29]);
				iric9s.setAuth_num(attributes[30]);
				iric9s.setPri_loc_attr(attributes[31]);
				iric9s.setPri_loc(attributes[32]);
				iric9s.setEulst_attr(attributes[33]);
				iric9s.setEulst(attributes[34]);
				iric9s.setCcea_attr(attributes[35]);
				iric9s.setCcea(attributes[36]);
				iric9s.setCfa_btn_attr(attributes[37]);
				iric9s.setCfa_btn(attributes[38]);
				iric9s.setCb_attr(attributes[39]);
				iric9s.setCb(attributes[40]);
				iric9s.setCbbtn_attr(attributes[41]);
				iric9s.setCbbtn(attributes[42]);
				iric9s.setNcon_attr(attributes[43]);
				iric9s.setNcon(attributes[44]);
				iric9s.setAft_attr(attributes[45]);
				iric9s.setAft(attributes[46]);
				iric9s.setSapr_attr(attributes[47]);
				iric9s.setSapr(attributes[48]);
				iric9s.setSano_attr(attributes[49]);
				iric9s.setSano(attributes[50]);
				iric9s.setSasf_attr(attributes[51]);
				iric9s.setSasf(attributes[52]);
				iric9s.setSasd_attr(attributes[53]);
				iric9s.setSasd(attributes[54]);
				iric9s.setSasn_attr(attributes[55]);
				iric9s.setSasn(attributes[56]);
				iric9s.setSath_attr(attributes[57]);
				iric9s.setSath(attributes[58]);
				iric9s.setSass_attr(attributes[59]);
				iric9s.setSass(attributes[60]);
				iric9s.setLd1_attr(attributes[61]);
				iric9s.setLd1(attributes[62]);
				iric9s.setLv1_attr(attributes[63]);
				iric9s.setLv1(attributes[64]);
				iric9s.setLd2_attr(attributes[65]);
				iric9s.setLd2(attributes[66]);
				iric9s.setLv2_attr(attributes[67]);
				iric9s.setLv2(attributes[68]);
				iric9s.setLd3_attr(attributes[69]);
				iric9s.setLd3(attributes[70]);
				iric9s.setLv3_attr(attributes[71]);
				iric9s.setLv3(attributes[72]);
				iric9s.setAai_attr(attributes[73]);
				iric9s.setAai(attributes[74]);
				iric9s.setCity_attr(attributes[75]);
				iric9s.setCity(attributes[76]);
				iric9s.setState_attr(attributes[77]);
				iric9s.setState(attributes[78]);
				iric9s.setZip_attr(attributes[79]);
				iric9s.setZip(attributes[80]);
				iric9s.setNidr_attr(attributes[81]);
				iric9s.setNidr(attributes[82]);
				iric9s.setIwo_attr(attributes[83]);
				iric9s.setIwo(attributes[84]);
				iric9s.setAloc_attr(attributes[85]);
				iric9s.setAloc(attributes[86]);
				iric9s.setLcon_attr(attributes[87]);
				iric9s.setLcon(attributes[88]);
				iric9s.setTelno_attr(attributes[89]);
				iric9s.setTelno(attributes[90]);
				iric9s.setPtnract_attr(attributes[91]);
				iric9s.setPtnract(attributes[92]);
				iric9s.setPtnrq_attr(attributes[93]);
				iric9s.setPtnrq(attributes[94]);
				iric9s.setPtnr1_attr(attributes[95]);
				iric9s.setPtnr1(attributes[96]);
				iric9s.setPtnr2_attr(attributes[97]);
				iric9s.setPtnr2(attributes[98]);
				iric9s.setPtnr3_attr(attributes[99]);
				iric9s.setPtnr3(attributes[100]);
				iric9s.setNpi_attr(attributes[101]);
				iric9s.setNpi(attributes[102]);
				iric9s.setDidr_attr(attributes[103]);
				iric9s.setDidr(attributes[104]);
				iric9s.setTgtli_attr(attributes[105]);
				iric9s.setTgtli(attributes[106]);
				iric9s.setDba_attr(attributes[107]);
				iric9s.setDba(attributes[108]);
				iric9s.setDba2_attr(attributes[109]);
				iric9s.setDba2(attributes[110]);
				iric9s.setDblock_attr(attributes[111]);
				iric9s.setDblock(attributes[112]);
				iric9s.setDblock2_attr(attributes[113]);
				iric9s.setDblock2(attributes[114]);
				iric9s.setNba_attr(attributes[115]);
				iric9s.setNba(attributes[116]);
				iric9s.setNbank1_attr(attributes[117]);
				iric9s.setNbank1(attributes[118]);
				iric9s.setNbank2_attr(attributes[119]);
				iric9s.setNbank2(attributes[120]);
				iric9s.setNbank3_attr(attributes[121]);
				iric9s.setNbank3(attributes[122]);
				iric9s.setNbank4_attr(attributes[123]);
				iric9s.setNbank4(attributes[124]);
				iric9s.setDstnact_attr(attributes[125]);
				iric9s.setDstnact(attributes[126]);
				iric9s.setDstnq_attr(attributes[127]);
				iric9s.setDstnq(attributes[128]);
				iric9s.setDstn1_attr(attributes[129]);
				iric9s.setDstn1(attributes[130]);
				iric9s.setDstn2_attr(attributes[131]);
				iric9s.setDstn2(attributes[132]);
				iric9s.setDstn3_attr(attributes[133]);
				iric9s.setDstn3(attributes[134]);
				iric9s.setDstn4_attr(attributes[135]);
				iric9s.setDstn4(attributes[136]);
				iric9s.setDstn5_attr(attributes[137]);
				iric9s.setDstn5(attributes[138]);
				iric9s.setTglna_attr(attributes[139]);
				iric9s.setTglna(attributes[140]);
				iric9s.setTgn_attr(attributes[141]);
				iric9s.setTgn(attributes[142]);
				iric9s.setPtgn_of_attr(attributes[143]);
				iric9s.setPtgn_of(attributes[144]);
				iric9s.setTgtli2_attr(attributes[145]);
				iric9s.setTgtli2(attributes[146]);
				iric9s.setTgrti_attr(attributes[147]);
				iric9s.setTgrti(attributes[148]);
				iric9s.setTgdir_attr(attributes[149]);
				iric9s.setTgdir(attributes[150]);
				iric9s.setPtgnh_attr(attributes[151]);
				iric9s.setPtgnh(attributes[152]);
				iric9s.setDgout_attr(attributes[153]);
				iric9s.setDgout(attributes[154]);
				iric9s.setDg_rcvd_attr(attributes[155]);
				iric9s.setDg_rcvd(attributes[156]);
				iric9s.setPdod_attr(attributes[157]);
				iric9s.setPdod(attributes[158]);
				iric9s.setPic_attr(attributes[159]);
				iric9s.setPic(attributes[160]);
				iric9s.setLpic_attr(attributes[161]);
				iric9s.setLpic(attributes[162]);
				iric9s.setGlare_attr(attributes[163]);
				iric9s.setGlare(attributes[164]);
				iric9s.setPbxid_attr(attributes[165]);
				iric9s.setPbxid(attributes[166]);
				iric9s.setCid_attr(attributes[167]);
				iric9s.setCid(attributes[168]);
				iric9s.setTot_attr(attributes[169]);
				iric9s.setTot(attributes[170]);
				iric9s.setGsind1_attr(attributes[171]);
				iric9s.setGsind1(attributes[172]);
				iric9s.setGsind2_attr(attributes[173]);
				iric9s.setGsind2(attributes[174]);
				iric9s.setGsind3_attr(attributes[175]);
				iric9s.setGsind3(attributes[176]);
				iric9s.setGsind4_attr(attributes[177]);
				iric9s.setGsind4(attributes[178]);
				iric9s.setGsind5_attr(attributes[179]);
				iric9s.setGsind5(attributes[180]);
				iric9s.setGsqty1_attr(attributes[181]);
				iric9s.setGsqty1(attributes[182]);
				iric9s.setGsqty2_attr(attributes[183]);
				iric9s.setGsqty2(attributes[184]);
				iric9s.setGsqty3_attr(attributes[185]);
				iric9s.setGsqty3(attributes[186]);
				iric9s.setGsqty4_attr(attributes[187]);
				iric9s.setGsqty4(attributes[188]);
				iric9s.setGsqty5_attr(attributes[189]);
				iric9s.setGsqty5(attributes[190]);
				iric9s.setGind1_attr(attributes[191]);
				iric9s.setGind1(attributes[192]);
				iric9s.setGind2_attr(attributes[193]);
				iric9s.setGind2(attributes[194]);
				iric9s.setGind3_attr(attributes[195]);
				iric9s.setGind3(attributes[196]);
				iric9s.setGind4_attr(attributes[197]);
				iric9s.setGind4(attributes[198]);
				iric9s.setGqty1_attr(attributes[199]);
				iric9s.setGqty1(attributes[200]);
				iric9s.setGqty2_attr(attributes[201]);
				iric9s.setGqty2(attributes[202]);
				iric9s.setGqty3_attr(attributes[203]);
				iric9s.setGqty3(attributes[204]);
				iric9s.setGqty4_attr(attributes[205]);
				iric9s.setGqty4(attributes[206]);
				iric9s.setSecloc_attr(attributes[207]);
				iric9s.setSecloc(attributes[208]);
				iric9s.setSec_cb_attr(attributes[209]);
				iric9s.setSec_cb(attributes[210]);
				iric9s.setSec_cbbtn_attr(attributes[211]);
				iric9s.setSec_cbbtn(attributes[212]);
				iric9s.setActl_attr(attributes[213]);
				iric9s.setActl(attributes[214]);
				iric9s.setCfa_ckt_attr(attributes[215]);
				iric9s.setCfa_ckt(attributes[216]);
				iric9s.setLoc_seq_num(attributes[217]);

				treeViewList_840_9State.add(iric9s);

			}
			selectRequestData.setSubHeader(receivedSubHeader);
			session.setAttribute("treeViewList_840_9State", treeViewList_840_9State);
			// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
		}
		// ***********************************Sadasiva code End***********************

		// ***********************************Amit Pathak code
		// start***********************
		SubData subData_420Recid = subDatas.get(RecIdFor12State.CS_RECID_DELIVERY_ADDRESS.getRecIdValue());
		SubData subData_430Recid = subDatas.get(RecIdFor12State.CS_RECID_LISTING.getRecIdValue());
		SubData subData_435Recid = subDatas.get(RecIdFor12State.CS_RECID_LISTING_TEXT.getRecIdValue());
		SubData subData_436Recid = subDatas.get(RecIdFor12State.CS_RECID_LISTING_TEXT_DTL.getRecIdValue());
		SubData subData_440Recid = subDatas.get(RecIdFor12State.CS_RECID_CAPTION.getRecIdValue());

		if (subData_420Recid != null && subData_420Recid.getSubHeader().getRecord_type().equals("420")) {

			SubHeader receivedSubHeader = subData_420Recid.getSubHeader();
			String[] subDataRows = subData_420Recid.getSubDataRows();
			List<DirectoryDeliveryAddress9> treeViewList_420 = new ArrayList();
			treeViewList.add("420");

			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 58);
				// System.out.println("attributes:=420:Reqid======> " +
				// Arrays.toString(attributes));
				DirectoryDeliveryAddress9 directoryDeliveryAddress9State = new DirectoryDeliveryAddress9();

				directoryDeliveryAddress9State.setDact_attr(attributes[0]);
				directoryDeliveryAddress9State.setDact(attributes[1]);
				directoryDeliveryAddress9State.setDdapr_attr(attributes[2]);
				directoryDeliveryAddress9State.setDdapr(attributes[3]);
				directoryDeliveryAddress9State.setDdano_attr(attributes[4]);
				directoryDeliveryAddress9State.setDdano(attributes[5]);
				directoryDeliveryAddress9State.setDdasf_attr(attributes[6]);
				directoryDeliveryAddress9State.setDdasf(attributes[7]);
				directoryDeliveryAddress9State.setDdasd_attr(attributes[8]);
				directoryDeliveryAddress9State.setDdasd(attributes[9]);
				directoryDeliveryAddress9State.setDdasn_attr(attributes[10]);
				directoryDeliveryAddress9State.setDdasn(attributes[11]);
				directoryDeliveryAddress9State.setDdath_attr(attributes[12]);
				directoryDeliveryAddress9State.setDdath(attributes[13]);
				directoryDeliveryAddress9State.setDdass_attr(attributes[14]);
				directoryDeliveryAddress9State.setDdass(attributes[15]);
				directoryDeliveryAddress9State.setDel_ld1_attr(attributes[16]);
				directoryDeliveryAddress9State.setLd1(attributes[17]);
				directoryDeliveryAddress9State.setDel_lv1_attr(attributes[18]);
				directoryDeliveryAddress9State.setLv1(attributes[19]);
				directoryDeliveryAddress9State.setDel_ld2_attr(attributes[20]);
				directoryDeliveryAddress9State.setLd2(attributes[21]);
				directoryDeliveryAddress9State.setDel_lv2_attr(attributes[22]);
				directoryDeliveryAddress9State.setLv2(attributes[23]);
				directoryDeliveryAddress9State.setDel_ld3_attr(attributes[24]);
				directoryDeliveryAddress9State.setLd3(attributes[25]);
				directoryDeliveryAddress9State.setDel_lv3_attr(attributes[26]);
				directoryDeliveryAddress9State.setLv3(attributes[27]);
				directoryDeliveryAddress9State.setDel_aai_attr(attributes[28]);
				directoryDeliveryAddress9State.setAai(attributes[29]);
				directoryDeliveryAddress9State.setDel_city_attr(attributes[30]);
				directoryDeliveryAddress9State.setCity(attributes[31]);
				directoryDeliveryAddress9State.setDel_state_attr(attributes[32]);
				directoryDeliveryAddress9State.setState(attributes[33]);
				directoryDeliveryAddress9State.setDel_zip_attr(attributes[34]);
				directoryDeliveryAddress9State.setZip(attributes[35]);
				directoryDeliveryAddress9State.setDirqty_attr(attributes[36]);
				directoryDeliveryAddress9State.setDirqty(attributes[37]);
				directoryDeliveryAddress9State.setDirtyp1_attr(attributes[38]);
				directoryDeliveryAddress9State.setDirtyp1(attributes[39]);
				directoryDeliveryAddress9State.setDirtyp2_attr(attributes[40]);
				directoryDeliveryAddress9State.setDirtyp2(attributes[41]);
				directoryDeliveryAddress9State.setDirtyp3_attr(attributes[42]);
				directoryDeliveryAddress9State.setDirtyp3(attributes[43]);
				directoryDeliveryAddress9State.setDirqtya1_attr(attributes[44]);
				directoryDeliveryAddress9State.setDirqtya1(attributes[45]);
				directoryDeliveryAddress9State.setDirqtya2_attr(attributes[46]);
				directoryDeliveryAddress9State.setDirqtya2(attributes[47]);
				directoryDeliveryAddress9State.setDirqtya3_attr(attributes[48]);
				directoryDeliveryAddress9State.setDirqtya3(attributes[49]);
				directoryDeliveryAddress9State.setDirqtync1_attr(attributes[50]);
				directoryDeliveryAddress9State.setDirqtync1(attributes[51]);
				directoryDeliveryAddress9State.setDirqtync2_attr(attributes[52]);
				directoryDeliveryAddress9State.setDirqtync2(attributes[53]);
				directoryDeliveryAddress9State.setDirqtync3_attr(attributes[54]);
				directoryDeliveryAddress9State.setDirqtync3(attributes[55]);
				directoryDeliveryAddress9State.setName_attr(attributes[56]);
				directoryDeliveryAddress9State.setName(attributes[57]);

				treeViewList_420.add(directoryDeliveryAddress9State);
			}
			selectRequestData.setSubHeader(receivedSubHeader);
			session.setAttribute("treeViewList_420", treeViewList_420);
			// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
		}

		if (subData_430Recid != null && subData_430Recid.getSubHeader().getRecord_type().equals("430")) {

			SubHeader receivedSubHeader = subData_430Recid.getSubHeader();
			String[] subDataRows = subData_430Recid.getSubDataRows();
			List<DirectoryListing9> treeViewList_430 = new ArrayList();
			treeViewList.add("430");
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 122);
				// System.out.println("attributes:=430======> " + Arrays.toString(attributes));
				DirectoryListing9 directoryListing9states = new DirectoryListing9();

				directoryListing9states.setItemnum(attributes[0]);
				directoryListing9states.setDlnum_attr(attributes[1]);
				directoryListing9states.setDlnum(attributes[2]);
				directoryListing9states.setLact_attr(attributes[3]);
				directoryListing9states.setLact(attributes[4]);
				directoryListing9states.setAli_attr(attributes[5]);
				directoryListing9states.setAli(attributes[6]);
				directoryListing9states.setRty_attr(attributes[7]);
				directoryListing9states.setRty(attributes[8]);
				directoryListing9states.setLty_attr(attributes[9]);
				directoryListing9states.setLty(attributes[10]);
				directoryListing9states.setStyc_attr(attributes[11]);
				directoryListing9states.setStyc(attributes[12]);
				directoryListing9states.setToa_attr(attributes[13]);
				directoryListing9states.setToa(attributes[14]);
				directoryListing9states.setDoi_attr(attributes[15]);
				directoryListing9states.setDoi(attributes[16]);
				directoryListing9states.setWpp_attr(attributes[17]);
				directoryListing9states.setWpp(attributes[18]);
				directoryListing9states.setDml_attr(attributes[19]);
				directoryListing9states.setDml(attributes[20]);
				directoryListing9states.setBro_attr(attributes[21]);
				directoryListing9states.setBro(attributes[22]);
				directoryListing9states.setAdv_attr(attributes[23]);
				directoryListing9states.setAdv(attributes[24]);
				directoryListing9states.setStr_attr(attributes[25]);
				directoryListing9states.setStr(attributes[26]);
				directoryListing9states.setDlnm_attr(attributes[27]);
				directoryListing9states.setDlnm(attributes[28]);
				directoryListing9states.setDiridl_attr(attributes[29]);
				directoryListing9states.setDiridl(attributes[30]);
				directoryListing9states.setProf_attr(attributes[31]);
				directoryListing9states.setProf(attributes[32]);
				directoryListing9states.setDirsub_attr(attributes[33]);
				directoryListing9states.setDirsub(attributes[34]);
				directoryListing9states.setOmsd_attr(attributes[35]);
				directoryListing9states.setOmsd(attributes[36]);
				directoryListing9states.setLtn_attr(attributes[37]);
				directoryListing9states.setLtn(attributes[38]);
				directoryListing9states.setNstn_attr(attributes[39]);
				directoryListing9states.setNstn(attributes[40]);
				directoryListing9states.setOmtn_attr(attributes[41]);
				directoryListing9states.setOmtn(attributes[42]);
				directoryListing9states.setLex_attr(attributes[43]);
				directoryListing9states.setLex(attributes[44]);
				directoryListing9states.setDna_attr(attributes[45]);
				directoryListing9states.setDna(attributes[46]);
				directoryListing9states.setLnpl_attr(attributes[47]);
				directoryListing9states.setLnpl(attributes[48]);
				directoryListing9states.setLnln_attr(attributes[49]);
				directoryListing9states.setLnln(attributes[50]);
				directoryListing9states.setLnfn_attr(attributes[51]);
				directoryListing9states.setLnfn(attributes[52]);
				directoryListing9states.setDes_attr(attributes[53]);
				directoryListing9states.setDes(attributes[54]);
				directoryListing9states.setTl_attr(attributes[55]);
				directoryListing9states.setTl(attributes[56]);
				directoryListing9states.setTitle1_attr(attributes[57]);
				directoryListing9states.setTitle1(attributes[58]);
				directoryListing9states.setTitle2_attr(attributes[59]);
				directoryListing9states.setTitle2(attributes[60]);
				directoryListing9states.setTld_attr(attributes[61]);
				directoryListing9states.setTld(attributes[62]);
				directoryListing9states.setTitle1d_attr(attributes[63]);
				directoryListing9states.setTitle1d(attributes[64]);
				directoryListing9states.setTitle2d_attr(attributes[65]);
				directoryListing9states.setTitle2d(attributes[66]);
				directoryListing9states.setNick_attr(attributes[67]);
				directoryListing9states.setNick(attributes[68]);
				directoryListing9states.setPla_attr(attributes[69]);
				directoryListing9states.setPla(attributes[70]);
				directoryListing9states.setLphrase_attr(attributes[71]);
				directoryListing9states.setLphrase(attributes[72]);
				directoryListing9states.setAdi_attr(attributes[73]);
				directoryListing9states.setAdi(attributes[74]);
				directoryListing9states.setDno_attr(attributes[75]);
				directoryListing9states.setDno(attributes[76]);
				directoryListing9states.setLapr_attr(attributes[77]);
				directoryListing9states.setLapr(attributes[78]);
				directoryListing9states.setLano_attr(attributes[79]);
				directoryListing9states.setLano(attributes[80]);
				directoryListing9states.setLasf_attr(attributes[81]);
				directoryListing9states.setLasf(attributes[82]);
				directoryListing9states.setLasd_attr(attributes[83]);
				directoryListing9states.setLasd(attributes[84]);
				directoryListing9states.setLasn_attr(attributes[85]);
				directoryListing9states.setLasn(attributes[86]);
				directoryListing9states.setLath_attr(attributes[87]);
				directoryListing9states.setLath(attributes[88]);
				directoryListing9states.setLass_attr(attributes[89]);
				directoryListing9states.setLass(attributes[90]);
				directoryListing9states.setLalo_attr(attributes[91]);
				directoryListing9states.setLalo(attributes[92]);
				directoryListing9states.setLaloc_attr(attributes[93]);
				directoryListing9states.setLaloc(attributes[94]);
				directoryListing9states.setLast_attr(attributes[95]);
				directoryListing9states.setLast(attributes[96]);
				directoryListing9states.setLazc_attr(attributes[97]);
				directoryListing9states.setLazc(attributes[98]);
				directoryListing9states.setSic_attr(attributes[99]);
				directoryListing9states.setSic(attributes[100]);
				directoryListing9states.setYph_attr(attributes[101]);
				directoryListing9states.setYph(attributes[102]);
				directoryListing9states.setEos_attr(attributes[103]);
				directoryListing9states.setEos(attributes[104]);
				directoryListing9states.setDirname_attr(attributes[105]);
				directoryListing9states.setDirname(attributes[106]);
				directoryListing9states.setShtn_attr(attributes[107]);
				directoryListing9states.setShtn(attributes[108]);
				directoryListing9states.setHs_attr(attributes[109]);
				directoryListing9states.setHs(attributes[110]);
				directoryListing9states.setSo_attr(attributes[111]);
				directoryListing9states.setSo(attributes[112]);
				directoryListing9states.setFainfo_attr(attributes[113]);
				directoryListing9states.setFainfo(attributes[114]);
				directoryListing9states.setFatn_attr(attributes[115]);
				directoryListing9states.setFatn(attributes[116]);
				directoryListing9states.setLocnum_attr(attributes[117]);
				directoryListing9states.setLocnum(attributes[118]);
				directoryListing9states.setDl_yph_attr(attributes[119]);
				directoryListing9states.setDl_yph(attributes[120]);
				directoryListing9states.setLoc_seq_num(attributes[121]);

				treeViewList_430.add(directoryListing9states);
			}
			selectRequestData.setSubHeader(receivedSubHeader);
			session.setAttribute("treeViewList_430", treeViewList_430);
			// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
		}
		if (subData_435Recid != null && subData_435Recid.getSubHeader().getRecord_type().equals("435")) {

			SubHeader receivedSubHeader = subData_435Recid.getSubHeader();
			String[] subDataRows = subData_435Recid.getSubDataRows();
			List<DirectoryListingText9> treeViewList_435 = new ArrayList();
			treeViewList.add("435");
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 4);
				// System.out.println("attributes:==435=====> " + Arrays.toString(attributes));
				DirectoryListingText9 directoryListingText9States = new DirectoryListingText9();

				directoryListingText9States.setItemnum(attributes[0]);
				directoryListingText9States.setDlnum_attr(attributes[1]);
				directoryListingText9States.setDlnum(attributes[2]);
				directoryListingText9States.setLoc_seq_num(attributes[3]);

				treeViewList_435.add(directoryListingText9States);
			}
			selectRequestData.setSubHeader(receivedSubHeader);
			session.setAttribute("treeViewList_435", treeViewList_435);
			// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
		}
		if (subData_436Recid != null && subData_436Recid.getSubHeader().getRecord_type().equals("436")) {

			SubHeader receivedSubHeader = subData_436Recid.getSubHeader();
			String[] subDataRows = subData_436Recid.getSubDataRows();
			List<TxtListDetail9> treeViewList_436 = new ArrayList();
			treeViewList.add("436");
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 10);
				// System.out.println("attributes:==436=====> " + Arrays.toString(attributes));
				TxtListDetail9 txtListDetail = new TxtListDetail9();

				txtListDetail.setItem_num(attributes[0]);
				txtListDetail.setLtxty_attr(attributes[1]);
				txtListDetail.setLtxty(attributes[2]);
				txtListDetail.setLtext_attr(attributes[3]);
				txtListDetail.setLtext(attributes[4]);
				txtListDetail.setLtxnum_attr(attributes[5]);
				txtListDetail.setLtxnum(attributes[6]);
				txtListDetail.setLphrase_attr(attributes[7]);
				txtListDetail.setLphrase(attributes[8]);
				txtListDetail.setLoc_seq_num(attributes[9]);

				treeViewList_436.add(txtListDetail);
			}
			selectRequestData.setSubHeader(receivedSubHeader);
			session.setAttribute("treeViewList_436", treeViewList_436);
			// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
		}
		if (subData_440Recid != null && subData_440Recid.getSubHeader().getRecord_type().equals("440")) {

			SubHeader receivedSubHeader = subData_440Recid.getSubHeader();
			String[] subDataRows = subData_440Recid.getSubDataRows();
			List<DirectoryCaption9> treeViewList_440 = new ArrayList();
			treeViewList.add("440");
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 17);
				// System.out.println("attributes:==440=====> " + Arrays.toString(attributes));
				DirectoryCaption9 directoryCaption9States = new DirectoryCaption9();

				directoryCaption9States.setItemnum(attributes[0]);
				directoryCaption9States.setDlnum_attr(attributes[1]);
				directoryCaption9States.setDlnum(attributes[2]);
				directoryCaption9States.setLvl_attr(attributes[3]);
				directoryCaption9States.setLvl(attributes[4]);
				directoryCaption9States.setPls_attr(attributes[5]);
				directoryCaption9States.setPls(attributes[6]);
				directoryCaption9States.setPlinfo_attr(attributes[7]);
				directoryCaption9States.setPlinfo(attributes[8]);
				directoryCaption9States.setPltn_attr(attributes[9]);
				directoryCaption9States.setPltn(attributes[10]);
				directoryCaption9States.setSo_attr(attributes[11]);
				directoryCaption9States.setSo(attributes[12]);
				directoryCaption9States.setFainfo_attr(attributes[13]);
				directoryCaption9States.setFainfo(attributes[14]);
				directoryCaption9States.setFatn_attr(attributes[15]);
				directoryCaption9States.setFatn(attributes[16]);

				treeViewList_440.add(directoryCaption9States);
			}
			selectRequestData.setSubHeader(receivedSubHeader);
			session.setAttribute("treeViewList_440", treeViewList_440);
			// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
		}

		// ***********************************Amit Pathak code
		// End***********************

		return treeViewList;
	}

	private List confirmationTaskGeneral(SelectRequestData selectRequestData, Map<String, SubData> subDatas,
			HttpSession session, List treeViewList) {
		SubData subData_558Recid = subDatas.get(RecIdFor9State.CS_RECID_CONFIRM_REQORD.getRecIdValue());
		SubData subData_552Recid = subDatas.get(RecIdFor9State.CS_RECID_CONFIRM_REFNUM.getRecIdValue());
		SubData subData9_550Recid = subDatas.get(RecIdFor9State.CS_RECID_CONFIRM.getRecIdValue());
		SubData subData9_551Recid = subDatas.get(RecIdFor9State.CS_RECID_CONFIRM_HNUM.getRecIdValue());
		SubData subData_531Recid = subDatas.get(RecIdFor12State.CS_RECID_NOTES_INPUT.getRecIdValue());
		SubData subData_549Recid = subDatas.get(RecIdFor12State.CS_RECID_PREISSUE.getRecIdValue());
		SubData subData_540Recid = subDatas.get(RecIdFor12State.CS_RECID_ISSUE_RESEND.getRecIdValue());
		SubData subData_547Recid =  subDatas.get("547");
		SubData subData_544Recid =  subDatas.get("544");
		SubData subData_546Recid =  subDatas.get("546");
		if (subData_546Recid != null && subData_546Recid.getSubHeader().getRecord_type().equals("546")) {
			// List<FollowUpData9States> treeViewList_549 = new ArrayList();
			SubHeader receivedSubHeader = subData_546Recid.getSubHeader();
			String[] subDataRows = subData_546Recid.getSubDataRows();
//			System.out.println("sub data for 546" + Arrays.toString(subDataRows));
			treeViewList.add("546");

		}
		////////*****************************540***********************/////
		if (subData_540Recid != null && subData_540Recid.getSubHeader().getRecord_type().equals("540")) {
			//List<FollowUpData9States> treeViewList_549 = new ArrayList();
			SubHeader receivedSubHeader = subData_540Recid.getSubHeader();
			String[] subDataRows = subData_540Recid.getSubDataRows();
//			System.out.println("sub data for 540" + Arrays.toString(subDataRows));
			treeViewList.add("540");
			
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 9);
			
				session.setAttribute("recid_40Data", attributes);
//				System.out.println("forr 540" + Arrays.toString(attributes));
			
		}
		
		}
		
		
		/////////////////////////////////549//////////////////////////
		if (subData_549Recid != null && subData_549Recid.getSubHeader().getRecord_type().equals("549")) {
			//List<FollowUpData9States> treeViewList_549 = new ArrayList();
			SubHeader receivedSubHeader = subData_549Recid.getSubHeader();
			String[] subDataRows = subData_549Recid.getSubDataRows();
//			System.out.println("sub data for 549" + Arrays.toString(subDataRows));
			treeViewList.add("549");
			
			
			
			
		}
		
		/////////////////////////////////547///////////////////////////
		if (subData_547Recid != null && subData_547Recid.getSubHeader().getRecord_type().equals("547")) {
			//List<FollowUpData9States> treeViewList_549 = new ArrayList();
			SubHeader receivedSubHeader = subData_547Recid.getSubHeader();
			String[] subDataRows = subData_547Recid.getSubDataRows();
//			System.out.println("sub data for 547" + Arrays.toString(subDataRows));
			treeViewList.add("547");
			
			
			
			
		}
		
		/////////////////////////////544/////////////////////////////
		if (subData_544Recid != null && subData_544Recid.getSubHeader().getRecord_type().equals("544")) {
			//List<FollowUpData9States> treeViewList_549 = new ArrayList();
			SubHeader receivedSubHeader = subData_544Recid.getSubHeader();
			String[] subDataRows = subData_544Recid.getSubDataRows();
//			System.out.println("sub data for 544" + Arrays.toString(subDataRows));
			treeViewList.add("544");
			
			
			
			
		}
		
		if (subData_531Recid != null && subData_531Recid.getSubHeader().getRecord_type().equals("531")) {
			List<FollowUpData9States> treeViewList_531 = new ArrayList();
			SubHeader receivedSubHeader = subData_531Recid.getSubHeader();
			String[] subDataRows = subData_531Recid.getSubDataRows();
//			System.out.println("sub data for 531" + Arrays.toString(subDataRows));
			treeViewList.add("531");
			if(!treeViewList.contains("532")){
				session.removeAttribute("treeViewList_532");
				System.out.println("***************removing session**********");
			}
			// int i = 0;
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 9);
//				System.out.println("attributes:=531:Reqid======> " + Arrays.toString(attributes));
				FollowUpData9States followUp = new FollowUpData9States();
				followUp.setNotes_datetime(attributes[0]);
				followUp.setUser_id_attr(attributes[1]);
				followUp.setUser_id(attributes[2]);
				followUp.setLasr_ver_attr(attributes[3]);
				followUp.setLasr_ver(attributes[4]);
				followUp.setFollow_up_date_attr(attributes[5]);
				followUp.setFollow_up_date(attributes[6]);
				followUp.setNotes_attr(attributes[7]);
				followUp.setNotes(attributes[8]);
				treeViewList_531.add(followUp);
			}
			selectRequestData.setSubHeader(receivedSubHeader);
			// System.out.println("++++treeViewList+++before session+++"+treeViewList_543);
			session.setAttribute("treeViewList_531", treeViewList_531);
			// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
		}

		if (subData9_551Recid != null && subData9_551Recid.getSubHeader().getRecord_type().equals("551")) {
			SubHeader receivedSubHeader = subData9_551Recid.getSubHeader();
			String[] subDataRows = subData9_551Recid.getSubDataRows();
			List<ConfirmationTask_RecId_551> treeViewList_551 = new ArrayList();
			treeViewList.add("551");
			String lsrNo = "";
			String status = "";
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);
//				System.out.println("attributes:=551======> " + Arrays.toString(attributes));
				ConfirmationTask_RecId_551 noteFupData = new ConfirmationTask_RecId_551();
				noteFupData.setItem_num(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
				noteFupData.setHnum(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
				noteFupData.setHid_attr(attributes[2] != null && attributes[2] != "" ? attributes[2] : " "); // Not
																												// getting
																												// data...!
				noteFupData.setHid(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
				noteFupData.setHunt_tli_attr(attributes[4] != null && attributes[4] != "" ? attributes[4] : " ");
				noteFupData.setHunt_tli(attributes[5] != null && attributes[5] != "" ? attributes[5] : " ");

				treeViewList_551.add(noteFupData);
			}
			selectRequestData.setSubHeader(receivedSubHeader);
			session.setAttribute("treeViewList_551", treeViewList_551);

		}
		if (subData_558Recid != null && subData_558Recid.getSubHeader().getRecord_type().equals("558")) {
			SubHeader receivedSubHeader = subData_558Recid.getSubHeader();
			String[] subDataRows = subData_558Recid.getSubDataRows();
			List<ConfirmationTask_RecId_558> treeViewList_558 = new ArrayList();
			treeViewList.add("558");
			String lsrNo = "";
			String status = "";
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);
//				System.out.println("attributes:=558======> " + Arrays.toString(attributes));
				ConfirmationTask_RecId_558 noteFupData = new ConfirmationTask_RecId_558();
				noteFupData.setOld_dtm(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
				noteFupData.setOld_ord(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
				noteFupData.setOrd_attr(attributes[2] != null && attributes[2] != "" ? attributes[2] : " "); // Not
																												// getting
																												// data...!
				noteFupData.setOrd(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
				noteFupData.setFdt_attr(attributes[4] != null && attributes[4] != "" ? attributes[4] : " ");
				noteFupData.setFdt(attributes[5] != null && attributes[5] != "" ? attributes[5] : " ");
				noteFupData.setDd_attr(attributes[6] != null && attributes[6] != "" ? attributes[6] : " ");
				//noteFupData.setDd(FormatUtil.getMqStringToDate(attributes[7] != null && attributes[7] != "" ? attributes[7] : " "));
				noteFupData.setDd(attributes[7] != null && attributes[7] != "" ? attributes[7] : " ");
				noteFupData.setComt_dt_attr(attributes[8] != null && attributes[8] != "" ? attributes[8] : " ");
				noteFupData.setComt_dt(attributes[9] != null && attributes[9] != "" ? attributes[9] : " ");
				noteFupData.setPosted_date_attr(attributes[10] != null && attributes[10] != "" ? attributes[10] : " ");
				noteFupData.setPosted_date(attributes[11] != null && attributes[11] != "" ? attributes[11] : " ");
				noteFupData.setApptime_attr(attributes[12] != null && attributes[12] != "" ? attributes[12] : " ");
				noteFupData.setApptime(attributes[13] != null && attributes[13] != "" ? attributes[13] : " ");

				treeViewList_558.add(noteFupData);
			}
			selectRequestData.setSubHeader(receivedSubHeader);
			session.setAttribute("treeViewList_558", treeViewList_558);
			// model.addAttribute("treeViewList_558", treeViewList_558);
			System.out.println("Model get Attribute  ");
		}

		if (subData_552Recid != null && subData_552Recid.getSubHeader().getRecord_type().equals("552")) {
			SubHeader receivedSubHeader = subData_552Recid.getSubHeader();
			String[] subDataRows = subData_552Recid.getSubDataRows();
			List<ConfirmationTask_RecId_552> treeViewList_552 = new ArrayList();
			treeViewList.add("552");
			String lsrNo = "";
			String status = "";
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 43);
//				System.out.println("attributes:=552======> " + Arrays.toString(attributes));
				ConfirmationTask_RecId_552 noteFupData = new ConfirmationTask_RecId_552();
				noteFupData.setItemnum(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
				noteFupData.setLnum(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
				noteFupData.setNumname(attributes[2] != null && attributes[2] != "" ? attributes[2] : " "); // Not
																											// getting
																											// data...!
				noteFupData.setNum_nbr(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
				noteFupData.setOrd_attr(attributes[4] != null && attributes[4] != "" ? attributes[4] : " ");
				noteFupData.setOrd(attributes[5] != null && attributes[5] != "" ? attributes[5] : " ");
				noteFupData.setLord_attr(attributes[6] != null && attributes[6] != "" ? attributes[6] : " ");
				noteFupData.setLord(attributes[7] != null && attributes[7] != "" ? attributes[7] : " ");

				noteFupData.setFdt_attr(attributes[8] != null && attributes[8] != "" ? attributes[8] : " ");
				noteFupData.setFdt(attributes[9] != null && attributes[9] != "" ? attributes[9] : " ");
				noteFupData.setDd_attr(attributes[10] != null && attributes[10] != "" ? attributes[10] : " ");
				noteFupData.setDd(FormatUtil.getMqStringToDate(attributes[11] != null && attributes[11] != "" ? attributes[11] : " "));// susheel
				noteFupData.setEcckt_attr(attributes[12] != null && attributes[12] != "" ? attributes[12] : " ");
				noteFupData.setEcckt(attributes[13] != null && attributes[13] != "" ? attributes[13] : " ");
				noteFupData.setCkr(attributes[14] != null && attributes[14] != "" ? attributes[14] : " ");
				noteFupData.setShared_nbr(attributes[15] != null && attributes[15] != "" ? attributes[15] : " ");
				noteFupData.setDisc_nbr(attributes[16] != null && attributes[16] != "" ? attributes[16] : " "); // Not
																												// getting
																												// data...!
				noteFupData.setRecckt(attributes[17] != null && attributes[17] != "" ? attributes[17] : " ");
				noteFupData.setTns_attr(attributes[18] != null && attributes[18] != "" ? attributes[18] : " ");
				noteFupData.setTns(attributes[19] != null && attributes[19] != "" ? attributes[19] : " ");
				noteFupData.setTers_attr(attributes[20] != null && attributes[20] != "" ? attributes[20] : " ");
				noteFupData.setTers(attributes[21] != null && attributes[21] != "" ? attributes[21] : " ");
				noteFupData.setCfa(attributes[22] != null && attributes[22] != "" ? attributes[22] : " ");
				noteFupData.setCcea(attributes[23] != null && attributes[23] != "" ? attributes[23] : " ");
				noteFupData.setIspid_attr(attributes[24] != null && attributes[24] != "" ? attributes[24] : " ");
				noteFupData.setIspid(attributes[25] != null && attributes[25] != "" ? attributes[25] : " ");
				noteFupData.setFecckt_attr(attributes[26] != null && attributes[26] != "" ? attributes[26] : " ");
				noteFupData.setFecckt(attributes[27] != null && attributes[27] != "" ? attributes[27] : " ");

				noteFupData.setNpord_attr(attributes[28] != null && attributes[28] != "" ? attributes[28] : " ");
				noteFupData.setNpord(attributes[29] != null && attributes[29] != "" ? attributes[29] : " ");
				noteFupData.setPorted_nbr(attributes[30] != null && attributes[30] != "" ? attributes[30] : " "); // Not
																													// getting
																													// data...!
				noteFupData.setRti_attr(attributes[31] != null && attributes[31] != "" ? attributes[31] : " ");
				noteFupData.setRti(attributes[32] != null && attributes[32] != "" ? attributes[32] : " ");
				noteFupData.setCbcid_attr(attributes[33] != null && attributes[33] != "" ? attributes[33] : " ");
				noteFupData.setCbcid(attributes[34] != null && attributes[34] != "" ? attributes[34] : " ");
				noteFupData.setCableid_attr(attributes[35] != null && attributes[35] != "" ? attributes[35] : " ");
				noteFupData.setCableid(attributes[36] != null && attributes[36] != "" ? attributes[36] : " ");
				noteFupData.setChan_pair_attr(attributes[37] != null && attributes[37] != "" ? attributes[37] : " ");
				noteFupData.setChain_pair(attributes[38] != null && attributes[38] != "" ? attributes[38] : " ");
				noteFupData.setOld_ord(attributes[39] != null && attributes[39] != "" ? attributes[39] : " ");
				noteFupData.setOld_lord(attributes[40] != null && attributes[40] != "" ? attributes[40] : " ");
				noteFupData.setOld_npord(attributes[41] != null && attributes[41] != "" ? attributes[41] : " ");
				noteFupData.setLoc_seq_num(attributes[42] != null && attributes[42] != "" ? attributes[42] : " ");
				treeViewList_552.add(noteFupData);
			}
			selectRequestData.setSubHeader(receivedSubHeader);
			session.setAttribute("treeViewList_552", treeViewList_552);

		}
		if (subData9_550Recid != null && subData9_550Recid.getSubHeader().getRecord_type().equals("550")) {

			List<ConfirmationTask_RecId_550> treeViewList9_550 = new ArrayList<>();
			SubHeader receivedSubHeader = subData9_550Recid.getSubHeader();
			String[] subDataRows = subData9_550Recid.getSubDataRows();
			treeViewList.add("550");

			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 27);
//				System.out.println("attributes:=550:Reqid======> " + Arrays.toString(attributes));
				ConfirmationTask_RecId_550 confirmationTask9state = new ConfirmationTask_RecId_550();
				confirmationTask9state.setCver(attributes[0]);
				confirmationTask9state.setAtn_attr(attributes[1]);
				confirmationTask9state.setAtn(attributes[2]);
				confirmationTask9state.setInit_attr(attributes[3]);
				confirmationTask9state.setInit(attributes[4]);
				confirmationTask9state.setRep(attributes[5]);
				confirmationTask9state.setTel_no(attributes[6]);
				confirmationTask9state.setRt(attributes[7]);
				confirmationTask9state.setEcver(attributes[8]);
				confirmationTask9state.setD_t_sent_local(attributes[9]);
				confirmationTask9state.setResponse_d_t_sent_central_time(attributes[10]);
				confirmationTask9state.setPia(attributes[11]);
				confirmationTask9state.setChc(attributes[12]);
				confirmationTask9state.setFdt_att(attributes[13]);
				confirmationTask9state.setFdt(attributes[14]);
				confirmationTask9state.setDd_attr(attributes[15]);
				confirmationTask9state.setDd(attributes[16]);
				confirmationTask9state.setApptime_attr(attributes[17]);
				confirmationTask9state.setApptime(attributes[18]);
				confirmationTask9state.setEbd_attr(attributes[19]);
				confirmationTask9state.setEbd(attributes[20]);
				confirmationTask9state.setBan1_attr(attributes[21]);
				confirmationTask9state.setBan1(attributes[22]);
				confirmationTask9state.setBan2_attr(attributes[23]);
				confirmationTask9state.setBan2(attributes[24]);
				confirmationTask9state.setAn_attr(attributes[25]);
				confirmationTask9state.setAn(attributes[26]);

				treeViewList9_550.add(confirmationTask9state);
			}
			selectRequestData.setSubHeader(receivedSubHeader);
			// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			System.out.println("++++treeViewList_550+++before session+++" + treeViewList9_550);
			session.setAttribute("treeViewList9_550", treeViewList9_550);
		}

		return treeViewList;

	}

	// *********************************Saurabh sprint11 code start
	// ***************************************
	public CorrectingConfTaskNoProdMain writeSelectedRequestCorrectingConfNoProdData(
			CorrectingConfTaskNoProdMain correctingconfTaskNoProdMain, String user_id, String object_handle,
			HttpSession session) {

		Header header = null;
		SubHeader subHeader = null;
		StringBuilder subHeaderandData = new StringBuilder();
		System.out.println("Service:::111:inside:user_id::user_id::::" + user_id);
		String dataString856 = "";
		String dataString858 = "";
		String dataString049 = "";
		int count = 0000;
		List<Correcting_ConfirmationTask_RecId_856> correctingList_856 = correctingconfTaskNoProdMain
				.getCorrecting_ConfirmationTask_RecId_856();
		List<Correcting_ConfirmationTask_RecId_858> correctingList_858 = correctingconfTaskNoProdMain
				.getCorrecting_ConfirmationTask_RecId_858();
		List<NotesFupBindingData12States> conformationList_049 = correctingconfTaskNoProdMain
				.getNotesFupBindingData9States();
		List filterRecidList = (ArrayList) session.getAttribute("treeViewList");
		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();
		if (filterRecidList.contains("049")) {

			for (NotesFupBindingData12States notesFupBindingData9States : conformationList_049) {
				count++;
				session.setAttribute("Lrs_No", notesFupBindingData9States.getRequest_id().substring(0, 17).trim());
				dataString049 = notesFupBindingData9States.getNotesFupBindingData9String();
//				System.out.println("::::::dataString: confirmationTask_RecId_049_new for::::" + dataString049);

			}
		}
		System.out.println("Ord value------------------------------->" + correctingList_858.get(0).getOrd());
		int i = 0;
		List<Correcting_ConfirmationTask_RecId_858> conformationList_858 = (List<Correcting_ConfirmationTask_RecId_858>) (session
				.getAttribute("treeViewList_858"));

		if (filterRecidList.contains("858")) {
			for (Correcting_ConfirmationTask_RecId_858 correcting_confTask_RecId_858 : conformationList_858) {
				count++;
			}
		}
		if (filterRecidList.contains("049")) {
			String countVal = "";
			System.out.println("Count:::" + count);
			if (count < 10) {
				System.out.println("less:::");
				countVal = "000" + count;
			}
			if (count >= 10) {
				System.out.println("greater:::");
				countVal = "00" + count;
			}
			header = prepareHeader1(user_id, object_handle, countVal);
			subHeader = prepareSubHeader(RecIdFor9State.CS_RECID_HEADER.getRecIdValue());
			subHeaderandData.append(mqMessageStringBuilder.addHeader(header));
			subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString049.toString()));
		}

		if (filterRecidList.contains("858")) {
			int j = 0;
			for (Correcting_ConfirmationTask_RecId_858 correcting_confTask_RecId_858 : correctingList_858) {
				correcting_confTask_RecId_858.setApptime(conformationList_858.get(i).getApptime());
				correcting_confTask_RecId_858.setApptime_attr(conformationList_858.get(i).getApptime_attr());
				correcting_confTask_RecId_858.setComt_dt(conformationList_858.get(i).getComt_dt());
				correcting_confTask_RecId_858.setComt_dt_attr(conformationList_858.get(i).getComt_dt_attr());
				correcting_confTask_RecId_858.setDd(conformationList_858.get(i).getDd());
				correcting_confTask_RecId_858.setDd_attr(conformationList_858.get(i).getDd_attr());
				correcting_confTask_RecId_858.setFdt(conformationList_858.get(i).getFdt());
				correcting_confTask_RecId_858.setFdt_attr(conformationList_858.get(i).getFdt_attr());
				correcting_confTask_RecId_858.setOld_dtm(conformationList_858.get(i).getOld_dtm());
				correcting_confTask_RecId_858.setOld_ord(conformationList_858.get(i).getOld_ord());
				correcting_confTask_RecId_858.setOrd_attr(conformationList_858.get(i).getOrd_attr());
				correcting_confTask_RecId_858.setPosted_date(conformationList_858.get(i).getPosted_date());
				correcting_confTask_RecId_858.setPosted_date_attr(conformationList_858.get(i).getPosted_date_attr());
				// correcting_confTask_RecId_858.setOrd(correctingList_858.get(i).getOrd());
				System.out
						.println("After set Ord value------------------------------->" + correcting_confTask_RecId_858);
				i++;
				if (correcting_confTask_RecId_858.getOrd_attr().contains("U")) {
					correcting_confTask_RecId_858.setOrd_attr("Y");
				}
				if (correcting_confTask_RecId_858.getApptime_attr().contains("U")) {
					correcting_confTask_RecId_858.setApptime_attr("Y");
				}
				correcting_confTask_RecId_858.setApptime_attr("R");
				correcting_confTask_RecId_858.setOld_ord(conformationList_858.get(j).getOrd());
				dataString858 = correcting_confTask_RecId_858.getSelectRequest858DataString();
//				System.out.println("::::::dataString: correcting_confTask_RecId_858 for::::" + dataString858);
				subHeader = prepareSubHeader(RecIdFor9State.CS_RECID_ISSUE_PIA_REQORD_V6.getRecIdValue());
				subHeaderandData
						.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString858.toString()));
				j++;
				// mqMessageStringBuilder.addHeaderSubHeaderAndData(header,subHeader,
				// dataString);
			}
		}


//		System.out.println("::::::subHeaderandData:::: for::::" + subHeaderandData.toString());
		String mqMessageString = mqMessageStringBuilder.getMqMessageString();
//		System.out.println("::::::58144444 formqMessageString::::" + mqMessageString);
		boolean isWritten = mqWriteUtil.writeDataToMQString(mqMessageString,session);
		// boolean isWritten = false;
		// String reg= (String) session.getAttribute("myReg");

		if (isWritten) {

			MQReceivedData mqReceivedData;
			
			try {

			mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
			 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
			  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
		//	  Header receivedHeader = mqReceivedData.getHeader(); 
			  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
					System.out.println("*************inside if*************** "); 
					mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
				} 
			  
			  
//			  System.out.println(mqReceivedData.getHeader().toString()); 
		} catch (Exception e) { 
			// TODO Auto-generated catch block 
			 mqReceivedData = mqReadUtil.readDataFromMQ(session); 
			e.printStackTrace(); 


		}
//			System.out.println("::::::mqReceivedData for::::" + mqReceivedData);
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
//			System.out.println("::::::subDatas for::::" + subDatas);
			Header receivedHeader = mqReceivedData.getHeader();
			correctingconfTaskNoProdMain.setHeader(receivedHeader);
			System.out.println("::::::receivedHeader for::::returncode::::" + receivedHeader.getReturn_code());
			SubData subData = subDatas.get(RecIdFor12State.CS_RECID_ERROR.getRecIdValue());
//			System.out.println("subData: " + subData);
			if (subData != null) {
				String[] subDataRows = subData.getSubDataRows();

				String[] attributes = mqReadUtil.getAttributes(subDataRows[0], 4);
//				System.out.println("attributes: Aug 10 " + Arrays.toString(attributes));
				// System.out.println("recieved subheader" + receivedSubHeader.toString() );
				if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {

					System.out.println("inside 999");
					String errorData = attributes[0];

					System.out.println("inside 999" + attributes[1]);
					System.out.println("inside 999" + attributes[2]);
					System.out.println("inside 999" + attributes[3]);
					ShowErrorService showErrorService = new ShowErrorService();
					focError = showErrorService.getErrorList(attributes[0].trim(), attributes[1], "", "U");

					session.setAttribute("showError", focError);
					System.err.println("ERRORS ******" + focError.toString());

				}
			}

		}
		return correctingconfTaskNoProdMain;
	}
	
	public ConfirmationTaskNoProd9Main writeSelectedRequestConfTaskNoProd9MainData(ConfirmationTaskNoProd9Main confirmationTaskNoProd9Main, String user_id, String object_handle, HttpSession session) {
    
		Header header = null;
		SubHeader subHeader = null;
		StringBuilder subHeaderandData = new StringBuilder();
		System.out.println("Service:::111:inside:user_id::user_id::::"+user_id);
		String dataString556= "";
		String dataString558 = "";
		String dataString049 = "" ;
		int count = 0000;
	List<ConfirmationTaskNoProd_RecId_556> correctingList_556 = confirmationTaskNoProd9Main.getConfirmationTaskNoProd_RecId_556();
	List<ConfirmationTask_RecId_558> correctingList_558 = confirmationTaskNoProd9Main.getConfirmationTask_RecId_558();
	List<NotesFupBindingData12States> conformationList_049 = confirmationTaskNoProd9Main.getNotesFupBindingData9States();
	List<ConfirmationTask_RecId_558> conformationList_558 = (List<ConfirmationTask_RecId_558>)(session.getAttribute("treeViewList_558"));
	List filterRecidList = (ArrayList)session.getAttribute("treeViewList");
		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();
		if(session.getAttribute("showError")!= null) {
			session.removeAttribute("showError");
			}
		if (filterRecidList.contains("049")) {

			for (NotesFupBindingData12States notesFupBindingData9States : conformationList_049) {
				count++;
				session.setAttribute("Lrs_No", notesFupBindingData9States.getRequest_id().substring(0, 17).trim());
				dataString049 = notesFupBindingData9States.getNotesFupBindingData9String();
//				System.out.println("::::::dataString: confirmationTask_RecId_049_new for::::" + dataString049);

			}
		}
		if(filterRecidList.contains("558")) {
			for (ConfirmationTask_RecId_558 confirmationTask_RecId_558 : correctingList_558) {
				count++;
				}
			}
		if(filterRecidList.contains("049")) {
			String countVal = "";
			System.out.println("Count:::" + count);
			if (count < 10) {
				System.out.println("less:::");
				countVal = "000" + count;
			}
			if (count >= 10) {
				System.out.println("greater:::");
				countVal = "00" + count;
			}
			header = prepareHeader(user_id, object_handle, countVal);
			subHeader = prepareSubHeader(RecIdFor9State.CS_RECID_HEADER.getRecIdValue());
			subHeaderandData.append(mqMessageStringBuilder.addHeader(header));
			subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString049.toString()));
		}
		if(filterRecidList.contains("558")) {
		int i = 0; 
		int j =0 ;
			for (ConfirmationTask_RecId_558 recId_558 : correctingList_558) {
				count++;
				recId_558.setApptime(conformationList_558.get(i).getApptime());
				recId_558.setApptime_attr(conformationList_558.get(i).getApptime_attr());
				recId_558.setComt_dt(conformationList_558.get(i).getComt_dt());
				recId_558.setComt_dt_attr(conformationList_558.get(i).getComt_dt_attr());
//				recId_558.setDd(conformationList_558.get(i).getDd());	
				recId_558.setDd_attr(conformationList_558.get(i).getDd_attr());
				recId_558.setFdt(conformationList_558.get(i).getFdt());
				recId_558.setFdt_attr(conformationList_558.get(i).getFdt_attr());
				recId_558.setOld_dtm(conformationList_558.get(i).getOld_dtm());	
				recId_558.setOld_ord(conformationList_558.get(i).getOld_ord());
				recId_558.setOrd_attr(conformationList_558.get(i).getOrd_attr());
				recId_558.setPosted_date(conformationList_558.get(i).getPosted_date());
				recId_558.setPosted_date_attr(conformationList_558.get(i).getPosted_date_attr());
				//correcting_confTask_RecId_858.setOrd(correctingList_858.get(i).getOrd());
				System.out.println("After set Ord value------------------------------->"+recId_558);
				i++;
				if(recId_558.getOrd_attr().contains("U")) {
					recId_558.setOrd_attr("Y");
				}
				if(recId_558.getDd_attr().contains("U")) {
					recId_558.setDd_attr("Y");
				}
				if(recId_558.getApptime_attr().contains("U")) {
					recId_558.setApptime_attr("Y");
				}
				recId_558.setApptime_attr("R");
				recId_558.setOld_ord(conformationList_558.get(j).getOrd());
				dataString558 = recId_558.getSelectRequest558DataString();
//				System.out.println("::::::dataString: correcting_confTask_RecId_558 for::::"+dataString558);
				subHeader = prepareSubHeader(RecIdFor9State.CS_RECID_CONFIRM_REQORD.getRecIdValue());
				subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString558.toString()));
			//	mqMessageStringBuilder.addHeaderSubHeaderAndData(header,subHeader, dataString);
				j++;
				}
			}

		
//		System.out.println("::::::subHeaderandData:::: for::::" + subHeaderandData.toString());
		String mqMessageString = mqMessageStringBuilder.getMqMessageString();
//		System.out.println("::::::58144444 formqMessageString::::" + mqMessageString);
		boolean isWritten = mqWriteUtil.writeDataToMQString(mqMessageString,session);
		//boolean isWritten = false;
		// String reg= (String) session.getAttribute("myReg");

		if (isWritten) {

			MQReceivedData mqReceivedData;
			
			try {

			mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
			 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
			  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
		//	  Header receivedHeader = mqReceivedData.getHeader(); 
			  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
					System.out.println("*************inside if*************** "); 
					mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
				} 
			  
			  
//			  System.out.println(mqReceivedData.getHeader().toString()); 
		} catch (Exception e) { 
			// TODO Auto-generated catch block 
			 mqReceivedData = mqReadUtil.readDataFromMQ(session); 
			e.printStackTrace(); 


		}
//			System.out.println("::::::mqReceivedData for::::" + mqReceivedData);
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
//			System.out.println("::::::subDatas for::::" + subDatas);
			Header receivedHeader = mqReceivedData.getHeader();
			confirmationTaskNoProd9Main.setHeader(receivedHeader);
//			System.out.println("::::::receivedHeader for::::returncode::::" + receivedHeader.getReturn_code());
			SubData subData = subDatas.get(RecIdFor12State.CS_RECID_ERROR.getRecIdValue());
//			System.out.println("subData: " + subData);
			SubData subdata558 = subDatas.get(RecIdFor9State.CS_RECID_CONFIRM_REQORD.getRecIdValue());
			if (subData != null) {
				String[] subDataRows = subData.getSubDataRows();
				

				String[] attributes = mqReadUtil.getAttributes(subDataRows[0], 4);
//				System.out.println("attributes: Aug 10 " + Arrays.toString(attributes));
				// System.out.println("recieved subheader" + receivedSubHeader.toString() );
				if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {

					System.out.println("inside 999");
					String errorData = attributes[0];

					System.out.println("inside 999" + attributes[1]);
					System.out.println("inside 999" + attributes[2]);
					System.out.println("inside 999" + attributes[3]);
					ShowErrorService showErrorService = new ShowErrorService();
					focError = showErrorService.getErrorList(attributes[0].trim(), attributes[1], "", "U");

					session.setAttribute("showError", focError);
					System.err.println("ERRORS ******" + focError.toString());

				}
			}
			if (subdata558 != null) {
				String[] subDataRows558 = subdata558.getSubDataRows();
				String[] attributes = mqReadUtil.getAttributes(subDataRows558[0], 4);
				if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
					for (String subDataRow : subDataRows558) {
//							System.err.println("Sub data row is: "+subDataRow.toString());
								//For greater LSR versions exist error message
								if(attributes[0].equals("LG0118"))
								{
									String lsr_no = (String) session.getAttribute("Lrs_No");
									focError = showErrorService.getShowErrorList(subDataRow.substring(0,6), attributes[2], lsr_no, "", focError);
								}
								else{
									focError = showErrorService.getShowErrorList(subDataRow.substring(0,6), attributes[2], "","U", focError);
								}
							}
					session.setAttribute("showError", focError);
				}
			}
			

		}
		return confirmationTaskNoProd9Main;
		}

	public CorrectingConfTask9Main writeSelectedRequestCorrectingConfTask9Data(
			CorrectingConfTask9Main correctingConfTask9Main, String user_id, String object_handle,
			HttpSession session) {

		// Header header = prepareHeader(user_id, object_handle);
				Header header = null;
				SubHeader subHeader = null;
				StringBuilder subHeaderandData = new StringBuilder();
				System.out.println("Service:::111:inside:user_id::user_id::::" + user_id);
				String dataString049 = "";
				String dataString858 = "";
				String dataString851 = "";
				String dataString852 = "";
				String dataString850 = "";
				int count = 0000;
				boolean boolean_850 = true;
				boolean boolean_852 = true;
				boolean boolean_858 = true;
				List<CorrectingConfTask9_RecId_850> conformationList_850 = correctingConfTask9Main.getCorrectingConfTask9_RecId_850();
				List<Correcting_ConfirmationTask_RecId_858> conformationList_858 = correctingConfTask9Main.getCorrecting_ConfirmationTask_RecId_858();
				List<CorrectingConfTask9_RecId_851> conformationList_851 = correctingConfTask9Main.getCorrectingConfTask9_RecId_851();
				List<NotesFupBindingData12States> conformationList_049 = correctingConfTask9Main.getNotesFupBindingData9States();
				List<CorrectingConfTask9_RecId_852> conformationList_852 = correctingConfTask9Main.getCorrectingConfTask9_RecId_852();

				List<CorrectingConfTask9_RecId_850> conformationList_850_old = (List<CorrectingConfTask9_RecId_850>) (session.getAttribute("treeViewList9_850"));
				List<Correcting_ConfirmationTask_RecId_858> conformationList_858_old = (List<Correcting_ConfirmationTask_RecId_858>) (session.getAttribute("treeViewList_858"));
				List<CorrectingConfTask9_RecId_852> conformationList_852_old = (List<CorrectingConfTask9_RecId_852>) session.getAttribute("treeViewList9_852");
				
				List<CorrectingConfTask9_RecId_850> updatedList_850 = getUpdatedRowsForCCT_850(conformationList_850, conformationList_850_old);
				 List<CorrectingConfTask9_RecId_852> updatedList_852 = null ;
				if (conformationList_852 != null) {
				updatedList_852 = getUpdatedRowsForCCT_852(conformationList_852, conformationList_852_old);
				}
				List<Correcting_ConfirmationTask_RecId_858> updatedList_858 = getUpdatedRowsForCCT_858(conformationList_858, conformationList_858_old);
				
				List filterRecidList = (ArrayList) session.getAttribute("treeViewList");
				MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();
				
				if (conformationList_852 != null) {
					count = updatedList_850.size() + updatedList_852.size() + updatedList_858.size();
					} else {
					count = updatedList_850.size() + updatedList_858.size();
					}
				
				if (filterRecidList.contains("049")) {

					for (NotesFupBindingData12States notesFupBindingData9States : conformationList_049) {
						count++;
						session.setAttribute("Lrs_No", notesFupBindingData9States.getRequest_id().substring(0, 17).trim());
						dataString049 = notesFupBindingData9States.getNotesFupBindingData9String();
//						System.out.println("::::::dataString: confirmationTask_RecId_049_new for::::" + dataString049);

					}
				}
				
				if (filterRecidList.contains("049")) {
					String countVal = "";

					System.out.println("Count:::" + count);
					if (count < 10) {
						System.out.println("less:::");
						countVal = "000" + count;
					}
					if (count >= 10) {
						System.out.println("greater:::");
						countVal = "00" + count;
					}
					header = prepareHeader1(user_id, object_handle, countVal);
					subHeader = prepareSubHeader(RecIdFor9State.CS_RECID_HEADER.getRecIdValue());
					subHeaderandData.append(mqMessageStringBuilder.addHeader(header));
					subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString049.toString()));
				}
				if (filterRecidList.contains("850")) {
					int i = 0;
					for (CorrectingConfTask9_RecId_850 confirmationTask_RecId_850_new : updatedList_850) { 
						
						if(confirmationTask_RecId_850_new.getBan1_attr().contains("U")) {
							confirmationTask_RecId_850_new.setBan1_attr("Y");
						}
						if(confirmationTask_RecId_850_new.getBan2_attr().contains("U")) {
							confirmationTask_RecId_850_new.setBan2_attr("Y");
						}
						if(confirmationTask_RecId_850_new.getDd_att().contains("U")) {
							confirmationTask_RecId_850_new.setDd_att("Y");
						}
						if(confirmationTask_RecId_850_new.getEbd_attr().contains("U")) {
							confirmationTask_RecId_850_new.setEbd_attr("Y");
						}
						if(confirmationTask_RecId_850_new.getFdt_attr().contains("U")) {
							confirmationTask_RecId_850_new.setFdt_attr("Y");
						}
						dataString850 = confirmationTask_RecId_850_new.getCorrectingConfTask9_RecId_850();
//							System.out.println("::::::dataString: confirmationTask_RecId_850_new for::::" + dataString850);
							subHeader = prepareSubHeader(RecIdFor9State.CS_RECID_ISSUE_PIA_FIX_V6.getRecIdValue());
							subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString850.toString()));
							i++;
					}
				}

				if (filterRecidList.contains("858")) {
					int j = 0;
					for (Correcting_ConfirmationTask_RecId_858 confirmationTask_RecId_858_new : updatedList_858) {
						
						if (conformationList_858_old.get(j).getOrd().equals(confirmationTask_RecId_858_new.getOrd())) {
							System.out.println("In Recid 858 ORD field not updated so 858 not Ready for MQ transaction -------------------------->");
							boolean_858 = false;
						} else {
							dataString858 = confirmationTask_RecId_858_new.getSelectRequest858DataString();
//							System.out.println("::::::dataString: confirmationTask_RecId_858_new for::::" + dataString858);
							subHeader = prepareSubHeader(RecIdFor9State.CS_RECID_ISSUE_PIA_REQORD_V6.getRecIdValue());
							subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString858.toString()));
							j++;
					}
					}
				}

				if (filterRecidList.contains("852")) {
					int i= 0;
					for (CorrectingConfTask9_RecId_852 confirmationTask_RecId_852_new :updatedList_852 ) {
						i++;
							dataString852 = confirmationTask_RecId_852_new.getCorrectingConfTask9_RecId_852();
//							System.out.println("::::::dataString: confirmationTask_RecId_852_new for::::" + dataString852);
							subHeader = prepareSubHeader(RecIdFor9State.CS_RECID_ISSUE_PIA_DTL_V6.getRecIdValue());
							subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString852.toString()));
					}
				}

//		System.out.println("::::::subHeaderandData:::: for::::" + subHeaderandData.toString());
		String mqMessageString = mqMessageStringBuilder.getMqMessageString();
//		System.out.println("::::::58144444 formqMessageString::::" + mqMessageString);
		boolean isWritten = mqWriteUtil.writeDataToMQString(mqMessageString,session);
		//boolean isWritten = false;
		// String reg= (String) session.getAttribute("myReg");

		if (isWritten) {

			MQReceivedData mqReceivedData;
			
			try {

			mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
			 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
			  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
		//	  Header receivedHeader = mqReceivedData.getHeader(); 
			  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
					System.out.println("*************inside if*************** "); 
					mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
				} 
			  
			  
//			  System.out.println(mqReceivedData.getHeader().toString()); 
		} catch (Exception e) { 
			// TODO Auto-generated catch block 
			 mqReceivedData = mqReadUtil.readDataFromMQ(session); 
			e.printStackTrace(); 


		}
//			System.out.println("::::::mqReceivedData for::::" + mqReceivedData);
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
//			System.out.println("::::::subDatas for::::" + subDatas);
			Header receivedHeader = mqReceivedData.getHeader();
			correctingConfTask9Main.setHeader(receivedHeader);
			System.out.println("::::::receivedHeader for::::returncode::::" + receivedHeader.getReturn_code());
			SubData subData = subDatas.get(RecIdFor12State.CS_RECID_ERROR.getRecIdValue());
//			System.out.println("subData: " + subData);
			
			SubData subdata850 = subDatas.get(RecIdFor9State.CS_RECID_ISSUE_PIA_FIX_V6.getRecIdValue());
			SubData subdata852 = subDatas.get(RecIdFor9State.CS_RECID_ISSUE_PIA_DTL_V6.getRecIdValue());
			SubData subdata858 = subDatas.get(RecIdFor9State.CS_RECID_ISSUE_PIA_REQORD_V6.getRecIdValue());
			
			if (subData != null) {
				String[] subDataRows = subData.getSubDataRows();

				String[] attributes = mqReadUtil.getAttributes(subDataRows[0], 4);
//				System.out.println("attributes: Aug 10 " + Arrays.toString(attributes));
				// System.out.println("recieved subheader" + receivedSubHeader.toString() );
				if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {

					System.out.println("inside 999");
					String errorData = attributes[0];

					System.out.println("inside 999" + attributes[1]);
					System.out.println("inside 999" + attributes[2]);
					System.out.println("inside 999" + attributes[3]);
					ShowErrorService showErrorService = new ShowErrorService();
					focError = showErrorService.getErrorList(attributes[0].trim(), attributes[1], "", "U");

					session.setAttribute("showError", focError);
					System.err.println("ERRORS ******" + focError.toString());

				}
				
				if (subdata850 != null) {
					
					String[] subDataRows850 = subdata850.getSubDataRows();
					if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
						for (String subDataRow : subDataRows850) {
							
//								System.err.println("Sub data row is: "+subDataRow.toString());
									
									//For greater LSR versions exist error message
									if(attributes[0].equals("LG0118"))
									{
										String lsr_no = (String) session.getAttribute("Lrs_No");
										focError = showErrorService.getShowErrorList(subDataRow.substring(0,6), attributes[2], lsr_no, "", focError);
									}
									else{
										focError = showErrorService.getShowErrorList(subDataRow.substring(0,6), attributes[2], "","U", focError);
									}
								}
					}
				}
				
				if (subdata852 != null) {

					String[] subDataRows852 = subdata852.getSubDataRows();
					if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
						for (String subDataRow : subDataRows852) {

							System.err.println("Sub data row is: " + subDataRow.toString());

							// For greater LSR versions exist error message
							if (attributes[0].equals("LG0118")) {
								String lsr_no = (String) session.getAttribute("Lrs_No");
								focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2],
										lsr_no, "", focError);
							} else {
								focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2],
										"", "U", focError);
							}
						}
					}
				}

				if (subdata858 != null) {

					String[] subDataRows858 = subdata858.getSubDataRows();
					if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
						for (String subDataRow : subDataRows858) {

//							System.err.println("Sub data row is: " + subDataRow.toString());

							// For greater LSR versions exist error message
							if (attributes[0].equals("LG0118")) {
								String lsr_no = (String) session.getAttribute("Lrs_No");
								focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2],
										lsr_no, "", focError);
							} else {
								focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2],
										"", "U", focError);
							}
						}
					}
				}

			}

		}
		return correctingConfTask9Main;
	}
	
	// Start Y/N Functionallity for Correcting confirmation Task 9 state
	public List<CorrectingConfTask9_RecId_852> getUpdatedRowsForCCT_852(List<CorrectingConfTask9_RecId_852> newList,List<CorrectingConfTask9_RecId_852> oldList) {

		List<CorrectingConfTask9_RecId_852> updatedList= new ArrayList<CorrectingConfTask9_RecId_852>();
		int i = 0 ;
		for (CorrectingConfTask9_RecId_852 tableRow : newList) {
			if (!tableRow.getEcckt().equalsIgnoreCase(oldList.get(i).getEcckt()) || !tableRow.getTers().equalsIgnoreCase(oldList.get(i).getTers())) {
				if(tableRow.getOrd_attr().contains("U")) {
					if(tableRow.getOrd().equals(oldList.get(i).getOrd()))
						tableRow.setOrd_attr("N");
					else								
						tableRow.setOrd_attr("Y");
				}			
				if(tableRow.getEcckt_attr().contains("U")) {
					if(tableRow.getEcckt().equals(oldList.get(i).getEcckt()))
						tableRow.setEcckt_attr("N");
					else
						tableRow.setEcckt_attr("Y");
				}
				if(tableRow.getTers_attr().contains("U")) {
					if(tableRow.getTers().equals(oldList.get(i).getTers()))
						tableRow.setTers_attr("N");
					else
						tableRow.setTers_attr("Y");
				}							
				if(tableRow.getLord_attr().contains("U")) {
					if(tableRow.getLord().equals(oldList.get(i).getLord()))
						tableRow.setLord_attr("N");
					else
						tableRow.setLord_attr("Y");
				}			
				if(tableRow.getTns_attr().contains("U")) {
					if(tableRow.getTns().equals(oldList.get(i).getTns()))
						tableRow.setTns_attr("N");
					else
						tableRow.setTns_attr("Y");
				}			
				if(tableRow.getIspid_attr().contains("U")) {
					if(tableRow.getIspid().equals(oldList.get(i).getIspid()))
						tableRow.setIspid_attr("N");
					else
						tableRow.setIspid_attr("Y");
				}
				if(tableRow.getFecckt_attr().contains("U")) {
					if(tableRow.getFecckt().equals(oldList.get(i).getFecckt()))
						tableRow.setFecckt_attr("N");
					else
						tableRow.setFecckt_attr("Y");
				}
				if(tableRow.getNpord_attr().contains("U")) {
					if(tableRow.getNpord().equals(oldList.get(i).getNpord()))
						tableRow.setNpord_attr("N");
					else
						tableRow.setNpord_attr("Y");
				}			
				if(tableRow.getRti_attr().contains("U")) {
					if(tableRow.getRti().equals(oldList.get(i).getRti()))
						tableRow.setRti_attr("N");
					else
						tableRow.setRti_attr("Y");
				}
				if(tableRow.getCbcid_attr().contains("U")) {
					if(tableRow.getCbcid().equals(oldList.get(i).getCbcid()))
						tableRow.setCbcid_attr("N");
					else
						tableRow.setCbcid_attr("Y");
				}
				if(tableRow.getCableid_attr().contains("U")) {
					if(tableRow.getCableid().equals(oldList.get(i).getCableid()))
						tableRow.setCableid_attr("N");
					else
						tableRow.setCableid_attr("Y");
				}
				if(tableRow.getChan_pair_attr().contains("U")) {
					if(tableRow.getChan_pair().equals(oldList.get(i).getChan_pair()))
						tableRow.setChan_pair_attr("N");
					else
						tableRow.setChan_pair_attr("Y");
				}
				
				if(!tableRow.getOrd().equalsIgnoreCase(oldList.get(i).getOrd())) {
					String old_order = oldList.get(i).getOrd();
					tableRow.setOld_ord(old_order);
				}
				
				/*(if(!tableRow.getLord().equalsIgnoreCase(oldList.get(i).getLord())) {
					String old_lord = oldList.get(i).getLord();
					tableRow.setOld_lord(old_lord);
				}*/
				
				if(!tableRow.getNpord().equalsIgnoreCase(oldList.get(i).getNpord())) {
					String old_npord = oldList.get(i).getNpord();
					tableRow.setOld_npord(old_npord);
				}
				
				updatedList.add(tableRow);
				System.out.println("852 Row: "+tableRow.toString());
			}
			i++;
		}
		System.err.println("Old 852 List: "+oldList.toString());
		System.err.println("new 852 List: "+newList.toString());
		System.err.println("Updated 852 List: "+updatedList.toString());
		return updatedList;
		}
	
	public List<Correcting_ConfirmationTask_RecId_858> getUpdatedRowsForCCT_858(List<Correcting_ConfirmationTask_RecId_858> newList,List<Correcting_ConfirmationTask_RecId_858> oldList) {

		List<Correcting_ConfirmationTask_RecId_858> updatedList= new ArrayList<Correcting_ConfirmationTask_RecId_858>();
		int i = 0 ;
		for (Correcting_ConfirmationTask_RecId_858 tableRow : newList) {
			if (!tableRow.getOrd().equalsIgnoreCase(oldList.get(i).getOrd()) || !tableRow.getApptime().equalsIgnoreCase(oldList.get(i).getApptime())) {
				
				if(tableRow.getOrd_attr().contains("U")) {
					if(tableRow.getOrd().equals(oldList.get(i).getOrd()))
						tableRow.setOrd_attr("N");
					else								
						tableRow.setOrd_attr("Y");
				}
				
				if(!tableRow.getOrd().equalsIgnoreCase(oldList.get(i).getOrd())) {
					String old_order = oldList.get(i).getOrd();
					tableRow.setOld_ord(old_order);
				}

				if(tableRow.getApptime_attr().contains("U")) {
					if (tableRow.getApptime().equalsIgnoreCase(oldList.get(i).getApptime())) {
						tableRow.setApptime_attr("N");
					} else {
						tableRow.setApptime_attr("Y");
					}
				}
				updatedList.add(tableRow);
			}
			i++;
		}
		System.err.println("Old 858 List: "+oldList.toString());
		System.err.println("new 858 List: "+newList.toString());
		System.err.println("Updated 858 List: "+updatedList.toString());
		return updatedList;
		}
	
	public List<CorrectingConfTask9_RecId_850> getUpdatedRowsForCCT_850(List<CorrectingConfTask9_RecId_850> newList,List<CorrectingConfTask9_RecId_850> oldList) {

		List<CorrectingConfTask9_RecId_850> updatedList= new ArrayList<CorrectingConfTask9_RecId_850>();
		int i = 0 ;
		for (CorrectingConfTask9_RecId_850 tableRow : oldList) {
			if (!tableRow.getFdt().equalsIgnoreCase(newList.get(i).getFdt())
					|| !tableRow.getEbd().equalsIgnoreCase(newList.get(i).getEbd())
					|| !tableRow.getDd().equalsIgnoreCase(newList.get(i).getDd())
					|| !tableRow.getBan2().equalsIgnoreCase(newList.get(i).getBan2())
					|| !tableRow.getBan1().equalsIgnoreCase(newList.get(i).getBan1())) {
				
				if (tableRow.getFdt().equalsIgnoreCase(newList.get(i).getFdt())) {
					tableRow.setFdt_attr("N");
				} else {
					tableRow.setFdt_attr("Y");
					tableRow.setFdt(newList.get(i).getFdt());
				}
				if (tableRow.getBan1().equalsIgnoreCase(newList.get(i).getBan1())) {
					tableRow.setBan1_attr("N");
				} else {
					tableRow.setBan1_attr("Y");
					tableRow.setBan1(newList.get(i).getBan1());
				}
				if (tableRow.getBan2().equalsIgnoreCase(newList.get(i).getBan2())) {
					tableRow.setBan2_attr("N");
				} else {
					tableRow.setBan2_attr("Y");
					tableRow.setBan2(newList.get(i).getBan2());
				}
				if (tableRow.getDd().equalsIgnoreCase(newList.get(i).getDd())) {
					tableRow.setDd_att("N");
				} else {
					tableRow.setDd_att("Y");
					tableRow.setDd(newList.get(i).getDd());
				}
				if (tableRow.getEbd().equalsIgnoreCase(newList.get(i).getEbd())) {
					tableRow.setEbd_attr("N");
				} else {
					tableRow.setEbd_attr("Y");
					tableRow.setEbd(newList.get(i).getEbd());
				}
				updatedList.add(tableRow);
			}
			i++;
		}
		System.err.println("Old 850 List: "+oldList.toString());
		System.err.println("new 850 List: "+newList.toString());
		System.err.println("Updated 850 List: "+updatedList.toString());
		return updatedList;
		}
	// End Y/N Functionallity for Correcting confirmation Task 9 state
	//Anjali
	
		public List<CompletionActivityRLSOG6LscInfo> getUpdatedRowsdata(List<CompletionActivityRLSOG6LscInfo> newList,List<CompletionActivityRLSOG6LscInfo> oldList) {

			List<CompletionActivityRLSOG6LscInfo> updatedList= new ArrayList<CompletionActivityRLSOG6LscInfo>();
			for(int i=0;i<newList.size();i++)
			{
				CompletionActivityRLSOG6LscInfo tableRow=newList.get(i);
			if(!tableRow.getComp_dt().equalsIgnoreCase(oldList.get(i).getComp_dt()))
			{
				
			//tableRow.setDd(oldList.get(i).getComp_dt());
			if(tableRow.getOrd().equalsIgnoreCase(oldList.get(i).getOrd()))
					{
					//tableRow.setOrd_attr("R");
					}
			else {
			tableRow.setOld_ord(oldList.get(i).getOrd());
			tableRow.setComp_dt(newList.get(i).getComp_dt());
			
			}
			updatedList.add(tableRow);
			}
			
			
			}
			System.err.println("Old List: "+oldList.toString());
			System.err.println("new List: "+newList.toString());
			return updatedList;
			}
		
		private String getNumCount(int size) {
			String numCount = String.format("%04d", size);
			return numCount;
			}
		public CompletionMainTask writeSelectedRequestConformationDataMethod9(CompletionMainTask completionMainTask, String user_id, String object_handle, HttpSession session) {

			Header header = null;
			SubHeader subHeader = null;
			StringBuilder subHeaderandData = new StringBuilder();
			System.out.println("Service:::Anjali:inside:user_id::user_id::::"+user_id);
			String dataString049 = "";
			String dataString560 = "";
			String dataString568 = "";
			int count = 0000;
			focError.clear();
			
			
			
			List<CompletionProviderTask> List_560 = completionMainTask.getCompletionTask_RecID_560();
			List<CompletionActivityRLSOG6LscInfo> List_568 = completionMainTask.getCompletionTask_RecID_568();
			List<NotesFupBindingData12States> List_049 = completionMainTask.getNotesFupBindingData12States();
		    List filterRecidList = (ArrayList)session.getAttribute("treeViewList");
			MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();
			List<NotesFupBindingData12States> conformationList_12States  = (List<NotesFupBindingData12States>)session.getAttribute("treeViewList_049");
			List<CompletionActivityRLSOG6LscInfo> updateList_568=getUpdatedRowsdata(List_568, (List<CompletionActivityRLSOG6LscInfo>)session.getAttribute("treeViewList568"));
			
			
			
			if(filterRecidList.contains("049")) {
				
				for (NotesFupBindingData12States notesFupBindingData9States : conformationList_12States){
					count++;
					session.setAttribute("Lrs_No", notesFupBindingData9States.getRequest_id().substring(0, 17).trim());
//					System.out.println("::::::for:LrsNo:session::"+session.getAttribute("Lrs_No"));
					dataString049 = notesFupBindingData9States.getNotesFupBindingData9String();
//					System.out.println("::::::dataString: 049 for::::"+dataString049);
					
					
					}
				}			

			if(filterRecidList.contains("049")) {
				
				String countVal = "";
				
				System.out.println("Count:::"+count);
				if(count<10) {
					System.out.println("less:::");
					countVal= "000"+count;
				}
				if(count>=10) {
					System.out.println("greater:::");
					countVal= "00"+count;
				}
				
				System.out.println("Count value print "+countVal);
				
			System.err.println(updateList_568.toString()+" :::::");
			countVal=getNumCount(updateList_568.size()+2);
				
				header = prepareHeader_141src(user_id, object_handle, countVal);
				
				
				subHeader = prepareSubHeader(RecIdFor12State.CS_RECID_HEADER.getRecIdValue());
				subHeaderandData.append(mqMessageStringBuilder.addHeader(header));
				subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString049.toString()));
				
//				System.out.println("header" +header + "Sub Header Data "+subHeaderandData);
			}
			
				
			if(filterRecidList.contains("568")) {
				
				
				for (CompletionActivityRLSOG6LscInfo completion_RecId_568_new : updateList_568) {
					
					if(completion_RecId_568_new.getApptime_attr().contains("U")) {
						completion_RecId_568_new.setApptime_attr("Y");
					}
					if(completion_RecId_568_new.getOrd_attr().contains("U")) {
						completion_RecId_568_new.setOrd_attr("R");
					}
					if(completion_RecId_568_new.getFdt_attr().contains("U")) {
						completion_RecId_568_new.setFdt_attr("Y");
					}
					if(completion_RecId_568_new.getDd_attr().contains("U")) {
						completion_RecId_568_new.setDd_attr("Y");
					}
					if(completion_RecId_568_new.getComp_dt_attr().contains("U")) {
						completion_RecId_568_new.setComp_dt_attr("Y");
					}
					
					completion_RecId_568_new.setOrd_attr("R");
					completion_RecId_568_new.setApptime_attr("R");
					dataString568 = completion_RecId_568_new.getCompletionActivityRLSOG6LscInfo568();
//					System.out.println("::::::data String For : Completion Task_RecId_568_new for::::"+dataString568);

					subHeader = prepareSubHeader(RecIdFor12State.CS_RECID_COMPLETE_REQORD.getRecIdValue());
					subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString568.toString()));
					}
				}
			
//			System.out.println("::::::subHeaderandData:::: for 568::::"+subHeaderandData.toString());
			String mqMessageString = mqMessageStringBuilder.getMqMessageString();
//			System.err.println(mqMessageString);
			//boolean isWritten= false;
			boolean isWritten = mqWriteUtil.writeDataToMQString(mqMessageString,session);
			

			
			if (isWritten) {

				MQReceivedData mqReceivedData;
				
				try {

				mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
				 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
				  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
			//	  Header receivedHeader = mqReceivedData.getHeader(); 
				  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
						System.out.println("*************inside if*************** "); 
						mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
					} 
				  
				  
//				  System.out.println(mqReceivedData.getHeader().toString()); 
			} catch (Exception e) { 
				// TODO Auto-generated catch block 
				 mqReceivedData = mqReadUtil.readDataFromMQ(session); 
				e.printStackTrace(); 


			}
//				System.out.println("::::::mqReceivedData for::::"+mqReceivedData);
				Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
//				System.out.println("::::::subDatas for::::"+subDatas);
				Header receivedHeader = mqReceivedData.getHeader();
				completionMainTask.setHeader(receivedHeader);
				System.out.println("::::::receivedHeader for::::returncode::::"+receivedHeader.getReturn_code());
				SubData subData = subDatas.get(RecIdFor12State.CS_RECID_ERROR.getRecIdValue());
				
				SubData subData560 = subDatas.get(RecIdFor9State.CS_RECID_COMPLETE.getRecIdValue());
				SubData subData568 = subDatas.get(RecIdFor9State.CS_RECID_COMPLETE_REQORD.getRecIdValue());
				SubData subdata050=subDatas.get(RecIdFor12State.CS_RECID_LSR.getRecIdValue());
					
//				System.out.println("subData: "+"----->"+subData);
				if (subData != null) {
					
					String[] subDataRows = subData.getSubDataRows();
					if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
					for (String subDataRow : subDataRows) {
						
						String[] sentData = subDataRow.split(",");
						System.out.println("sentData after separation" + sentData);
						for (String a : sentData) {
						
							ShowErrorService showErrorService = new ShowErrorService();
						ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
						String uon_msg = readErrorMsgsJson.getErrorMsg(a.substring(0, 6).trim());
						
						focError = showErrorService.getErrorListMultiple(a.substring(0, 6).trim(), uon_msg, "", "U",focError);		
						System.err.println("ERRORS *600*****" + focError.toString());
					}}
					}
				}
				if (subdata050 != null) {
					
					String[] subDataRows = subdata050.getSubDataRows();
					if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
					for (String subDataRow : subDataRows) {
						
						String[] sentData = subDataRow.split(",");
						System.out.println("sentData after separation" + sentData);
						for (String a : sentData) {
						
							ShowErrorService showErrorService = new ShowErrorService();
						ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
						String uon_msg = readErrorMsgsJson.getErrorMsg(a.substring(0, 6).trim());
						
						focError = showErrorService.getErrorListMultiple(a.substring(0, 6).trim(), uon_msg, "", "U",focError);						
						
						System.err.println("ERRORS *600*****" + focError.toString());
					}}
					}
				}
				if(subData560 != null) {
					String[] subDataRows560 = subData560.getSubDataRows();
					if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
						for (String subDataRow : subDataRows560) {
							
							String[] sentData = subDataRow.split(",");
							System.out.println("sentData after separation" + sentData);
							for (String a : sentData) {
							
								ShowErrorService showErrorService = new ShowErrorService();
							ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
							String uon_msg = readErrorMsgsJson.getErrorMsg(a.substring(0, 6).trim());
							
							focError = showErrorService.getErrorListMultiple(a.substring(0, 6).trim(), uon_msg, "", "U",focError);
							
							//focMulipleError.add(focError);
							//session.setAttribute("showError", focError);
							System.err.println("ERRORS ****** inside 560" + focError.toString());
						}}
					}}
					if(subData568 != null) {
						String[] subDataRows568 = subData568.getSubDataRows();
						if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
						
							for (String subDataRow : subDataRows568) {
//								System.err.println("Sub data row is: "+subDataRow.toString());
									String[] attributes = mqReadUtil.getAttributes(subDataRow, 4);
									//For greater LSR versions exist error message
									if(attributes[0].equals("LG0118"))
									{
										String lsr_no = (String) session.getAttribute("Lrs_No");
										focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2], lsr_no, "", focError);
									}
									else{
										focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2], "","U", focError);
									}
									
									System.err.println("ERRORS *568*****" + focError.toString());
								}
						}}
				
				
					session.setAttribute("showError", focError);
			
				}
			
			 
			return completionMainTask;

			}
		
	private Header prepareHeader_141src(String user_id, String object_handle, String count) {
			
			Header header = new Header();

			header.setUser_id(user_id);
			header.setProcess(Process.CS_REQUEST.getProcessCode());
			header.setTab_ind(TabInd.SOC.getTabIndCode());
			header.setProcess_group_ind(ProcessGroupInd.ISSUE_IND.getProcessGroupInd());
			header.setObject_handle(object_handle);
			header.setObject_handle2(null);
			header.setLog_ind(LogInd.N.name());
			header.setStarttime(null);
			header.setEndtime(null);
			header.setGuid(null);
			header.setSession_trans_count("0000001");
			header.setHost_trans_seq(null);
			header.setReturn_code(null);
			header.setRead_only_ind(null);
			header.setNum_detail(count);		
			header.setRead_only_user_id(null);
			header.setLasrversion(null);

			return header;
		}


		//end code By An				



	private List correctingConfTaskNoProd(SelectRequestData selectRequestData, Map<String, SubData> subDatas,
			HttpSession session, List treeViewList) {
		SubData subData_858Recid = subDatas.get(RecIdFor9State.CS_RECID_ISSUE_PIA_REQORD_V6.getRecIdValue());
		SubData subData_856Recid = subDatas.get(RecIdFor9State.CS_RECID_ISSUE_PIA_NOPROD_V6.getRecIdValue());
//		System.out.println("Data for RecId---->856 " + subData_856Recid);
//		System.out.println("Data for RecId---->858 " + subData_858Recid);

		if (subData_856Recid != null && subData_856Recid.getSubHeader().getRecord_type().equals("856")) {
//			System.out.println("Data for RecId---->856 " + subData_856Recid);
			SubHeader receivedSubHeader = subData_856Recid.getSubHeader();
			String[] subDataRows = subData_856Recid.getSubDataRows();
			List<Correcting_ConfirmationTask_RecId_856> treeViewList_856 = new ArrayList();
			treeViewList.add("856");
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);
//				System.out.println("attributes:==856=====> " + Arrays.toString(attributes));
				Correcting_ConfirmationTask_RecId_856 corr_confrm_9state = new Correcting_ConfirmationTask_RecId_856();
				corr_confrm_9state.setCver(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
				corr_confrm_9state.setSvc_rep(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
				corr_confrm_9state.setSvc_rep_tn(attributes[2]);
				corr_confrm_9state.setAtn_attr(attributes[3]);
				corr_confrm_9state.setAtn(attributes[4]);
				corr_confrm_9state.setRt(attributes[5]);
				corr_confrm_9state.setEcver(attributes[6]);
				corr_confrm_9state.setD_t_sent_local(attributes[7]);
				corr_confrm_9state.setResponse_d_t_sent_central_time(attributes[8]);
				corr_confrm_9state.setDd_attr(attributes[9]);
				corr_confrm_9state.setDd(attributes[10]);
				corr_confrm_9state.setPia(attributes[11]);
				corr_confrm_9state.setAn_attr(attributes[12]);
				corr_confrm_9state.setAn(attributes[13]);

				treeViewList_856.add(corr_confrm_9state);
			}
			selectRequestData.setSubHeader(receivedSubHeader);
			session.setAttribute("treeViewList_856", treeViewList_856);
		}

		if (subData_858Recid != null && subData_858Recid.getSubHeader().getRecord_type().equals("858")) {
//			System.out.println("Data for RecId---->858 " + subData_858Recid);
			SubHeader receivedSubHeader = subData_858Recid.getSubHeader();
			String[] subDataRows = subData_858Recid.getSubDataRows();
			List<Correcting_ConfirmationTask_RecId_858> treeViewList_858 = new ArrayList();
			treeViewList.add("858");
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);
//				System.out.println("attributes:==858=====> " + Arrays.toString(attributes));
				Correcting_ConfirmationTask_RecId_858 corr_confrm_9state = new Correcting_ConfirmationTask_RecId_858();
				corr_confrm_9state.setOld_dtm(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
				corr_confrm_9state.setOld_ord(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
				corr_confrm_9state.setOrd_attr(attributes[2] != null && attributes[2] != "" ? attributes[2] : " ");
				corr_confrm_9state.setOrd(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
				corr_confrm_9state.setFdt_attr(attributes[4] != null && attributes[4] != "" ? attributes[4] : " ");
				corr_confrm_9state.setFdt(attributes[5] != null && attributes[5] != "" ? attributes[5] : " ");
				corr_confrm_9state.setDd_attr(attributes[6] != null && attributes[6] != "" ? attributes[6] : " ");
				corr_confrm_9state.setDd(attributes[7] != null && attributes[7] != "" ? attributes[7] : " ");
				corr_confrm_9state.setComt_dt_attr(attributes[8] != null && attributes[8] != "" ? attributes[8] : " ");
				corr_confrm_9state.setComt_dt(attributes[9] != null && attributes[9] != "" ? attributes[9] : " ");
				corr_confrm_9state
						.setPosted_date_attr(attributes[10] != null && attributes[10] != "" ? attributes[10] : " ");
				corr_confrm_9state
						.setPosted_date(attributes[11] != null && attributes[11] != "" ? attributes[11] : " ");
				corr_confrm_9state
						.setApptime_attr(attributes[12] != null && attributes[12] != "" ? attributes[12] : " ");
				corr_confrm_9state.setApptime(attributes[13] != null && attributes[13] != "" ? attributes[13] : " ");

				treeViewList_858.add(corr_confrm_9state);
			}
			selectRequestData.setSubHeader(receivedSubHeader);
			session.setAttribute("treeViewList_858", treeViewList_858);
		}
		return treeViewList;
	}

	private List confirmationTaskNoProd(SelectRequestData selectRequestData, Map<String, SubData> subDatas,
			HttpSession session, List treeViewList) {
		SubData subData_556Recid = subDatas.get(RecIdFor12State.CS_RECID_CONFIRM_NOPROD.getRecIdValue());
		if (subData_556Recid != null && subData_556Recid.getSubHeader().getRecord_type().equals("556")) {
			SubHeader receivedSubHeader = subData_556Recid.getSubHeader();
			String[] subDataRows = subData_556Recid.getSubDataRows();
			List<ConfirmationTaskNoProd_RecId_556> treeViewList_556 = new ArrayList();
			treeViewList.add("556");
			String lsrNo = "";
			String status = "";
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);
//				System.out.println("attributes:=556======> " + Arrays.toString(attributes));
				ConfirmationTaskNoProd_RecId_556 noteFupData = new ConfirmationTaskNoProd_RecId_556();
				noteFupData.setCver(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
				noteFupData.setSvc_rep_tn(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
				noteFupData.setSvc_rep(attributes[2] != null && attributes[2] != "" ? attributes[2] : " "); // Not
																											// getting
																											// data...!
				noteFupData.setAtn_attr(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
				noteFupData.setAtn(attributes[4] != null && attributes[4] != "" ? attributes[4] : " ");
				noteFupData.setRt(attributes[5] != null && attributes[5] != "" ? attributes[5] : " ");
				noteFupData.setEcver(attributes[6] != null && attributes[6] != "" ? attributes[6] : " ");
				noteFupData.setD_t_sent_local(attributes[7] != null && attributes[7] != "" ? attributes[7] : " ");

				noteFupData.setResponse_d_t_sent_central_time(
						attributes[8] != null && attributes[8] != "" ? attributes[8] : " ");
				noteFupData.setDd_attr(attributes[9] != null && attributes[9] != "" ? attributes[9] : " ");
				noteFupData.setDd(attributes[10] != null && attributes[10] != "" ? attributes[10] : " ");
				noteFupData.setPia(attributes[11] != null && attributes[11] != "" ? attributes[11] : " ");
				noteFupData.setAn_attr(attributes[12] != null && attributes[12] != "" ? attributes[12] : " ");
				noteFupData.setAn(attributes[13] != null && attributes[13] != "" ? attributes[13] : " ");

				treeViewList_556.add(noteFupData);
			}
			selectRequestData.setSubHeader(receivedSubHeader);
			session.setAttribute("treeViewList_556", treeViewList_556);
			// model.addAttribute("treeViewList_558", treeViewList_558);
			System.out.println("Model get Attribute  ");
		}
		return treeViewList;
	}

	private List correctingConfTask9(SelectRequestData selectRequestData, Map<String, SubData> subDatas,
			HttpSession session, List treeViewList) {
//	List treeViewList_850 = new ArrayList();
//	List treeViewList_858 = new ArrayList();
//	List treeViewList_851 = new ArrayList();
//	List treeViewList_852 = new ArrayList();

		SubData subData_850Recid = subDatas.get(RecIdFor9State.CS_RECID_ISSUE_PIA_FIX_V6.getRecIdValue());
		SubData subData_858Recid = subDatas.get(RecIdFor9State.CS_RECID_ISSUE_PIA_REQORD_V6.getRecIdValue());
		SubData subData_851Recid = subDatas.get(RecIdFor9State.CS_RECID_ISSUE_PIA_HUNT_V6.getRecIdValue());
		SubData subData_852Recid = subDatas.get(RecIdFor9State.CS_RECID_ISSUE_PIA_DTL_V6.getRecIdValue());
		SubData subData_560Recid = subDatas.get(RecIdFor12State.CS_RECID_COMPLETE.getRecIdValue());
		SubData subData_568Recid = subDatas.get(RecIdFor12State.CS_RECID_COMPLETE_REQORD.getRecIdValue());

		if (subData_850Recid != null && subData_850Recid.getSubHeader().getRecord_type().equals("850")) {

			SubHeader receivedSubHeader = subData_850Recid.getSubHeader();
			String[] subDataRows = subData_850Recid.getSubDataRows();

			List<CorrectingConfTask9_RecId_850> treeViewList9_850 = new ArrayList();
			treeViewList.add("850");
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 27);
//				System.out.println("attributes:=850======> " + Arrays.toString(attributes));
				CorrectingConfTask9_RecId_850 correctingConfTask9_RecId_850 = new CorrectingConfTask9_RecId_850();
				correctingConfTask9_RecId_850.setCver(attributes[0]);
				correctingConfTask9_RecId_850.setAtn_attr(attributes[1]);
				correctingConfTask9_RecId_850.setAtn(attributes[2]);
				correctingConfTask9_RecId_850.setInit_attr(attributes[3]);
				correctingConfTask9_RecId_850.setInit(attributes[4]);
				correctingConfTask9_RecId_850.setRep(attributes[5]);
				correctingConfTask9_RecId_850.setTel_no(attributes[6]);
				correctingConfTask9_RecId_850.setRt(attributes[7]);
				correctingConfTask9_RecId_850.setEcver(attributes[8]);
				correctingConfTask9_RecId_850.setD_t_sent_local(attributes[9]);
				correctingConfTask9_RecId_850.setResponse_d_t_sent_central_time(attributes[10]);
				correctingConfTask9_RecId_850.setPia(attributes[11]);
				correctingConfTask9_RecId_850.setChc(attributes[12]);
				correctingConfTask9_RecId_850.setFdt_attr(attributes[13]);
				correctingConfTask9_RecId_850.setFdt(attributes[14]);
				correctingConfTask9_RecId_850.setDd_att(attributes[15]);
				correctingConfTask9_RecId_850.setDd(attributes[16]);
				correctingConfTask9_RecId_850.setApptime_attr(attributes[17]);
				correctingConfTask9_RecId_850.setApptime(attributes[18]);
				correctingConfTask9_RecId_850.setEbd_attr(attributes[19]);
				correctingConfTask9_RecId_850.setEbd(attributes[20]);
				correctingConfTask9_RecId_850.setBan1_attr(attributes[21]);
				correctingConfTask9_RecId_850.setBan1(attributes[22]);
				correctingConfTask9_RecId_850.setBan2_attr(attributes[23]);
				correctingConfTask9_RecId_850.setBan2(attributes[24]);
				correctingConfTask9_RecId_850.setAn_attr(attributes[25]);
				correctingConfTask9_RecId_850.setAn(attributes[26]);

				treeViewList9_850.add(correctingConfTask9_RecId_850);
			}
			session.setAttribute("treeViewList9_850", treeViewList9_850);
			selectRequestData.setSubHeader(receivedSubHeader);
		}
	
		

		if (subData_851Recid != null && subData_851Recid.getSubHeader().getRecord_type().equals("851")) {

			SubHeader receivedSubHeader = subData_851Recid.getSubHeader();
			String[] subDataRows = subData_851Recid.getSubDataRows();

			List<CorrectingConfTask9_RecId_851> treeViewList9_851 = new ArrayList();
			treeViewList.add("851");
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 6);
//				System.out.println("attributes:=851======> " + Arrays.toString(attributes));
				CorrectingConfTask9_RecId_851 correctingConfTask9_RecId_851 = new CorrectingConfTask9_RecId_851();
				correctingConfTask9_RecId_851.setItem_num(attributes[0]);
				correctingConfTask9_RecId_851.setHnum(attributes[1]);
				correctingConfTask9_RecId_851.setHid_attr(attributes[2]);
				correctingConfTask9_RecId_851.setHid(attributes[3]);
				correctingConfTask9_RecId_851.setHunt_tli_attr(attributes[4]);
				correctingConfTask9_RecId_851.setHunt_tli(attributes[5]);

				treeViewList9_851.add(correctingConfTask9_RecId_851);
			}
			session.setAttribute("treeViewList9_851", treeViewList9_851);
			selectRequestData.setSubHeader(receivedSubHeader);
		}
		if (subData_852Recid != null && subData_852Recid.getSubHeader().getRecord_type().equals("852")) {

			SubHeader receivedSubHeader = subData_852Recid.getSubHeader();
			String[] subDataRows = subData_852Recid.getSubDataRows();

			List<CorrectingConfTask9_RecId_852> treeViewList9_852 = new ArrayList();
			treeViewList.add("852");
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 43);
//				System.out.println("attributes:=852======> " + Arrays.toString(attributes));
				CorrectingConfTask9_RecId_852 correctingConfTask9_RecId_852 = new CorrectingConfTask9_RecId_852();
				correctingConfTask9_RecId_852.setItemnum(attributes[0]);
				correctingConfTask9_RecId_852.setLnum(attributes[1]);
				correctingConfTask9_RecId_852.setNumname(attributes[2]);
				correctingConfTask9_RecId_852.setNum_nbr(attributes[3]);
				correctingConfTask9_RecId_852.setOrd_attr(attributes[4]);
				correctingConfTask9_RecId_852.setOrd(attributes[5]);
				correctingConfTask9_RecId_852.setLord_attr(attributes[6]);
				correctingConfTask9_RecId_852.setLord(attributes[7]);
				correctingConfTask9_RecId_852.setFdt_attr(attributes[8]);
				correctingConfTask9_RecId_852.setFdt(attributes[9]);
				correctingConfTask9_RecId_852.setDd_attr(attributes[10]);
				correctingConfTask9_RecId_852.setDd(attributes[11]);
				correctingConfTask9_RecId_852.setEcckt_attr(attributes[12]);
				correctingConfTask9_RecId_852.setEcckt(attributes[13]);
				correctingConfTask9_RecId_852.setCkr(attributes[14]);
				correctingConfTask9_RecId_852.setShared_nbr(attributes[15]);
				correctingConfTask9_RecId_852.setDisc_nbr(attributes[16]);
				correctingConfTask9_RecId_852.setRecckt(attributes[17]);
				correctingConfTask9_RecId_852.setTns_attr(attributes[18]);
				correctingConfTask9_RecId_852.setTns(attributes[19]);
				correctingConfTask9_RecId_852.setTers_attr(attributes[20]);
				correctingConfTask9_RecId_852.setTers(attributes[21]);
				correctingConfTask9_RecId_852.setCfa(attributes[22]);
				correctingConfTask9_RecId_852.setCcea(attributes[23]);
				correctingConfTask9_RecId_852.setIspid_attr(attributes[24]);
				correctingConfTask9_RecId_852.setIspid(attributes[25]);
				correctingConfTask9_RecId_852.setFecckt_attr(attributes[26]);
				correctingConfTask9_RecId_852.setFecckt(attributes[27]);
				correctingConfTask9_RecId_852.setNpord_attr(attributes[28]);
				correctingConfTask9_RecId_852.setNpord(attributes[29]);
				correctingConfTask9_RecId_852.setPorted_nbr(attributes[30]);
				correctingConfTask9_RecId_852.setRti_attr(attributes[31]);
				correctingConfTask9_RecId_852.setRti(attributes[32]);
				correctingConfTask9_RecId_852.setCbcid_attr(attributes[33]);
				correctingConfTask9_RecId_852.setCbcid(attributes[34]);
				correctingConfTask9_RecId_852.setCableid_attr(attributes[35]);
				correctingConfTask9_RecId_852.setCableid(attributes[36]);
				correctingConfTask9_RecId_852.setChan_pair_attr(attributes[37]);
				correctingConfTask9_RecId_852.setChan_pair(attributes[38]);
				correctingConfTask9_RecId_852.setOld_ord(attributes[39]);
				correctingConfTask9_RecId_852.setOld_lord(attributes[40]);
				correctingConfTask9_RecId_852.setOld_npord(attributes[41]);
				correctingConfTask9_RecId_852.setLoc_seq_num(attributes[42]);
				treeViewList9_852.add(correctingConfTask9_RecId_852);
			}
			session.setAttribute("treeViewList9_852", treeViewList9_852);
			selectRequestData.setSubHeader(receivedSubHeader);
		}
	//// for recId 560 and 568  ----> Anjali
		
				if (subData_560Recid != null && subData_560Recid.getSubHeader().getRecord_type().equals("560")) {

					SubHeader receivedSubHeader = subData_560Recid.getSubHeader();
					String[] subDataRows = subData_560Recid.getSubDataRows();
					List<CompletionProviderTask> treeViewList560 = new ArrayList();
					treeViewList.add("560");

					for (String subDataRow : subDataRows) {
						String[] attributes = mqReadUtil.getAttributes(subDataRow, 11);
//						System.out.println("subData_560_Recid======> " + Arrays.toString(attributes));

						CompletionProviderTask completionProviderTask = new CompletionProviderTask();

						completionProviderTask.setCver(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
						completionProviderTask.setAtn(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
						completionProviderTask.setRt(attributes[2] != null && attributes[2] != "" ? attributes[2] : " ");
						completionProviderTask.setEcver(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
						completionProviderTask
								.setD_t_sent_local(attributes[4] != null && attributes[4] != "" ? attributes[4] : " ");
						completionProviderTask.setResponse_d_t_sent_central_time(
								attributes[5] != null && attributes[5] != "" ? attributes[5] : " ");
						completionProviderTask
								.setComp_dt_attr(attributes[6] != null && attributes[6] != "" ? attributes[6] : " ");
						completionProviderTask
								.setComp_dt(attributes[7] != null && attributes[7] != "" ? attributes[7] : " ");
						completionProviderTask
								.setCompany_code_attr(attributes[8] != null && attributes[8] != "" ? attributes[8] : " ");
						completionProviderTask
								.setCompany_code(attributes[9] != null && attributes[9] != "" ? attributes[9] : " ");
						completionProviderTask.setAn(attributes[10] != null && attributes[10] != "" ? attributes[10] : " ");

						treeViewList560.add(completionProviderTask);

					}
					session.setAttribute("treeViewList560", treeViewList560);
					selectRequestData.setSubHeader(receivedSubHeader);

				}
				
				if (subData_568Recid != null && subData_568Recid.getSubHeader().getRecord_type().equals("568")) {

					SubHeader receivedSubHeader = subData_568Recid.getSubHeader();
					String[] subDataRows = subData_568Recid.getSubDataRows();
					List<CompletionActivityRLSOG6LscInfo> treeViewList568 = new ArrayList();
					treeViewList.add("568");

					for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);
//					System.out.println("subData_568_Recid======> " + Arrays.toString(attributes));
					

					CompletionActivityRLSOG6LscInfo completionActivityRLSOG6LscInfo = new CompletionActivityRLSOG6LscInfo();
					

					completionActivityRLSOG6LscInfo
					.setOld_dtm(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
					completionActivityRLSOG6LscInfo
					.setOld_ord(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
					completionActivityRLSOG6LscInfo
					.setOrd_attr(attributes[2] != null && attributes[2] != "" ? attributes[2] : " ");
					completionActivityRLSOG6LscInfo
					.setOrd(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
					completionActivityRLSOG6LscInfo
					.setFdt_attr(attributes[4] != null && attributes[4] != "" ? attributes[4] : " ");
					completionActivityRLSOG6LscInfo
					.setFdt(attributes[5] != null && attributes[5] != "" ? attributes[5] : " ");
					completionActivityRLSOG6LscInfo
					.setDd_attr(attributes[6] != null && attributes[6] != "" ? attributes[6] : " ");
					completionActivityRLSOG6LscInfo
					.setDd(attributes[7] != null && attributes[7] != "" ? attributes[7] : " ");
					completionActivityRLSOG6LscInfo
					.setComp_dt_attr(attributes[8] != null && attributes[8] != "" ? attributes[8] : " ");
					completionActivityRLSOG6LscInfo
					.setComp_dt(attributes[9] != null && attributes[9] != "" ? attributes[9] : " ");
					completionActivityRLSOG6LscInfo
					.setPosted_date_attr(attributes[10] != null && attributes[10] != "" ? attributes[10] : " ");
					completionActivityRLSOG6LscInfo
					.setPosted_date(attributes[11] != null && attributes[11] != "" ? attributes[11] : " ");
					completionActivityRLSOG6LscInfo
					.setApptime_attr(attributes[12] != null && attributes[12] != "" ? attributes[12] : " ");
					completionActivityRLSOG6LscInfo
					.setApptime(attributes[13] != null && attributes[13] != "" ? attributes[13] : " ");

					treeViewList568.add(completionActivityRLSOG6LscInfo);

					}
					session.setAttribute("treeViewList568", treeViewList568);
					selectRequestData.setSubHeader(receivedSubHeader);

					}
				
				/* Att cancel task 12 state screen get data treeviwe Recid-543-LSR- */
				//Mahendra
				SubData subData_543Recid = subDatas.get(RecIdFor9State.CS_RECID_DISPLAY_SBC_CANCEL.getRecIdValue());
				 if (subData_543Recid != null && subData_543Recid.getSubHeader().getRecord_type().equals("543")) {
		                List<AttCancelTask9> treeViewList9_543 = new ArrayList();
						SubHeader receivedSubHeader = subData_543Recid.getSubHeader();
						String[] subDataRows = subData_543Recid.getSubDataRows();
						treeViewList.add("543");	
						for (String subDataRow : subDataRows) {
							String[] attributes = mqReadUtil.getAttributes(subDataRow, 8);
//							System.out.println("attributes:=543:Reqid======> " + Arrays.toString(attributes));
							AttCancelTask9 attCancelTask = new AttCancelTask9();
							attCancelTask.setOrd(attributes[0]);
							attCancelTask.setOrd_status(attributes[1]);
							attCancelTask.setDd(attributes[2]);
							attCancelTask.setRcode(attributes[3]);
							attCancelTask.setJcode(attributes[4]);
							attCancelTask.setRdet(attributes[5]);
							attCancelTask.setDt_sent_local(attributes[6]);
							attCancelTask.setDt_sent_central_time(attributes[7]);
							
							treeViewList9_543.add(attCancelTask);
						}
						selectRequestData.setSubHeader(receivedSubHeader);
						session.setAttribute("treeViewList9_543", treeViewList9_543);
						
					}


		return treeViewList;
	}
	
	public List<ConfirmationTask_RecId_558> getUpdatedRows_558(List<ConfirmationTask_RecId_558> newList,List<ConfirmationTask_RecId_558> oldList) {

		List<ConfirmationTask_RecId_558> updatedList= new ArrayList<ConfirmationTask_RecId_558>();
		for (int i = 0; i < oldList.size(); i++) {
			ConfirmationTask_RecId_558 tableRow = newList.get(i);
			if (!tableRow.getOrd().equalsIgnoreCase(oldList.get(i).getOrd())) {

				// tableRow.setDd(oldList.get(i).getComp_dt());
				if (tableRow.getOrd().equalsIgnoreCase(oldList.get(i).getOrd())) {
					tableRow.setOrd_attr("N");
				} else {
					tableRow.setOld_ord(oldList.get(i).getOrd());

				}
			}

			if (tableRow.getDd_attr().equalsIgnoreCase("U") && tableRow.getDd().equalsIgnoreCase(oldList.get(i).getDd())) {
				tableRow.setDd_attr("N");
			}

			if (tableRow.getFdt_attr().equalsIgnoreCase("U") && tableRow.getFdt().equalsIgnoreCase(oldList.get(i).getFdt())) {
				tableRow.setFdt_attr("N");
			}

			if (tableRow.getComt_dt_attr().equalsIgnoreCase("U") && tableRow.getComt_dt().equalsIgnoreCase(oldList.get(i).getComt_dt())) {
				tableRow.setComt_dt_attr("N");
			}
			
			if (tableRow.getPosted_date_attr().equalsIgnoreCase("U") && tableRow.getPosted_date().equalsIgnoreCase(oldList.get(i).getPosted_date())) {
				tableRow.setPosted_date_attr("N");
			}
			
			if (tableRow.getApptime_attr().equalsIgnoreCase("U") && tableRow.getApptime().equalsIgnoreCase(oldList.get(i).getApptime())) {
				tableRow.setApptime_attr("N");
			}

			updatedList.add(tableRow);
		}
		

		System.err.println("Old List: "+oldList.toString());
		System.err.println("new List: "+newList.toString());
		return updatedList;
		}
	
	public List<ConfirmationTask_RecId_552> getUpdatedRows_552(List<ConfirmationTask_RecId_552> newList,List<ConfirmationTask_RecId_552> oldList) {

		List<ConfirmationTask_RecId_552> updatedList= new ArrayList<ConfirmationTask_RecId_552>();
		for (int i = 0; i < oldList.size(); i++) {
			ConfirmationTask_RecId_552 tableRow = newList.get(i);
			if(tableRow.getOrd()==null) {
				tableRow.setOrd("");
			}
			if (!tableRow.getOrd().equalsIgnoreCase(oldList.get(i).getOrd())) {

				// tableRow.setDd(oldList.get(i).getComp_dt());
				if (tableRow.getOrd().equalsIgnoreCase(oldList.get(i).getOrd())) {
					tableRow.setOrd_attr("N");
				} else {
					tableRow.setOld_ord(oldList.get(i).getOrd());

				
				}
			}
			
			if(tableRow.getLord() ==null) {
				tableRow.setLord("");
			}
			if (!tableRow.getLord().equalsIgnoreCase(oldList.get(i).getLord())) {

				// tableRow.setDd(oldList.get(i).getComp_dt());
				if (tableRow.getLord().equalsIgnoreCase(oldList.get(i).getLord())) {
					tableRow.setLord_attr("N");
				} else {
					tableRow.setOld_lord(oldList.get(i).getLord());

				
				}
			}
			
			if(tableRow.getNpord()==null) {
				tableRow.setNpord("");
			}
			if (!tableRow.getNpord().equalsIgnoreCase(oldList.get(i).getNpord())) {

				// tableRow.setDd(oldList.get(i).getComp_dt());
				if (tableRow.getNpord().equalsIgnoreCase(oldList.get(i).getNpord())) {
					tableRow.setNpord_attr("N");
				} else {
					tableRow.setOld_npord(oldList.get(i).getNpord());

				}
			}

			if (tableRow.getFdt_attr().equalsIgnoreCase("U") && tableRow.getFdt().equalsIgnoreCase(oldList.get(i).getFdt())) {
				tableRow.setFdt_attr("N");
			}

			if (tableRow.getDd_attr().equalsIgnoreCase("U") && tableRow.getDd().equalsIgnoreCase(oldList.get(i).getDd())) {
				tableRow.setDd_attr("N");
			}
			
			if (tableRow.getEcckt_attr().equalsIgnoreCase("U") && tableRow.getEcckt().equalsIgnoreCase(oldList.get(i).getEcckt())) {
				tableRow.setEcckt_attr("N");
			}
			
			if (tableRow.getTns_attr().equalsIgnoreCase("U") && tableRow.getTns().equalsIgnoreCase(oldList.get(i).getTns())) {
				tableRow.setTns_attr("N");
			}
			
			if (tableRow.getTers_attr().equalsIgnoreCase("U") && tableRow.getTers().equalsIgnoreCase(oldList.get(i).getTers())) {
				tableRow.setTers_attr("N");
			}
			
			if (tableRow.getIspid_attr().equalsIgnoreCase("U") && tableRow.getIspid().equalsIgnoreCase(oldList.get(i).getIspid())) {
				tableRow.setIspid_attr("N");
			}
			
			if (tableRow.getFecckt_attr().equalsIgnoreCase("U") && tableRow.getFecckt().equalsIgnoreCase(oldList.get(i).getFecckt())) {
				tableRow.setFecckt_attr("N");
			}
			
			if (tableRow.getRti_attr().equalsIgnoreCase("U") && tableRow.getRti().equalsIgnoreCase(oldList.get(i).getRti())) {
				tableRow.setRti_attr("N");
			}
			
			if (tableRow.getCbcid_attr().equalsIgnoreCase("U") && tableRow.getCbcid().equalsIgnoreCase(oldList.get(i).getCbcid())) {
				tableRow.setCbcid_attr("N");
			}
			
			if (tableRow.getCableid_attr().equalsIgnoreCase("U") && tableRow.getCableid().equalsIgnoreCase(oldList.get(i).getCableid())) {
				tableRow.setCableid_attr("N");
			}
			
			if (tableRow.getChan_pair_attr().equalsIgnoreCase("U") && tableRow.getChain_pair().equalsIgnoreCase(oldList.get(i).getChain_pair())) {
				tableRow.setChan_pair_attr("N");
			}

			updatedList.add(tableRow);
		}
		System.err.println("Old List: "+oldList.toString());
		System.err.println("new List: "+newList.toString());
		return updatedList;
		}
	
		
		public List<ConfirmationTask_RecId_551> getUpdatedRows_551(List<ConfirmationTask_RecId_551> newList,
				List<ConfirmationTask_RecId_551> oldList) {

			List<ConfirmationTask_RecId_551> updatedList = new ArrayList<ConfirmationTask_RecId_551>();
			for (int i = 0; i < oldList.size(); i++) {
				ConfirmationTask_RecId_551 tableRow = newList.get(i);

				if (tableRow.getHid_attr().equalsIgnoreCase("U")
						&& tableRow.getHid().equalsIgnoreCase(oldList.get(i).getHid())) {
					tableRow.setHid_attr("N");
				}

				if (tableRow.getHunt_tli_attr().equalsIgnoreCase("U")
						&& tableRow.getHunt_tli().equalsIgnoreCase(oldList.get(i).getHunt_tli())) {
					tableRow.setHunt_tli_attr("N");
				}

				updatedList.add(tableRow);
			}

			System.err.println("Old List: " + oldList.toString());
			System.err.println("new List: " + newList.toString());
			return updatedList;
		}
		 

	// *********************************Saurabh sprint11 code End
	// ***************************************
	
	private List jeopardyTaskListData(SelectRequestData selectRequestData, Map<String, SubData> subDatas, HttpSession session,
			List treeViewList) {
		
		SubData subData_581Recid = subDatas.get(RecIdFor12State.CS_RECID_JEOPARDY_ORDNUM.getRecIdValue());
		SubData subData_582Recid = subDatas.get(RecIdFor12State.CS_RECID_JEOPARDY_UPDATE.getRecIdValue());
		SubData subData_583Recid = subDatas.get(RecIdFor12State.CS_RECID_JEOPARDY_DETAIL.getRecIdValue());

		if (subData_581Recid != null && subData_581Recid.getSubHeader().getRecord_type().equals("581")) {

		SubHeader receivedSubHeader = subData_581Recid.getSubHeader();
		String[] subDataRows = subData_581Recid.getSubDataRows();
		List<JeopardyTask12STRechId581> treeViewList_581 = new ArrayList();
		//List<String> ordList= new ArrayList();
		treeViewList.add("581");
		int i = 0;
		for (String subDataRow : subDataRows) {

//		System.out.println( "***************** subDataRows "+ subDataRow);
		String[] attributes = mqReadUtil.getAttributes(subDataRow, 2);
//		System.out.println("attributes:=581:Reqid======> " + Arrays.toString(attributes));
		JeopardyTask12STRechId581 jeopardyTask12STRechId581 = new JeopardyTask12STRechId581();

		jeopardyTask12STRechId581.setOrd(attributes[0]);
		jeopardyTask12STRechId581.setSpeccode(attributes[1]);


		
//		System.out.println("jeopardyTask12STRechId581"+ jeopardyTask12STRechId581);
		treeViewList_581.add(jeopardyTask12STRechId581);

		}

		session.setAttribute("treeViewList_581", treeViewList_581);
		String test = treeViewList_581.get(0).getOrd();
		session.setAttribute("test", test);
		selectRequestData.setSubHeader(receivedSubHeader);

		}

		if (subData_583Recid != null && subData_583Recid.getSubHeader().getRecord_type().equals("583")) {

		SubHeader receivedSubHeader = subData_583Recid.getSubHeader();
		String[] subDataRows = subData_583Recid.getSubDataRows();
		List<JeopardyTask12STRechId583> treeViewList_583 = new ArrayList();
		treeViewList.add("583");
		int i = 0;
		for (String subDataRow : subDataRows) {
		String[] attributes = mqReadUtil.getAttributes(subDataRow, 20);
//		System.out.println("attributes:=583:Reqid======> " + Arrays.toString(attributes));
		JeopardyTask12STRechId583 jeopardyTask12STRechId583 = new JeopardyTask12STRechId583();

		jeopardyTask12STRechId583.setEcver_attr(attributes[0]);
		jeopardyTask12STRechId583.setEcver(attributes[1]);
		jeopardyTask12STRechId583.setJep_ecckt_attr(attributes[2]);
		jeopardyTask12STRechId583.setJep_ecckt(attributes[3]);
		jeopardyTask12STRechId583.setJep_tns_attr(attributes[4]);
		jeopardyTask12STRechId583.setJep_tns(attributes[5]);
		jeopardyTask12STRechId583.setJep_cfa_attr(attributes[6]);
		jeopardyTask12STRechId583.setJep_cfa(attributes[7]);
		jeopardyTask12STRechId583.setJep_ccea_attr(attributes[8]);
		jeopardyTask12STRechId583.setJep_ccea(attributes[9]);
		jeopardyTask12STRechId583.setCbcid_attr(attributes[10]);
		jeopardyTask12STRechId583.setCbcid(attributes[11]);
		jeopardyTask12STRechId583.setCableid_attr(attributes[12]);
		jeopardyTask12STRechId583.setCableid(attributes[13]);
		jeopardyTask12STRechId583.setChan_pair_attr(attributes[14]);
		jeopardyTask12STRechId583.setChan_pair(attributes[15]);
		jeopardyTask12STRechId583.setApptime_attr(attributes[16]);
		jeopardyTask12STRechId583.setApptime(attributes[17]);
		jeopardyTask12STRechId583.setClec_note_attr(attributes[18]);
		jeopardyTask12STRechId583.setClec_note(attributes[19]);

		treeViewList_583.add(jeopardyTask12STRechId583);
		}
		session.setAttribute("treeViewList_583", treeViewList_583);
		selectRequestData.setSubHeader(receivedSubHeader);

		}
		return treeViewList;
	}
	
	public List completionProviderTaskWithLoss(SelectRequestData selectRequestData, Map<String, SubData> subDatas,
			HttpSession session, List treeViewList) {
		
		SubData subData_560Recid = subDatas.get(RecIdFor9State.CS_RECID_COMPLETE.getRecIdValue());
		SubData subData_568Recid = subDatas.get(RecIdFor9State.CS_RECID_COMPLETE_REQORD.getRecIdValue());
		SubData subData_577Recid = subDatas.get(RecIdFor12State.CS_RECID_LOSS_LSR_INFO.getRecIdValue());
		SubData subData_578Recid = subDatas.get(RecIdFor12State.CS_RECID_LOSS_INFO.getRecIdValue());
		
		if (subData_560Recid != null && subData_560Recid.getSubHeader().getRecord_type().equals("560")) {

			SubHeader receivedSubHeader = subData_560Recid.getSubHeader();
			String[] subDataRows = subData_560Recid.getSubDataRows();
			List<CompletionProviderTask> treeViewList560 = new ArrayList();
			treeViewList.add("560");

			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 11);

				CompletionProviderTask completionProviderTask = new CompletionProviderTask();

				completionProviderTask.setCver(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
				completionProviderTask.setAtn(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
				completionProviderTask.setRt(attributes[2] != null && attributes[2] != "" ? attributes[2] : " ");
				completionProviderTask.setEcver(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
				completionProviderTask
						.setD_t_sent_local(attributes[4] != null && attributes[4] != "" ? attributes[4] : " ");
				completionProviderTask.setResponse_d_t_sent_central_time(
						attributes[5] != null && attributes[5] != "" ? attributes[5] : " ");
				completionProviderTask
						.setComp_dt_attr(attributes[6] != null && attributes[6] != "" ? attributes[6] : " ");
				completionProviderTask
						.setComp_dt(attributes[7] != null && attributes[7] != "" ? attributes[7] : " ");
				completionProviderTask
						.setCompany_code_attr(attributes[8] != null && attributes[8] != "" ? attributes[8] : " ");
				completionProviderTask
						.setCompany_code(attributes[9] != null && attributes[9] != "" ? attributes[9] : " ");
				completionProviderTask.setAn(attributes[10] != null && attributes[10] != "" ? attributes[10] : " ");

				treeViewList560.add(completionProviderTask);

			}
			session.setAttribute("treeViewList560", treeViewList560);
			selectRequestData.setSubHeader(receivedSubHeader);

		}
		
		if (subData_568Recid != null && subData_568Recid.getSubHeader().getRecord_type().equals("568")) {

			SubHeader receivedSubHeader = subData_568Recid.getSubHeader();
			String[] subDataRows = subData_568Recid.getSubDataRows();
			List<CompletionActivityRLSOG6LscInfo> treeViewList568 = new ArrayList();
			treeViewList.add("568");

			for (String subDataRow : subDataRows) {
			String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);
			

			CompletionActivityRLSOG6LscInfo completionActivityRLSOG6LscInfo = new CompletionActivityRLSOG6LscInfo();
			

			completionActivityRLSOG6LscInfo
			.setOld_dtm(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
			completionActivityRLSOG6LscInfo
			.setOld_ord(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
			completionActivityRLSOG6LscInfo
			.setOrd_attr(attributes[2] != null && attributes[2] != "" ? attributes[2] : " ");
			completionActivityRLSOG6LscInfo
			.setOrd(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
			completionActivityRLSOG6LscInfo
			.setFdt_attr(attributes[4] != null && attributes[4] != "" ? attributes[4] : " ");
			completionActivityRLSOG6LscInfo
			.setFdt(attributes[5] != null && attributes[5] != "" ? attributes[5] : " ");
			completionActivityRLSOG6LscInfo
			.setDd_attr(attributes[6] != null && attributes[6] != "" ? attributes[6] : " ");
			completionActivityRLSOG6LscInfo
			.setDd(attributes[7] != null && attributes[7] != "" ? attributes[7] : " ");
			completionActivityRLSOG6LscInfo
			.setComp_dt_attr(attributes[8] != null && attributes[8] != "" ? attributes[8] : " ");
			completionActivityRLSOG6LscInfo
			.setComp_dt(attributes[9] != null && attributes[9] != "" ? attributes[9] : " ");
			completionActivityRLSOG6LscInfo
			.setPosted_date_attr(attributes[10] != null && attributes[10] != "" ? attributes[10] : " ");
			completionActivityRLSOG6LscInfo
			.setPosted_date(attributes[11] != null && attributes[11] != "" ? attributes[11] : " ");
			completionActivityRLSOG6LscInfo
			.setApptime_attr(attributes[12] != null && attributes[12] != "" ? attributes[12] : " ");
			completionActivityRLSOG6LscInfo
			.setApptime(attributes[13] != null && attributes[13] != "" ? attributes[13] : " ");

			treeViewList568.add(completionActivityRLSOG6LscInfo);

			}
			session.setAttribute("treeViewList568", treeViewList568);
			selectRequestData.setSubHeader(receivedSubHeader);

			}

		if (subData_577Recid != null && subData_577Recid.getSubHeader().getRecord_type().equals("577")) {

			SubHeader receivedSubHeader = subData_577Recid.getSubHeader();
			String[] subDataRows = subData_577Recid.getSubDataRows();
			List<CompletionProviderTaskWithLossLasrInfo> treeViewList577 = new ArrayList();
			treeViewList.add("577");

			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 11);

				CompletionProviderTaskWithLossLasrInfo completionProviderTaskWithLossLasrInfo = new CompletionProviderTaskWithLossLasrInfo();

				completionProviderTaskWithLossLasrInfo
						.setA_numname_attr(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
				completionProviderTaskWithLossLasrInfo
						.setA_numname(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
				completionProviderTaskWithLossLasrInfo
						.setA_numnbr_attr(attributes[2] != null && attributes[2] != "" ? attributes[2] : " ");
				completionProviderTaskWithLossLasrInfo
						.setA_numnbr(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
				completionProviderTaskWithLossLasrInfo
						.setA_wtn_attr(attributes[4] != null && attributes[4] != "" ? attributes[4] : " ");
				completionProviderTaskWithLossLasrInfo
						.setA_wtn(attributes[5] != null && attributes[5] != "" ? attributes[5] : " ");
				completionProviderTaskWithLossLasrInfo
						.setA_ecckt_attr(attributes[6] != null && attributes[6] != "" ? attributes[6] : " ");
				completionProviderTaskWithLossLasrInfo
						.setA_ecckt(attributes[7] != null && attributes[7] != "" ? attributes[7] : " ");
				completionProviderTaskWithLossLasrInfo
						.setA_cvd_attr(attributes[8] != null && attributes[8] != "" ? attributes[8] : " ");
				completionProviderTaskWithLossLasrInfo
						.setA_cvd(attributes[9] != null && attributes[9] != "" ? attributes[9] : " ");

				treeViewList577.add(completionProviderTaskWithLossLasrInfo);

			}
			session.setAttribute("treeViewList577", treeViewList577);
			selectRequestData.setSubHeader(receivedSubHeader);
		}

		if (subData_578Recid != null && subData_578Recid.getSubHeader().getRecord_type().equals("578")) {

			SubHeader receivedSubHeader = subData_578Recid.getSubHeader();
			String[] subDataRows = subData_578Recid.getSubDataRows();
			List<CompletionProviderTaskLossInfo> treeViewList578 = new ArrayList();
			treeViewList.add("578");

			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 10);

				CompletionProviderTaskLossInfo completionProviderTaskLossInfo = new CompletionProviderTaskLossInfo();

				completionProviderTaskLossInfo
						.setNumname_attr(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
				completionProviderTaskLossInfo
						.setNumname(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
				completionProviderTaskLossInfo
						.setNumnbr_attr(attributes[2] != null && attributes[2] != "" ? attributes[2] : " ");
				completionProviderTaskLossInfo
						.setNumnbr(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
				completionProviderTaskLossInfo
						.setWtn_attr(attributes[4] != null && attributes[4] != "" ? attributes[4] : " ");
				completionProviderTaskLossInfo
						.setWtn(attributes[5] != null && attributes[5] != "" ? attributes[5] : " ");
				completionProviderTaskLossInfo
						.setEcckt_attr(attributes[6] != null && attributes[6] != "" ? attributes[6] : " ");
				completionProviderTaskLossInfo
						.setEcckt(attributes[7] != null && attributes[7] != "" ? attributes[7] : " ");
				completionProviderTaskLossInfo
						.setCvd_attr(attributes[8] != null && attributes[8] != "" ? attributes[8] : " ");
				completionProviderTaskLossInfo
						.setCvd(attributes[9] != null && attributes[9] != "" ? attributes[9] : " ");

				treeViewList578.add(completionProviderTaskLossInfo);
			}
			session.setAttribute("treeViewList578", treeViewList578);
			selectRequestData.setSubHeader(receivedSubHeader);
		}
		
		return treeViewList;
	}

		
	public List<ShowError> getErrorList() {
		return showError;
	}

	public List<ShowError> getUpdatedErrorList() {
		return focError;
	}
	public List<ShowError> getErrorLists() {
		return postbilltask;
	}
}
