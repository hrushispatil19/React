package com.att.lasr.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.lasr.model.Header;
import com.att.lasr.model.MQReceivedData;
import com.att.lasr.model.NotesFupBindingData12States;
import com.att.lasr.model.ShowError;
import com.att.lasr.model.SubData;
import com.att.lasr.model.SubHeader;
import com.att.lasr.model.UpdateOrderNumberData;
import com.att.lasr.model.UpdateOrderNumberRow;
import com.att.lasr.utils.MQMessageStringBuilder;
import com.att.lasr.utils.MQReadUtil;
import com.att.lasr.utils.MQWriteUtil;
import com.att.lasr.utils.enums.LastInd;
import com.att.lasr.utils.enums.LogInd;
import com.att.lasr.utils.enums.Process;
import com.att.lasr.utils.enums.ProcessGroupInd;
import com.att.lasr.utils.enums.ProcessMode;
import com.att.lasr.utils.enums.RecIdFor12State;

@Service
public class UpdateOrderNumberService {

	@Autowired
	private MQReadUtil mqReadUtil;

	@Autowired
	private MQWriteUtil mqWriteUtil;

	@Autowired
	HttpSession httpSession;
	
	List<ShowError> showUpdateErrorList = new ArrayList<ShowError>();

	public String writeSaveUpdateOrderDataToMQ(List<UpdateOrderNumberRow> updateOrderNumberDataList, String userId,
			String object_handle, HttpSession session) {
		
		String numCount = getNumCount(updateOrderNumberDataList.size() + 1);
		Header header = prepareSaveHeader(userId, object_handle, numCount);
		StringBuilder subHeaderandData = new StringBuilder();
		String rc="";

		String dataString = "";

		// 049 RecId code
		List<NotesFupBindingData12States> dataObject_049 = (List<NotesFupBindingData12States>) session
				.getAttribute("treeViewList_049");

		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();
		SubHeader subHeader = prepareSaveSubHeader(RecIdFor12State.CS_RECID_HEADER.getRecIdValue());

		for (NotesFupBindingData12States notesFupBindingData12States : dataObject_049) {
			
			session.setAttribute("Lrs_No", notesFupBindingData12States.getRequest_id().substring(0, 17).trim());
			dataString = notesFupBindingData12States.getNotesFupBindingData12String();
			subHeaderandData.append(mqMessageStringBuilder.addHeader(header));
			subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString).toString());

		}

		subHeader = prepareSaveSubHeader(RecIdFor12State.CS_RECID_UPDATE_COMPLETE_REQORD.getRecIdValue());
		int index=0;
		
		
		
		for (UpdateOrderNumberRow row : updateOrderNumberDataList) {
			
			if(row.getOrd_attr().contains("U")) {
				row.setOrd_attr("Y");
			}
			if(row.getFdt_attr().contains("U")) {
				row.setFdt_attr("Y");
			}
			if(row.getDd_attr().contains("U")) {
				row.setDd_attr("Y");
			}
			if(row.getApptime_attr().contains("U")) {
				row.setApptime_attr("Y");
			}
			if(row.getApptime_attr()== null || row.getApptime_attr()=="")
			{
				row.setApptime_attr("R");
			}
			
			dataString = row.getUpdateOrderDataString();
			subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString));
			
			index++;
		}
		
		//System.out.println("mqMessageStringBuilder ->>"+mqMessageStringBuilder.getMqMessageString());
		
		boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder,session);

		if (isWritten) {

			MQReceivedData mqReceivedData;
			
			try {

			mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
			 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
			  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
		//	  Header receivedHeader = mqReceivedData.getHeader(); 
			  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
					System.out.println("*************inside if*************** "); 
					mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
				} 
			  
			  
			  System.out.println(mqReceivedData.getHeader().toString()); 
		} catch (Exception e) { 
			// TODO Auto-generated catch block 
			 mqReceivedData = mqReadUtil.readDataFromMQ(session); 
			e.printStackTrace(); 


		}
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
			Header receivedHeader = mqReceivedData.getHeader();
			System.out.println("returncode Edit Ecckt::::" + receivedHeader.getReturn_code());
			SubData subData = subDatas.get(RecIdFor12State.CS_RECID_ERROR.getRecIdValue());
			ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
			if (subData != null) {
				String[] subDataRows = subData.getSubDataRows();
					
				String[] attributes = mqReadUtil.getAttributes(subDataRows[0], 4);
				
				if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {

					String uon_msg = readErrorMsgsJson.getErrorMsg("LG0017");
					session.setAttribute("uon_err_msg", uon_msg);

					ShowErrorService showErrorService = new ShowErrorService();
					showUpdateErrorList = showErrorService.getErrorList(attributes[0].trim(), attributes[1],
							"", "U");

					session.setAttribute("showError", showUpdateErrorList);

				}

				
			}
			if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("000")) {
				rc= receivedHeader.getReturn_code().trim();
				String uon_msg = readErrorMsgsJson.getErrorMsg("LG0016");
				session.setAttribute("uon_info_msg", uon_msg);

			}
			if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("889")) {

				String ecckt_msg = readErrorMsgsJson.getErrorMsg("LG0067");
				session.setAttribute("ecckt_err_msg", ecckt_msg);

			}
			if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("888")) {

				String ecckt_msg = readErrorMsgsJson.getErrorMsg("LG0022");
				session.setAttribute("ecckt_err_msg", ecckt_msg);

			}

			
		}
		
		return rc;
	}
	
	public List<UpdateOrderNumberRow> getUpdatedRows(List<UpdateOrderNumberRow> newList,List<UpdateOrderNumberRow> oldList) {
		
		List<UpdateOrderNumberRow> updatedList= new ArrayList<UpdateOrderNumberRow>();
		for(int i=0;i<newList.size();i++)
		{
			UpdateOrderNumberRow tableRow=newList.get(i);
			if(!tableRow.getOrd().equalsIgnoreCase(oldList.get(i).getOrd()))
			{
				tableRow.setOld_ord(oldList.get(i).getOrd());
				updatedList.add(tableRow);
			}
		}
		return updatedList;
	}
	
	public List<ShowError> getUpdatedErrorList() {
		return showUpdateErrorList;
	}

	
	private SubHeader prepareSaveSubHeader(String recId) {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_UPDATE.getProcessModeCode());
		subHeader.setRecord_type(recId);
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private Header prepareSaveHeader(String user_id, String object_handle, String numCount) {
		// Prepare Header
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_REQUEST.getProcessCode());
		header.setTab_ind("574");
		header.setProcess_group_ind(ProcessGroupInd.SAVE_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail(numCount);
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}

	private String getNumCount(int size) {
		String numCount = String.format("%04d", size);
		return numCount;
	}

}
