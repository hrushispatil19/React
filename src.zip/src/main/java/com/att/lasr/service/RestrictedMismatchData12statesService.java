package com.att.lasr.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.lasr.model.Header;
import com.att.lasr.model.MQReceivedData;
import com.att.lasr.model.RestrictedMismatchData12states;
import com.att.lasr.model.RestrictedMismatchTableRow12states;
import com.att.lasr.model.SubData;
import com.att.lasr.model.SubHeader;
import com.att.lasr.utils.MQMessageStringBuilder;
import com.att.lasr.utils.MQReadUtil;
import com.att.lasr.utils.MQWriteUtil;
import com.att.lasr.utils.enums.LastInd;
import com.att.lasr.utils.enums.LogInd;
import com.att.lasr.utils.enums.Process;
import com.att.lasr.utils.enums.ProcessGroupInd;
import com.att.lasr.utils.enums.ProcessMode;
import com.att.lasr.utils.enums.RecIdFor12State;

@Service
public class RestrictedMismatchData12statesService {

	@Autowired
	private MQReadUtil mqReadUtil;

	@Autowired
	private MQWriteUtil mqWriteUtil;

	public RestrictedMismatchData12states writeRestrictedMismatchData12statesToMQ(
			RestrictedMismatchData12states restrictedMismatchData, String user_id, String object_handle,HttpSession session) {

		Header header = prepareHeader(user_id,object_handle);
		SubHeader subHeader = prepareSubHeader();

		System.out.println("Header value====================>" + header.toString());
		System.out.println("subHeader====================>" + subHeader.toString());
		// RestrictedMismatchData.setPrevnext_cde("R");

		String dataString = restrictedMismatchData.getRestrictedMismatchString();
		System.out.println("===================>" + dataString);

		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder().addHeaderSubHeaderAndData(header,
				subHeader, dataString);

		boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder,session);

		System.out.println("====isWritten=======================>" + isWritten);
		RestrictedMismatchData12states restrictedMismatchDataFromMQ = restrictedMismatchData;

		if (isWritten) {

			MQReceivedData mqReceivedData;
			
			try {

			mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
			 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
			  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
		//	  Header receivedHeader = mqReceivedData.getHeader(); 
			  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
					System.out.println("*************inside if*************** "); 
					mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
				} 
			  
			  
			  System.out.println(mqReceivedData.getHeader().toString()); 
		} catch (Exception e) { 
			// TODO Auto-generated catch block 
			 mqReceivedData = mqReadUtil.readDataFromMQ(session); 
			e.printStackTrace(); 


		}
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
			Header receivedHeader = mqReceivedData.getHeader();
			restrictedMismatchData.setHeader(receivedHeader);

			SubData subData = subDatas.get(RecIdFor12State.CS_RECID_MISMATCH.getRecIdValue());
			if (subData != null) {
				SubHeader receivedSubHeader = subData.getSubHeader();
				String[] subDataRows = subData.getSubDataRows();

				List<RestrictedMismatchTableRow12states> restrictedMismatchTableRows = new ArrayList<>();

				for (String subDataRow : subDataRows) {

					String[] attributes = mqReadUtil.getAttributes(subDataRow, 23);
//					System.out.println("attributes: " + Arrays.toString(attributes));
					RestrictedMismatchTableRow12states misMatchTableRow = new RestrictedMismatchTableRow12states();

					misMatchTableRow.setWorked_ind_attr(attributes[0]);
					misMatchTableRow.setWorked_ind(attributes[1]);
					misMatchTableRow.setNotif_typ(attributes[2]);
					misMatchTableRow.setDate_time_mismatched(attributes[3]);
					misMatchTableRow.setRequest_id(attributes[4]);
					misMatchTableRow.setCompany_code(attributes[5]);
					misMatchTableRow.setPon(attributes[6]);
					misMatchTableRow.setOrder_no(attributes[7]);
					misMatchTableRow.setStatus(attributes[8]);
					misMatchTableRow.setLocation(attributes[9]);
					misMatchTableRow.setError_message(attributes[10]);
					misMatchTableRow.setRcode(attributes[11]);
					misMatchTableRow.setRdet(attributes[12]);
					misMatchTableRow.setEsdd(attributes[13]);
					misMatchTableRow.setDate(attributes[14]);
					misMatchTableRow.setJcode(attributes[15]);
					misMatchTableRow.setDate_time_entered(attributes[16]);
					misMatchTableRow.setOrder_sfx(attributes[17]);
					misMatchTableRow.setRelease_version(attributes[18]);
					misMatchTableRow.setUser_id(attributes[19]);
					misMatchTableRow.setTotal_record(attributes[20]);
					misMatchTableRow.setStart_page(attributes[21]);
					misMatchTableRow.setEnd_page(attributes[22]);

					restrictedMismatchTableRows.add(misMatchTableRow);
				}
				restrictedMismatchDataFromMQ.setSubHeader(receivedSubHeader);
				restrictedMismatchDataFromMQ.setRestrictedMisTableRows12states(restrictedMismatchTableRows);
				System.out.println("restrictedMismatchDataFromMQ.getRestrictedMisTableRows12states()  size()"+restrictedMismatchDataFromMQ.getRestrictedMisTableRows12states().size());
			}
		}
		return restrictedMismatchDataFromMQ;

	}

	private SubHeader prepareSubHeader() {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_RETRIEVE.getProcessModeCode());
		subHeader.setRecord_type(RecIdFor12State.CS_RECID_MISMATCH.getRecIdValue());
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private Header prepareHeader(String user_id, String object_handle) {
		// Prepare Header
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_SELECT_MISMATCH.getProcessCode());
		header.setTab_ind(null);
		header.setProcess_group_ind(ProcessGroupInd.RETRIEVE_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail("0001");
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}

}
