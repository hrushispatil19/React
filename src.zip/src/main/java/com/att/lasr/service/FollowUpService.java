package com.att.lasr.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.att.lasr.model.FollowUpData;
import com.att.lasr.model.FollowUpTableRow;
import com.att.lasr.model.Header;
import com.att.lasr.model.MQReceivedData;
import com.att.lasr.model.NotesFupBindingData12States;
import com.att.lasr.model.SubData;
import com.att.lasr.model.SubHeader;
import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;
import com.att.lasr.utils.MQMessageStringBuilder;
import com.att.lasr.utils.MQReadUtil;
import com.att.lasr.utils.MQWriteUtil;
import com.att.lasr.utils.enums.LastInd;
import com.att.lasr.utils.enums.ProcessGroupInd;
import com.att.lasr.utils.enums.ProcessMode;
import com.att.lasr.utils.enums.RecIdFor12State;

@Service
public class FollowUpService {

	@Autowired
	private MQReadUtil mqReadUtil;

	@Autowired
	private MQWriteUtil mqWriteUtil;

	public void writeCloseTransactionDataToMQ(FollowUpData followUpData,
			ArrayList<FollowUpTableRow> followUpTableRow, String user_id, HttpSession session) {
        System.out.println("calling writeCloseTransactionDataToMQ");
        
        String reg = (String) session.getAttribute("myReg");
		// user_id = EnvRegionController.getLoginObject().getUser_id();
        List<NotesFupBindingData12States> treeViewList = (List<NotesFupBindingData12States>) session
				.getAttribute("treeViewList_049");
		String version = treeViewList.get(0).getRequest_id().substring(15, 17);
		System.out.println("**************"+ version + "************");
        followUpData.setNotes_attr("Y");
        followUpData.setUser_id(user_id);
        followUpData.setUser_id_attr("Y");
        followUpData.setLasr_ver_attr("Y");
        followUpData.setLasr_ver(version);
        followUpData.setFollow_up_date_attr("Y");
        Boolean indicator = null;
        followUpData.setNotes_attr("Y");
        if(followUpData.getNotes() != "" ) {
        	indicator = true;
        }
        else {
        	indicator = false;
        }
        Header header = prepareHeader(user_id,indicator);
		SubHeader subHeaderRecid049 = prepareSubHeader();
		SubHeader subHeader1Editablenotes = prepareSubHeader1();
		SubHeader subHeader2Recid532 = prepareSubHeader2();
		String dataString = followUpData.getFollowUpData();
		 
		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();
		String Recid_049 = createdataforMq(treeViewList);
		String Recid_049_9states = createdataforMq9states(treeViewList);
		FollowUpTableRow followUpTableRow1 = (FollowUpTableRow) session.getAttribute("followUpUser");
		if (reg.equals("12 States")){
		mqMessageStringBuilder.addHeaderSubHeaderAndData(header,
				subHeaderRecid049, Recid_049);}
		else {
			mqMessageStringBuilder.addHeaderSubHeaderAndData(header,
					subHeaderRecid049, Recid_049_9states);
		}
		System.out.println(followUpData.getNotes_attr());
		if(followUpData.getNotes() != ""  ) {
			
			mqMessageStringBuilder.appendSubHeaderAndData(subHeader1Editablenotes, dataString);
			
		}
		
		else {
			String tablepart = createdataforMq2(followUpTableRow1,followUpData);
			mqMessageStringBuilder.appendSubHeaderAndData(subHeader2Recid532, tablepart);
		}
		
		
		 
	//	FollowUpData followup = new FollowUpData();
	//	String followup1=session.getAttribute("followUpData");
	
		 		
		//	mqMessageStringBuilder.appendSubHeaderAndData(subHeader1, final2);
	//mqMessageStringBuilder.appendSubHeaderAndData(subHeader2, final3);
	

		System.out.println("mq message string builder response" + mqMessageStringBuilder);
		boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder,session);
		System.out.println(isWritten);
		if (isWritten) {

			MQReceivedData mqReceivedData;
			
			try {

			mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
			 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
			  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
		//	  Header receivedHeader = mqReceivedData.getHeader(); 
			  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
					System.out.println("*************inside if*************** "); 
					mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
				} 
			  
			  
			  System.out.println(mqReceivedData.getHeader().toString()); 
		} catch (Exception e) { 
			// TODO Auto-generated catch block 
			 mqReceivedData = mqReadUtil.readDataFromMQ(session); 
			e.printStackTrace(); 


		}
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
			Header receivedHeader = mqReceivedData.getHeader();
			System.out.println(receivedHeader.toString());}
		return;

	}

	private String createdataforMq1(ArrayList<FollowUpData> followUpData) {
		StringBuilder sb = new StringBuilder();
		
		// sb.append(treeViewList).append(Constants.TAB) .append(Constants.TAB);
		sb.append(followUpData.get(0).getNotes_datetime()).append(Constants.TAB);
		sb.append(followUpData.get(0).getUser_id_attr()).append(Constants.TAB);
		sb.append(followUpData.get(0).getUser_id()).append(Constants.TAB);
		sb.append(followUpData.get(0).getLasr_ver_attr()).append(Constants.TAB);
		sb.append(followUpData.get(0).getLasr_ver()).append(Constants.TAB);
		sb.append(followUpData.get(0).getFollow_up_date_attr()).append(Constants.TAB);
		sb.append(followUpData.get(0).getFollow_up_date()).append(Constants.TAB);
		sb.append(followUpData.get(0).getNotes_attr()).append(Constants.TAB);
		sb.append(followUpData.get(0).getNotes()).append(Constants.TAB).append(Constants.TAB);

		String finalString1 = FormatUtil.getValueWithSpaces(sb.toString(), 2400);
		return finalString1;
	}

	private String createdataforMq2(FollowUpTableRow followUpTableRow,FollowUpData followUpData) {
		StringBuilder sb = new StringBuilder();
		
		 String worked_ind_attr="Y";
		
		 
		 String worked_ind=followUpData.getWorked_ind();
		 if(worked_ind == null ) {
			 worked_ind= "N";	 
		 }
		 else if (worked_ind.equals("on")) {
			 worked_ind= "Y";	
		 }
		 else {
			 worked_ind= "N";	
		 }
		 String cancel_ind_attr="Y";
		 
		 String cancel_ind=followUpData.getCancel_ind();
		 if(cancel_ind == null ) {
			 cancel_ind="N";
		 }
		 else if (cancel_ind.equals("on")) {
			 cancel_ind="Y";
		 }
		 else {
			 cancel_ind="N";
		 }
		 String notes_datetime=followUpTableRow.getNotes_datetime();
		 String user_id_attr=followUpTableRow.getUser_id_attr();
		 String user_id=followUpTableRow.getUser_id();
		 String lasr_ver_attr=followUpTableRow.getLasr_ver_attr();
		 String lasr_ver=followUpTableRow.getLasr_ver();
		 String follow_up_date_attr=followUpTableRow.getFollow_up_date_attr();
		 String follow_up_date=followUpTableRow.getFollow_up_date();
		 String fup_worked_date_attr=followUpTableRow.getFup_worked_date_attr();
		 String fup_worked_date=followUpTableRow.getFup_worked_date();
		 String fup_end_date_attr=followUpTableRow.getFup_end_date_attr();
		 String fup_end_date=followUpTableRow.getFup_end_date();
		 String notes_attr=followUpTableRow.getNotes_attr();
		 String notes=followUpTableRow.getNotes();
		// sb.append(treeViewList).append(Constants.TAB) .append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(worked_ind_attr, 1)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(worked_ind, 1)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(cancel_ind_attr, 1)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(cancel_ind, 1)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(notes_datetime, 17)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(user_id_attr, 1)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(user_id, 7)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(lasr_ver_attr, 1)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(lasr_ver, 2)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(follow_up_date_attr, 1)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(follow_up_date, 10)).append(Constants.TAB);
		sb.append(fup_worked_date_attr).append(Constants.TAB);
		sb.append(fup_worked_date).append(Constants.TAB);
		sb.append(fup_end_date_attr).append(Constants.TAB);
		sb.append(fup_end_date).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(notes_attr, 1)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(notes, 2300)).append(Constants.TAB).append(Constants.TAB);

		String finalString2 = FormatUtil.getValueWithSpaces(sb.toString(), 2400);
		return finalString2;
	}

	private SubHeader prepareSubHeader() {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_SPECIAL.getProcessModeCode());
		subHeader.setRecord_type(RecIdFor12State.CS_RECID_HEADER.getRecIdValue());
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private SubHeader prepareSubHeader1() {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_ADD.getProcessModeCode());
		subHeader.setRecord_type(RecIdFor12State.CS_RECID_NOTES_INPUT.getRecIdValue());
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private SubHeader prepareSubHeader2() {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_UPDATE.getProcessModeCode());
		subHeader.setRecord_type(RecIdFor12State.CS_RECID_FUP_EDIT.getRecIdValue());
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private Header prepareHeader(String user_id,Boolean indicator) {
		// Prepare Header
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess("REQ");
		if(indicator == true) {
		header.setTab_ind(RecIdFor12State.CS_RECID_NOTES_INPUT.getRecIdValue());}
		else {
			header.setTab_ind(RecIdFor12State.CS_RECID_NOTES.getRecIdValue());
		}
		
		header.setProcess_group_ind(ProcessGroupInd.SAVE_IND.getProcessGroupInd());
		header.setObject_handle("00000000");
		header.setObject_handle2(null);
		header.setLog_ind(null);
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail("0002");
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}

	public String createdataforMq(List<NotesFupBindingData12States>
	treeViewList){
	String cc = treeViewList.get(0).getCompany_code();
	String DTReceived = treeViewList.get(0).getDate_time_received();
	String pon = treeViewList.get(0).getPon();
	String Rver = treeViewList.get(0).getRver();
	String LsrNo = treeViewList.get(0).getRequest_id();
	String ReqTyp = treeViewList.get(0).getReqtype();
	String Status = treeViewList.get(0).getStatus();
	String lspauth_attr= treeViewList.get(0).getLspauth_attr();
	String lspauth = treeViewList.get(0).getLspauth();
	StringBuilder sb = new StringBuilder();
	//sb.append(treeViewList).append(Constants.TAB) .append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(cc, 4)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(DTReceived, 17)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(pon, 16)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(Rver, 5)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(LsrNo, 18)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(ReqTyp, 2)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(Status, 12)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(lspauth_attr, 1)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(lspauth, 4)).append(Constants.TAB).append(Constants.TAB);
	//sb.append(treeViewList.get(0).getLspAuth()).append(Constants.TAB);


	//sb.append(treeViewList.get(0).getStatus()).append(Constants.TAB).append(Constants.TAB);
	String finalString = FormatUtil.getValueWithSpaces(sb.toString(), 2400);

	return finalString; }
	
	public String createdataforMq9states(List<NotesFupBindingData12States>
	treeViewList){
	String cc = treeViewList.get(0).getCompany_code();
	String DTReceived = treeViewList.get(0).getDate_time_received();
	String pon = treeViewList.get(0).getPon();
	String Rver = treeViewList.get(0).getRver();
	String LsrNo = treeViewList.get(0).getRequest_id();
	String ReqTyp = treeViewList.get(0).getReqtype();
	String Status = treeViewList.get(0).getStatus();
	String lspauth_attr= treeViewList.get(0).getLspauth_attr();
	String lspauth = treeViewList.get(0).getLspauth();
	String cvoip = "N";
	String aan= null;
	String atn = null;
	String natn= null;
	String nan = null;
	String an = null;
	StringBuilder sb = new StringBuilder();
	//sb.append(treeViewList).append(Constants.TAB) .append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(cc, 4)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(DTReceived, 17)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(pon, 16)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(Rver, 5)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(LsrNo, 18)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(ReqTyp, 2)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(Status, 22)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(lspauth_attr, 1)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(lspauth, 4)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(cvoip, 1)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(aan, 13)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(atn, 10)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(natn, 10)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(nan, 10)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(an, 13)).append(Constants.TAB).append(Constants.TAB);
	//sb.append(treeViewList.get(0).getLspAuth()).append(Constants.TAB);


	//sb.append(treeViewList.get(0).getStatus()).append(Constants.TAB).append(Constants.TAB);
	String finalString = FormatUtil.getValueWithSpaces(sb.toString(), 2400);

	return finalString; }
	
	

}
