package com.att.lasr.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import javax.servlet.http.HttpSession;

import com.att.lasr.controller.EnvRegionController;
import com.att.lasr.model.AllValidAreaMgrData;
import com.att.lasr.model.AllValidMgrData;
import com.att.lasr.model.AllValidUserData;
import com.att.lasr.model.AllValidWorkGroupData;
import com.att.lasr.model.EnvRegion;
import com.att.lasr.model.Header;
import com.att.lasr.model.JeopardyListRechId014;
import com.att.lasr.model.JeopardyListRechId019;
import com.att.lasr.model.Login;
import com.att.lasr.model.MQReceivedData;
import com.att.lasr.model.ManualRejectRec018;
import com.att.lasr.model.RejectFieldIdsTableRow;
import com.att.lasr.model.RejectManualLoginDto;
import com.att.lasr.model.SubData;
import com.att.lasr.model.SubHeader;
import com.att.lasr.model.UserType;
import com.att.lasr.model.WindowAccessData;
import com.att.lasr.model.WorkGroupAssignedUserData;
import com.att.lasr.model.WorkgroupCCData;
import com.att.lasr.model.WorkgroupReassignedUserData;
import com.att.lasr.utils.MQMessageStringBuilder;
import com.att.lasr.utils.MQReadUtil;
import com.att.lasr.utils.MQWriteUtil;
import com.att.lasr.utils.enums.LastInd;
import com.att.lasr.utils.enums.LogInd;
import com.att.lasr.utils.enums.Process;
import com.att.lasr.utils.enums.ProcessGroupInd;
import com.att.lasr.utils.enums.ProcessMode;
import com.att.lasr.utils.enums.RecIdFor12State;

@Service
public class LoginService {

	@Autowired
	HttpSession httpSession;
	
	@Autowired
	EnvRegionController envCtrl;
	
	@Autowired
	private MQReadUtil mqReadUtil;
	
	@Autowired
	private MQWriteUtil mqWriteUtil;
	
//	static String userProfileUser_id;

	
	
	public Login writeLoginToMQ(Login login, HttpSession session) {
		List<RejectFieldIdsTableRow> rejectFieldIdsTableRows = new ArrayList<>();
	List<WindowAccessData> windowAccesDataRows = new ArrayList<>();
	List<AllValidUserData> allValidUserDataRows = new ArrayList<>();
	List<AllValidAreaMgrData> allValidAreaMgrDataRows = new ArrayList<>();
	List<AllValidMgrData> allValidMgrDataRows = new ArrayList<>();
	List<AllValidWorkGroupData> allValidWorkGroupDataRows = new ArrayList<>();
	List<WorkgroupCCData> workgroupCCDataRows = new ArrayList<>();
	List<WorkgroupReassignedUserData> workgroupReassignedUserDataRows = new ArrayList<>();
	List<WorkGroupAssignedUserData> workgroupassignedUserDataRows = new ArrayList<>();
	List<JeopardyListRechId014> jeopardyListRows = new ArrayList<>(); 
	List<JeopardyListRechId019> jeopardyListRows019 = new ArrayList<>();
	List<UserType> userTypeListRows = new ArrayList<>();
	

	List<RejectManualLoginDto> manuajRejectLoginDTODataRows = new ArrayList<>();
	 List<ManualRejectRec018> manualRejectRec018 = new ArrayList<ManualRejectRec018>();


	Header header = prepareHeader(login.getUser_id());
	String userProfileUser_id=login.getUser_id();
	SubHeader subHeader = prepareSubHeader();
	
	// Customize LossData
	String region =  (String) httpSession.getAttribute("envregion");
	System.out.println(region);
	if (region.equals("D3 - 9 states Dev") || region.equals("D5 - SE ST2")|| region.equals("D2 - 9 states Dev")|| region.equals("D8 - SE RS2")|| region.equals("D6 - SE RS1")|| region.equals("D7 - SE ST1")|| region.equals("D9 - SE CAVE/CLEC")|| region.equals("SE Production")) { 
		System.out.println("inside if block"); 
		login.setBusunit("B"); 
	} 
	else if(region.equals("T3 - MW System Test")|| region.equals("T1 - MW Clec Test")|| region.equals("T2 - MW prod mirror")|| region.equals("MW Production")) { 
		login.setBusunit("A"); 
	} 
	else if (region.equals("B1 - 12 states Dev")|| region.equals("A0 - 12 states Dev")|| region.equals("A2 - SW Clec Test")|| region.equals("AH - SW prod mirror")|| region.equals("A5 - SW System Test")|| region.equals("SW Production")|| region.equals("AA - 12 states Dev")) { 
		login.setBusunit("S"); 
	} 
	else  { 
		System.out.println("inside else block"); 
		login.setBusunit("P"); 
	}
	

	String dataString = login.getLoginDataString();

	MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder().addHeaderSubHeaderAndData(header,
			subHeader, dataString);
	Login loginFromMQ = login;

	boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder,session);
	//MQReceivedData mqReceivedData = mqReadUtil.readDataFromMQ(session);
	MQReceivedData mqReceivedData;
	try {

	mqReceivedData = mqReadUtil.readSortDataFromMQ(session);
	long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES);
	Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
	Header receivedHeader = mqReceivedData.getHeader();
	while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) {
	System.out.println("*************inside if*************** ");
	mqReceivedData = mqReadUtil.readSortDataFromMQ(session);
	}


	System.out.println(mqReceivedData.getHeader().toString());
	} catch (Exception e) {
	
	mqReceivedData = mqReadUtil.readDataFromMQ(session);
	e.printStackTrace();


	}
	Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
	Header receivedHeader = mqReceivedData.getHeader();
	loginFromMQ.setHeader(receivedHeader);

	if (isWritten) {

		setAllValidMgrData(allValidMgrDataRows, loginFromMQ, subDatas);
		setAllValidAreaMgrDataRows(allValidAreaMgrDataRows, loginFromMQ, subDatas);
		setAllValidUserDataRows(allValidUserDataRows, loginFromMQ, subDatas);
		setAllValidWorkGroupDataRows(allValidWorkGroupDataRows, loginFromMQ, subDatas);
		setWorkgroupCCDataRows(workgroupCCDataRows, loginFromMQ, subDatas);
		setWorkgroupReassignedUserDataRows(workgroupReassignedUserDataRows, loginFromMQ, subDatas);
		setWorkgroupassignedUserDataRows(workgroupassignedUserDataRows, loginFromMQ, subDatas);
		setJeopardyList(jeopardyListRows, loginFromMQ, subDatas, httpSession);
		setJeopardyListRech019(jeopardyListRows019, loginFromMQ, subDatas, httpSession);
		setRejectManualLoginDataRows(manuajRejectLoginDTODataRows, loginFromMQ, subDatas,session);
			setRejectManualLoginRec018DataRows(manualRejectRec018, loginFromMQ, subDatas,session);

		setUserType( userTypeListRows,  loginFromMQ, subDatas, session);
	}

	return loginFromMQ;
	
	}
	
//	public static String getUserProfileUser_id() {
//		return userProfileUser_id;
//		}
	
	
	
	 
		

	
	private void setRejectManualLoginRec018DataRows(List<ManualRejectRec018> manualRejectRec018, Login loginFromMQ,
		Map<String, SubData> subDatas, HttpSession session) {
		SubData subData = subDatas.get(RecIdFor12State.CS_RECID_REJECT_FIELD_IDS.getRecIdValue());
		if (subData != null) {

			String[] subDataRows = subData.getSubDataRows();
//				System.out.println("subDataRows-->"+subDataRows.length);
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 9);
					//errCodeMesageManualRej.
				ManualRejectRec018 manualRejectDTOData = new ManualRejectRec018();
				manualRejectDTOData.setName(attributes[0] ==null ? "":attributes[0]);
				manualRejectDTOData.setType(attributes[1] ==null ? "":attributes[1]);
				manualRejectDTOData.setLength(attributes[2] ==null ? "":attributes[2]);
				manualRejectDTOData.setDecimal(attributes[3] ==null ? "":attributes[3]);
				manualRejectDTOData.setInitialValue(attributes[4] ==null ? "":attributes[4]);
				manualRejectDTOData.setValidationExpression(attributes[5] ==null ? "":attributes[5]);
				manualRejectDTOData.setValidationMessage(attributes[6] ==null ? "":attributes[6]);
				manualRejectDTOData.setDbName(attributes[7] ==null ? "":attributes[7]);
				
				manualRejectRec018.add(manualRejectDTOData);
				
				
				
			}
			loginFromMQ.setManualRejectRec018(manualRejectRec018);
			System.out.println("loginFromMQ.manualRejectRec018 size"+loginFromMQ.getManualRejectRec018().size());
//			System.out.println("loginFromMQ.manualRejectRec018 0 data"+loginFromMQ.getManualRejectRec018().get(0));
//			System.out.println("loginFromMQ.manualRejectRec018 1 data"+loginFromMQ.getManualRejectRec018().get(1));
			//System.out.println("errCodeMesageManualRej ->"+errCodeMesageManualRej);
		}
		session.setAttribute("LoginManualRejectRec018Data", manualRejectRec018);
		httpSession.setAttribute("LoginManualRejectRec018Data", manualRejectRec018);
	
	}

	private void setRejectManualLoginDataRows(List<RejectManualLoginDto> manualRejectLoginDTODataRows, Login loginFromMQ,
			Map<String, SubData> subDatas,HttpSession session) {
		EnvRegion envRegionType= (EnvRegion) httpSession.getAttribute("environmentRegion");
		String stateType= envRegionType.getStateType();
		String userId=(String) httpSession.getAttribute("activeUser");
		List<String> errCodeMesageManualRej= new ArrayList<String>();

		
		System.err.println("active user"+userId+"region"+stateType);
			//if("12 States".equals(stateType))
			SubData subData = subDatas.get(RecIdFor12State.CS_RECID_REJECT_LIST.getRecIdValue());
			if (subData != null) {

				String[] subDataRows = subData.getSubDataRows();
//					System.out.println("subDataRows-->"+subDataRows.length);
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 6);
					if("10.14".equals(attributes[0])) {
						//errCodeMesageManualRej.
					RejectManualLoginDto manualRejectDTOData = new RejectManualLoginDto();
					manualRejectDTOData.setLastVersion(attributes[0]);
					manualRejectDTOData.setFieldName(attributes[1] ==null ? "":attributes[1]);
					manualRejectDTOData.setRejectCodeAttr(attributes[2] ==null ? "":attributes[2]);
					manualRejectDTOData.setRejectCode(attributes[3] ==null ? "":attributes[3]);
					manualRejectDTOData.setRejectMessage(attributes[4] ==null ? "":attributes[4]);
//					String temp=".fieldName.:"+".-.,.rejectCode.:."+manualRejectDTOData.getRejectCode()+".,.RejectMessage.:."+manualRejectDTOData.getRejectMessage()+".$";
					String temp="-,"+manualRejectDTOData.getRejectCode()+","+manualRejectDTOData.getRejectMessage()+"$";
					//temp.append("fieldName":-,"rejectCode":");//+manualRejectDTOData.getRejectCode()+",RejectMessage:"+manualRejectDTOData.getRejectMessage()+"$";
					errCodeMesageManualRej.add(temp);
					manualRejectLoginDTODataRows.add(manualRejectDTOData);
					
					
					}
				}
				loginFromMQ.setManualRejectDTODataRows(manualRejectLoginDTODataRows);
				System.out.println("loginFromMQ.setManualRejectDTODataRows size"+loginFromMQ.getManualRejectDTODataRows().size());
				System.out.println("errCodeMesageManualRej ->"+errCodeMesageManualRej);
				
			} 
			session.setAttribute("LoginManualRejectData", manualRejectLoginDTODataRows);
			httpSession.setAttribute("LoginManualRejectData", manualRejectLoginDTODataRows);
			session.setAttribute("errCodeMesageManualRej", errCodeMesageManualRej);
			httpSession.setAttribute("errCodeMesageManualRej", errCodeMesageManualRej);
	}
	

		
	private void setWorkgroupassignedUserDataRows(List<WorkGroupAssignedUserData> workgroupassignedUserDataRows,
			Login loginFromMQ, Map<String, SubData> subDatas) {
		SubData subData = subDatas.get(RecIdFor12State.CS_RECID_ASSIGNED_USER.getRecIdValue());
		if (subData != null) {

			String[] subDataRows = subData.getSubDataRows();

			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 3);
//				System.out.println("attributes: " + Arrays.toString(attributes));

				WorkGroupAssignedUserData workgroupassignedUserData = new WorkGroupAssignedUserData();
				workgroupassignedUserData.setUser_id(attributes[0]);
				workgroupassignedUserData.setUser_name(attributes[1]);
				workgroupassignedUserDataRows.add(workgroupassignedUserData);
			}

			loginFromMQ.setWorkgroupassignedUserDataRows(workgroupassignedUserDataRows);
			System.out.println("loginFromMQ.getWorkgroupReassignedUserDataRows size"+loginFromMQ.getWorkgroupReassignedUserDataRows().size());
		}
	}

	private void setWorkgroupReassignedUserDataRows(List<WorkgroupReassignedUserData> workgroupReassignedUserDataRows,
			Login loginFromMQ, Map<String, SubData> subDatas) {
		SubData subData = subDatas.get(RecIdFor12State.CS_RECID_REASSIGNED_USER.getRecIdValue());
		if (subData != null) {

			String[] subDataRows = subData.getSubDataRows();

			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 3);
//				System.out.println("attributes: " + Arrays.toString(attributes));

				WorkgroupReassignedUserData workgroupReassignedUserData = new WorkgroupReassignedUserData();
				workgroupReassignedUserData.setUser_id(attributes[0]);
				workgroupReassignedUserData.setUser_name(attributes[1]);
				workgroupReassignedUserDataRows.add(workgroupReassignedUserData);
			}

			loginFromMQ.setWorkgroupReassignedUserDataRows(workgroupReassignedUserDataRows);
			System.out.println("loginFromMQ.getWorkgroupReassignedUserDataRows size"+loginFromMQ.getWorkgroupReassignedUserDataRows().size());
		}
	}

	private void setWorkgroupCCDataRows(List<WorkgroupCCData> workgroupCCDataRows, Login loginFromMQ,
			Map<String, SubData> subDatas) {
		SubData subData = subDatas.get(RecIdFor12State.CS_RECID_WORKGROUP_CC.getRecIdValue());
		if (subData != null) {

			String[] subDataRows = subData.getSubDataRows();

			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 3);
//				System.out.println("attributes: " + Arrays.toString(attributes));

				WorkgroupCCData workgroupCCData = new WorkgroupCCData();
				workgroupCCData.setWorkgroup_id(attributes[0]);
				workgroupCCData.setCompany_code(attributes[1]);
				workgroupCCData.setDummy(attributes[2]);
				workgroupCCDataRows.add(workgroupCCData);
				// System.out.println(workgroupCCDataRows.toString());
			}

			loginFromMQ.setWorkgroupCCDataRows(workgroupCCDataRows);
			System.out.println("loginFromMQ.getWorkgroupCCDataRows size"+loginFromMQ.getWorkgroupCCDataRows().size());
		}
	}

	private void setAllValidWorkGroupDataRows(List<AllValidWorkGroupData> allValidWorkGroupDataRows, Login loginFromMQ,
			Map<String, SubData> subDatas) {
		SubData subData = subDatas.get(RecIdFor12State.CS_RECID_VALID_WORKGROUP.getRecIdValue());
		if (subData != null) {

			String[] subDataRows = subData.getSubDataRows();

			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 3);
//				System.out.println("attributes: " + Arrays.toString(attributes));

				AllValidWorkGroupData allValidWorkGroupData = new AllValidWorkGroupData();
				allValidWorkGroupData.setWorkGroup_ID(attributes[0]);
				allValidWorkGroupData.setWorkGroup_Name(attributes[1]);
				allValidWorkGroupDataRows.add(allValidWorkGroupData);
				// System.out.println(allValidUserData.toString());
			}

			loginFromMQ.setAllValidWorkGroupDataRows(allValidWorkGroupDataRows);
			System.out.println("loginFromMQ.getAllValidWorkGroupDataRows size"+loginFromMQ.getAllValidWorkGroupDataRows().size());
		}
	}

	private void setAllValidUserDataRows(List<AllValidUserData> allValidUserDataRows, Login loginFromMQ,
			Map<String, SubData> subDatas) {
		SubData subData = subDatas.get(RecIdFor12State.CS_RECID_ALLVALID_USER.getRecIdValue());
		if (subData != null) {

			String[] subDataRows = subData.getSubDataRows();

			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 3);
//				System.out.println("attributes: " + Arrays.toString(attributes));

				AllValidUserData allValidUserData = new AllValidUserData();
				allValidUserData.setUser_id(attributes[0]);
				allValidUserData.setUser_name(attributes[1]);
				allValidUserDataRows.add(allValidUserData);
				// System.out.println(allValidUserData.toString());
			}

			loginFromMQ.setAllValidUserDataRows(allValidUserDataRows);
			System.out.println("loginFromMQ.getAllValidUserDataRows size"+loginFromMQ.getAllValidUserDataRows().size());
		}
	}

	private void setAllValidAreaMgrDataRows(List<AllValidAreaMgrData> allValidAreaMgrDataRows, Login loginFromMQ,
			Map<String, SubData> subDatas) {
		SubData subData = subDatas.get(RecIdFor12State.CS_RECID_ALLVALID_AREAMGR.getRecIdValue());
		if (subData != null) {

			String[] subDataRows = subData.getSubDataRows();

			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 3);
//				System.out.println("attributes: " + Arrays.toString(attributes));

				AllValidAreaMgrData allValidAreaMgrData = new AllValidAreaMgrData();
				allValidAreaMgrData.setUser_id(attributes[0]);
				allValidAreaMgrData.setUser_name(attributes[1]);
				allValidAreaMgrDataRows.add(allValidAreaMgrData);

			}

			loginFromMQ.setAllValidAreaMgrDataRows(allValidAreaMgrDataRows);
			System.out.println("loginFromMQ.getAllValidAreaMgrDataRows size"+loginFromMQ.getAllValidAreaMgrDataRows().size());
		}
	}

	private void setAllValidMgrData(List<AllValidMgrData> allValidMgrDataRows, Login loginFromMQ,
			Map<String, SubData> subDatas) {
		SubData subData = subDatas.get(RecIdFor12State.CS_RECID_ALLVALID_MGR.getRecIdValue());
		if (subData != null) {

			String[] subDataRows = subData.getSubDataRows();

			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 13);
//				System.out.println("attributes: " + Arrays.toString(attributes));

				AllValidMgrData allValidMgrData = new AllValidMgrData();
				allValidMgrData.setUser_id(attributes[0]);
				allValidMgrData.setUser_name(attributes[1]);
				allValidMgrDataRows.add(allValidMgrData);

			}

			loginFromMQ.setAllValidMgrDataRows(allValidMgrDataRows);
			
			System.out.println("loginFromMQ.getAllValidMgrDataRows size"+loginFromMQ.getAllValidMgrDataRows().size());
		}
	}

	private void setJeopardyList(List<JeopardyListRechId014> JeopardyListRows, Login loginFromMQ, 
			Map<String, SubData> subDatas, HttpSession session) { 
		SubData subData = subDatas.get(RecIdFor12State.CS_RECID_JEOPARDY_LIST.getRecIdValue()); 
		
		if (subData != null) { 
 
			String[] subDataRows = subData.getSubDataRows(); 
 
			for (String subDataRow : subDataRows) { 
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 7); 
			//	System.out.println("attributes: " + Arrays.toString(attributes)); 
 
				JeopardyListRechId014 jeopardylistdata = new JeopardyListRechId014(); 
				jeopardylistdata.setLasrversion(attributes[0]); 
				jeopardylistdata.setJcode(attributes[1]); 
				jeopardylistdata.setRcode(attributes[2]); 
				jeopardylistdata.setRdet(attributes[3]); 
 
				if(jeopardylistdata.getLasrversion().equals("10.14")) {
				JeopardyListRows.add(jeopardylistdata); 
				//System.out.println("JeopardyListRows " + JeopardyListRows);
				}
				// System.out.println(allValidUserData.toString()); 
			} 
			session.setAttribute("JeopardyListRows", JeopardyListRows);
			loginFromMQ.setJeopardyListRows(JeopardyListRows); 
		} 
	}
	
	private void setJeopardyListRech019(List<JeopardyListRechId019> JeopardyListRows019, Login loginFromMQ, 
			Map<String, SubData> subDatas, HttpSession session) { 
		SubData subData = subDatas.get(RecIdFor12State.CS_RECID_APPTIME.getRecIdValue()); 
		if (subData != null) { 
 
			String[] subDataRows = subData.getSubDataRows(); 
 
			for (String subDataRow : subDataRows) { 
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 7); 
				//System.out.println("attributes: " + Arrays.toString(attributes)); 
				JeopardyListRechId019 jeopardylistdata019 = new JeopardyListRechId019();
				
				  jeopardylistdata019.setBusiness_unit(attributes[0]);
				  jeopardylistdata019.setLasr_version(attributes[1]);
				  jeopardylistdata019.setApptime(attributes[2]);
				 
				
				if(jeopardylistdata019.getLasr_version().equals("10.14") && jeopardylistdata019.getBusiness_unit().equals("B")) {
					JeopardyListRows019.add(jeopardylistdata019);
				}
				// System.out.println(allValidUserData.toString()); 
			} 
			//System.out.println("JeopardyListRows019 " + JeopardyListRows019.toString()); 
			session.setAttribute("JeopardyListRows019", JeopardyListRows019);
			loginFromMQ.setJeopardyListRows019(JeopardyListRows019); 
		} 
	}
	//Sneha=================
		private void setUserType(List<UserType> userTypeRows, Login loginFromMQ,
				Map<String, SubData> subDatas,HttpSession session) {
			SubData subData = subDatas.get(RecIdFor12State.CS_RECID_VARIABLES.getRecIdValue());
			if (subData != null) {

				String[] subDataRows = subData.getSubDataRows();
				UserType allData = new UserType();
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 2);
//					System.out.println("attributes: " + Arrays.toString(attributes));

					
					allData.setUser_type(attributes[0]);
					allData.setCompany_ind(attributes[1]);
					System.out.println("Data for recId 013"+subDataRow);
				}
				
				String us= allData.getUser_type();
				
				session.setAttribute("UserType", us);
				loginFromMQ.setUserTypeListRows(userTypeRows);
				
				System.out.println("loginFromMQ.UserTypeList size"+loginFromMQ.getUserTypeListRows().size());
			}
		}
		
		//===============sneha
		
		
	
	private SubHeader prepareSubHeader() {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_SPECIAL.getProcessModeCode());
		subHeader.setRecord_type(RecIdFor12State.CS_RECID_LOGON.getRecIdValue());
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private Header prepareHeader(String user_id) {
		// Prepare Header

		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_LOGON.getProcessCode());
		header.setTab_ind(null);
		header.setProcess_group_ind(ProcessGroupInd.SPECIAL_IND.getProcessGroupInd());
		header.setObject_handle("00000001");
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail("0001");
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}
}
