package com.att.lasr.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.lasr.model.Header;
import com.att.lasr.model.MQReceivedData;
import com.att.lasr.model.SelectProviderData;
import com.att.lasr.model.SelectProviderTableRow;
import com.att.lasr.model.SubData;
import com.att.lasr.model.SubHeader;
import com.att.lasr.utils.MQMessageStringBuilder;
import com.att.lasr.utils.MQReadUtil;
import com.att.lasr.utils.MQWriteUtil;
import com.att.lasr.utils.enums.LastInd;
import com.att.lasr.utils.enums.LogInd;
import com.att.lasr.utils.enums.Process;
import com.att.lasr.utils.enums.ProcessGroupInd;
import com.att.lasr.utils.enums.ProcessMode;
import com.att.lasr.utils.enums.RecIdFor12State;

@Service
public class SelectProviderService {

	@Autowired
	private MQReadUtil mqReadUtil;

	@Autowired
	private MQWriteUtil mqWriteUtil;

	public SelectProviderData writeSelectProviderDataToMQ(SelectProviderData selectProviderData, String user_id, String object_handle,HttpSession session) {

		Header header = prepareHeader(user_id,object_handle);
		SubHeader subHeader = prepareSubHeader();

		String dataString = selectProviderData.getSelectProviderDataString();

		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder().addHeaderSubHeaderAndData(header,
				subHeader, dataString);

		boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder,session);

		if (isWritten) {

			MQReceivedData mqReceivedData;
			
			try {

			mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
			 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
			  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
		//	  Header receivedHeader = mqReceivedData.getHeader(); 
			  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
					System.out.println("*************inside if*************** "); 
					mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
				} 
			  
			  
			  System.out.println(mqReceivedData.getHeader().toString()); 
		} catch (Exception e) { 
			// TODO Auto-generated catch block 
			 mqReceivedData = mqReadUtil.readDataFromMQ(session); 
			e.printStackTrace(); 


		}
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
			Header receivedHeader = mqReceivedData.getHeader();
			selectProviderData.setHeader(receivedHeader);

			SubData subData = subDatas.get(RecIdFor12State.CS_RECID_SELECT_PROVIDER.getRecIdValue());
			if (subData != null) {
				SubHeader receivedSubHeader = subData.getSubHeader();

				String[] subDataRows = subData.getSubDataRows();
				String error = subDataRows[0];
				if(error.contains("LG")) {
					selectProviderData.setError("0 Records Found");
					return selectProviderData;
				}
				List<SelectProviderTableRow> selectProviderTableRows = new ArrayList<>();

				for (String subDataRow : subDataRows) {

					String[] attributes = mqReadUtil.getAttributes(subDataRow, 15);
//					System.out.println("attributes: " + Arrays.toString(attributes));
					SelectProviderTableRow selectProviderTableRow = new SelectProviderTableRow();

					selectProviderTableRow.setNt(attributes[0]);
					selectProviderTableRow.setNta(attributes[1]);
					selectProviderTableRow.setRdy(attributes[2]);
					selectProviderTableRow.setCvd(attributes[3]);
					selectProviderTableRow.setWtn(attributes[4]);
					selectProviderTableRow.setEcckt(attributes[5]);
					selectProviderTableRow.setTnc(attributes[6]);
					selectProviderTableRow.setDt_sent_center(attributes[7]);
					selectProviderTableRow.setSent_by(attributes[8]);
					selectProviderTableRow.setLsr_no(attributes[9]);
					selectProviderTableRow.setDash(attributes[10]);
					selectProviderTableRow.setLasr_sup(attributes[11]);
					selectProviderTableRow.setOrd_no(attributes[12]);
					selectProviderTableRow.setGaining_cc(attributes[13]);
					selectProviderTableRow.setLine(attributes[14]);

					selectProviderTableRows.add(selectProviderTableRow);

				}
				selectProviderData.setSubHeader(receivedSubHeader);
				selectProviderData.setSelectProviderTableRows(selectProviderTableRows);
				System.out.println("selectProviderData.getSelectProviderTableRows() size()"+selectProviderData.getSelectProviderTableRows().size());
			}
		}
		return selectProviderData;
	}

	private SubHeader prepareSubHeader() {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_RETRIEVE.getProcessModeCode());
		subHeader.setRecord_type(RecIdFor12State.CS_RECID_SELECT_PROVIDER_CRITERIA.getRecIdValue());
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private Header prepareHeader(String user_id, String object_handle) {
		// Prepare Header
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_SELECT_LOSS.getProcessCode());
		header.setTab_ind(null);
		header.setProcess_group_ind(ProcessGroupInd.RETRIEVE_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail("0001");
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}

}
