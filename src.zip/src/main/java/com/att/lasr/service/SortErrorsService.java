package com.att.lasr.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.att.lasr.model.Header;
import com.att.lasr.model.MQReceivedData;
import com.att.lasr.model.NotesFupBindingData12States;
import com.att.lasr.model.ShowError;
import com.att.lasr.model.SortErrorData;
import com.att.lasr.model.SubData;
import com.att.lasr.model.SubHeader;
import com.att.lasr.utils.MQMessageStringBuilder;
import com.att.lasr.utils.MQReadUtil;
import com.att.lasr.utils.MQWriteUtil;
import com.att.lasr.utils.enums.LastInd;
import com.att.lasr.utils.enums.LogInd;
import com.att.lasr.utils.enums.Process;
import com.att.lasr.utils.enums.ProcessGroupInd;
import com.att.lasr.utils.enums.ProcessMode;
import com.att.lasr.utils.enums.RecIdFor9State;
import com.att.lasr.utils.enums.TabInd;

@Service
public class SortErrorsService {

	@Autowired
	private MQReadUtil mqReadUtil;

	@Autowired
	private MQWriteUtil mqWriteUtil;

	@Autowired
	HttpSession httpSession;

	List<ShowError> sortErrorList = new ArrayList<ShowError>();

	public boolean writeSortErrorstoMQforSort(SortErrorData sortErrorData, String user_id, String object_handle,
			HttpSession session) {

		@SuppressWarnings("unchecked")
		List<NotesFupBindingData12States> dataObject_049 = (List<NotesFupBindingData12States>) session
				.getAttribute("treeViewList_049");
		session.setAttribute("Lrs_No", dataObject_049.get(0).getRequest_id().substring(0, 17).trim());
		Header header = prepareHeaderforSort(user_id, object_handle);
		SubHeader subHeader = prepareSubHeaderforSort();

		String dataString = sortErrorData.getSortErrorDataStringforSort();

		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder().addHeaderSubHeaderAndData(header,
				subHeader, dataString);

		session.removeAttribute("sort_info_msg");
		session.removeAttribute("sort_err_msg");
		session.setAttribute("sort_info_msg", "");
		session.setAttribute("sort_err_msg", "");

		boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder, session);

		String returncode = "";
		long start = System.currentTimeMillis();
		long end = start + 300*1000;
		if (isWritten) {
			MQReceivedData mqReceivedData;
			Map<String, SubData> subDatas;
			try {
				mqReceivedData = mqReadUtil.readSortDataFromMQ(session);

				while (mqReceivedData.getHeader() == null && System.currentTimeMillis() < end) {
					mqReceivedData = mqReadUtil.readSortDataFromMQ(session);
				}
				returncode = mqReceivedData.getHeader().getReturn_code();
				//session.setAttribute("returncode", returncode);
				//System.err.println("returncode: "+mqReceivedData.getHeader().toString());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				mqReceivedData = mqReadUtil.readDataFromMQ(session);
				//e.printStackTrace();
			}
			
			ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();

			if(mqReceivedData.getHeader() == null)
			{
				String sort_msg = readErrorMsgsJson.getErrorMsg("LG0001");
				session.setAttribute("sort_info_msg", sort_msg);
				return false;
			}
			System.err.println("mqReceivedData in sort is : " + mqReceivedData.toString());
			
			subDatas = mqReceivedData.getSubDatas();
			SubData subData = subDatas.get(RecIdFor9State.CS_RECID_SORT.getRecIdValue());
			System.out.println("subDatas in sort::" + subDatas);
			
			
			if (returncode != null && returncode.equals("000")) {

				String sort_msg = readErrorMsgsJson.getErrorMsg("LG0307");
				if (sort_msg.contains("%PARM%")) {
					String lsrn = dataObject_049.get(0).getRequest_id();
					sort_msg = sort_msg.replace("%PARM%", lsrn);
				}
				session.setAttribute("sort_info_msg", sort_msg);

			}

			if (returncode != null && returncode.equals("999")) {
				if (subData != null) {
					String[] subDataRows = subData.getSubDataRows();
					String[] attributes = mqReadUtil.getAttributes(subDataRows[0], 4);

					String sort_msg = readErrorMsgsJson.getErrorMsg(attributes[0].substring(0, 6));
					if (sort_msg.contains("%PARM%")) {
						String lsrn = dataObject_049.get(0).getRequest_id();
						sort_msg = sort_msg.replace("%PARM%", lsrn);
					}
					session.setAttribute("sort_err_msg", sort_msg);

				}
			}

			if (returncode != null && returncode.equals("888")) {

				String sort_msg = readErrorMsgsJson.getErrorMsg("LG0022");
				session.setAttribute("sort_err_msg", sort_msg);

			}

			if (returncode != null && returncode.equals("889")) {

				String sort_msg = readErrorMsgsJson.getErrorMsg("LG0067");
				session.setAttribute("sort_err_msg", sort_msg);

			}

		}
		return true;
	}

	public boolean writeSortErrorstoMQforIssue(List<SortErrorData> sortErrorDataList, String user_id,
			String object_handle, HttpSession session) {
		@SuppressWarnings("unchecked")
		List<NotesFupBindingData12States> dataObject_049 = (List<NotesFupBindingData12States>) session
				.getAttribute("treeViewList_049");
		session.setAttribute("Lrs_No", dataObject_049.get(0).getRequest_id().substring(0, 17).trim());

		Header header = prepareHeaderforIssue(user_id, object_handle,
				(sortErrorDataList.size() + dataObject_049.size()));
		SubHeader subHeaderSort = prepareSubHeaderfor049();
		SubHeader subHeaderIssue = prepareSubHeaderforIssue();
		
		String dataStringRequest = "";
		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder().addHeader(header);

		for (NotesFupBindingData12States notesFupBindingData12States : dataObject_049) {

			session.setAttribute("Lrs_No", notesFupBindingData12States.getRequest_id().substring(0, 17).trim());
			dataStringRequest = notesFupBindingData12States.getNotesFupBindingData9String();
			mqMessageStringBuilder.appendSubHeaderAndData(subHeaderSort, dataStringRequest);
		}

		// System.out.println("sortErrorDataList out of loop:::"+sortErrorDataList);

		for (int i = 0; i < sortErrorDataList.size(); i++) {
			String dataStringIssue = sortErrorDataList.get(i).getSortErrorDataStringforIssue();
			System.out.println("dataStringIssue:::" + dataStringIssue);
			mqMessageStringBuilder.appendSubHeaderAndData(subHeaderIssue, dataStringIssue);
		}

		System.err.println("final ,Sort Task MQ String:::" + mqMessageStringBuilder.getMqMessageString());

		boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder, session);
		
		String returncode = "";
		long start = System.currentTimeMillis();
		long end = start + 300*1000;
		
		if (isWritten) {

			MQReceivedData mqReceivedData;
			Map<String, SubData> subDatas;
			try {
				mqReceivedData = mqReadUtil.readSortDataFromMQ(session);

				while (mqReceivedData.getHeader() == null && System.currentTimeMillis() < end) {
					mqReceivedData = mqReadUtil.readSortDataFromMQ(session);
				}
				returncode = mqReceivedData.getHeader().getReturn_code();
				//session.setAttribute("returncode", returncode);
				//System.err.println("returncode: "+mqReceivedData.getHeader().toString());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				mqReceivedData = mqReadUtil.readDataFromMQ(session);
				//e.printStackTrace();
			}
			
			ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();

			if(mqReceivedData.getHeader() == null)
			{
				String sort_msg = readErrorMsgsJson.getErrorMsg("LG0001");
				session.setAttribute("sort_info_msg", sort_msg);
				return false;
			}
			System.err.println("mqReceivedData in sort issue is : " + mqReceivedData.toString());
			subDatas = mqReceivedData.getSubDatas();
			System.out.println("receivedHeader Return_code:::" + returncode);

			SubData subData = subDatas.get(RecIdFor9State.CS_RECID_ERROR.getRecIdValue());
			SubData subData_603 = subDatas.get(RecIdFor9State.CS_RECID_SORT_ERROR.getRecIdValue());
			// ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
			ShowErrorService errorService = new ShowErrorService();

			if (returncode != null && returncode.equals("000")) {

				String sort_msg = readErrorMsgsJson.getErrorMsg("LG0307");
				if (sort_msg.contains("%PARM%")) {
					String lsrn = dataObject_049.get(0).getRequest_id();
					sort_msg = sort_msg.replace("%PARM%", lsrn);
				}
				session.setAttribute("sort_info_msg", sort_msg);

			}

			if (returncode != null && returncode.equals("999")) {

				if (subData != null) {
					String[] subDataRows = subData.getSubDataRows();
					String[] attributes = mqReadUtil.getAttributes(subDataRows[0], 4);

					String sort_msg = readErrorMsgsJson.getErrorMsg(attributes[0].substring(0, 6));
					if (sort_msg.contains("%PARM%")) {
						String lsrn = dataObject_049.get(0).getRequest_id();
						sort_msg = sort_msg.replace("%PARM%", lsrn);
					}
					session.setAttribute("sort_err_msg", sort_msg);

				}

				if (subData_603 != null) {
					String[] subDataRows = subData_603.getSubDataRows();

					for (String subDataRow : subDataRows) {
						System.err.println("Sub data row is: " + subDataRow.toString());
						String[] attributes = mqReadUtil.getAttributes(subDataRow, 4);
						// For greater LSR versions exist error message
						if (attributes[0].substring(0, 6).equals("LG0118")) {
							String lsr_no = (String) session.getAttribute("Lrs_No");
							sortErrorList = errorService.getErrorListMultiple(attributes[0], attributes[2], lsr_no, "",
									sortErrorList);
						} else {
							sortErrorList = errorService.getErrorListMultiple(attributes[0], attributes[2], "", "U",
									sortErrorList);
						}
					}
				}

			}

			if (returncode != null && returncode.equals("888")) {

				String sort_msg = readErrorMsgsJson.getErrorMsg("LG0022");
				session.setAttribute("sort_err_msg", sort_msg);

			}

			if (returncode != null && returncode.equals("889")) {

				String ecckt_msg = readErrorMsgsJson.getErrorMsg("LG0067");
				session.setAttribute("sort_err_msg", ecckt_msg);

			}
		}

		return isWritten;
	}

	private SubHeader prepareSubHeaderforIssue() {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_UPDATE.getProcessModeCode());
		subHeader.setRecord_type(RecIdFor9State.CS_RECID_SORT_ERROR.getRecIdValue());
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private SubHeader prepareSubHeaderforSort() {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_UPDATE.getProcessModeCode());
		subHeader.setRecord_type(RecIdFor9State.CS_RECID_SORT.getRecIdValue());
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private SubHeader prepareSubHeaderfor049() {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_UPDATE.getProcessModeCode());
		subHeader.setRecord_type(RecIdFor9State.CS_RECID_HEADER.getRecIdValue());
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private Header prepareHeaderforSort(String user_id, String object_handle) {
		// Prepare Header
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_REQUEST.getProcessCode());
		header.setTab_ind(TabInd.SORT.getTabIndCode());
		header.setProcess_group_ind(ProcessGroupInd.SORT_IND.getProcessGroupInd());
		header.setObject_handle("00000000");
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail("0001");
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}

	private Header prepareHeaderforIssue(String user_id, String object_handle, int rowCnt) {
		// Prepare Header
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_REQUEST.getProcessCode());
		header.setTab_ind(TabInd.ISSUE.getTabIndCode());
		header.setProcess_group_ind(ProcessGroupInd.ISSUE_IND.getProcessGroupInd());
		header.setObject_handle("00000000");
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		String str = String.format("%04d", rowCnt);
		header.setNum_detail(str);
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}

	public List<ShowError> getSortErrorList() {
		// TODO Auto-generated method stub
		return sortErrorList;
	}
}
