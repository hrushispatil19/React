package com.att.lasr.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.att.lasr.model.CompletionActivityRLSOG6;
import com.att.lasr.model.CompletionActivityRLSOG6LscInfo;
import com.att.lasr.model.CompletionLSOG6;
import com.att.lasr.model.CompletionLSOGReqTypeJ;
import com.att.lasr.model.CompletionLSOGReqTypeJDetails;
import com.att.lasr.model.CompletionProviderTask;
import com.att.lasr.model.CompletionProviderTaskActivityR;

import com.att.lasr.model.CompletionProviderTaskLossInfo;
import com.att.lasr.model.CompletionProviderTaskWithLossLasrInfo;
import com.att.lasr.model.Header;
import com.att.lasr.model.MQReceivedData;

import com.att.lasr.model.SelectRequestData;
import com.att.lasr.model.SelectRequestTableRow;
import com.att.lasr.model.SelectRequestTableRow9;
import com.att.lasr.model.SubData;
import com.att.lasr.model.SubHeader;

import com.att.lasr.utils.MQMessageStringBuilder;
import com.att.lasr.utils.MQReadUtil;
import com.att.lasr.utils.MQWriteUtil;
import com.att.lasr.utils.enums.LastInd;
import com.att.lasr.utils.enums.LogInd;
import com.att.lasr.utils.enums.Process;
import com.att.lasr.utils.enums.ProcessGroupInd;
import com.att.lasr.utils.enums.ProcessMode;
import com.att.lasr.utils.enums.RecIdFor12State;
import com.att.lasr.utils.enums.RecIdFor9State;

@Service
public class SelectRequestService {

	@Autowired
	private MQReadUtil mqReadUtil;

	@Autowired
	private MQWriteUtil mqWriteUtil;

	private List<String> WorkloadController;

	public SelectRequestData writeSelectRequestDataToMQ(SelectRequestData selectRequestData, String user_id, String object_handle, HttpSession session) {

		Header header = prepareHeader(user_id, object_handle);
		SubHeader subHeader = prepareSubHeader();

		selectRequestData.setPrevnext_cde("R");

		String dataString = selectRequestData.getSelectRequestDataString();

		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder().addHeaderSubHeaderAndData(header,
				subHeader, dataString);

		boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder,session);
		String reg= (String) session.getAttribute("myReg");
		
		if (isWritten) {

			MQReceivedData mqReceivedData;
			
			try {

			mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
			 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
			  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
		//	  Header receivedHeader = mqReceivedData.getHeader(); 
			  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
					System.out.println("*************inside if*************** "); 
					mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
				} 
			  
			  
			  System.out.println(mqReceivedData.getHeader().toString()); 
		} catch (Exception e) { 
			// TODO Auto-generated catch block 
			 mqReceivedData = mqReadUtil.readDataFromMQ(session); 
			e.printStackTrace(); 


		}
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
			Header receivedHeader = mqReceivedData.getHeader();
			selectRequestData.setHeader(receivedHeader);
			if(receivedHeader.getReturn_code().equals("889")) {
				selectRequestData.setError("User Disconnected, Please Login Again to Continue");
				return selectRequestData;
			}


			if(reg.equalsIgnoreCase("12 states")) {
				SubData subData = subDatas.get(RecIdFor12State.CS_RECID_SELECT_REQUEST.getRecIdValue());
				
				
				if (subData != null) {

					SubHeader receivedSubHeader = subData.getSubHeader();
					String[] subDataRows = subData.getSubDataRows();

					List<SelectRequestTableRow> selectRequestTableRows = new ArrayList<>();
					int i = 0;
					
					for (String subDataRow : subDataRows) {
						String[] attributes = mqReadUtil.getAttributes(subDataRow, 24);
//						System.out.println("attributes:=======> " + Arrays.toString(attributes));
						SelectRequestTableRow selectReqTableRow = new SelectRequestTableRow();

						selectReqTableRow.setDate_time_received(attributes[0]);
						selectReqTableRow.setCc(attributes[1]);
						selectReqTableRow.setRequest_id(attributes[2]);
						selectReqTableRow.setStatus(attributes[3]);
						selectReqTableRow.setPon(attributes[4]);
						selectReqTableRow.setDdd(attributes[5]);
						selectReqTableRow.setRectyp(attributes[6]);
						selectReqTableRow.setAct(attributes[7]);
						selectReqTableRow.setJep(attributes[8]);
						selectReqTableRow.setCancel_ind(attributes[9]);
						selectReqTableRow.setRelease_version(attributes[10]);

						selectReqTableRow.setWork_group_id(attributes[11]);
						selectReqTableRow.setAssigned_uid(attributes[12]);
						selectReqTableRow.setRpon(attributes[13]);
						selectReqTableRow.setProject(attributes[14]);
						selectReqTableRow.setArch(attributes[15]);

						selectReqTableRow.setTotal_record(attributes[16]);
						selectReqTableRow.setStart_page(attributes[17]);
						selectReqTableRow.setEnd_page(attributes[18]);
						selectReqTableRow.setBegin_time_nextptr(attributes[19]);
						selectReqTableRow.setEnd_time_nextptr(attributes[20]);
						selectReqTableRow.setBegin_time_prevptr(attributes[21]);
						selectReqTableRow.setEnd_time_prevptr(attributes[22]);
						selectReqTableRow.setArch_number(attributes[23]);
						selectReqTableRow.setUniqueId(i++);

						selectRequestTableRows.add(selectReqTableRow);
					}
					selectRequestData.setSubHeader(receivedSubHeader);
					selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
					System.out.println("selectRequestData.getSelectRequestTableRows() size()"+selectRequestData.getSelectRequestTableRows().size());
				}
				
			}else {
				SubData subData9 = subDatas.get(RecIdFor9State.CS_RECID_SELECT_REQUEST.getRecIdValue());
				if (subData9 != null) {

					SubHeader receivedSubHeader = subData9.getSubHeader();
					String[] subDataRows = subData9.getSubDataRows();

					List<SelectRequestTableRow9> selectRequestTableRows = new ArrayList<>();
					int i = 0;
					for (String subDataRow : subDataRows) {
						String[] attributes = mqReadUtil.getAttributes(subDataRow, 26);
//						System.out.println("attributes:=======> " + Arrays.toString(attributes));
						SelectRequestTableRow9 selectReqTableRow = new SelectRequestTableRow9();

						selectReqTableRow.setDate_time_received(attributes[0]);
						selectReqTableRow.setCc(attributes[1]);
						selectReqTableRow.setRequest_id(attributes[2]);
						selectReqTableRow.setStatus(attributes[3]);
						selectReqTableRow.setPon(attributes[4]);
						selectReqTableRow.setDdd(attributes[5]);
						selectReqTableRow.setRectyp(attributes[6]);
						selectReqTableRow.setAct(attributes[7]);
						selectReqTableRow.setJep(attributes[8]);
						selectReqTableRow.setCancel_ind(attributes[9]);
						selectReqTableRow.setRelease_version(attributes[10]);

						selectReqTableRow.setWork_group_id(attributes[11]);
						selectReqTableRow.setAssigned_uid(attributes[12]);
						selectReqTableRow.setRpon(attributes[13]);
						selectReqTableRow.setProject(attributes[14]);
						selectReqTableRow.setArch(attributes[15]);

						selectReqTableRow.setTotal_record(attributes[16]);
						selectReqTableRow.setStart_page(attributes[17]);
						selectReqTableRow.setEnd_page(attributes[18]);
						selectReqTableRow.setBegin_time_nextptr(attributes[19]);
						selectReqTableRow.setEnd_time_nextptr(attributes[20]);
						selectReqTableRow.setBegin_time_prevptr(attributes[21]);
						selectReqTableRow.setEnd_time_prevptr(attributes[22]);
						selectReqTableRow.setArch_number(attributes[23]);
						selectReqTableRow.setArchived_date(attributes[24]);
						selectReqTableRow.setArchived_purge_date(attributes[25]);
						selectReqTableRow.setUniqueId(i++);

						selectRequestTableRows.add(selectReqTableRow);
					}
					selectRequestData.setSubHeader(receivedSubHeader);
					selectRequestData.setSelectRequestTableRows9(selectRequestTableRows);
					System.out.println("selectRequestData.getSelectRequestTableRows() size()"+selectRequestData.getSelectRequestTableRows().size());
				}
			}
			
		 
		}
		return selectRequestData;

	}
	

		

	
	private SubHeader prepareTreeSubHeader() {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_RETRIEVE.getProcessModeCode());
		subHeader.setRecord_type(null);
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private Header prepareTreeHeader(String user_id, String object_handle) {
		// Prepare Header
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_REQUEST.getProcessCode());
		header.setTab_ind(null);
		header.setProcess_group_ind(ProcessGroupInd.RETRIEVE_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail("0001");
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}

	private SubHeader prepareSubHeader() {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_RETRIEVE.getProcessModeCode());
		subHeader.setRecord_type(RecIdFor12State.CS_RECID_SELECT_REQUEST.getRecIdValue());
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private Header prepareHeader(String user_id, String object_handle) {
		// Prepare Header
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_SELECT_REQUEST.getProcessCode());
		header.setTab_ind(null);
		header.setProcess_group_ind(ProcessGroupInd.RETRIEVE_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail("0001");
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}
	


}
