package com.att.lasr.utils.enums;

public enum LastInd {
	Y, N;
}
