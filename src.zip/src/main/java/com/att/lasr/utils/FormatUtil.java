package com.att.lasr.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


import com.att.lasr.model.Header;
import com.att.lasr.model.SubHeader;

public class FormatUtil {

	//private static final Logger logger = LoggerFactory.getLogger(FormatUtil.class);

	private static final String MQ_DATE_FORMAT = "MMddyyyy";
	private static final String INPUT_DATE_FORMAT = "yyyy-MM-dd";

	public static String getValueWithSpaces(String value, int size) { 
		value = (value == null) ? Constants.EMPTY_STRING : value.toUpperCase();
		return String.format("%-" + size + "s", value);
	}

	public static char[] getHeaderCharArray(String headerString) {
		char[] headerChars = new char[150];
		int[] fieldsLength = { 0, 7, 3, 3, 1, 8, 8, 1, 17, 17, 32, 7, 2, 3, 1, 4, 7, 5 };
		int fieldFirstIndex = 0;
		int fieldLastIndex = 0;
		for (int i = 0; i < fieldsLength.length - 1; i++) {

			fieldFirstIndex = fieldFirstIndex + fieldsLength[i];
			fieldLastIndex = fieldFirstIndex + fieldsLength[i + 1] - 1;
			for (int j = fieldFirstIndex; j <= fieldLastIndex; j++) {
				if (headerString.charAt(j) == ' ' && j == fieldFirstIndex) {
					break;
				}
				headerChars[j] = headerString.charAt(j);
			}
		}
		return headerChars;
	}

	public static char[] getSubHeaderCharArray(String subHeaderString) {
		char[] subHeaderChars = new char[50];
		int[] fieldsLength = { 0, 1, 1, 3, 3, 4, 3 };
		int fieldFirstIndex = 0;
		int fieldLastIndex = 0;
		for (int i = 0; i < fieldsLength.length - 1; i++) {

			fieldFirstIndex = fieldFirstIndex + fieldsLength[i];
			fieldLastIndex = fieldFirstIndex + fieldsLength[i + 1] - 1;
			for (int j = fieldFirstIndex; j <= fieldLastIndex; j++) {
				if (subHeaderString.charAt(j) == ' ' && j == fieldFirstIndex) {
					break;
				}
				subHeaderChars[j] = subHeaderString.charAt(j);
			}
		}
		return subHeaderChars;
	}

	public static String getMqDateFormatString(String dateString) {
		String mqDateFormatString = Constants.EMPTY_STRING;
		try {
			if (dateString != null && !Constants.EMPTY_STRING.equals(dateString)) {
				SimpleDateFormat inputDateFormat = new SimpleDateFormat(INPUT_DATE_FORMAT);
				SimpleDateFormat mqDateFormat = new SimpleDateFormat(MQ_DATE_FORMAT);
				Date date = inputDateFormat.parse(dateString);
				mqDateFormatString = mqDateFormat.format(date);
			}
		} catch (ParseException e) {
			e.printStackTrace();
			//logger.error("ParseException while parsing dateString: " + dateString);
		}

		return mqDateFormatString;
	}
	public static String getMqStringToDate(String dateString) {
		String mqDateFormatString = Constants.EMPTY_STRING; 
		  DateFormat ft = new SimpleDateFormat("MMddyyyy");
			 DateFormat ft1 = new SimpleDateFormat("yyyy-MM-dd");
	  try { 
		  if (dateString != null && !Constants.EMPTY_STRING.equals(dateString)) {
	
			  mqDateFormatString = ft1.format((Date)ft.parse(dateString));
	  } } 
	  catch (ParseException e) {
			e.printStackTrace();
//	  logger.error("ParseException while parsing dateString: " + dateString); 
	  }
	  
	  return mqDateFormatString; 
	  }
	  
	  public static String getMqDateToString(String dateString) {
			String mqDateFormatString = Constants.EMPTY_STRING; 
			  DateFormat ft = new SimpleDateFormat("MMddyyyy");
				 DateFormat ft1 = new SimpleDateFormat("yyyy-MM-dd");
		  try { 
			  if (dateString != null && !Constants.EMPTY_STRING.equals(dateString)) {
		
				  mqDateFormatString = ft.format((Date)ft1.parse(dateString));
		  } 
			  } 
		  catch (ParseException e) {
				e.printStackTrace();
//		  logger.error("ParseException while parsing dateString: " + dateString); 
		  }
		  
		  return mqDateFormatString; 
		  }
	public static String getStringWithoutDashes(String stringWithDashes) {
		String stringWithoutDashes = Constants.EMPTY_STRING;
		if (stringWithDashes != null && !Constants.EMPTY_STRING.equals(stringWithDashes)) {
			stringWithoutDashes = stringWithDashes.replace(Constants.DASH, Constants.EMPTY_STRING);
		}
		return stringWithoutDashes;

	}

	public static String getTelephoneNumberWithDashes(String telephoneNumberWithoutDashes) {
		String telephoneNumberWithDashes = Constants.EMPTY_STRING;
		if (telephoneNumberWithoutDashes != null && !Constants.EMPTY_STRING.equals(telephoneNumberWithoutDashes)) {
			int length = telephoneNumberWithoutDashes.length();
			if (length > 3) {
				telephoneNumberWithDashes = telephoneNumberWithoutDashes.substring(0, 3) + Constants.DASH;
				if (length > 6) {
					telephoneNumberWithDashes = telephoneNumberWithDashes + telephoneNumberWithoutDashes.substring(3, 6)
							+ Constants.DASH + telephoneNumberWithoutDashes.substring(6, length);
				} else {
					telephoneNumberWithDashes = telephoneNumberWithDashes
							+ telephoneNumberWithoutDashes.substring(3, length);
				}
			} else {
				telephoneNumberWithDashes = telephoneNumberWithoutDashes;
			}
		}
		return telephoneNumberWithDashes;
	}

	public static Header prepareHeader(String user_id, String process, String tab_ind, String process_group_ind,
			String object_handle, String object_handle2, String log_ind, String starttime, String endtime, String guid,
			String session_trans_count, String host_trans_seq, String return_code, String read_only_ind,
			String num_detail, String read_only_user_id, String lasrversion) {
		// Prepare Header
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(process);
		header.setTab_ind(tab_ind);
		header.setProcess_group_ind(process_group_ind);
		header.setObject_handle(object_handle);
		header.setObject_handle2(object_handle2);
		header.setLog_ind(log_ind);
		header.setStarttime(starttime);
		header.setEndtime(endtime);
		header.setGuid(guid);
		header.setSession_trans_count(session_trans_count);
		header.setHost_trans_seq(host_trans_seq);
		header.setReturn_code(return_code);
		header.setRead_only_ind(read_only_ind);
		header.setNum_detail(num_detail);
		header.setRead_only_user_id(read_only_user_id);
		header.setLasrversion(lasrversion);

		return header;
	}

	public static SubHeader prepareSubHeader(String last_ind, String process_mode, String record_type,
			String return_code, String dw_rownum, String ecver) {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(last_ind);
		subHeader.setProcess_mode(process_mode);
		subHeader.setRecord_type(record_type);
		subHeader.setReturn_code(return_code);
		subHeader.setDw_rownum(dw_rownum);
		subHeader.setEcver(ecver);

		return subHeader;
	}

	public static String getNumberWithDashes(String telephoneNumberWithoutDashes) {
		String telephoneNumberWithDashes = Constants.EMPTY_STRING;
		if (telephoneNumberWithoutDashes != null && !Constants.EMPTY_STRING.equals(telephoneNumberWithoutDashes)) {
			int length = telephoneNumberWithoutDashes.length();
			if (length > 3) {
				telephoneNumberWithDashes = telephoneNumberWithoutDashes.substring(0, 3) + Constants.DASH;
				if (length > 6) {
					telephoneNumberWithDashes = telephoneNumberWithDashes + telephoneNumberWithoutDashes.substring(3, 6)
							+ Constants.DASH + telephoneNumberWithoutDashes.substring(6, 10) + Constants.DASH
							+ telephoneNumberWithoutDashes.substring(9, length);
				} else {
					telephoneNumberWithDashes = telephoneNumberWithDashes
							+ telephoneNumberWithoutDashes.substring(3, length);
				}
			} else {
				telephoneNumberWithDashes = telephoneNumberWithoutDashes;
			}
		}
		return telephoneNumberWithDashes;
	}

}
