package com.att.lasr.utils;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.lasr.controller.EnvRegionController;
import com.att.lasr.model.Header;
import com.att.lasr.model.MQDetails;
import com.att.lasr.model.MQReceivedData;
import com.att.lasr.model.SubData;
import com.att.lasr.model.SubHeader;
import com.ibm.mq.MQEnvironment;
import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import com.ibm.mq.constants.CMQC;

@Component
public class MQReadUtil {

	@Autowired
	HttpSession httpSession;
	
	@Autowired
	EnvRegionController envRegionCtrl;
	
	
//	EnvRegion envregion = EnvRegionController.getobj();
	//private static final Logger logger = LoggerFactory.getLogger(MQReadUtil.class);

	private String mqDataString;

	@Autowired
	MQWriteUtil mqWriteUtil;
	
	
	@Value("#{${recIds.9states}}")
	private List<String> recIds9States;

	@Value("#{${recIds.12states}}")
	private List<String> recIds12States;

	public MQReceivedData readDataFromMQ(HttpSession session) {
		MQReceivedData mqReceivedData = new MQReceivedData();
		Map<String, SubData> subDatas = new HashMap<>();

		try {
			String region = (String) httpSession.getAttribute("envregion");
			System.out.println("region in mqread -->"+region);


			MQDetails mqDetFromSession= mqWriteUtil.getMqDetailsFromSession(session);

				if(mqDetFromSession != null) {
			
					MQEnvironment.hostname = mqDetFromSession.getHostName();
					MQEnvironment.channel = mqDetFromSession.getChannel();
					//MQEnvironment.sslCipherSuite = "TLS_RSA_WITH_AES_128_CBC_SHA256";
					MQEnvironment.port = mqDetFromSession.getPort();
					String Businessunit = mqDetFromSession.getBusinessUnit(); 
					httpSession.setAttribute("BusinessunitTest", Businessunit);
					session.setAttribute("BusinessunitTest", Businessunit);
//					mQQueue = mqQueueManager.accessQueue(getMQDetails(region).getQueueName(), openOptions);
					//httpSession.setAttribute(Businessunit, Businessunit);
					//session.setAttribute(Businessunit, Businessunit);
					
				}




			
//			MQEnvironment.hostname = MQWriteUtil.getMQDetails(region).getHostName();
//			MQEnvironment.channel = MQWriteUtil.getMQDetails(region).getChannel();
//			MQEnvironment.port = MQWriteUtil.getMQDetails(region).getPort();
//			MQQueueManager mqQueueManager = new MQQueueManager(MQWriteUtil.getMQDetails(region).getQueueManager());

				MQQueueManager mqQueueManager = new MQQueueManager(mqDetFromSession.getQueueManager());


			int openOptions = CMQC.MQOO_INQUIRE + CMQC.MQOO_FAIL_IF_QUIESCING + CMQC.MQOO_INPUT_SHARED;
			MQQueue mqQueue = null;
			int depth = 0;

			try {
				System.out.println("Inside Try Block");
				Thread.sleep(1500);
				System.out.println("After 1.5 sec delay");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			
			
			
			Instant maxtRetryTime = Instant.now().plusSeconds(300);
			Instant currentTime = Instant.now();

			while (depth == 0 && maxtRetryTime.isAfter(currentTime)) {
//				mqQueue = mqQueueManager.accessQueue(MQWriteUtil.getMQDetails(region).getReadQueueName(), openOptions,
//						null, // default queue manager
//						null, // no dynamic queue name
//						null); // no alternate user id

				mqQueue = mqQueueManager.accessQueue(mqDetFromSession.getReadQueueName(), openOptions,
						null, // default queue manager
						null, // no dynamic queue name
						null); // no alternate user id

				
				System.out.println("MQRead v1.0 connected.");

				depth = mqQueue.getCurrentDepth();
				currentTime = Instant.now();
			}

			System.out.println("Current depth: " + depth);

			if (depth == 0) {
				return mqReceivedData;
			}

			MQGetMessageOptions mqGetMessageOptions = new MQGetMessageOptions();
			mqGetMessageOptions.options = CMQC.MQGMO_NO_WAIT + CMQC.MQGMO_FAIL_IF_QUIESCING + CMQC.MQGMO_CONVERT;

//			while (true) {
				MQMessage mqMessage = new MQMessage();
				try {
//					mqMessage.correlationId = EnvRegionController.getCorelationobj().getCorelationID(); 
					mqMessage.correlationId = envRegionCtrl.getCorelationIfFromSession(session);
//					mqMessage.correlationId = envRegionCtrl.getCorelationIfFromSession(session).getCorelationID();
					mqGetMessageOptions.matchOptions = CMQC.MQMO_MATCH_CORREL_ID;
					System.out.println("Corln Id matched");
					/*
					 * Instant maxtRetryTime1 = Instant.now().plusSeconds(5); Instant currentTime1 =
					 * Instant.now();
					 * System.out.println("Before while: "+maxtRetryTime1+": "+currentTime1); while
					 * (maxtRetryTime1.isAfter(currentTime1)) {
					 * 
					 * }
					 */
					
					//Yash
					
					/*
					 * try { System.out.println("Inside Try Block"); Thread.sleep(500);
					 * System.out.println("After 5 sec delay"); } catch (InterruptedException e) {
					 * e.printStackTrace(); }
					 */
					
					 
					
					mqQueue.get(mqMessage, mqGetMessageOptions);
					byte[] mqMessageBytes = new byte[mqMessage.getMessageLength()];
					mqMessage.readFully(mqMessageBytes);
//					System.out.println("mqMessageBytes" + Arrays.toString(mqMessageBytes));
					String recievedString = new String(mqMessageBytes, StandardCharsets.UTF_8);
//					System.out.println("recievedString: " + recievedString);
					// dataToFile(recievedString);
					String headerString = recievedString.substring(0, 150);
					Header header = prepareHeader(headerString);
					String return_code = header.getReturn_code();
					httpSession.setAttribute("return_code", return_code);
					mqReceivedData.setHeader(header);
					mqDataString = recievedString.substring(150);
//					logger.info("mqDataString: " + mqDataString);

					//if ("000".equals(header.getReturn_code())) {
						String[] recIdDataStrings = mqDataString.split("\\f");

						for (String recIdData : recIdDataStrings) {

							recIdData= trimmedData(recIdData); 
							 
							if (null != recIdData && !recIdData.trim().equals("")  ) 
	 
							{ 
	 
								//String trimmedRecIDData = recIdData.trim(); 
	 
								String recId = recIdData.substring(2, 5); 
//								logger.info("recId: " + recId + ", recIdData: " + recIdData); 
	 
								if (isValidRecId(recId)) { 
	 
//									System.out.println(recId); 
	 
									String subHeaderString =recIdData.substring(0, 50); 
									SubHeader subHeader = prepareSubHeader(subHeaderString); 
	 
									recIdData = recIdData.substring(50); 
									String[] subDataRows = recIdData.split("\\n");

									SubData subData = new SubData();

									if (subDatas.containsKey(recId)) {
										subData = subDatas.get(recId);
										String[] previousSubDataRows = subData.getSubDataRows();
										subData.setSubDataRows(mergeSubDatas(previousSubDataRows, subDataRows));
									} else {
										subData.setSubHeader(subHeader);
										subData.setSubDataRows(subDataRows);
									}

									subDatas.put(recId, subData);

								} 
							 else {
//									logger.error("Invalid recId received: " + recId);
//									System.err.println("Invalid recId received: " + recId);
								}
							} else {
								System.err.println("Recieved Blank Data...");
							}
						}
					//} else {
					//	System.out.println("Return Code: " + header.getReturn_code());
					//}
					mqMessage.clearMessage();
				}

				catch (IOException e) {
					e.printStackTrace();
					//logger.error("IOException while reading messages: " + e.getMessage());
//					break;
				} catch (MQException e) {
					if (e.completionCode == 2 && e.reasonCode == MQException.MQRC_NO_MSG_AVAILABLE) {
						if (depth > 0) {
							System.out.println("All messages read.");
						}
					} else {
						e.printStackTrace();
						//logger.error("Exception while reading messages: " + e);
					}
//					break;
				}
//			}
			mqQueue.close();
			mqQueueManager.disconnect();

		} catch (IllegalArgumentException e) {
			e.printStackTrace();
			//logger.error("Usage: java MQRead <-h host> <-p port> <-c channel> <-m QueueManagerName> <-q QueueName>");
		} catch (MQException e) {
			e.printStackTrace();
			//logger.error("MQException while reading messages: " + e);
		}
		mqReceivedData.setSubDatas(subDatas);
		return mqReceivedData;
	}

	public static void dataToFile(String dataString) throws IOException {

//		Path fileName = Path.of("H:\\Documents\\DataDocuments\\read_mq_data.txt");
//		String content = dataString;
//		Files.writeString(fileName, content);

//		String actual = Files.readString(fileName);
//		System.out.println(actual);
	}
	
	private String  trimmedData(String data) { 
		String trimmeddata; 
		if ( !data.trim().equals("") && isValidRecId(data.substring(2,5))) 	{ 
			return data; 
		} 
		else { 
			trimmeddata = data.trim(); 
			return trimmeddata; 
		} 
	}

	private Header prepareHeader(String headerString) {
		Header header = new Header();

		header.setUser_id(headerString.substring(0, 7).trim());
		header.setProcess(headerString.substring(7, 10).trim());
		header.setTab_ind(headerString.substring(10, 13).trim());
		header.setProcess_group_ind(headerString.substring(13, 14).trim());
		header.setObject_handle(headerString.substring(14, 22).trim());
		header.setObject_handle2(headerString.substring(22, 30).trim());
		header.setLog_ind(headerString.substring(30, 31).trim());
		header.setStarttime(headerString.substring(31, 48).trim());
		header.setEndtime(headerString.substring(48, 65).trim());
		header.setGuid(headerString.substring(65, 97).trim());
		header.setSession_trans_count(headerString.substring(97, 104).trim());
		header.setHost_trans_seq(headerString.substring(104, 106).trim());
		header.setReturn_code(headerString.substring(106, 109).trim());
		header.setRead_only_ind(headerString.substring(109, 110).trim());
		header.setNum_detail(headerString.substring(110, 114).trim());
		header.setRead_only_user_id(headerString.substring(114, 121).trim());
		header.setLasrversion(headerString.substring(121, 126).trim());

		return header;
	}

	private SubHeader prepareSubHeader(String subHeaderString) {
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(subHeaderString.substring(0, 1).trim());
		subHeader.setProcess_mode(subHeaderString.substring(1, 2).trim());
		subHeader.setRecord_type(subHeaderString.substring(2, 5).trim());
		subHeader.setReturn_code(subHeaderString.substring(5, 8).trim());
		subHeader.setDw_rownum(subHeaderString.substring(8, 12).trim());
		subHeader.setEcver(subHeaderString.substring(12, 15).trim());

		return subHeader;
	}

	public boolean isValidRecId(String recId) {
		return recIds9States.contains(recId) || recIds12States.contains(recId);
	}

	public String[] getAttributes(String objectData, int expectedAttributesCount) {
		String[] attributes = new String[expectedAttributesCount];
		Arrays.fill(attributes, Constants.EMPTY_STRING);
		String[] receivedAttributes = objectData.split("\\t");
//		System.out.println("receivedAttributes : " + receivedAttributes.length);
		if (receivedAttributes.length <= expectedAttributesCount) {
			for (int index = 0; index < receivedAttributes.length; index++) {
				attributes[index] = receivedAttributes[index].trim();
			}
		} else {
			//e.printStackTrace();
			System.out.println(String.format(
					"Received more attributes than expected attributes count, expectedAttributesCount: %s, receivedAttributesCount: %s",
					expectedAttributesCount, receivedAttributes.length));
		}
		return attributes;
	}

	private String[] mergeSubDatas(String[] subDatas1, String[] subDatas2) {
		int subDatas1Length = subDatas1.length;
		int subDatas2Length = subDatas2.length;
		int c1 = subDatas1Length + subDatas2Length;
		String[] mergedSubDatas = new String[c1];
		System.arraycopy(subDatas1, 0, mergedSubDatas, 0, subDatas1Length);
		System.arraycopy(subDatas2, 0, mergedSubDatas, subDatas1Length, subDatas2Length);
		return mergedSubDatas;
	}
	public String getReturncode(HttpSession session) {
		String returnCode="";
		 returnCode=(String) session.getAttribute("return_code");
		if(returnCode == null || returnCode.equals("")) {
			returnCode=(String) httpSession.getAttribute("return_code");
			session.setAttribute("return_code",returnCode);
		}else {
			System.err.println("return code from getReturncode is "+returnCode);
		}
		return returnCode;
	}
	
//	public static String getReturncode() {
//		return return_code;
//		}
	
	public MQReceivedData readSortDataFromMQ(HttpSession session) throws MQException, IOException {
		MQReceivedData mqReceivedData = new MQReceivedData();
		Map<String, SubData> subDatas = new HashMap<>();

	
			String region = (String) httpSession.getAttribute("envregion");
			//System.out.println("region in mqread -->"+region);


			MQDetails mqDetFromSession= mqWriteUtil.getMqDetailsFromSession(session);

				if(mqDetFromSession != null) {
			
					MQEnvironment.hostname = mqDetFromSession.getHostName();
					MQEnvironment.channel = mqDetFromSession.getChannel();
					//MQEnvironment.sslCipherSuite = "TLS_RSA_WITH_AES_128_CBC_SHA256";
					MQEnvironment.port = mqDetFromSession.getPort();
					//String Businessunit = mqDetFromSession.getBusinessUnit(); 
//					mQQueue = mqQueueManager.accessQueue(getMQDetails(region).getQueueName(), openOptions);
					//httpSession.setAttribute(Businessunit, Businessunit);
					//session.setAttribute(Businessunit, Businessunit);
					
				}


			MQQueueManager mqQueueManager = new MQQueueManager(mqDetFromSession.getQueueManager());


			int openOptions = CMQC.MQOO_INQUIRE + CMQC.MQOO_FAIL_IF_QUIESCING + CMQC.MQOO_INPUT_SHARED;
			MQQueue mqQueue = null;
			int depth = 0;
			Instant maxtRetryTime = Instant.now().plusSeconds(300);
			Instant currentTime = Instant.now();

			
//				mqQueue = mqQueueManager.accessQueue(MQWriteUtil.getMQDetails(region).getReadQueueName(), openOptions,
//						null, // default queue manager
//						null, // no dynamic queue name
//						null); // no alternate user id

				try {
					//accessQueue(mqDetFromSession, mqQueueManager, openOptions); // no alternate user id
					//depth = mqQueue.getCurrentDepth();
					mqQueue = mqQueueManager.accessQueue(mqDetFromSession.getReadQueueName(), openOptions,
							null, // default queue manager
							null, // no dynamic queue name
							null);	
				} catch (MQException e) {
					// TODO Auto-generated catch block
					mqQueue.close();
					mqQueueManager.disconnect();
					return mqReceivedData;
					
				}

				System.out.println("MQRead v1.0 connected.");

			MQGetMessageOptions mqGetMessageOptions = new MQGetMessageOptions();
			mqGetMessageOptions.options = CMQC.MQGMO_NO_WAIT + CMQC.MQGMO_FAIL_IF_QUIESCING + CMQC.MQGMO_CONVERT;

//			while (true) {
				MQMessage mqMessage = new MQMessage();
				
//					mqMessage.correlationId = EnvRegionController.getCorelationobj().getCorelationID(); 
					byte[] corId= (byte[]) session.getAttribute("fiveminCorID");
				
				mqMessage.correlationId = envRegionCtrl.getCorelationIfFromSession(session);
//					mqMessage.correlationId = envRegionCtrl.getCorelationIfFromSession(session).getCorelationID();
					mqGetMessageOptions.matchOptions = CMQC.MQMO_MATCH_CORREL_ID;
					
	
					try {
						mqQueue.get(mqMessage, mqGetMessageOptions);
					} catch (MQException e) {
						// TODO Auto-generated catch block
						mqQueue.close();
						mqQueueManager.disconnect();
						return mqReceivedData;
					
					}
					byte[] mqMessageBytes = new byte[mqMessage.getMessageLength()];
					mqMessage.readFully(mqMessageBytes);
//					System.out.println("mqMessageBytes" + Arrays.toString(mqMessageBytes));
					String recievedString = new String(mqMessageBytes, StandardCharsets.UTF_8);
					System.out.println("received string");
					mqQueue.close();
					mqQueueManager.disconnect();
					
//					System.out.println("recievedString: " + recievedString);
					// dataToFile(recievedString);
					String headerString = recievedString.substring(0, 150);
					Header header = prepareHeader(headerString);
					String return_code = header.getReturn_code();
					httpSession.setAttribute("return_code", return_code);
					mqReceivedData.setHeader(header);
					mqDataString = recievedString.substring(150);
//					logger.info("mqDataString: " + mqDataString);

					//if ("000".equals(header.getReturn_code())) {
						String[] recIdDataStrings = mqDataString.split("\\f");

						for (String recIdData : recIdDataStrings) {

							recIdData= trimmedData(recIdData); 
							 
							if (null != recIdData && !recIdData.trim().equals("")  ) 
	 
							{ 
	 
								//String trimmedRecIDData = recIdData.trim(); 
	 
								String recId = recIdData.substring(2, 5); 
//								logger.info("recId: " + recId + ", recIdData: " + recIdData); 
	 
								if (isValidRecId(recId)) { 
	 
//									System.out.println(recId); 
	 
									String subHeaderString =recIdData.substring(0, 50); 
									SubHeader subHeader = prepareSubHeader(subHeaderString); 
	 
									recIdData = recIdData.substring(50); 
									String[] subDataRows = recIdData.split("\\n");

									SubData subData = new SubData();

									if (subDatas.containsKey(recId)) {
										subData = subDatas.get(recId);
										String[] previousSubDataRows = subData.getSubDataRows();
										subData.setSubDataRows(mergeSubDatas(previousSubDataRows, subDataRows));
									} else {
										subData.setSubHeader(subHeader);
										subData.setSubDataRows(subDataRows);
									}

									subDatas.put(recId, subData);

								} 
							 else {
//									logger.error("Invalid recId received: " + recId);
//									System.err.println("Invalid recId received: " + recId);
								}
							} else {
								System.err.println("Recieved Blank Data...");
							}
						}
					
					mqMessage.clearMessage();
				
		mqReceivedData.setSubDatas(subDatas);
		return mqReceivedData;
//		}
	}
}