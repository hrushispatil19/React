package com.att.lasr.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.att.lasr.model.EnvRegion;
import com.att.lasr.model.Login;
import com.att.lasr.model.ShowError;
import com.att.lasr.model.UserProfileData;
import com.att.lasr.service.LoginService;
import com.att.lasr.service.LogoffService;
import com.att.lasr.service.ReadErrorMsgsJson;
import com.att.lasr.service.UserProfileService;
import com.att.lasr.utils.MockDtoDataUtil;
import com.google.gson.Gson;

@Controller
@SessionAttributes("region")
public class UserProfileController {

	@Autowired
	public HttpSession httpSession;

	@Autowired
	public UserProfileController userProfileCtrl;

	@Autowired
	public WorkloadController workloadCtrl;
	
	@Autowired
	EnvRegionController envRegionCtrl;
	

	@Autowired
	private UserProfileService userProfileService;

//	EnvRegion e = EnvRegionController.getobj();
	 //UserProfileData retriveUserData = null;
	 //UserProfileData saveUserData = null;

	@RequestMapping(value = "/userProfile", method = RequestMethod.GET)
	public String showUserProfilePage(ModelMap model, HttpSession session) {
		System.out.println("in /userProfile get method");
		
		String userId = (String) httpSession.getAttribute("userId");
		String environment = (String) session.getAttribute("environment");
//		Login login = EnvRegionController.getLoginObject();

		Login login =envRegionCtrl.getLoginObjectFromSession(session);
		
		
		
//		EnvRegion e = envRegionCtrl.getEnvRegionFromSession(session,model);
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		System.out.println("User Id in Workload GET: " + userId);
		model.addAttribute("userId", userId);
		model.addAttribute("environment", environment);
		model.addAttribute("envregion", e);
		model.addAttribute("login", login);
		model.addAttribute("indicator",false)	;
		model.addAttribute("indicator1",false)	;
		model.addAttribute("indicator2",false)	;
		model.addAttribute("indicator3",false)	;
		model.addAttribute("indicator4",false) ;
		model.addAttribute("screenObj", workloadCtrl.screenObj);
		model.addAttribute("navbarArr", session.getAttribute("navBarArr"));
		model.remove("userProfileData");
//		model.addAttribute("userProfileUser_id", LoginService.getUserProfileUser_id());
		model.addAttribute("userProfileUser_id", userId);
		
		String currInde = "";
		
		Object currInd = session.getAttribute("currentPageIndex");
		if (!(currInd == null)) {
			currInde = currInd.toString();
			System.out.println("session -->" + session.getAttribute("currentPageIndex"));
			System.out.println("currInde" + currInde);
		}

		int currIndex = 0;
		if (!checkNullString(currInde)) {
			currIndex = Integer.parseInt(currInde);
			session.setAttribute("currentPageIndex", currIndex + "");
		}

		UserProfileData userProfileDto = getUserProfileDataFromSession(session, currIndex);
		model.addAttribute("userProfileData", userProfileDto);

		String error_msg = (String) session.getAttribute("error_msg");
		model.addAttribute("error_msg", error_msg);
		List<ShowError> error= (List<ShowError>) session.getAttribute("showError");
		model.addAttribute("showError", error);
//		model.addAttribute("userProfileData", userProfileDto);
		return "userProfile";
	}

	public boolean checkNullString(String val) {
		boolean flag = true;
		if ("".equals(val) || val == null) {
			flag = true;
		} else {
			flag = false;
		}
		return flag;
	}

	private UserProfileData getUserProfileDataFromSession(HttpSession session, int currIndex) {
		UserProfileData myUserprofileObj = new UserProfileData();
		try {
			List<UserProfileData> userProfileDatalist = (List<UserProfileData>) session
					.getAttribute("userProfileDatalist");
			return userProfileDatalist.get(currIndex);
		} catch (Exception e) {
			System.out.println("got exception" + e.getMessage());
			return myUserprofileObj;

		}
	}

	@RequestMapping(value = "/userProfile", method = RequestMethod.POST)
	public String addTabOfSamePageUP(@RequestBody String tab, ModelMap model, HttpSession session) {
		model.remove("error_msg");
		session.setAttribute("error_msg", "");
		System.out.println("in  /userProfile post method ->>" + tab);
		String userId = (String) httpSession.getAttribute("userId");
		String environment = (String) session.getAttribute("environment");
		System.out.println("User Id in userProfile POST: " + userId);

		List<String> reqData = new ArrayList<String>();
		String[] sentData = tab.split("\\$");
		System.out.println("sentData after separation" + sentData);
		for (String a : sentData) {
			reqData.add(a);
			System.out.println("send data userProfile-> " + a);
		}

		if ("F".equalsIgnoreCase(reqData.get(1))) {
			fetchUserProfileData(reqData, model, session);
		} else if ("S".equalsIgnoreCase(reqData.get(1))) {
			saveUserProfileData(reqData, model, session);
		}else if ("R".equalsIgnoreCase(reqData.get(1))) {
			resetUserProfileData(reqData, model, session);
		}
		else if ("L".equalsIgnoreCase(reqData.get(1))) {
			LogoffUserProfileData(reqData, model, session);
		} else {
			workloadCtrl.setDataToCorrespondingDTO(reqData, model, session);
			if ("Y".equalsIgnoreCase(reqData.get(1))) {
				workloadCtrl.getSameTabs(reqData, model, userId, session);
			}
		}
//		EnvRegion e = envRegionCtrl.getEnvRegionFromSession(session,model);
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("userId", userId);
		model.addAttribute("environment", environment);
		model.addAttribute("indicator",false)	;
		model.addAttribute("indicator1",false)	;
		model.addAttribute("indicator2",false)	;
		model.addAttribute("indicator3",false)	;
		model.addAttribute("indicator4",false) ;
		model.addAttribute("envregion", e);
		return "userProfile";
	}
   
	private void resetUserProfileData(List<String> reqData, ModelMap model, HttpSession session) {
		session.removeAttribute("showError");
		System.err.println("In Reset Data: "+reqData.toString());
		UserProfileData userData = new UserProfileData();
		int currentIndex = Integer.parseInt(reqData.get(2));
		setUserProfileDataObj(userData, currentIndex, session);
		System.out.println("user data: "+userData.toString());
	}

	public void saveUserProfileData(List<String> sentData, ModelMap model, HttpSession session) {
		session.removeAttribute("showError");
		session.removeAttribute("error_msg");

//		String user_id = EnvRegionController.getLoginObject().getUser_id();
		String user_id=(String) session.getAttribute("activeUser");
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		user_id=user_id.toUpperCase();
		ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();

		int currentIndex = Integer.parseInt(sentData.get(7));
		session.setAttribute("currentPageIndex", currentIndex);
		String objHandle = (String) session.getAttribute("objectHandle");
		int objectHandle = 0;
		if (checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}

		model.remove("userProfileData");

		UserProfileData userData = new UserProfileData();

		System.out.println("UserProfileData ->>: " + sentData.get(3));
		Gson gson = new Gson();
		UserProfileData userProfileData = gson.fromJson(sentData.get(3), UserProfileData.class);
		String object_handle = workloadCtrl.getObjectHandle(objectHandle);
		System.out.println("UserProfileData ->>: " + userProfileData.toString());
		UserProfileData retriveUserData=getUserProfileDataFromSession(session,currentIndex);
		//saveUserData = userProfileData;
		/*if ( getUserProfileDataFromSession(session,currentIndex) == null) {
			System.out.println("retrieved data is null");

			userData = userProfileService.writeSaveUserProfileDataToMQ(userProfileData, user_id, object_handle);
			List<ShowError> showError = UserProfileService.getErrorList();
			System.out.println("^^^^^^^^^^userProfileDataWithMQData: " + userData.toString());
			setUserProfileDataObj(userData, currentIndex, session);
			
			session.setAttribute("showError", showError);
			model.addAttribute("showError", showError);
			
			System.out.println(showError);

			// Login login = EnvRegionController.getLoginObject();
			// model.addAttribute("login", login);
		} else {*/

			if ((!userProfileService.isDataUpdated(userProfileData, retriveUserData)) && (retriveUserData != null)) {
				String error_msg = readErrorMsgsJson.getErrorMsg("LG0027");
				model.addAttribute("error_msg", error_msg);
				session.setAttribute("error_msg", error_msg);
				System.out.println("error_msg" + error_msg);
				setUserProfileDataObj(retriveUserData, currentIndex, session);
				//System.out.println("*****Data not updated*****");

			} else {
				System.out.println("retrieved user data : " + retriveUserData.toString());

				if ((retriveUserData.getUser_id() != null) && (retriveUserData.getUser_id() != "")) {

					System.out.println("userProfileData 237:" + userProfileData.toString());

					userData = userProfileService.updateUserProfileDataToMQ(userProfileData, retriveUserData, user_id,
							object_handle, session);

					if (userData.getHeader().getReturn_code() != null
							&& userData.getHeader().getReturn_code().equals("000")) {
						String error_msg = readErrorMsgsJson.getErrorMsg("LG0016");
						session.setAttribute("error_msg", error_msg);

					}

					setUserProfileDataObj(userData, currentIndex, session);
					//List<ShowError> showError = userProfileService.getErrorList();
					//session.setAttribute("showError", showError);
					//model.addAttribute("showError", showError);

				} else {
					userData = userProfileService.writeSaveUserProfileDataToMQ(userProfileData, user_id, object_handle,
							session);

					if (userData.getHeader().getReturn_code() != null
							&& userData.getHeader().getReturn_code().equals("000")) {
						String error_msg = readErrorMsgsJson.getErrorMsg("LG0016");
						session.setAttribute("error_msg", error_msg);

					}

					setUserProfileDataObj(userData, currentIndex, session);
					//List<ShowError> showError = userProfileService.getErrorList();
					//session.setAttribute("showError", showError);
					//model.addAttribute("showError", showError);

					//System.out.println(showError);
				}
					//System.out.println("####################To show object handle in retrieved data w0" + userData);
				}
	


	}

	public void fetchUserProfileData(List<String> sentData, ModelMap model, HttpSession session) {
//		String user_id = EnvRegionController.getLoginObject().getUser_id();
		String user_id=(String) session.getAttribute("activeUser");
		user_id=user_id.toUpperCase();
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		int currentIndex = Integer.parseInt(sentData.get(7));
		session.setAttribute("currentPageIndex", currentIndex);
		String objHandle = (String) session.getAttribute("objectHandle");
		int objectHandle = 0;
		if (checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}
		model.remove("userProfileData");
		model.remove("error_msg");
		session.setAttribute("error_msg","");

		UserProfileData userData = new UserProfileData();

		System.out.println("UserProfileData ->>: " + sentData.get(3));
		Gson gson = new Gson();
		UserProfileData userProfileData = gson.fromJson(sentData.get(3), UserProfileData.class);
		String object_handle = workloadCtrl.getObjectHandle(objectHandle);
		System.out.println("UserProfileData ->>: " + userProfileData.toString());

		userData = userProfileService.writeRetrieveUserProfileDataToMQ(userProfileData, user_id, object_handle,session);

		//retriveUserData = userProfileData;
		//UserProfileData checkData=new UserProfileData();
		//checkData=userProfileData;
		//model.addAttribute("checkData",checkData);
		//System.out.println("Retrieve UserProfileData : " + retriveUserData.toString());

		setUserProfileDataObj(userData, currentIndex, session);

		System.out.println("To show object handle in retrieved data w0" + userData);

	}

	public void LogoffUserProfileData(List<String> sentData, ModelMap model, HttpSession session) {
		LogoffService logoffService=new LogoffService();
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
//		String user_id = EnvRegionController.getLoginObject().getUser_id();
		String user_id=(String) session.getAttribute("activeUser");
		user_id=user_id.toUpperCase();
		int currentIndex = Integer.parseInt(sentData.get(7));
		session.setAttribute("currentPageIndex", currentIndex);
		String objHandle = (String) session.getAttribute("objectHandle");
		int objectHandle = 0;
		if (checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}

		model.remove("userProfileData");

		UserProfileData userProfileData = new UserProfileData();

		System.out.println("UserProfileLogoffData ->>: " + sentData.get(3));
		Gson gson = new Gson();
		UserProfileData userData = gson.fromJson(sentData.get(3), UserProfileData.class);
		String object_handle = workloadCtrl.getObjectHandle(objectHandle);
		System.out.println("UserProfileSaveData ->>: " + userData.toString());

		userProfileData = userProfileService.writeSlogoffUserProfileDataToMQ(userData, user_id, object_handle,session);
		setUserProfileDataObj(userProfileData, currentIndex, session);
		System.out.println("To show object handle in retrieved data w0" + userProfileData);
		String err_msg= logoffService.logoffValidation(userProfileData.getHeader().getReturn_code());
		model.addAttribute("error_msg",err_msg);
		session.setAttribute("error_msg", err_msg);
		System.out.println("RC: "+userProfileData.getHeader().getReturn_code());

	}

	private void setUserProfileDataObj(UserProfileData userProfileData, int currentIndex, HttpSession session) {
		List<UserProfileData> userProfilelist = (List<UserProfileData>) session.getAttribute("userProfileDatalist");
		List<UserProfileData> userProfileDataLst = new ArrayList<UserProfileData>();
		if (userProfilelist == null) {

			for (int x = 0; x < 5; x++) {
				UserProfileData upd = new UserProfileData();
				upd = MockDtoDataUtil.getUserProfileMockData();
				userProfileDataLst.add(upd);
			}
			session.setAttribute("userprofileDatalist", userProfileDataLst);
			userProfilelist = (List<UserProfileData>) session.getAttribute("userprofileDatalist");
			System.out.println("userprofileDatalist from session size" + userProfileDataLst.size());

			userProfilelist.set(currentIndex, userProfileData);
			session.setAttribute("userprofileDatalist", userProfileDataLst);
		} else {
			userProfilelist.set(currentIndex, userProfileData);
			session.setAttribute("userprofileDatalist", userProfilelist);
		}

	}

}