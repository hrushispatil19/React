package com.att.lasr.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.att.lasr.model.EnvRegion;
import com.att.lasr.model.IssueProviderData;
import com.att.lasr.model.Login;
import com.att.lasr.model.SelectProviderData;
import com.att.lasr.service.IssueProviderService;
import com.att.lasr.service.ReadErrorMsgsJson;
import com.att.lasr.service.SelectProviderService;
import com.att.lasr.utils.MockDtoDataUtil;
import com.google.gson.Gson;

@Controller
@SessionAttributes("region")
public class ProviderController {

	@Autowired
	public ProviderController providerCtrl;

	@Autowired
	public WorkloadController workloadCtrl;

	@Autowired
	HttpSession httpSession;

	@Autowired
	private SelectProviderService selectProviderService;

	@Autowired
	private IssueProviderService issueProviderService;
	
	@Autowired
	private EnvRegionController envRegionCtrl;

//	EnvRegion e = EnvRegionController.getobj();

	@RequestMapping(value = "/issueProvider", method = RequestMethod.GET)
	public String showIssueProvider(ModelMap model, HttpSession session) {
		System.out.println("in /issueProvider get method");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		String userId = (String) httpSession.getAttribute("userId");
		String environment = (String) session.getAttribute("environment");
		model.addAttribute("userId", userId);
		model.addAttribute("environment", environment);
		model.addAttribute("envregion", e);
		model.addAttribute("screenObj", workloadCtrl.screenObj);
		model.addAttribute("navbarArr", session.getAttribute("navBarArr"));
		model.addAttribute("indicator",false)	;
		model.addAttribute("indicator1",false)	;
		model.addAttribute("indicator2",false)	;
		model.addAttribute("indicator3",false)	;
		model.addAttribute("indicator4",false) ;
		String currInde = "";
		Object currInd = session.getAttribute("currentPageIndex");
		if (!(currInd == null)) {
			currInde = currInd.toString();
			System.out.println("session -->" + session.getAttribute("currentPageIndex"));
			System.out.println("currInde" + currInde);
		}

		int currIndex = 0;
		if (!checkNullString(currInde)) {
			currIndex = Integer.parseInt(currInde);
			session.setAttribute("currentPageIndex", currIndex + "");
		}
		IssueProviderData issueProviderDto = getIssueProviderDataFromSession(session, currIndex);
		session.setAttribute("issuedata", issueProviderDto);
		//System.out.println("data to display-->" + issueProviderDto.getIssueProviderTableRows().size());
		model.addAttribute("issueProviderData", issueProviderDto);
		String error= issueProviderDto.getMessage();
		if(error != null && !error.isEmpty()) {
			
			ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
		String error_msg = readErrorMsgsJson.getErrorMsg(error);
		if(error_msg.contains("PARM")) {
			String[]msgs = error_msg.split("\\%");
			String errorcode= msgs[0];
			model.addAttribute("error",errorcode);
			
			
		}
		else {
		
		model.addAttribute("error",error_msg );}}
		
		return "issueProvider";
	}

	private IssueProviderData getIssueProviderDataFromSession(HttpSession session, int currIndex) {

		IssueProviderData issueProviderData = new IssueProviderData();
		try {

			List<IssueProviderData> issueProviderDatalist = (List<IssueProviderData>) session
					.getAttribute("issueProviderDatalist");
			System.out.println("issueProviderDatalist size-->" + issueProviderDatalist.size());
			return issueProviderDatalist.get(currIndex);
		} catch (Exception e) {
			System.out.println("got exception" + e.getMessage());
			return issueProviderData;
		}

	}

	@RequestMapping(value = "/issueProvider", method = RequestMethod.POST)
	public String addTabOfSamePageIP(@RequestBody String tab, ModelMap model, HttpSession session) {

		System.out.println("in  /issueProvider post method ->>" + tab);
		String userId = (String) httpSession.getAttribute("userId");
		String environment = (String) session.getAttribute("environment");
		System.out.println("User Id in issueProvider POST: " + userId);
		List<String> reqData = new ArrayList<String>();

		String[] sentData = tab.split("\\$");
		System.out.println("sentData after separation" + sentData);
		for (String a : sentData) {
			reqData.add(a);
			System.out.println("send data issueProvider-> " + a);
		}

		if ("F".equalsIgnoreCase(reqData.get(1))) {
			fetchIssueProviderData(reqData, model, session);
		} else {

			workloadCtrl.setDataToCorrespondingDTO(reqData, model, session);
			if ("Y".equalsIgnoreCase(reqData.get(1))) {
				workloadCtrl.getSameTabs(reqData, model, userId, session);
			}
		}
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("userId", userId);
		model.addAttribute("environment", environment);
		model.addAttribute("indicator",false)	;
		model.addAttribute("indicator1",false)	;
		model.addAttribute("indicator2",false)	;
		model.addAttribute("indicator3",false)	;
		model.addAttribute("indicator4",false) ;
		model.addAttribute("envregion", e);
		return "issueProvider";
	}

	public void fetchIssueProviderData(List<String> sentData, ModelMap model, HttpSession session) {
		String user_id =envRegionCtrl.getUserIdFromSession( session);
		int currentIndex = Integer.parseInt(sentData.get(7));
		session.setAttribute("currentPageIndex", currentIndex);
		String objHandle = (String) session.getAttribute("objectHandle");
		int objectHandle = 0;
		if (checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}
		model.remove("issueProviderData");

		IssueProviderData issueData = new IssueProviderData();

		System.out.println("IssueProviderData ->>: " + sentData.get(3));
		Gson gson = new Gson();
		IssueProviderData issueProviderData = gson.fromJson(sentData.get(3), IssueProviderData.class);
		String object_handle = workloadCtrl.getObjectHandle(objectHandle);
		System.out.println("*************************************************");
		System.out.println("IssueProviderData ->>: " + issueProviderData.toString());
		System.out.println("*************************************************");
		issueData = issueProviderService.writeIssueProviderDataToMQ(issueProviderData, user_id, object_handle,session);

		setIssueProviderDataObj(issueData, currentIndex, session);
		System.out.println("IssueProviderDataWithMQData size-->" + issueData.getIssueProviderTableRows().size());
		System.out.println("To show object handle in retrieved data w0" + issueData);

	}

	private void setIssueProviderDataObj(IssueProviderData issueData, int currentIndex, HttpSession session) {
		System.out.println("issueData in setIssueProviderDataDataObj-->" + issueData);
		List<IssueProviderData> issueProviderDatalist = (List<IssueProviderData>) session
				.getAttribute("issueProviderDatalist");
		List<IssueProviderData> issueProviderDataLst = new ArrayList<IssueProviderData>();
		if (issueProviderDatalist == null) {

			for (int x = 0; x < 5; x++) {
				IssueProviderData issueProvider = new IssueProviderData();
				issueProvider = MockDtoDataUtil.getIssueProviderMockData();
				issueProviderDataLst.add(issueProvider);
			}
			session.setAttribute("issueProviderDatalist", issueProviderDataLst);
			issueProviderDatalist = (List<IssueProviderData>) session.getAttribute("issueProviderDatalist");
			System.out.println("issueProviderDatalist from session size" + issueProviderDatalist.size());

			issueProviderDatalist.set(currentIndex, issueData);
			session.setAttribute("issueProviderDatalist", issueProviderDataLst);
		} else {
			issueProviderDatalist.set(currentIndex, issueData);
			session.setAttribute("issueProviderDatalist", issueProviderDatalist);
		}

	}

	@RequestMapping(value = "/selectProvider", method = RequestMethod.GET)
	public String showSelectProvider(ModelMap model, HttpSession session) {
		System.out.println("in /selectProvider get method");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		String userId = (String) httpSession.getAttribute("userId");
		String environment = (String) session.getAttribute("environment");
		model.addAttribute("userId", userId);
		model.addAttribute("environment", environment);
		model.addAttribute("envregion", e);
		model.addAttribute("screenObj", workloadCtrl.screenObj);
		model.addAttribute("indicator",false)	;
		model.addAttribute("indicator1",false)	;
		model.addAttribute("indicator2",false)	;
		model.addAttribute("indicator3",false)	;
		model.addAttribute("indicator4",false) ;
		model.addAttribute("navbarArr", session.getAttribute("navBarArr"));
		String currInde = "";
		Object currInd = session.getAttribute("currentPageIndex");
		if (!(currInd == null)) {
			currInde = currInd.toString();
			System.out.println("session -->" + session.getAttribute("currentPageIndex"));
			System.out.println("currInde" + currInde);
		}

		int currIndex = 0;
		if (!checkNullString(currInde)) {
			currIndex = Integer.parseInt(currInde);
			session.setAttribute("currentPageIndex", currIndex + "");
		}
		SelectProviderData selectProviderDto = getSelectProviderDataFromSession(session, currIndex);
		//System.out.println("data to display-->" + selectProviderDto.getSelectProviderTableRows().size());
		model.addAttribute("selectProviderData", selectProviderDto);

		return "selectProvider";

	}

	private SelectProviderData getSelectProviderDataFromSession(HttpSession session, int currIndex) {

		SelectProviderData selectProviderData = new SelectProviderData();
		try {

			List<SelectProviderData> selectProviderDatalist = (List<SelectProviderData>) session
					.getAttribute("selectProviderDatalist");
			System.out.println("selectProviderDatalist size-->" + selectProviderDatalist.size());
			return selectProviderDatalist.get(currIndex);
		} catch (Exception e) {
			System.out.println("got exception" + e.getMessage());
			return selectProviderData;
		}

	}

	@RequestMapping(value = "/selectProvider", method = RequestMethod.POST)
	public String addTabOfSamePageSP(@RequestBody String tab, ModelMap model, HttpSession session) {
		System.out.println("in  /selectProvider post method ->>" + tab);
		String userId = (String) httpSession.getAttribute("userId");
		String environment = (String) session.getAttribute("environment");
//		Login login = EnvRegionController.getLoginObject();

		Login login =envRegionCtrl.getLoginObjectFromSession(session);

			
		model.addAttribute("login", login);
		System.out.println("User Id in selectProvider POST: " + userId);

		List<String> reqData = new ArrayList<String>();

		String[] sentData = tab.split("\\$");
		System.out.println("sentData after separation" + sentData);
		for (String a : sentData) {
			reqData.add(a);
			System.out.println("send data selectProvider-> " + a);
		}

		if ("F".equalsIgnoreCase(reqData.get(1))) {
			fetchSelectProviderData(reqData, model, session);
		} else {

			workloadCtrl.setDataToCorrespondingDTO(reqData, model, session);
			if ("Y".equalsIgnoreCase(reqData.get(1))) {
				workloadCtrl.getSameTabs(reqData, model, userId, session);
			}
		}
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("userId", userId);
		model.addAttribute("indicator",false)	;
		model.addAttribute("indicator1",false)	;
		model.addAttribute("indicator2",false)	;
		model.addAttribute("indicator3",false)	;
		model.addAttribute("indicator4",false) ;
		model.addAttribute("environment", environment);
		model.addAttribute("envregion", e);
		
		return "selectProvider";
	}

	public void fetchSelectProviderData(List<String> sentData, ModelMap model, HttpSession session) {
		String user_id =envRegionCtrl.getUserIdFromSession( session);
		int currentIndex = Integer.parseInt(sentData.get(7));
		session.setAttribute("currentPageIndex", currentIndex);
		String objHandle = (String) session.getAttribute("objectHandle");
		int objectHandle = 0;
		if (checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}
		model.remove("selectProviderData");

		SelectProviderData selProviderData = new SelectProviderData();

		System.out.println("SelectProviderData ->>: " + sentData.get(3));
		Gson gson = new Gson();
		SelectProviderData selectProviderData = gson.fromJson(sentData.get(3), SelectProviderData.class);
		String object_handle = workloadCtrl.getObjectHandle(objectHandle);
		System.out.println("SelectProviderData ->>: " + selectProviderData.toString());

		selProviderData = selectProviderService.writeSelectProviderDataToMQ(selectProviderData, user_id, object_handle,session);

		setSelectProviderDataObj(selProviderData, currentIndex, session);
		System.out
				.println("SelectProviderDataWithMQData size-->" + selProviderData.getSelectProviderTableRows().size());
		System.out.println("To show object handle in retrieved data w0" + selProviderData);

	}

	private void setSelectProviderDataObj(SelectProviderData selProviderData, int currentIndex, HttpSession session) {
		System.out.println("selProviderData in setSelectProviderDataDataObj-->" + selProviderData);
		List<SelectProviderData> selectProviderDatalist = (List<SelectProviderData>) session
				.getAttribute("selectProviderDatalist");
		List<SelectProviderData> selectProviderDataLst = new ArrayList<SelectProviderData>();
		if (selectProviderDatalist == null) {

			for (int x = 0; x < 5; x++) {
				SelectProviderData selectProvider = new SelectProviderData();
				selectProvider = MockDtoDataUtil.getSelectProviderMockData();
				selectProviderDataLst.add(selectProvider);
			}
			session.setAttribute("selectProviderDatalist", selectProviderDataLst);
			selectProviderDatalist = (List<SelectProviderData>) session.getAttribute("selectProviderDatalist");
			System.out.println("selectProviderDatalist from session size" + selectProviderDataLst.size());

			selectProviderDatalist.set(currentIndex, selProviderData);
			session.setAttribute("selectProviderDatalist", selectProviderDataLst);
		} else {
			selectProviderDatalist.set(currentIndex, selProviderData);
			session.setAttribute("selectProviderDatalist", selectProviderDatalist);
		}

	}

	public boolean checkNullString(String val) {
		boolean flag = true;
		if ("".equals(val) || val == null) {
			flag = true;
		} else {
			flag = false;
		}
		return flag;
	}

}
