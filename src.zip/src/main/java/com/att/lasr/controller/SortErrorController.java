package com.att.lasr.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.att.lasr.model.EnvRegion;
import com.att.lasr.model.ShowError;
import com.att.lasr.model.SortErrorData;
import com.att.lasr.service.SortErrorsService;

@Controller
@SessionAttributes("region")
public class SortErrorController {
	
	@Autowired
	SelectController selectController;

	@Autowired
	SortErrorsService sortErrorsService;
	
	@Autowired
	public WorkloadController workloadCtrl;
	
	@Autowired
	private EnvRegionController envRegionCtrl;

	@RequestMapping(value = "/setErrorInfo", method = RequestMethod.POST)
	public String setErrorInfo(@RequestBody String input, ModelMap model, HttpSession session) {
		System.out.println("input:::" + input);
		String infoMsg = input.split("~")[0];
		String errorMsg = input.split("~")[1];
		
		session.setAttribute("uon_info_msg", infoMsg.trim());
		session.setAttribute("uon_err_msg", errorMsg.trim());
		
		return "redirect:/treeview9states";
	}

	@RequestMapping(value = "/sortErrorsTask", method = RequestMethod.POST)
	public String sortErrorsTask(@RequestBody String input, ModelMap model, HttpSession session) {
		String user_id =envRegionCtrl.getUserIdFromSession( session);
		System.out.println("input:::" + input);
		String objHandle = (String) session.getAttribute("objectHandle");
		int objectHandle = 0;
		if (checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}

		SortErrorData sortErrorData = new SortErrorData();
		sortErrorData.setLSR(input.split("-")[0]);
		sortErrorData.setLSR_ver(input.split("-")[1]);

		String object_handle = WorkloadController.getObjectHandle(objectHandle);
		boolean flag=sortErrorsService.writeSortErrorstoMQforSort(sortErrorData, user_id, object_handle,session);
		if(flag == true) {
			selectController.completionselectOkPopup(model, session);
		}
		String info_msg= (String) session.getAttribute("sort_info_msg");
		if(info_msg != null)
		{
			model.addAttribute("sort_info_msg",info_msg);
		}
		String err_msg= (String) session.getAttribute("sort_err_msg");
		if(err_msg != null)
		{
			model.addAttribute("sort_err_msg",err_msg);
		}
		
		return "redirect:/treeview9states";
	}
	
	@RequestMapping(value = "/issueSortErrorTask", method = RequestMethod.POST)
	public String issueSortErrorTask(@RequestBody String input, ModelMap model, HttpSession session) {
		String user_id =envRegionCtrl.getUserIdFromSession( session);
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		String activeUser = (String) session.getAttribute("activeUser");
		String environment = (String) session.getAttribute("environment");
		System.out.println("input:::" + input);
		String objHandle = (String) session.getAttribute("objectHandle");
		int objectHandle = 0;
		if (checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}
		
		List<SortErrorData> sortErrorDatas = new ArrayList<SortErrorData>();
		
		if(!input.isEmpty()) {
			String inputArr [] = input.split("\\$");
			System.out.println("inputArr length::"+inputArr.length);
			System.out.println("inputArr::"+inputArr);
			SortErrorData sortErrorData = new SortErrorData();
			for(int i=0;i<inputArr.length;i++) {
				sortErrorData = new SortErrorData();
				String sortString = inputArr[i].substring(1);
				System.out.println("sortString:::"+sortString);
				String[] sortErrorArr = sortString.split("~");
				sortErrorData.setOrder_attr(sortErrorArr[0]);
				sortErrorData.setService_order(sortErrorArr[1]);
				sortErrorData.setSo_msg(sortErrorArr[2]);
				sortErrorData.setRule_attr(sortErrorArr[3]);
				sortErrorData.setRule_name(sortErrorArr[4]);
				sortErrorData.setError_attr(sortErrorArr[5]);
				sortErrorData.setError_message(sortErrorArr[6]);
				sortErrorData.setAction_attr(sortErrorArr[7]);
				sortErrorData.setAction(sortErrorArr[8]);
				sortErrorData.setComment_attr(sortErrorArr[9]);
				sortErrorData.setComment(sortErrorArr[10]);
				sortErrorDatas.add(sortErrorData);
			}
		}

		
		boolean flag= sortErrorsService.writeSortErrorstoMQforIssue(sortErrorDatas, user_id, objHandle, session);
			
		if(flag == true) {
			selectController.completionselectOkPopup(model, session);
		}
		session.setAttribute("jspRender", "SortErrors9");
	
		//errMsg= (String) session.getAttribute("stask_err");
		//infoMsg= (String) session.getAttribute("stask_info");
		String info_msg= (String) session.getAttribute("sort_info_msg");
		if(info_msg != null)
		{
			model.addAttribute("sort_info_msg",info_msg);
		}
		String err_msg= (String) session.getAttribute("sort_err_msg");
		if(err_msg != null)
		{
			model.addAttribute("sort_err_msg",err_msg);
		}
		List<ShowError> showError = sortErrorsService.getSortErrorList();
		model.addAttribute("showError",showError);
		model.addAttribute("activeUser", activeUser);
		model.addAttribute("environment", environment);
		model.addAttribute("envregion", e);
		//session.setAttribute("stask_err", errMsg);
		//session.setAttribute("stask_info", infoMsg);
	
		return "redirect:/treeview9states";
	}
	
	@RequestMapping(value = "/resetSortErrors", method = RequestMethod.POST)
	public String resetSortErrors(ModelMap model, HttpSession session) {
		System.out.println("/resetSortErrors");
		
		model.remove("sort_info_msg");
		model.remove("sort_err_msg");
		session.removeAttribute("sort_info_msg");
		session.removeAttribute("sort_err_msg");
		
		return "redirect:/treeview9states";
	}
	
	public boolean checkNullString(String val) {
		boolean flag = true;
		if ("".equals(val) || val == null) {
			flag = true;
		} else {
			flag = false;
		}
		return flag;
	}
}
