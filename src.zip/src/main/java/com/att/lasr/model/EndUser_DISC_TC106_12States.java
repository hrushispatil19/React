/**
 * 
 */
package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author mk5650
 *
 */
@Getter
@Setter
@NoArgsConstructor
@ToString
public class EndUser_DISC_TC106_12States {

	private String item_num;
	private String tc_id_sec_attr;
	private String tc_id_sec;
	private String tc_to_sec_attr;
	private String tc_to_sec;
	private String tc_name_sec_attr;
	private String tc_name_sec;
	
}
