package com.att.lasr.model;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Data;

@Data
public class SelectRequestTableRow {
	
	public String date_time_received; 
	public String cc; 
	public String request_id;
	public String status;
	public String pon;
	public String ddd;
	public String rectyp;
	public String act;
	public String jep;
	public String cancel_ind;
	public String release_version;
	public String work_group_id;	
	public String assigned_uid;	
	public String rpon;
	public String project;	
	public String arch;	
	public String total_record;
	public String start_page;
	public String end_page;
	public String begin_time_nextptr;
	public String end_time_nextptr;
	public String begin_time_prevptr;
	public String end_time_prevptr;
	public String arch_number;
	//public String version = request_id;
	public int uniqueId;
	
	public String getSelectRequestTreeDataString(String tabValue) {
		StringBuilder selectRequestDataSb = new StringBuilder();

		
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(request_id.substring(0, 14), 14).trim()).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(request_id.substring(15, 17), 2).trim()).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(status, 14)).append(Constants.TAB);
		//selectRequestDataSb.append(FormatUtil.getValueWithSpaces(release_version, 5)).append(Constants.TAB).append(Constants.TAB);
		
		if(tabValue!= null && tabValue.equalsIgnoreCase("Y")) {
			System.out.println("tabValue::::::if:::::::::;"+tabValue);
			selectRequestDataSb.append(FormatUtil.getValueWithSpaces(release_version, 5)).append(Constants.TAB);
			selectRequestDataSb.append(FormatUtil.getValueWithSpaces(pon, 16)).append(Constants.TAB);
			selectRequestDataSb.append(FormatUtil.getValueWithSpaces(cc, 4)).append(Constants.TAB).append(Constants.TAB).append(Constants.TAB).append(Constants.TAB);
		}else {System.out.println("tabValue:::::else::::::::::;"+tabValue);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(release_version, 5)).append(Constants.TAB).append(Constants.TAB);
		
		}


		String selectRequestDataString = FormatUtil.getValueWithSpaces(selectRequestDataSb.toString(), 2400);
		return selectRequestDataString;
	}
	
}
