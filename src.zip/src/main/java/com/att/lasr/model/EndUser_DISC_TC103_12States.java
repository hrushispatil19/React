/**
 * 
 */
package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author mk5650
 *
 */
@Getter
@Setter
@NoArgsConstructor
@ToString
public class EndUser_DISC_TC103_12States {
	
	private String item_num;
	private String dnum_attr;
	private String dnum;
	private String disc_nbr_attr;
	private String disc_nbr;
	private String disc_ter_attr;
	private String disc_ter;
	private String eu_tc_opt_attr;
	private String eu_tc_opt;
	private String eu_tc_per_attr;
	private String eu_tc_per;
	private String eu_tc_to_pri_attr;
	private String eu_tc_to_pri;
	private String eu_tc_name_pri_attr;
	private String eu_tc_name_pri;
	private String eu_tc_id_attr;
	private String eu_tc_id;
	

}
