package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ConfirmationNonProdLSOG6Row {
	
	private String cver;
	private String svc_rep;
	private String svc_rep_tn;
	private String atn_attr;
	private String atn;
	private String rt;
	private String ecver;
	private String d_t_sent_local;
	private String response_d_t_sent_central_time;
	private String dd_attr;
	private String dd;
	private String pia;
	private String an_attr;
	private String an;
	
	
	

}
