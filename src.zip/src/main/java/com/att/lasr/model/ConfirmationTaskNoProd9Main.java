package com.att.lasr.model;

import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@ToString
public class ConfirmationTaskNoProd9Main {
	
	private Header header;

	private SubHeader subHeader;
	
	private List<ConfirmationTaskNoProd_RecId_556> confirmationTaskNoProd_RecId_556 ;
	private List<ConfirmationTask_RecId_558> confirmationTask_RecId_558 ;
	private List<NotesFupBindingData12States> notesFupBindingData9States;
	
}
