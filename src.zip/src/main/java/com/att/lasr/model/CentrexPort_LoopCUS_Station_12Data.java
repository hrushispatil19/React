package com.att.lasr.model;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString

public class CentrexPort_LoopCUS_Station_12Data {
	
	
	private String item_num;
	private String lnum_attr;	
	private String lnum;
	private String lna_attr;
	private String lna;
	private String npi_attr;
	private String npi;
	private String lst_attr;
	private String lst;
	private String tns_attr;
	private String tns;
	private String ters_attr;
	private String ters;
	private String otn_attr;
	private String otn;
	private String ispid_attr;
	private String ispid;
	private String isdnp_attr;
	private String isdnp;
	private String ecckt_attr;
	private String ecckt;
	private String cfa_attr;
	private String cfa;
	private String ccea_attr;
	private String ccea;
	private String ckr_attr;
	private String ckr;
	private String pic_attr;
	private String pic;
	private String lpic_attr;
	private String lpic;
	private String ssig_attr;
	private String ssig;
	private String ba_attr;
	private String ba;
	private String block_attr;
	private String block;
	private String tsp_attr;
	private String tsp;
	private String jk_code_attr;
	private String jk_code;
	private String jk_num_attr;
	private String jk_num;
	private String jk_pos_attr;
	private String jk_pos;
	private String jr_attr;
	private String jr;
	private String nidr_attr;
	private String nidr;
	private String iwjk1_attr;
	private String iwjk1;
	private String iwjk2_attr;
	private String iwjk2;
	private String iwjk3_attr;
	private String iwjk3;
	private String iwjk4_attr;
	private String iwjk4;
	private String iwjk5_attr;
	private String iwjk5;
	private String iwjq1_attr;
	private String iwjq1;
	private String iwjq2_attr;
	private String iwjq2;
	
	private String iwjq3_attr;
	private String iwjq3;
	private String iwjq4_attr;
	private String iwjq4;
	private String iwjq5_attr;
	private String iwjq5;
	private String sai_attr;
	private String sai;
	private String name_attr;
	private String name;
	private String ncon_attr;
	private String ncon;
	private String aft_attr;
	private String aft;
	private String sapr_attr;
	private String sapr;
	private String sano_attr;
	private String sano;
	private String sasf_attr;
	private String sasf;
	private String sasd_attr;
	private String sasd;
	private String sasn_attr;
	private String  sasn;
	private String sath_attr;
	private String sath;
	private String sass_attr;
	private String sass;
	private String ld1_attr;
	private String ld1;
	private String lv1_attr;
	private String lv1;
	private String ld2_attr;
	private String ld2;
	private String lv2_attr;
	private String lv2;
	private String ld3_attr;
	private String ld3;
	private String lv3_attr;
	private String lv3;
	private String aai_attr;
	private String aai;
	private String city_attr;
	private String city;
	private String state_attr;
	private String state;
	private String zip_attr;
	private String zip;
	private String lcon_attr;
	private String lcon;
	private String telno_attr;
	private String telno;
	
	
	  

}
