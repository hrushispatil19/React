package com.att.lasr.model;

import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class SubHeader {

	private String last_ind;
	private String process_mode;
	private String record_type;
	private String return_code;
	private String dw_rownum;
	private String ecver;

	public String getStringWithSpaces() {

		StringBuffer subStringSb = new StringBuffer();
		
		subStringSb.append(FormatUtil.getValueWithSpaces(last_ind, 1));
		subStringSb.append(FormatUtil.getValueWithSpaces(process_mode, 1));
		subStringSb.append(FormatUtil.getValueWithSpaces(record_type, 3));
		subStringSb.append(FormatUtil.getValueWithSpaces(return_code, 3));
		subStringSb.append(FormatUtil.getValueWithSpaces(dw_rownum, 4));
		subStringSb.append(FormatUtil.getValueWithSpaces(ecver, 3));

		String subHeaderString = FormatUtil.getValueWithSpaces(subStringSb.toString(), 50);
		return subHeaderString;
	}

}
