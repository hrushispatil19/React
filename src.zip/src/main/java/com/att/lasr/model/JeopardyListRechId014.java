package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@ToString
public class JeopardyListRechId014 {

	private String lasrversion;
	private String jcode;
	private String rcode;
	private String rdet;
}
