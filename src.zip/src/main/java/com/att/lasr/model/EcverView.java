package com.att.lasr.model;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class EcverView {

	private String userID;
	private String ecver;
	
	StringBuilder ecverDataSb = new StringBuilder();

	public String getEcverViewString() {
	ecverDataSb.append(FormatUtil.getValueWithSpaces(userID,7)).append(Constants.TAB);
	ecverDataSb.append(FormatUtil.getValueWithSpaces(ecver,3)).append(Constants.TAB).append(Constants.TAB);
	
	String ecverString = FormatUtil.getValueWithSpaces(ecverDataSb.toString(), 2400);
	return ecverString;
	
	}
}
