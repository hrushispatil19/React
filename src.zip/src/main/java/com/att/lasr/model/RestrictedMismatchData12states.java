package com.att.lasr.model;

import java.util.ArrayList;
import java.util.List;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class RestrictedMismatchData12states {
	
	private Header header;
	private SubHeader subHeader;


	private String worked_ind;
	private String focsoc_ind;
	private String company_code;
	private String pon;
	private String begin_date;
	private String end_date;
	private String request_id;
	private String lasr_version;
	private String request_type;
	private String sc;
	private String systemm;
	private String flowthru_ind;
	private String foc_drop_dwn;
	private String soc_drop_dwn;
	private String ptb_drop_dwn;
	private String restrict_sw;
	
	private List<RestrictedMismatchTableRow12states> restrictedMisTableRows12states = new ArrayList<>();
	
	public String getRestrictedMismatchString() {
		StringBuilder RestrictedMismatchDataSb = new StringBuilder();
		
		RestrictedMismatchDataSb.append(FormatUtil.getValueWithSpaces(worked_ind, 1)).append(Constants.TAB);
		RestrictedMismatchDataSb.append(FormatUtil.getValueWithSpaces(focsoc_ind, 1)).append(Constants.TAB);
		RestrictedMismatchDataSb.append(FormatUtil.getValueWithSpaces(company_code, 4)).append(Constants.TAB);
		RestrictedMismatchDataSb.append(FormatUtil.getValueWithSpaces(pon, 16)).append(Constants.TAB);
		RestrictedMismatchDataSb.append(FormatUtil.getValueWithSpaces(FormatUtil.getMqDateFormatString(begin_date), 8))
				.append(Constants.TAB);
		RestrictedMismatchDataSb.append(FormatUtil.getValueWithSpaces(FormatUtil.getMqDateFormatString(end_date), 8))
				.append(Constants.TAB);
		RestrictedMismatchDataSb.append(FormatUtil.getValueWithSpaces(request_id, 14)).append(Constants.TAB);
		RestrictedMismatchDataSb.append(FormatUtil.getValueWithSpaces(lasr_version, 2)).append(Constants.TAB);
		RestrictedMismatchDataSb.append(FormatUtil.getValueWithSpaces(request_type, 2)).append(Constants.TAB);
		RestrictedMismatchDataSb.append(FormatUtil.getValueWithSpaces(sc, 2)).append(Constants.TAB);
		RestrictedMismatchDataSb.append(FormatUtil.getValueWithSpaces(systemm, 22)).append(Constants.TAB);

		RestrictedMismatchDataSb.append(FormatUtil.getValueWithSpaces(flowthru_ind, 1)).append(Constants.TAB);
		RestrictedMismatchDataSb.append(FormatUtil.getValueWithSpaces(foc_drop_dwn, 6)).append(Constants.TAB);
		RestrictedMismatchDataSb.append(FormatUtil.getValueWithSpaces(soc_drop_dwn, 6)).append(Constants.TAB);
		RestrictedMismatchDataSb.append(FormatUtil.getValueWithSpaces(ptb_drop_dwn, 6)).append(Constants.TAB);
		RestrictedMismatchDataSb.append(FormatUtil.getValueWithSpaces(restrict_sw, 1)).append(Constants.TAB).append(Constants.TAB);

		
		String RestrictedMismatchDataString = FormatUtil.getValueWithSpaces(RestrictedMismatchDataSb.toString(), 2400);
		
		return RestrictedMismatchDataString;
	}

}
