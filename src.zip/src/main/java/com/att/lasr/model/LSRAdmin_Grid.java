package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class LSRAdmin_Grid {

	private String item_num;
	private String afa_attr;
	private String afa;
	private String account_feature_attr;
	private String account_feature;
	private String account_feature_detail_attr;
	private String account_feature_detail;
}
