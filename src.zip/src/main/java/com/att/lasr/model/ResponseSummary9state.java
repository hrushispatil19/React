package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ResponseSummary9state {
	
	private String ecver;
	private String lsrver;
	private String type;
	private String pia;
	private String d_t_sent_local;
	private String d_t_sent_central;
	private String userid;
	

}
