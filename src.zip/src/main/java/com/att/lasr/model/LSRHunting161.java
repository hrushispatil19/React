package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class LSRHunting161 {

	private String hid_attr;
	private String hid;
	private String hla_attr;
	private String hla;
	private String htseq_attr;
	private String htseq;
	private String ht_attr;
	private String ht;
	private String hunt_item_num_attr;
	private String hunt_item_num;
}
