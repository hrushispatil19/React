package com.att.lasr.model;

import java.util.ArrayList;
import java.util.List;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class FupRequestData {

	private Header header;
	private SubHeader subHeader;

	private String company_code;
	private String followup_begin_date;
	private String followup_end_date;
	private String worked_ind;
	private String sc;
	private String user_id;
	private String total_record;
	private String start_page;
	private String end_page;
	private String prevnext_cde;
	private String begin_time_nextptr;
	private String end_time_nextptr;
	private String begin_time_prevptr;
	private String end_time_prevptr;

	private List<FupReqTableRow> fupRequestTableRows = new ArrayList<>();

	public String getFupRequestDataString() {
		StringBuilder fupRequestDataSb = new StringBuilder();
		fupRequestDataSb.append(FormatUtil.getValueWithSpaces(company_code, 4)).append(Constants.TAB);
		fupRequestDataSb.append(FormatUtil.getValueWithSpaces(FormatUtil.getMqDateFormatString(followup_begin_date), 8))
				.append(Constants.TAB);
		fupRequestDataSb.append(FormatUtil.getValueWithSpaces(FormatUtil.getMqDateFormatString(followup_end_date), 8))
				.append(Constants.TAB);
		fupRequestDataSb.append(FormatUtil.getValueWithSpaces(worked_ind, 1)).append(Constants.TAB);
		fupRequestDataSb.append(FormatUtil.getValueWithSpaces(sc, 2)).append(Constants.TAB);
		fupRequestDataSb.append(FormatUtil.getValueWithSpaces(user_id, 7)).append(Constants.TAB);

		fupRequestDataSb.append(FormatUtil.getValueWithSpaces(total_record, 6)).append(Constants.TAB);
		fupRequestDataSb.append(FormatUtil.getValueWithSpaces(start_page, 3)).append(Constants.TAB);
		fupRequestDataSb.append(FormatUtil.getValueWithSpaces(end_page, 3)).append(Constants.TAB);
		fupRequestDataSb.append(FormatUtil.getValueWithSpaces(prevnext_cde, 1)).append(Constants.TAB);
		fupRequestDataSb.append(FormatUtil.getValueWithSpaces(begin_time_nextptr, 26)).append(Constants.TAB);
		fupRequestDataSb.append(FormatUtil.getValueWithSpaces(end_time_nextptr, 26)).append(Constants.TAB);

		fupRequestDataSb.append(FormatUtil.getValueWithSpaces(begin_time_prevptr, 26)).append(Constants.TAB);
		fupRequestDataSb.append(FormatUtil.getValueWithSpaces(end_time_prevptr, 26)).append(Constants.TAB)
				.append(Constants.TAB);

		String fupRequestDataString = FormatUtil.getValueWithSpaces(fupRequestDataSb.toString(), 2400);
		return fupRequestDataString;
	}

}
