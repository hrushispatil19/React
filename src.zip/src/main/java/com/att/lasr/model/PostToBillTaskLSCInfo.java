package com.att.lasr.model;



import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@Setter
@Getter
@NoArgsConstructor
@ToString


public class PostToBillTaskLSCInfo {
	
	private String ord_attr;
	private String ord;
	private String posted_date_attr;
	private String posted_date;


}
