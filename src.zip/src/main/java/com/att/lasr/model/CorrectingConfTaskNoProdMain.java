package com.att.lasr.model;

import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@ToString
public class CorrectingConfTaskNoProdMain {

	private Header header;

	private SubHeader subHeader;
	
	private List<Correcting_ConfirmationTask_RecId_856> correcting_ConfirmationTask_RecId_856;
	private List<Correcting_ConfirmationTask_RecId_858> correcting_ConfirmationTask_RecId_858;
	private List<NotesFupBindingData12States> NotesFupBindingData9States ;
}
