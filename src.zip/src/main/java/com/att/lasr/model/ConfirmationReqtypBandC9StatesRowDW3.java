package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ConfirmationReqtypBandC9StatesRowDW3 {
	
	private String ord;
	private String npord;
	private String discord;
	private String dd;
	private String fdt;

}
