package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class TxtListDetail {
	
	private String item_num;
	private String ltxty_attr;
	private String ltxty;
	private String ltext_attr;
	private String ltext;

}
