package com.att.lasr.model;



public class EnvRegion { 
	
	private String environment; 
	private String region; 
private String stateType;



public EnvRegion(String environment, String region, String stateType) {
	super();
	this.environment = environment;
	this.region = region;
	this.stateType = stateType;
}

public EnvRegion() {
	super();
	// TODO Auto-generated constructor stub
}

public String getRegion() { 
		return region; 
	} 
	public void setRegion(String region) { 
		this.region = region; 
	} 
	
	public String getStateType() {
		return stateType;
	}
	public void setStateType(String stateType) {
		this.stateType = stateType;
	}
	public String getEnvironment() { 
		return environment; 
	} 
	public void setEnvironment(String environment) { 
		this.environment = environment; 
	} 
	

	@Override 
	public String toString() { 
		return "EnvRegion [environment=" + environment + ", region=" + region + " ,stateType ="+stateType +"]"; 
	} 
 
}
