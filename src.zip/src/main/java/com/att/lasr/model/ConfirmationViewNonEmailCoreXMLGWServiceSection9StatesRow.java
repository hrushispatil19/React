package com.att.lasr.model;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ConfirmationViewNonEmailCoreXMLGWServiceSection9StatesRow {
	
	private String locnum_attr;
	private String locnum;
	private String lnum_attr;
	private String lnum;
	private String lnex_attr;
	private String lnex;
	private String ecckt_attr;
	private String ecckt;
	private String notyp_attr;
	private String notyp;
	private String lean_attr;
	private String lean;
	private String leatn_attr;
	private String leatn;
	private String tns_attr;
	private String tns;
	private String rti_attr;
	private String rti;
	private String ters_attr;
	private String ters;
	private String otn_attr;
	private String otn;
	private String matn_attr;
	private String matn;
	private String ispid_attr;
	private String ispid;
	private String lst_attr;
	private String lst;
	private String ckr_attr;
	private String ckr;
	private String lord_attr;
	private String lord;
	private String shelf_attr;
	private String shelf;
	private String ported_nbr_attr;
	private String ported_nbr;
	private String disc_nbr_attr;
	private String disc_nbr;
	private String chan_pair_attr;
	private String chan_pair;
	private String slot_attr;
	private String slot;
	private String cable_id_attr;
	private String cable_id;
	private String cable_id2_attr;
	private String cable_id2;
	private String sltn_attr;
	private String sltn;
	private String chan_pair2_attr;
	private String chan_pair2;
	private String relay_rack_attr;
	private String relay_rack;
	private String systemid_attr;
	private String systemid;
	private String pid_attr;
	private String pid;
	private String resid_attr;
	private String resid;
	private String dnum_attr;
	private String dnum;
	private String sat_attr;
	private String sat;
	private String npord_attr;
	private String npord;
	private String ter_attr;
	private String ter;
	private String cfa;
	private String scfa;

}
