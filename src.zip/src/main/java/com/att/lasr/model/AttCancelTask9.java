package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
/**
 * 
 * @author mb160k
 *
 */
@Getter
@Setter
@NoArgsConstructor
@ToString
public class AttCancelTask9 {
	
	private String ord;
	private String ord_status;
	private String dd;
	private String rcode;
	private String jcode;
	private String rdet;
	private String dt_sent_local;
	private String dt_sent_central_time;

}
