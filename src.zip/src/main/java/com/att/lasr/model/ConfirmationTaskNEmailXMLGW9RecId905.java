package com.att.lasr.model;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@ToString
@AllArgsConstructor
public class ConfirmationTaskNEmailXMLGW9RecId905 {
    private String ec_ver;
	private String cver;
	private String tran_ack_type;
	private String dt_sent;
	private String init;
	private String init_tel_no;
	private String rep;
	private String rep_tel_no;
	private String ban1;
	private String ban2;
	private String tran_set_id_code;
	private String tran_set_purpose_code;
	private String ponkey;
	private String status_code_attr;
	private String status_code;
	private String status_msg;
	
	public String getSelectRequest905DataString() {
		StringBuilder selectRequestDataSb = new StringBuilder();
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ec_ver, 3)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(cver, 2)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(tran_ack_type, 2)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(dt_sent, 17)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(init, 15)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(init_tel_no, 15)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(rep, 15)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(rep_tel_no, 10)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ban1, 13)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ban2, 13)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(tran_set_id_code, 3)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(tran_set_purpose_code, 2)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ponkey, 55)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(status_code_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(status_code, 2)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(status_msg, 100)).append(Constants.TAB).append(Constants.TAB);
		String selectRequestDataString = FormatUtil.getValueWithSpaces(selectRequestDataSb.toString(), 2400);
		return selectRequestDataString;
	}

}
