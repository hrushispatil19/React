package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class WorkgroupCCData {
	
	private String workgroup_id;
	private String company_code;
	private String dummy;

}
