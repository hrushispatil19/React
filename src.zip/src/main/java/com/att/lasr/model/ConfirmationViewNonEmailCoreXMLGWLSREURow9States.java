package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ConfirmationViewNonEmailCoreXMLGWLSREURow9States {

	private String ecver;
	private String cver;
	private String tran_ack_type;

	private String dt_sent;
	private String test_prod_ind;
	private String init;
	private String init_tel_no;
	private String rep;
	private String rep_tel_no;
	private String chc;
	private String ccna;
	private String isid;
	private String ibt;

	private String ebd_attr;
	private String ebd;
	private String bi1;
	private String ban1_attr;
	private String ban1;
	private String bi2;
	private String ban2_attr;
	private String ban2;
	private String fdt_attr;

	private String fdt;
	private String nnsp;
	private String dsgcon;
	private String dsgcon_tel_no;
	private String ean;
	private String eatn;

	private String iwban;
	private String disc_nbr;
	private String bopi;

	private String nor;
	private String tran_set_id;
	private String tran_set_purpose;
	private String dlord;
	private String ponkey;

	private String staus_code;
	private String status_msg;
	private String ddcd_attr;
	private String ddcd;

	private String gsid;
	private String aan;
	private String atn;

	private String natn;

	private String nan;
	private String an;
	private String error_code;
	private String rt;
	private String dt_sent_local;
	private String remarks_attr;
	private String remarks;

}
