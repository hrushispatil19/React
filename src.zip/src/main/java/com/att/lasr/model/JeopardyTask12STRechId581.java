package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class JeopardyTask12STRechId581 {
	
	private String ord;
	private String speccode;
	
	/*
	 * private String ecver_attr; private String ecver; private String ord_attr;
	 * private String ord; private String lord_attr; private String lord; private
	 * String jcode_attr; private String jcode; private String rcode_attr; private
	 * String rcode; private String esdd_attr; private String esdd;
	 */

}
