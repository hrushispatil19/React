package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class LSRHunting160_9States {
	
	private String hunt_item_num;
	private String hnum_attr;
	private String hnum;
	private String ha_attr;
	private String ha;
	private String hid_attr;
	private String hid;
	private String htli_attr;
	private String htli;
	private String hntyp_attr;
	private String hntyp;
	private String locnum;
	private String loc_seq_num;
}
