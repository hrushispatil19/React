package com.att.lasr.model;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ResaleTC_Grid_9state_Data {	


	private String item_num;
	private String tc_id_sec_attr;
	private String tc_id_sec;
	private String tc_to_sec_attr;
	private String tc_to_sec;
	private String tc_name_sec_attr;
	private String tc_name_sec;
	private String locnum;
	private String loc_seq_num;
		
}