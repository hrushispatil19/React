package com.att.lasr.model;

import java.util.ArrayList;
import java.util.List;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ConfirmationViewNonEmailCoreXMLGWDirectoryDW2Row9States {

  private String ltxty_attr;
  private String ltxty;
  private String ltetx_attr;
  private String  ltext;
  private String ltxtnum_attr;
  private String ltxt_num;
  private String lphrase_attr;
  private String lphrase;
	
}
