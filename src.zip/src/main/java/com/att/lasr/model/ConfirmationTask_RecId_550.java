package com.att.lasr.model;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author sp860u
 *
 */
@Setter
@Getter
@NoArgsConstructor
@ToString
public class ConfirmationTask_RecId_550 {
	
	private String cver ;
	private String atn_attr ;
	private String atn ;
	private String init_attr ;
	private String init ;
	private String rep ;
	private String tel_no ;
	private String rt ;
	private String ecver ;
	private String d_t_sent_local ;
	private String response_d_t_sent_central_time ;
	private String pia ; 
	private String chc ;
	private String fdt_att ;
	private String fdt ; 
	private String dd_attr ;
	private String dd ;
	private String apptime_attr;
	private String apptime;
	private String ebd_attr;
	private String ebd;
	private String ban1_attr;
	private String ban1;
	private String ban2_attr;
	private String ban2;
	private String an_attr;
	private String an;
	
	public String getSelectRequest550DataString() {
		StringBuilder selectRequestDataSb = new StringBuilder();

		
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(cver, 2)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(atn_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(atn, 12)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(init_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(init, 15)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(rep, 15)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(tel_no, 12)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(rt, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ecver, 3)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(d_t_sent_local, 17)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(response_d_t_sent_central_time, 17)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(pia, 21)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(chc, 1)).append(Constants.TAB);
		
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(fdt_att, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(fdt, 6)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(dd_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(dd, 10)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(apptime_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(apptime, 11)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ebd_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ebd, 8)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ban1_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ban1, 13)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ban2_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ban2, 13)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(an_attr, 1)).append(Constants.TAB);
		
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(an, 13)).append(Constants.TAB).append(Constants.TAB);;
		
		String selectRequestDataString = FormatUtil.getValueWithSpaces(selectRequestDataSb.toString(), 2400);
		return selectRequestDataString;
	}

}
