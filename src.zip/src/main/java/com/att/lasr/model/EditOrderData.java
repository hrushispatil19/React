package com.att.lasr.model;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class EditOrderData {

	
	private List<EditOrderTable1Row> editOrderTable1Rows= new ArrayList<>();
	
	private String ord;
	private String npord;
	private String discord;
	private String dd;
	private String fdt;
	
	private List<EditOrderTable2Row> editOrderTable2Rows=new ArrayList<>();
	
}
