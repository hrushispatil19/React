package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class FollowUpTableRow {

	private String worked_ind_attr;
	private String worked_ind;
	private String cancel_ind_attr;
	private String cancel_ind;
	private String notes_datetime;
	private String user_id_attr;
	private String user_id;
	private String lasr_ver_attr;
	private String lasr_ver;
	private String follow_up_date_attr;
	private String follow_up_date;
	private String fup_worked_date_attr;
	private String fup_worked_date;
	private String fup_end_date_attr;
	private String fup_end_date;
	private String notes_attr;
	private String notes;
	
}
