package com.att.lasr.model;

import java.util.ArrayList;
import java.util.List;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ConfirmationNonProdLSOG6Data {
	private Header header;
	private SubHeader subHeader;
	private String cver;
	private String svc_rep;
	private String svc_rep_tn;
	private String atn_attr;
	private String atn;
	private String rt;
	private String ecver;
	private String d_t_sent_local;
	private String response_d_t_sent_central_time;
	private String dd_attr;
	private String dd;
	private String pia;
	private String an_attr;
	private String an;
	
	private List<ConfirmationNonProdLSOG6Row> confirmationNonProdLSOG6Row = new ArrayList<>();

	public String getConfirmationNonProdLSOG6() {
		StringBuilder ConfirmationNonProdLSOG6sb = new StringBuilder();
	
		ConfirmationNonProdLSOG6sb.append(FormatUtil.getValueWithSpaces(cver, 4)).append(Constants.TAB);
		ConfirmationNonProdLSOG6sb.append(FormatUtil.getValueWithSpaces(svc_rep, 4)).append(Constants.TAB);
		ConfirmationNonProdLSOG6sb.append(FormatUtil.getValueWithSpaces(svc_rep_tn, 1)).append(Constants.TAB);
		ConfirmationNonProdLSOG6sb.append(FormatUtil.getValueWithSpaces(atn_attr, 4)).append(Constants.TAB);
		ConfirmationNonProdLSOG6sb.append(FormatUtil.getValueWithSpaces(atn, 1)).append(Constants.TAB);
		ConfirmationNonProdLSOG6sb.append(FormatUtil.getValueWithSpaces(rt, 12)).append(Constants.TAB);
		ConfirmationNonProdLSOG6sb.append(FormatUtil.getValueWithSpaces(ecver, 12)).append(Constants.TAB);
		//ConfirmationNonProdLSOG6sb.append(FormatUtil.getValueWithSpaces(d_t_sent_local)).append(Constants.TAB);
		ConfirmationNonProdLSOG6sb.append(FormatUtil.getValueWithSpaces(response_d_t_sent_central_time, 12)).append(Constants.TAB);
		ConfirmationNonProdLSOG6sb.append(FormatUtil.getValueWithSpaces(dd_attr, 12)).append(Constants.TAB);
		ConfirmationNonProdLSOG6sb.append(FormatUtil.getValueWithSpaces(dd, 12)).append(Constants.TAB);
		ConfirmationNonProdLSOG6sb.append(FormatUtil.getValueWithSpaces(pia, 12)).append(Constants.TAB);
		ConfirmationNonProdLSOG6sb.append(FormatUtil.getValueWithSpaces(an_attr, 12)).append(Constants.TAB);
		ConfirmationNonProdLSOG6sb.append(FormatUtil.getValueWithSpaces(an, 12)).append(Constants.TAB);

		String ConfirmationDataString = FormatUtil.getValueWithSpaces(ConfirmationNonProdLSOG6sb.toString(), 2400);
		return ConfirmationDataString;
	}
	

}
