package com.att.lasr.model;
import java.util.ArrayList;
import java.util.List;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ConfirmationLS0G6DW4Data {
	
	private Header header;
	private SubHeader subHeader;
	private String 	ord;
	private String npord;
	private String discord;
	private String dd;
	private String fdt;
	
	
	private List<ConfirmationLS0G6DW4Row> confirmationLS0G6DW4Row = new ArrayList<>();

	public String getConfirmationLS0G6DW4() {
		StringBuilder ConfirmationLS0G6DW4sb = new StringBuilder();
	
		ConfirmationLS0G6DW4sb.append(FormatUtil.getValueWithSpaces(ord, 20)).append(Constants.TAB);
		ConfirmationLS0G6DW4sb.append(FormatUtil.getValueWithSpaces(npord, 20)).append(Constants.TAB);
		ConfirmationLS0G6DW4sb.append(FormatUtil.getValueWithSpaces(discord, 20)).append(Constants.TAB);
		ConfirmationLS0G6DW4sb.append(FormatUtil.getValueWithSpaces(dd, 8)).append(Constants.TAB);
		ConfirmationLS0G6DW4sb.append(FormatUtil.getValueWithSpaces(fdt, 8)).append(Constants.TAB);

		String ConfirmationDataString = FormatUtil.getValueWithSpaces(ConfirmationLS0G6DW4sb.toString(), 2400);
		return ConfirmationDataString;
	}

}
