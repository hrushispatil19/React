package com.att.lasr.model;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString

public class SelectProviderTableRow {
	private String nt;
	private String nta;
	private String rdy;
	private String cvd;
	private String wtn;
	private String ecckt;
	private String tnc;
	private String dt_sent_center;
	private String sent_by;
	private String lsr_no;
	private String dash;
	private String lasr_sup;
	private String ord_no;
	private String gaining_cc;
	private String line;
	

}
