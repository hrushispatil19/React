/**
 * 
 */
package com.att.lasr.model;

import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author mk5650
 *
 */
@Getter
@Setter
@NoArgsConstructor
@ToString
public class SaveNotes {
	private Header header;
	private String notes_datetime;
	private String user_id_attr;
	private String user_id;
	private String lasr_ver_attr;
	private String lasr_ver;
	private String follow_up_date_attr;
	private String follow_up_date;
	private String notes_attr;
	private String notes;
}