package com.att.lasr.model;

import java.util.ArrayList;
import java.util.List;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString

public class SelectProviderData {

	private Header header;
	private SubHeader subHeader;
	private String company_code;
	private String conversion_begin_date;
	private String conversion_end_date;
	private String wtn;
	private String ecckt;
	private String error;
	private List<SelectProviderTableRow> SelectProviderTableRows = new ArrayList<>();

	public String getSelectProviderDataString() {
		StringBuilder SelectProviderDataSb = new StringBuilder();
		SelectProviderDataSb.append(FormatUtil.getValueWithSpaces(company_code, 4)).append(Constants.TAB);
		SelectProviderDataSb
				.append(FormatUtil.getValueWithSpaces(FormatUtil.getMqDateFormatString(conversion_begin_date), 8))
				.append(Constants.TAB);
		SelectProviderDataSb
				.append(FormatUtil.getValueWithSpaces(FormatUtil.getMqDateFormatString(conversion_end_date), 8))
				.append(Constants.TAB);
		SelectProviderDataSb.append(FormatUtil.getValueWithSpaces(FormatUtil.getStringWithoutDashes(wtn), 10))
				.append(Constants.TAB);
		SelectProviderDataSb.append(FormatUtil.getValueWithSpaces(ecckt, 46)).append(Constants.TAB)
				.append(Constants.TAB);

		String SelectProviderDataString = FormatUtil.getValueWithSpaces(SelectProviderDataSb.toString(), 2400);
		return SelectProviderDataString;

	}

}
