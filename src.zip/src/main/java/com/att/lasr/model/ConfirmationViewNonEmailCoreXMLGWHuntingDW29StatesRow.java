package com.att.lasr.model;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString

public class ConfirmationViewNonEmailCoreXMLGWHuntingDW29StatesRow {

	private String  htseq_Attr;;
	private String htseq;
	private String ht_attr;
	private String ht;
	private String loc_attr;
	private String loc;
	
}
