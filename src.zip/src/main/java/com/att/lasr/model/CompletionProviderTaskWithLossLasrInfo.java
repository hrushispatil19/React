package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class CompletionProviderTaskWithLossLasrInfo {
	
	private String a_numname_attr;
	private String a_numname;
	private String a_numnbr_attr;
	private String a_numnbr;
	private String a_wtn_attr;
	private String a_wtn;
	private String a_ecckt_attr;
	private String a_ecckt;
	private String a_cvd_attr;
	private String a_cvd;

}
