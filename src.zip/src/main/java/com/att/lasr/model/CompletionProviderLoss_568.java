package com.att.lasr.model;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class CompletionProviderLoss_568 {

	private String old_dtm;
	private String old_ord;
	private String ord_attr;
	private String ord;
	private String fdt_attr;
	private String fdt;
	private String dd_attr;
	private String dd;
	private String comp_dt_attr;
	private String comp_dt;
	private String posted_date_attr;
	private String posted_date;
	private String apptime_attr;
	private String apptime;
	
	public String getRecID568DataString() {
		StringBuilder updateOrderDataSb = new StringBuilder();

		updateOrderDataSb.append(FormatUtil.getValueWithSpaces(old_dtm, 26)).append(Constants.TAB);
		updateOrderDataSb.append(FormatUtil.getValueWithSpaces(old_ord, 20)).append(Constants.TAB);
		updateOrderDataSb.append(FormatUtil.getValueWithSpaces(ord_attr, 1)).append(Constants.TAB);
		updateOrderDataSb.append(FormatUtil.getValueWithSpaces(ord, 20)).append(Constants.TAB);
		updateOrderDataSb.append(FormatUtil.getValueWithSpaces(fdt_attr, 1)).append(Constants.TAB);
		updateOrderDataSb.append(FormatUtil.getValueWithSpaces(fdt, 6)).append(Constants.TAB);
		updateOrderDataSb.append(FormatUtil.getValueWithSpaces(dd_attr, 1)).append(Constants.TAB);
		updateOrderDataSb.append(FormatUtil.getValueWithSpaces(dd, 8)).append(Constants.TAB);
		updateOrderDataSb.append(FormatUtil.getValueWithSpaces(comp_dt_attr, 1)).append(Constants.TAB);
		updateOrderDataSb.append(FormatUtil.getValueWithSpaces(comp_dt, 8)).append(Constants.TAB);
		updateOrderDataSb.append(FormatUtil.getValueWithSpaces(posted_date_attr, 1)).append(Constants.TAB);
		updateOrderDataSb.append(FormatUtil.getValueWithSpaces(posted_date, 8)).append(Constants.TAB);
		updateOrderDataSb.append(FormatUtil.getValueWithSpaces(apptime_attr, 1)).append(Constants.TAB);
		updateOrderDataSb.append(FormatUtil.getValueWithSpaces(apptime, 11)).append(Constants.TAB).append(Constants.TAB);
		
		String updateOrderDataString = FormatUtil.getValueWithSpaces(updateOrderDataSb.toString(), 2400);
		
		return updateOrderDataString;
	}
}
