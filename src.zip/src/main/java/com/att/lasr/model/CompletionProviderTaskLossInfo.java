package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class CompletionProviderTaskLossInfo {
	
	private String numname_attr;
	private String numname;
	private String numnbr_attr;
	private String numnbr;
	private String wtn_attr;
	private String wtn;
	private String ecckt_attr;
	private String ecckt;
	private String cvd_attr;
	private String cvd;


}
