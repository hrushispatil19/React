package com.att.lasr.model;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString

public class CorrectingConfTask9_RecId_850 {

	private String cver;
	private String atn_attr;
	private String atn;
	private String init_attr;
	private String init;
	private String rep;
	private String tel_no;
	private String rt;
	private String ecver;
	private String d_t_sent_local;
	private String response_d_t_sent_central_time;
	private String pia;
	private String chc;
	private String fdt_attr;
	private String fdt;
	private String dd_att;
	private String dd;
	private String apptime_attr;
	private String apptime;
	private String ebd_attr;
	private String ebd;
	private String ban1_attr;
	private String ban1 ;
	private String ban2_attr;
	private String ban2 ;
	private String an_attr;
	private String an;
	
	public String getCorrectingConfTask9_RecId_850() {
		StringBuilder correctingConfTask9_RecId_850 = new StringBuilder();
	
	
		correctingConfTask9_RecId_850.append(FormatUtil.getValueWithSpaces(cver, 2)).append(Constants.TAB);
		correctingConfTask9_RecId_850.append(FormatUtil.getValueWithSpaces(atn_attr, 1)).append(Constants.TAB);
		correctingConfTask9_RecId_850.append(FormatUtil.getValueWithSpaces(atn, 10)).append(Constants.TAB);
		correctingConfTask9_RecId_850.append(FormatUtil.getValueWithSpaces(init_attr, 1)).append(Constants.TAB);
		correctingConfTask9_RecId_850.append(FormatUtil.getValueWithSpaces(init, 15)).append(Constants.TAB);
		correctingConfTask9_RecId_850.append(FormatUtil.getValueWithSpaces(rep, 15)).append(Constants.TAB);
		correctingConfTask9_RecId_850.append(FormatUtil.getValueWithSpaces(tel_no, 10)).append(Constants.TAB);
		correctingConfTask9_RecId_850.append(FormatUtil.getValueWithSpaces(rt, 1)).append(Constants.TAB);
		correctingConfTask9_RecId_850.append(FormatUtil.getValueWithSpaces(ecver, 3)).append(Constants.TAB);
		correctingConfTask9_RecId_850.append(FormatUtil.getValueWithSpaces(d_t_sent_local, 13)).append(Constants.TAB);
		correctingConfTask9_RecId_850.append(FormatUtil.getValueWithSpaces(response_d_t_sent_central_time, 13)).append(Constants.TAB);
		correctingConfTask9_RecId_850.append(FormatUtil.getValueWithSpaces(pia, 21)).append(Constants.TAB);
		correctingConfTask9_RecId_850.append(FormatUtil.getValueWithSpaces(chc, 1)).append(Constants.TAB);
		correctingConfTask9_RecId_850.append(FormatUtil.getValueWithSpaces(fdt_attr, 1)).append(Constants.TAB);
		correctingConfTask9_RecId_850.append(FormatUtil.getValueWithSpaces(fdt, 6)).append(Constants.TAB);
		correctingConfTask9_RecId_850.append(FormatUtil.getValueWithSpaces(dd_att, 1)).append(Constants.TAB);
		correctingConfTask9_RecId_850.append(FormatUtil.getValueWithSpaces(dd, 8)).append(Constants.TAB);
		correctingConfTask9_RecId_850.append(FormatUtil.getValueWithSpaces(apptime_attr, 1)).append(Constants.TAB);
		correctingConfTask9_RecId_850.append(FormatUtil.getValueWithSpaces(apptime, 11)).append(Constants.TAB);
		correctingConfTask9_RecId_850.append(FormatUtil.getValueWithSpaces(ebd_attr, 1)).append(Constants.TAB);
		correctingConfTask9_RecId_850.append(FormatUtil.getValueWithSpaces(ebd, 8)).append(Constants.TAB);
		correctingConfTask9_RecId_850.append(FormatUtil.getValueWithSpaces(ban1_attr, 1)).append(Constants.TAB);
		correctingConfTask9_RecId_850.append(FormatUtil.getValueWithSpaces(ban1, 13)).append(Constants.TAB);
		correctingConfTask9_RecId_850.append(FormatUtil.getValueWithSpaces(ban2_attr, 1)).append(Constants.TAB);
		correctingConfTask9_RecId_850.append(FormatUtil.getValueWithSpaces(ban2, 13)).append(Constants.TAB);
		correctingConfTask9_RecId_850.append(FormatUtil.getValueWithSpaces(an_attr, 1)).append(Constants.TAB);
		correctingConfTask9_RecId_850.append(FormatUtil.getValueWithSpaces(an, 13)).append(Constants.TAB).append(Constants.TAB);
	

		String ConfirmationDataString = FormatUtil.getValueWithSpaces(correctingConfTask9_RecId_850.toString(), 2400);
		return ConfirmationDataString;
	}
}
