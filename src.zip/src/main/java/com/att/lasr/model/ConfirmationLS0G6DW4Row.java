package com.att.lasr.model;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ConfirmationLS0G6DW4Row {
	
	private String 	ord;
	private String npord;
	private String discord;
	private String dd;
	private String fdt;


}
