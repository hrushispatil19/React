package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class FieldDataChangesData12State {

	private String supp;
	private String changed_dttm;
	private String order_num;
	private String field_name;
	private String hunt_item_num;
	private String item_num;
	private String lnum;
	private String numname;
	private String numnbr;
	private String changed_from;
	private String changed_to;
	private String changed_by;

}
