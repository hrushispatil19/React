package com.att.lasr.model;
import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString


public class CorrectingConfTask9_RecId_851 {

	
	private String item_num;	
	private String hnum;
	private String hid_attr;
	private String hid;
	private String hunt_tli_attr;
	private String hunt_tli;
	
	
	public String getCorrectingConfTask9_RecId_851() {
		StringBuilder correctingConfTask9_RecId_851 = new StringBuilder();
	
		correctingConfTask9_RecId_851.append(FormatUtil.getValueWithSpaces(item_num, 4)).append(Constants.TAB);
		correctingConfTask9_RecId_851.append(FormatUtil.getValueWithSpaces(hnum, 4)).append(Constants.TAB);
		correctingConfTask9_RecId_851.append(FormatUtil.getValueWithSpaces(hid_attr, 1)).append(Constants.TAB);
		correctingConfTask9_RecId_851.append(FormatUtil.getValueWithSpaces(hid, 4)).append(Constants.TAB);
		correctingConfTask9_RecId_851.append(FormatUtil.getValueWithSpaces(hunt_tli_attr, 1)).append(Constants.TAB);
		correctingConfTask9_RecId_851.append(FormatUtil.getValueWithSpaces(hunt_tli, 12)).append(Constants.TAB);

		String ConfirmationDataString = FormatUtil.getValueWithSpaces(correctingConfTask9_RecId_851.toString(), 2400);
		return ConfirmationDataString;
	}
}
