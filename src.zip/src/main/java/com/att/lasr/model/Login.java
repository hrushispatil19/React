package com.att.lasr.model;




import java.util.ArrayList;
import java.util.List;

import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString

public class Login {

	private Header header;
	private SubHeader subHeader;
	private String user_id;
	private String password;
	private String new_password;
	private String verify_new_password;
	private String system;
	private String busunit;
	private List<RejectFieldIdsTableRow> rejectFieldIdsTableRows = new ArrayList<>();
	private List<WindowAccessData> windowAccesDataRows = new ArrayList<>();
	private List<AllValidUserData>allValidUserDataRows = new ArrayList<>();
	private List<AllValidAreaMgrData>allValidAreaMgrDataRows = new ArrayList<>();
	private List<AllValidMgrData>allValidMgrDataRows = new ArrayList<>();
	private List<AllValidWorkGroupData>allValidWorkGroupDataRows = new ArrayList<>();
	private List<WorkgroupCCData>workgroupCCDataRows = new ArrayList<>();
	private List<WorkgroupReassignedUserData> workgroupReassignedUserDataRows =  new ArrayList<>();
	private List<WorkGroupAssignedUserData> workgroupassignedUserDataRows =  new ArrayList<>();
	private List<JeopardyListRechId014> jeopardyListRows = new ArrayList<>();
	private List<JeopardyListRechId019> jeopardyListRows019 = new ArrayList<>();
private List<RejectManualLoginDto> manualRejectDTODataRows = new ArrayList<>(); 

	private List<ManualRejectRec018> manualRejectRec018 = new ArrayList<ManualRejectRec018>();
	
	
	
	private List<UserType> userTypeListRows = new ArrayList<>();
	
	public String getLoginDataString() {
		StringBuilder loginDataSb = new StringBuilder();
		loginDataSb.append("       ");
		loginDataSb.append(FormatUtil.getValueWithSpaces(user_id, 7));
		loginDataSb.append(FormatUtil.getValueWithSpaces(password, 8));

		loginDataSb.append(FormatUtil.getValueWithSpaces(new_password, 8));

		loginDataSb.append(FormatUtil.getValueWithSpaces(busunit, 1));
		String loginDataString = FormatUtil.getValueWithSpaces(loginDataSb.toString(), 2400);
		return loginDataString;

	}

}
