package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class DirectoryCaption9 {
	
	private String itemnum;
	private String dlnum_attr;
	private String dlnum;
	private String lvl_attr;
	private String lvl;
	private String pls_attr;
	private String pls;
	private String plinfo_attr;
	private String plinfo;
	private String pltn_attr;
	private String pltn;
	private String so_attr;
	private String so;
	private String fainfo_attr;
	private String fainfo;
	private String fatn_attr;
	private String fatn;
}
