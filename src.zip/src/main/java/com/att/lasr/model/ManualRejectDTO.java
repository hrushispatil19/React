package com.att.lasr.model;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ManualRejectDTO {
	private String fieldNameAttr;
	private String fiedName;
	private String rejectCodeAttr;
	private String rejectCode;
	private String rejectMessageAttr;
	private String rejectMessage;
	private String itemnumAttr;
	private String itemnum;
	private String sublegnumAttr;
	private String sublegnum;
	private String numnameAttr;
	private String numname;
	private String numnbrAttr;
	private String numnbr;
	private String legnumAttr;
	private String legnum;
	private String lexFieldIdAttr;
	private String lexFieldId;
	

	public String getManualRejectDTODataString() {
		StringBuilder lscNoteDTODataSb = new StringBuilder();
		lscNoteDTODataSb.append(FormatUtil.getValueWithSpaces(fieldNameAttr, 1)).append(Constants.TAB);
		lscNoteDTODataSb.append(FormatUtil.getValueWithSpaces(fiedName, 30)).append(Constants.TAB);
		lscNoteDTODataSb.append(FormatUtil.getValueWithSpaces(rejectCodeAttr, 1)).append(Constants.TAB);
		lscNoteDTODataSb.append(FormatUtil.getValueWithSpaces(rejectCode, 6)).append(Constants.TAB);
		lscNoteDTODataSb.append(FormatUtil.getValueWithSpaces(rejectMessageAttr, 1)).append(Constants.TAB);
		lscNoteDTODataSb.append(FormatUtil.getValueWithSpaces(rejectMessage, 254)).append(Constants.TAB);		
		lscNoteDTODataSb.append(FormatUtil.getValueWithSpaces(itemnumAttr, 1)).append(Constants.TAB);		
		lscNoteDTODataSb.append(FormatUtil.getValueWithSpaces(itemnum, 4)).append(Constants.TAB);
		lscNoteDTODataSb.append(FormatUtil.getValueWithSpaces(sublegnumAttr, 1)).append(Constants.TAB);
		lscNoteDTODataSb.append(FormatUtil.getValueWithSpaces(sublegnum, 4)).append(Constants.TAB);
		lscNoteDTODataSb.append(FormatUtil.getValueWithSpaces(numnameAttr, 1)).append(Constants.TAB);
		lscNoteDTODataSb.append(FormatUtil.getValueWithSpaces(numname, 6)).append(Constants.TAB);
		lscNoteDTODataSb.append(FormatUtil.getValueWithSpaces(numnbrAttr, 1)).append(Constants.TAB);
		lscNoteDTODataSb.append(FormatUtil.getValueWithSpaces(numnbr, 4)).append(Constants.TAB);		
		lscNoteDTODataSb.append(FormatUtil.getValueWithSpaces(legnumAttr, 1)).append(Constants.TAB);		
		lscNoteDTODataSb.append(FormatUtil.getValueWithSpaces(legnum, 3)).append(Constants.TAB);
		lscNoteDTODataSb.append(FormatUtil.getValueWithSpaces(lexFieldIdAttr, 1)).append(Constants.TAB);
		lscNoteDTODataSb.append(FormatUtil.getValueWithSpaces(lexFieldId, 10)).append(Constants.TAB).append(Constants.TAB);
		String lscNoteRequestDataString = FormatUtil.getValueWithSpaces(lscNoteDTODataSb.toString(), 2400);
		return lscNoteRequestDataString;
	}

	
}
