package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ConfirmationViewNonEmailCoreXMLGWDirectoryRow9states {

	
	private String dlnum;
	
	private String ali_attr;
	private String ali;
	private String ltn_attr;
	private String ltn;
	private String nstn_attr;
	private String nstn;
	private String lact_attr;
	private String lact;
	private String lty_att;
	private String lty;
	private String styc_attr;
	private String styc;
	private String  doi_attr;
	private String doi;
	private String toa_attr;
	private String toa;
	private String wpp_attr;
	private String wpp;
	private String listnm__attr;
	private String lisnm;
	private String listadr_attr;
	private String listadr;
}
