package com.att.lasr.model;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class EditEccktData {
	
	private Header header;
	private SubHeader subHeader;
	
	private List<EditEccktTableRow> editEccktTableRows = new ArrayList<EditEccktTableRow>();
	
}
