package com.att.lasr.model;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString

public class CorrectingConfirmationLS0G6DW1row {

	private String cver;
	private String atn_attr;
	private String atn;
	private String init;
	private String rep;
	private String tel_no;
	private String rt;
	private String ecver;
	private String d_t_sent_local;
	private String response_d_t_sent_central_time;
	private String pia;
	private String chc;
	private String fdt_attr;
	private String fdt;
	private String dd_attr;
	private String dd;
	private String apptime_attr;
	private String apptime;
	private String an_attr;
	private String an;
	
	public String getCorrectingConfirmationLS0G6DW1() {
		StringBuilder confirmationLS0G6DW1sb = new StringBuilder();
	
	
		confirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(cver, 2)).append(Constants.TAB);
		confirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(atn_attr, 1)).append(Constants.TAB);
		confirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(atn, 12)).append(Constants.TAB);
		confirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(init, 15)).append(Constants.TAB);
		confirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(rep, 15)).append(Constants.TAB);
		confirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(tel_no, 12)).append(Constants.TAB);
		confirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(rt, 1)).append(Constants.TAB);
		confirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(ecver, 3)).append(Constants.TAB);
		confirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(d_t_sent_local, 17)).append(Constants.TAB);
		confirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(response_d_t_sent_central_time, 17)).append(Constants.TAB);
		confirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(pia, 9)).append(Constants.TAB);
		confirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(chc, 1)).append(Constants.TAB);
		confirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(fdt_attr, 1)).append(Constants.TAB);
		confirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(fdt, 6)).append(Constants.TAB);
		confirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(dd_attr, 1)).append(Constants.TAB);
		confirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(dd, 10)).append(Constants.TAB);
		confirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(apptime_attr, 1)).append(Constants.TAB);
		confirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(apptime, 11)).append(Constants.TAB);
		confirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(an_attr, 1)).append(Constants.TAB);
		confirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(an, 10)).append(Constants.TAB);
	

		String confirmationDataString = FormatUtil.getValueWithSpaces(confirmationLS0G6DW1sb.toString(), 2400);
		return confirmationDataString;
	}
}
