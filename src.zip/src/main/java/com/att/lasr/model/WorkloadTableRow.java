package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class WorkloadTableRow {

	private String status;
	private String date_time_received;
	private String company_code;
	private String expedite;
	private String ddd;
	private String request_id;
	private String pon;
	private String request_type;
	private String tos;
	private String activity;
	private String quantity;
	private String supplement_type;
	private String assigned_user_id_attr;
	private String assigned_user_id;
	private String rpon;
	private String jep_ind;
	private String aging_ind_attc;
	private String aging_ind;
	private String coor_hot_cut;
	private String pre_assign_user_id;
	private String release_version;
	private String total_record;
	private String start_page;
	private String end_page;
	private String begin_time_nextptr;
	private String end_time_nextptr;
	private String begin_time_prevptr;
	private String end_time_prevptr;

}
