package com.att.lasr.model;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@ToString
@AllArgsConstructor
public class ConfirmationTaskNEmailXMLGW9RecId906 {
	private String ord_attr;
	private String ord;
	private String nprod_attr;
	private String nprod;
	private String lord_attr;
	private String lord;
	private String dlord_attr;
	private String dlord;
	private String ddcd_attr;
	private String ddcd;
	private String old_ord;
	private String old_npord;
	private String old_lord;
	private String old_dlord;
	
	public String getSelectRequest906DataString() {
		StringBuilder selectRequestDataSb = new StringBuilder();
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ord_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ord, 20)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(nprod_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(nprod, 20)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(lord_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(lord, 20)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(dlord_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(dlord, 20)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ddcd_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ddcd, 8)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(old_ord, 20)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(old_npord, 20)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(old_lord, 20)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(old_dlord, 20)).append(Constants.TAB).append(Constants.TAB);
		String selectRequestDataString = FormatUtil.getValueWithSpaces(selectRequestDataSb.toString(), 2400);
		return selectRequestDataString;
	}

}
