package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class JeopardyViewTableData12State {

	private String jep_ecckt;
	private String jep_tns;
	private String jep_cfa;
	private String jep_ccea;
	private String cbcid;
	private String cableid;
	private String chan_pair;

}
