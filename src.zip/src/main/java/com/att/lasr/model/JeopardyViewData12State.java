package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class JeopardyViewData12State {

	private String cver_attr;
	private String cver;
	private String rt_attr;
	private String rt;
	private String ec_ver_attr;
	private String ec_ver;
	private String dt_sent_attr;
	private String dt_sent;
	
	private String response_dt_sent_attr;
	private String response_dt_sent;
	private String ord_attr;
	private String ord;	
	private String lord_attr;
	private String lord;
	private String jcode_attr;
	private String jcode;
	private String rcode_attr;
	private String rcode;
	private String rdet_attr;
	private String rdet;
	private String esdd_attr;
	private String esdd;
	private String sent_by_attr;
	private String sent_by;
	private String npord_attr;
	private String npord;
	private String spec_code;
	private String apptime_attr;
	private String apptime;

}
