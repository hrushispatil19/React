package com.att.lasr.model;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class SortErrorData {
	private Header header;
	private SubHeader subHeader;
	private String LSR;
	private String LSR_ver;
	
	private String order_attr;
	private String service_order;
	private String rule_attr;
	private String rule_name;
	private String error_attr;
	private String error_message;
	private String action_attr;
	private String action;
	private String comment_attr;
	private String comment;
	private String so_msg;
	
	public String getSortErrorDataStringforSort() {
		StringBuilder sortErrorSB = new StringBuilder();
		sortErrorSB.append(FormatUtil.getValueWithSpaces(LSR, 14)).append(Constants.TAB);
		sortErrorSB.append(FormatUtil.getValueWithSpaces(LSR_ver, 2)).append(Constants.TAB).append(Constants.TAB);

		String sortErrorDataStringforSort = FormatUtil.getValueWithSpaces(sortErrorSB.toString(), 2400);
		return sortErrorDataStringforSort;
	}
	
	public String getSortErrorDataStringforIssue() {
		StringBuilder sortErrorSB = new StringBuilder();
		
		sortErrorSB.append(FormatUtil.getValueWithSpaces(order_attr, 1)).append(Constants.TAB);
		sortErrorSB.append(FormatUtil.getValueWithSpaces(service_order, 9)).append(Constants.TAB);
		sortErrorSB.append(FormatUtil.getValueWithSpaces(rule_attr, 1)).append(Constants.TAB);
		sortErrorSB.append(FormatUtil.getValueWithSpaces(rule_name, 20)).append(Constants.TAB);
		sortErrorSB.append(FormatUtil.getValueWithSpaces(error_attr, 1)).append(Constants.TAB);
		sortErrorSB.append(FormatUtil.getValueWithSpaces(error_message, 300)).append(Constants.TAB);
		sortErrorSB.append(FormatUtil.getValueWithSpaces((action_attr.equals("U")?"Y":action_attr), 1)).append(Constants.TAB);
		sortErrorSB.append(FormatUtil.getValueWithSpaces(action, 10)).append(Constants.TAB);
		sortErrorSB.append(FormatUtil.getValueWithSpaces((comment_attr.equals("U")?"Y":comment_attr), 1)).append(Constants.TAB);
		sortErrorSB.append(FormatUtil.getValueWithSpaces(comment, 30)).append(Constants.TAB);
		sortErrorSB.append(FormatUtil.getValueWithSpaces(so_msg, 300)).append(Constants.TAB).append(Constants.TAB);
		
		String sortErrorDataString = FormatUtil.getValueWithSpaces(sortErrorSB.toString(), 2400);
		return sortErrorDataString;
	}
	
}
