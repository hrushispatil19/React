package com.att.lasr.model;

import lombok.Data;

@Data
public class AttErrorCodeData9 {
  
	private Header header;
	private SubHeader subHeader;
	private String lg_code;
	private String field_name;
	private String field_value;
	private String process_mode;
	private String err_failed;
}
