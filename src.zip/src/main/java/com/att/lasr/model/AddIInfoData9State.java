package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class AddIInfoData9State {

	private String lasrver;
	private String dt_enter;
	private String item_num;
	private String field_name;
	private String field_data;

}