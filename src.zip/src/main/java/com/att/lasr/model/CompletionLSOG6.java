package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class CompletionLSOG6 {
	

	
	private String a_cver; //2
	private String a_atn; //12
	private String a_rt; //1
	private String a_ecver; //3
	private String d_t_sent_local; //17
	private String response_d_t_sent_central_time; // 17
	private String a_comp_dt_attr; //1
	private String comp_dt; // 10
	private String a_company_code_attr;  //1
	private String a_comapny_code; //4
	private String a_an;  //10


}
