package com.att.lasr.model;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class JeopardyTask12STRechId582 {

	
	 private String ecver_attr;
	 private String ecver; 
	 private String ord_attr;
	 private String ord; 
	 private String lord_attr; 
	 private String lord; 
	 private String jcode_attr; 
	 private String jcode; 
	 private String rcode_attr; 
	 private String rcode; 
	 private String esdd_attr; 
	 private String esdd;
	 
	 public String getJeopardyTask12STRechId582String() {
			StringBuilder selectRequestDataSb = new StringBuilder();

			
			selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ecver_attr, 1)).append(Constants.TAB);
			selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ecver, 4)).append(Constants.TAB);
			selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ord_attr, 1)).append(Constants.TAB);
			selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ord, 20)).append(Constants.TAB);
			selectRequestDataSb.append(FormatUtil.getValueWithSpaces(lord_attr, 1)).append(Constants.TAB);
			selectRequestDataSb.append(lord.trim()).append(Constants.TAB);
			selectRequestDataSb.append(FormatUtil.getValueWithSpaces(jcode_attr, 1)).append(Constants.TAB);
			selectRequestDataSb.append(FormatUtil.getValueWithSpaces(jcode, 6)).append(Constants.TAB);
			selectRequestDataSb.append(FormatUtil.getValueWithSpaces(rcode_attr, 1)).append(Constants.TAB);
			selectRequestDataSb.append(FormatUtil.getValueWithSpaces(rcode, 2)).append(Constants.TAB);
		//	selectRequestDataSb.append(FormatUtil.getValueWithSpaces(esdd_attr, 1)).append(Constants.TAB);
			selectRequestDataSb.append(FormatUtil.getValueWithSpaces(FormatUtil.getMqDateFormatString(esdd), 8)).append(Constants.TAB).append(Constants.TAB);
			
		
			
			String selectRequestDataString = FormatUtil.getValueWithSpaces(selectRequestDataSb.toString(), 2400);
			return selectRequestDataString;
		}
	 
	 public String getJeopardyTask9STRechId582String() {
			StringBuilder selectRequestDataSb = new StringBuilder();

			
			selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ecver_attr, 1)).append(Constants.TAB);
			selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ecver, 4)).append(Constants.TAB);
			selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ord_attr, 1)).append(Constants.TAB);
			selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ord, 20)).append(Constants.TAB);
			selectRequestDataSb.append(FormatUtil.getValueWithSpaces(lord_attr, 1)).append(Constants.TAB);
			selectRequestDataSb.append(lord.trim()).append(Constants.TAB);
			selectRequestDataSb.append(FormatUtil.getValueWithSpaces(jcode_attr, 1)).append(Constants.TAB);
			selectRequestDataSb.append(FormatUtil.getValueWithSpaces(jcode, 2)).append(Constants.TAB);
			selectRequestDataSb.append(FormatUtil.getValueWithSpaces(rcode_attr, 1)).append(Constants.TAB);
			selectRequestDataSb.append(FormatUtil.getValueWithSpaces(rcode, 2)).append(Constants.TAB);
		//	selectRequestDataSb.append(FormatUtil.getValueWithSpaces(esdd_attr, 1)).append(Constants.TAB);
			selectRequestDataSb.append(FormatUtil.getValueWithSpaces(FormatUtil.getMqDateFormatString(esdd), 8)).append(Constants.TAB).append(Constants.TAB);
			
		
			
			String selectRequestDataString = FormatUtil.getValueWithSpaces(selectRequestDataSb.toString(), 2400);
			return selectRequestDataString;
		}
}
