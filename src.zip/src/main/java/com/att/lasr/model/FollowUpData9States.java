package com.att.lasr.model;

import java.util.ArrayList;
import java.util.List;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@NoArgsConstructor
@ToString
public class FollowUpData9States {
	private Header header;
	private String notes_datetime;
	private String user_id_attr;
	private String user_id;
	private String lasr_ver_attr;
	private String lasr_ver;
	private String follow_up_date_attr;
	private String follow_up_date;
	private String notes_attr;
	private String notes;
	
	private List<FollowUpTableRow> followUpTableRows = new ArrayList<FollowUpTableRow>();
	
	public String getSelectRequestNotesDataString() {
		StringBuilder selectRequestDataSb = new StringBuilder();

		
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(notes_datetime, 17)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(user_id_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(user_id, 7)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(lasr_ver_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(lasr_ver, 2)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(follow_up_date_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(follow_up_date, 8)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(notes_attr, 1)).append(Constants.TAB);
		
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(notes, 2300)).append(Constants.TAB).append(Constants.TAB);
		String selectRequestDataString = FormatUtil.getValueWithSpaces(selectRequestDataSb.toString(), 2400);
		return selectRequestDataString;
	}
	
}
