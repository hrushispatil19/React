package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ConfiramtionRemarksReview {
	
	private String fac_msg_attr;
	private String fac_msg;
	private String remarks_attr;
	private String remarks;
	

}
