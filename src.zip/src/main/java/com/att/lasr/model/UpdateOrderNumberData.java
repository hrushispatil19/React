package com.att.lasr.model;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class UpdateOrderNumberData implements Serializable{

	private Header header;
	private SubHeader subHeader;
	
	private List<NotesFupBindingData12States> notesFupBindingData12States;
	private List<UpdateOrderNumberRow> updateOrderNumberTableRows; 
}
