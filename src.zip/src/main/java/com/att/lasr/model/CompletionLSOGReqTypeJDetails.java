package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class CompletionLSOGReqTypeJDetails {
	
	
	public Header header;

	public SubHeader subHeader;
	
	private String itemnum; // 4
	private String dlnum; // 4
	private String ali; // 3
	private String ltn; //12
	private String nstn; // 20
	private String lact; // 1
	private String lty; //1
	private String styc; // 2
	private String toa; // 2
	private String doi; //1
	private String listnm; //252
	private String listadr; //150


}
