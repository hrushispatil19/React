package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ManualRejectRec018 {
	private String name;
	private String type;
	private String length;
	private String decimal;
	private String initialValue;
	private String validationExpression;
	private String validationMessage;
	private String dbName;
	
}
