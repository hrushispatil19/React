package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class InterfaceMessagesData12State {

	private String supp;
	private String dttm_message;
	private String item_num;
	private String inter_face;
	private String interface_status;

}
