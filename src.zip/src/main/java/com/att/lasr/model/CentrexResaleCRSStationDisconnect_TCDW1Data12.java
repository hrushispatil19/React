package com.att.lasr.model;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class CentrexResaleCRSStationDisconnect_TCDW1Data12 {
	private String item_num;
	private String lnum_attr;
	private String lnum;
	private String tc_opt_attr;
	private String tc_opt;
	private String tc_per_attr;
	private String tc_per;
	private String tc_to_pri_attr;
	private String tc_to_pri;
	private String tc_name_pri_attr;
	private String tc_name_pri;
	private String tc_id_attr;
	private String tc_id;
	
}
