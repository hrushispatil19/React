package com.att.lasr.model;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString


public class ConfirmationLS0G6DW3Row {

	
	private String item_num;	
	private String hnum;
	private String hid_attr;
	private String hid;
	private String hunt_tli_attr;
	private String hunt_tli;

	
	public String getConfirmationLS0G6DW3() {
		StringBuilder confirmationLS0G6DW3sb = new StringBuilder();
	
		confirmationLS0G6DW3sb.append(FormatUtil.getValueWithSpaces(item_num, 4)).append(Constants.TAB);
		confirmationLS0G6DW3sb.append(FormatUtil.getValueWithSpaces(hnum, 4)).append(Constants.TAB);
		confirmationLS0G6DW3sb.append(FormatUtil.getValueWithSpaces(hid_attr, 1)).append(Constants.TAB);
		confirmationLS0G6DW3sb.append(FormatUtil.getValueWithSpaces(hid, 4)).append(Constants.TAB);
		confirmationLS0G6DW3sb.append(FormatUtil.getValueWithSpaces(hunt_tli_attr, 1)).append(Constants.TAB);
		confirmationLS0G6DW3sb.append(FormatUtil.getValueWithSpaces(hunt_tli, 12)).append(Constants.TAB);

		String confirmationDataString = FormatUtil.getValueWithSpaces(confirmationLS0G6DW3sb.toString(), 2400);
		return confirmationDataString;
	}
}
