package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class RejectManualLoginDto  implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String lastVersion;
	private String fieldName;
	private String rejectCodeAttr;
	private String rejectCode;
	private String rejectMessage;
	
	
}
