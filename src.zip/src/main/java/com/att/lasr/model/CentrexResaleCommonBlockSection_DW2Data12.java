package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class CentrexResaleCommonBlockSection_DW2Data12 {
	private String sna_attr;
	private String sna;
	private String sn_attr;
	private String sn;
}
