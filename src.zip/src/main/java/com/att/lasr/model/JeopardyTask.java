package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class JeopardyTask {

	 private String ord; 
	 private String jcode; 
	 private String rcode;
	 private String esdd;
	 private String clec_note;
	 private String notes;
	 private String ecver;
	 private String clec_ecver;
	 private String jep_ecckt;
	 private String tns;
	 private String apptime;
	 private String cfa;
	 private String ccea;
	 private String cableid;
	 private String cbcid;
	 private String chanpair;
}
