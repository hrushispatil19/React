package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@NoArgsConstructor
@ToString
public class EndUser_12States {
	private String itemnum_attr;
	private String itemnum;
	private String itemnum1_attr;
	private String itemnum1;
	private String locnum_attr;
	private String locnum;
	private String locnum1_attr;
	private String locnum1;
	private String eu_name_attr;
	private String eu_name;
	private String eu_eatn_attr;
	private String eu_eatn;
	private String elt_attr;
	private String elt;
	private String wsop_attr;
	private String wsop;
	private String eu_ncon_attr;
	private String eu_ncon;
	private String eu_aft_attr;
	private String eu_aft;
	private String eu_sapr_attr;
	private String eu_sapr;
	private String eu_sapr1_attr;
	private String eu_sapr1;
	private String eu_sano_attr;
	private String eu_sano;
	private String eu_sano1_attr;
	private String eu_sano1;
	private String eu_sasf_attr;
	private String eu_sasf;
	private String eu_sasf1_attr;
	private String eu_sasf1;
	private String eu_sasd_attr;
	private String eu_sasd;
	private String eu_sasd1_attr;
	private String eu_sasd1;
	private String eu_sasn_attr;
	private String eu_sasn;
	private String eu_sasn1_attr;
	private String eu_sasn1;
	private String eu_sath_attr;
	private String eu_sath;
	private String eu_sath1_attr;
	private String eu_sath1;
	private String eu_sass_attr;
	private String eu_sass;
	private String eu_sass1_attr;
	private String eu_sass1;
	private String eu_ld1_attr;
	private String eu_ld1;
	private String eu_ld11_attr;
	private String eu_ld11;
	private String ei_lv1_attr;
	private String eu_lv1;
	private String eu_lv11_attr;
	private String eu_lv11;
	private String eu_ld2_attr;
	private String eu_ld2;
	private String eu_ld22_attr;
	private String eu_ld22;
	private String eu_lv2_attr;
	private String eu_lv2;
	private String eu_lv22_attr;
	private String eu_lv22;
	private String eu_ld3_attr;
	private String eu_ld3;
	private String eu_ld33_attr;
	private String eu_ld33;
	private String eu_lv3_attr;
	private String eu_lv3;
	private String eu_lv33_attr;
	private String eu_lv33;
	private String eu_aai_attr;
	private String eu_aai;
	private String eu_aai1_attr;
	private String eu_aai1;
	private String eu_city_attr;
	private String eu_city;
	private String eu_city1_attr;
	private String eu_city1;
	private String eu_state_attr;
	private String eu_state;
	private String eu_state1_attr;
	private String eu_state1;
	private String eu_zip_attr;
	private String eu_zip;
	private String eu_zip1_attr;
	private String eu_zip1;
	private String eu_lcon_attr;
	private String eu_lcon;
	private String eu_telno_attr;
	private String eu_telno;
	private String eu_acc_attr;
	private String eu_acc;
	private String cpe_mfr_attr;
	private String cpe_mfr;
	private String cpe_mod_attr;
	private String cpe_mod;


}
