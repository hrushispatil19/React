package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class DirectoryListing12 {
	
	private String itemnum;
	private String dlnum_attr;
	private String dlnum;
	private String lact_attr;
	private String lact;
	private String ali_attr;
	private String ali;
	private String rty_attr;
	private String rty;
	private String lty_attr;
	private String lty;
	private String styc_attr;
	private String styc;
	private String toa_attr;
	private String toa;
	private String doi_attr;
	private String doi;
	private String wpp_attr;
	private String wpp;
	private String dml_attr;
	private String dml;
	private String bro_attr;
	private String bro;
	private String adv_attr;
	private String adv;
	private String str_attr;
	private String str;
	private String dlnm_attr;
	private String dlnm;
	private String diridl_attr;
	private String diridl;
	private String prof_attr;
	private String prof;
	private String dirsub_attr;
	private String dirsub;
	private String omsd_attr;
	private String omsd;
	private String ltn_attr;
	private String ltn;
	private String nstn_attr;
	private String nstn;
	private String omtn_attr;
	private String omtn;
	private String lex_attr;
	private String lex;
	private String dna_attr;
	private String dna;
	private String lnpl_attr;
	private String lnpl;
	private String lnln_attr;
	private String lnln;
	private String lnfn_attr;
	private String lnfn;
	private String des_attr;
	private String des;
	private String tl_attr;
	private String tl;
	private String title1_attr;
	private String title1;
	private String title2_attr;
	private String title2;
	private String tld_attr;
	private String tld;
	private String title1d_attr;
	private String title1d;
	private String title2d_attr;
	private String title2d;
	private String nick_attr;
	private String nick;
	private String pla_attr;
	private String pla;
	private String lphrase_attr;
	private String lphrase;
	private String adi_attr;
	private String adi;
	private String dno_attr;
	private String dno;
	private String lapr_attr;
	private String lapr;
	private String lano_attr;
	private String lano;
	private String lasf_attr;
	private String lasf;
	private String lasd_attr;
	private String lasd;
	private String lasn_attr;
	private String lasn;
	private String lath_attr;
	private String lath;
	private String lass_attr;
	private String lass;
	private String lalo_attr;
	private String lalo;
	private String laloc_attr;
	private String laloc;
	private String last_attr;
	private String last;
	private String lazc_attr;
	private String lazc;
	private String sic_attr;
	private String sic;
	private String yph_attr;
	private String yph;


}
