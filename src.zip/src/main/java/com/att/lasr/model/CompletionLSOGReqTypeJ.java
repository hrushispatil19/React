package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class CompletionLSOGReqTypeJ {
	
	public Header header;

	public SubHeader subHeader;
	
	private String cver; //2
	private String dor; //17
	private String atn; //12
	private String  rt; //1
	private String ecver; //3
	private String d_t_sent_local; //17
	private String response_d_t_sent_central_time; // 17
	private String dda; //10
	

}
