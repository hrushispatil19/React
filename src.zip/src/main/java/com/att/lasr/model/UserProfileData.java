package com.att.lasr.model;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class UserProfileData {

	private Header header;
	private SubHeader subHeader;

	private String user_id_attr;
	private String user_id;
	private String name_attr;
	private String name;
	private String telephone_number_attr;
	private String telephone_number;
	private String user_type_attr;
	private String user_type;
	private String subsidiary_attr;
	private String subsidiary;
	private String typist_attr;
	private String typist;
	private String sales_code_attr;
	private String sales_code;
	private String dflt_ims_region_attr;
	private String dflt_ims_region;
	private String status_attr;
	private String status;
	private String manager_attr;
	private String manager;
	private String area_manager_attr;
	private String area_manager;
	private String last_updt_id;
	private String last_updt_dttm;
	private String multi_access_ind_attr;
	private String multi_access_ind;
	private String lg_code;
	private String field_name;
	private String field_value;
	private String process_mode;
	private String err_failed;

	public String getRetrieveUserProfileDataString() {
		StringBuilder userProfileDataSb = new StringBuilder();
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(user_id, 7)).append(Constants.TAB);
		String userProfileDataString = FormatUtil.getValueWithSpaces(userProfileDataSb.toString(), 2400);
		return userProfileDataString;
	}
	
	public String getLogoffUserProfileDataString() {
		
		StringBuilder userProfileDataSb = new StringBuilder();
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(user_id, 7)).append(Constants.TAB).append(Constants.TAB);
		String userProfileDataString = FormatUtil.getValueWithSpaces(userProfileDataSb.toString(), 2400);
		return userProfileDataString;
	}

	public String getSaveUserProfileDataString() {

		StringBuilder userProfileDataSb = new StringBuilder();
		userProfileDataSb.append(Constants.Y).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(user_id.toUpperCase(), 7)).append(Constants.TAB);
		userProfileDataSb.append(Constants.Y).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(name.toUpperCase(), 25)).append(Constants.TAB);
		userProfileDataSb.append(Constants.Y).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(FormatUtil.getStringWithoutDashes(telephone_number), 10))
				.append(Constants.TAB);
		userProfileDataSb.append(Constants.Y).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(user_type, 2)).append(Constants.TAB);
		userProfileDataSb.append(Constants.Y).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(subsidiary, 1)).append(Constants.TAB);
		userProfileDataSb.append(Constants.Y).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(typist.toUpperCase(), 4)).append(Constants.TAB);
		userProfileDataSb.append(Constants.Y).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(sales_code.toUpperCase(), 9)).append(Constants.TAB);
		userProfileDataSb.append(Constants.Y).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(dflt_ims_region, 10)).append(Constants.TAB);
		userProfileDataSb.append(Constants.Y).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(status, 1)).append(Constants.TAB);
		userProfileDataSb.append(Constants.Y).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(manager.toUpperCase(), 7)).append(Constants.TAB);
		userProfileDataSb.append(Constants.Y).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(area_manager.toUpperCase(), 7)).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(last_updt_id, 7)).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(last_updt_dttm, 18)).append(Constants.TAB);
		//userProfileDataSb.append(Constants.Y).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(multi_access_ind_attr, 1)).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(multi_access_ind, 1)).append(Constants.TAB).append(Constants.TAB);
		

		String userProfileDataString = FormatUtil.getValueWithSpaces(userProfileDataSb.toString(), 2400);
		return userProfileDataString;
	}
	
	public String geUpdateUserProfileDataString() {

		StringBuilder userProfileDataSb = new StringBuilder();
		
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(user_id_attr, 1)).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(user_id.toUpperCase(), 7)).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(name_attr, 1)).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(name.toUpperCase(), 25)).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(telephone_number_attr, 1)).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(FormatUtil.getStringWithoutDashes(telephone_number), 10))
				.append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(user_type_attr, 1)).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(user_type, 2)).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(subsidiary_attr, 1)).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(subsidiary, 1)).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(typist_attr, 1)).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(typist.toUpperCase(), 4)).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(sales_code_attr, 1)).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(sales_code.toUpperCase(), 9)).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(dflt_ims_region_attr, 1)).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(dflt_ims_region, 10)).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(status_attr, 1)).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(status, 1)).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(manager_attr, 1)).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(manager.toUpperCase(), 7)).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(area_manager_attr, 1)).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(area_manager.toUpperCase(), 7)).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(last_updt_id, 7)).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(last_updt_dttm, 18)).append(Constants.TAB);
		//userProfileDataSb.append(Constants.Y).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(multi_access_ind_attr, 1)).append(Constants.TAB);
		userProfileDataSb.append(FormatUtil.getValueWithSpaces(multi_access_ind, 1)).append(Constants.TAB).append(Constants.TAB);
		

		String userProfileDataString = FormatUtil.getValueWithSpaces(userProfileDataSb.toString(), 2400);
		return userProfileDataString;
	}
}
