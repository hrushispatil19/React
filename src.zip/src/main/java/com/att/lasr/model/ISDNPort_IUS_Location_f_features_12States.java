/**
 * 
 */
package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ISDNPort_IUS_Location_f_features_12States {
	
	
	private String item_num;
	private String f_fa_attr;
	private String f_fa;
	private String f_feature_attr;
	private String f_feature;
	private String f_feature_detail_attr;
	private String f_feature_detail;
	private String line_asgn_attr;
	private String line_asgn;

}
