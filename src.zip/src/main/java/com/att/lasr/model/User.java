package com.att.lasr.model;

import java.util.ArrayList;

public class User {
	
    int userId;
    String userName; 
    private ArrayList<String> userRoles = new ArrayList<String>();
 
    public User() {
        super();
    }
    public User(int userId, String userName,ArrayList<String> userRoles) {
        super();
        this.userId=userId;
        this.userName=userName;
        this.userRoles=userRoles;
    }
    public int getUserId() {
        return userId;
    }
    public void setUserId(int userId) {
        this.userId = userId;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public ArrayList<String> getUserRoles() {
        return userRoles;
    }
    public void setUserRoles(ArrayList<String> userRoles) {
        this.userRoles = userRoles;
    }
}
