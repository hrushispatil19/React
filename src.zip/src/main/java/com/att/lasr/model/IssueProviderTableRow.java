package com.att.lasr.model;



import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class IssueProviderTableRow {
	
	private String ord;
	private String cvd;
	private String wtn;
	private String ecckt;
	private String message;

}
