package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString

public class ConfirmationLS0G6DW1Row {

	private String a_cver;
	private String a_atn_attr;
	private String a_atn;
	private String a_init;
	private String a_rep;
	private String a_tel_no;
	private String a_rt;
	private String a_ecver;
	private String a_d_t_sent_local;
	private String a_response_d_t_sent_cent_time;
	private String a_pia;
	private String a_chc;
	private String a_fdt_attr;
	private String a_fdt;
	private String a_dd_att;
	private String a_dd;
	private String app_time_attr;
	private String apptime;
	private String a_an_attr;
	private String a_an;
	
	
}
