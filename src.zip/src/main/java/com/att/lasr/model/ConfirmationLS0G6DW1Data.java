package com.att.lasr.model;

import java.util.ArrayList;
import java.util.List;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString

public class ConfirmationLS0G6DW1Data {

	private Header header;
	private SubHeader subHeader;
	private String a_cver;
	private String a_atn_attr;
	private String a_atn;
	private String a_init;
	private String a_rep;
	private String a_tel_no;
	private String a_rt;
	private String a_ecver;
	private String a_d_t_sent_local;
	private String a_response_d_t_sent_cent_time;
	private String a_pia;
	private String a_chc;
	private String a_fdt_attr;
	private String a_fdt;
	private String a_dd_att;
	private String a_dd;
	private String app_time_attr;
	private String apptime;
	private String a_an_attr;
	private String a_an;
	
	private List<ConfirmationLS0G6DW1Row> confirmationLS0G6DW1Row = new ArrayList<>();

	public String getConfirmationLS0G6DW1() {
		StringBuilder ConfirmationLS0G6DW1sb = new StringBuilder();
	
	
		ConfirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(a_cver, 2)).append(Constants.TAB);
		ConfirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(a_atn_attr, 1)).append(Constants.TAB);
		ConfirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(a_atn, 12)).append(Constants.TAB);
		ConfirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(a_init, 15)).append(Constants.TAB);
		ConfirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(a_rep, 15)).append(Constants.TAB);
		ConfirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(a_tel_no, 12)).append(Constants.TAB);
		ConfirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(a_rt, 1)).append(Constants.TAB);
		ConfirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(a_ecver, 3)).append(Constants.TAB);
		ConfirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(a_d_t_sent_local, 17)).append(Constants.TAB);
		ConfirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(a_response_d_t_sent_cent_time, 17)).append(Constants.TAB);
		ConfirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(a_pia, 9)).append(Constants.TAB);
		ConfirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(a_chc, 1)).append(Constants.TAB);
		ConfirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(a_fdt_attr, 1)).append(Constants.TAB);
		ConfirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(a_fdt, 6)).append(Constants.TAB);
		ConfirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(a_dd_att, 1)).append(Constants.TAB);
		ConfirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(a_dd, 10)).append(Constants.TAB);
		ConfirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(app_time_attr, 1)).append(Constants.TAB);
		ConfirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(apptime, 11)).append(Constants.TAB);
		ConfirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(a_an_attr, 1)).append(Constants.TAB);
		ConfirmationLS0G6DW1sb.append(FormatUtil.getValueWithSpaces(a_an, 10)).append(Constants.TAB);
	

		String ConfirmationDataString = FormatUtil.getValueWithSpaces(ConfirmationLS0G6DW1sb.toString(), 2400);
		return ConfirmationDataString;
	}
	
}
