package com.att.lasr.model;

import java.util.Map;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class MQReceivedData {
	private Header header;
	private Map<String, SubData> subDatas;
}
