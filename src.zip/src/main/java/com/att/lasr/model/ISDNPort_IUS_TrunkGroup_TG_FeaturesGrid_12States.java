/**
 * 
 */
package com.att.lasr.model;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString

public class ISDNPort_IUS_TrunkGroup_TG_FeaturesGrid_12States {
	private String item_num;
	private String tgfa_attr;
	private String tgfa;
	private String tgfeature_attr;
	private String tgfeature;
	private String tgfeature_detail_attr;
	private String tgfeature_detail;
	private String line_asgn_attr;
	private String line_asgn;
}
