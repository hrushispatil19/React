/**
 * 
 */
package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ISDNPort_IUS_PRI_DISC_TC_12States {
	private String item_num;
	private String tc_id_sec_attr;
	private String tc_id_sec;
	private String tc_to_sec_attr;
	private String tc_to_sec;
	private String tc_name_sec_attr;
	private String tc_name_sec;
    private String locnum;
    private String loc_seq_num;
	

}
