package com.att.lasr.model;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author sp860u
 *
 */
@Setter
@Getter
@NoArgsConstructor
@ToString
public class Correcting_ConfirmationTask_RecId_856 {

	private String cver ;
	private String svc_rep ;
	private String svc_rep_tn ;
	private String atn_attr ;
	private String atn ;
	private String rt ;
	private String ecver ;
	private String d_t_sent_local ;
	private String response_d_t_sent_central_time ;
	private String dd_attr ;
	private String dd ;
	private String pia ;
	private String an_attr ;
	private String an ;
	
	public String getSelectRequest856DataString() {
		StringBuilder selectRequestDataSb = new StringBuilder();

		
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(cver, 2).trim()).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(svc_rep, 15).trim()).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(svc_rep_tn, 12).trim()).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(atn_attr, 1).trim()).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(atn, 12).trim()).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(rt, 1).trim()).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ecver, 3).trim()).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(d_t_sent_local, 17).trim()).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(response_d_t_sent_central_time, 17).trim()).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(dd_attr, 1).trim()).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(dd, 10).trim()).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(pia, 1).trim()).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(an_attr, 1).trim()).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(an, 13).trim()).append(Constants.TAB).append(Constants.TAB);
		String selectRequestDataString = FormatUtil.getValueWithSpaces(selectRequestDataSb.toString(), 2400);
		
		return selectRequestDataString;
	}
}
