package com.att.lasr.model;
import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ConfirmationReqtypRLSOG6102Row {

	private String cver;
	private String atn;
	private String rt;
	private String ecver;
	private String d_t_sent_local;
	private String response_d_t_sent_central_time; 
	private String an;
	public int uniqueId;
	
	public String getConfirmationReqtypRLSOG6102() {
		StringBuilder ConfirmationReqtypRLSOG6102sb = new StringBuilder();
	
		ConfirmationReqtypRLSOG6102sb.append(FormatUtil.getValueWithSpaces(cver, 2)).append(Constants.TAB);
		ConfirmationReqtypRLSOG6102sb.append(FormatUtil.getValueWithSpaces(atn, 12)).append(Constants.TAB);
		ConfirmationReqtypRLSOG6102sb.append(FormatUtil.getValueWithSpaces(rt, 1)).append(Constants.TAB);
		ConfirmationReqtypRLSOG6102sb.append(FormatUtil.getValueWithSpaces(ecver, 3)).append(Constants.TAB);
		ConfirmationReqtypRLSOG6102sb.append(FormatUtil.getValueWithSpaces(d_t_sent_local, 17)).append(Constants.TAB);
		ConfirmationReqtypRLSOG6102sb.append(FormatUtil.getValueWithSpaces(response_d_t_sent_central_time, 17)).append(Constants.TAB);
		ConfirmationReqtypRLSOG6102sb.append(FormatUtil.getValueWithSpaces(an, 10)).append(Constants.TAB);
		
		String ConfirmationDataString = FormatUtil.getValueWithSpaces(ConfirmationReqtypRLSOG6102sb.toString(), 2400);
		return ConfirmationDataString;
	}	
}
