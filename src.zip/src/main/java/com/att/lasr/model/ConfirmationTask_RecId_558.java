package com.att.lasr.model;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author sp860u
 *
 */
@Setter
@Getter
@NoArgsConstructor
@ToString
public class ConfirmationTask_RecId_558 {
	
	private String old_dtm ; 
	private String old_ord ;
	private String ord_attr;
	private String ord ;
	private String fdt_attr ;
	private String fdt ;
	private String dd_attr ;
	private String dd ;
	private String comt_dt_attr ;
	private String comt_dt ;
	private String posted_date_attr ;
	private String posted_date ;
	private String apptime_attr ;
	private String apptime ;
	
	public String getSelectRequest558DataString() {
		StringBuilder selectRequestDataSb = new StringBuilder();

		
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(old_dtm, 26)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(old_ord, 20)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ord_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ord, 20)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(fdt_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(fdt, 6)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(dd_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(dd, 8)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(comt_dt_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(comt_dt, 8)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(posted_date_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(posted_date, 8)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(apptime_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(apptime, 11)).append(Constants.TAB).append(Constants.TAB);
		String selectRequestDataString = FormatUtil.getValueWithSpaces(selectRequestDataSb.toString(), 2400);
		return selectRequestDataString;
	}
}
