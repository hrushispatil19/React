
  
function getTokenForHttps(xhttp){
	var token = $("meta[name='_csrf']").attr("content");
	var header = $("meta[name='_csrf_header']").attr("content");
	xhttp.setRequestHeader(header, token);
	
}	
	
	//window.onload = onLoadFunction;
//	var currUrl=document.location.hostname;  
	function onLoadFunction() {
		var currentHost=document.location.hostname; 
		console.log("in onLoadFunction fun currentHost",currentHost);
		if(currentHost=="onelasrgui.stage.att.com"){
		document.getElementById('submit').style.display = 'none';
		
		
		}else if(currentHost=="onelasrgui-w.stage.az.3pc.att.com"){
			$("#environment").append("DevelopmentTest"); 
			$("#region").append("A5 - SW System Test");
//			$('#region').attr('disabled', true);
//			$('#environment').attr('disabled', true);
			document.getElementById('submit').style.display = 'inline';
				
		}else if(currentHost=="onelasrgui-se.stage.az.3pc.att.com"){
			$("#environment").append("DevelopmentTest"); 
			$("#region").append("AA - 12 states Dev");
//			$('#region').attr('disabled', true);
//			$('#environment').attr('disabled', true);
			document.getElementById('submit').style.display = 'inline';
		
		
		}else if(currentHost=="onelasrgui-sw.stage.az.3pc.att.com"){
			$("#environment").append("DevelopmentTest"); 
			$("#region").append("D3 - 9 states Dev");
//			$('#region').attr('disabled', true);
//			$('#environment').attr('disabled', true);
			document.getElementById('submit').style.display = 'inline';
		
		
		
		}else if(currentHost=="onelasrgui-mw.stage.az.3pc.att.com"){
			$("#environment").append("DevelopmentTest"); 
			$("#region").append("T3 - MW System Test");
//			$('#region').attr('disabled', true);
//			$('#environment').attr('disabled', true);
			document.getElementById('submit').style.display = 'inline';
		
		}else{
		
    	document.getElementById('submit').style.display = 'none';
		
   		 }
	
	}
	
  function callForNewRegion(regionSelected)  {
//    https://onelasrgui.stage.att.com/OneLASRGUI/oauth2/authorization/globallogon
//	https://onelasrgui-se.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_SE
//	https://onelasrgui-sw.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_SW
//	https://onelasrgui-mw.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_MW
//	https://onelasrgui-w.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_W
 
//  SE--> AA - 12 states Dev SW--> D3 - 9 states Dev MW-->T3 - MW System Test stage -->A5 - SW System Test 
 	document.getElementById('submit').style.display = 'none';
  var myCurrHost=document.location.hostname;
   console.log("in callForNewRegion",regionSelected,myCurrHost);
   
   
	// NPRD
   if(myCurrHost=="onelasrgui.stage.att.com" && regionSelected=="AA - 12 states Dev"){
   URL="https://onelasrgui-se.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_SE";
		window.open(URL, '_blank');	
   }else if(myCurrHost=="onelasrgui.stage.att.com" && regionSelected=="D3 - 9 states Dev"){
   URL="https://onelasrgui-sw.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_SW";
		window.open(URL, '_blank');	
   }else if(myCurrHost=="onelasrgui.stage.att.com" && regionSelected=="T2 - MW prod mirror"){
   URL="https://onelasrgui-mw.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_MW";
		window.open(URL, '_blank');	
   }else if(myCurrHost=="onelasrgui.stage.att.com" && regionSelected=="P2 - W prod mirror"){
   URL="https://onelasrgui-w.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_W";
		window.open(URL, '_blank');	
   }else if(myCurrHost=="onelasrgui-w.stage.az.3pc.att.com" && regionSelected=="P2 - W prod mirror"){
		document.getElementById('submit').style.display = 'inline';
	
   }else if(myCurrHost=="onelasrgui-se.stage.az.3pc.att.com" && regionSelected=="AA - 12 states Dev"){
		document.getElementById('submit').style.display = 'inline';
	
   }else if(myCurrHost=="onelasrgui-sw.stage.az.3pc.att.com" && regionSelected=="D3 - 9 states Dev"){
			document.getElementById('submit').style.display = 'inline';
   }else if(myCurrHost=="onelasrgui-mw.stage.az.3pc.att.com"  && regionSelected=="T2 - MW prod mirror"){
			document.getElementById('submit').style.display = 'inline';
   }
        
	else  if(myCurrHost=="onelasrgui.stage.att.com" && regionSelected=="D7 - SE ST1"){
   URL="https://onelasrgui-d7.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_D7";
		window.open(URL, '_blank');	
   }else if(myCurrHost=="onelasrgui.stage.att.com" && regionSelected=="D6 - SE RS1"){
   URL="https://onelasrgui-d6.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_D6";
		window.open(URL, '_blank');	
   }else if(myCurrHost=="onelasrgui.stage.att.com" && regionSelected=="D2 - 9 states Dev"){
   URL="https://onelasrgui-d2.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_D2";
		window.open(URL, '_blank');	
   }else if(myCurrHost=="onelasrgui.stage.att.com" && regionSelected=="D5 - SE ST2"){
   URL="https://onelasrgui-d5.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_D5";
		window.open(URL, '_blank');	
   }else  if(myCurrHost=="onelasrgui.stage.att.com" && regionSelected=="D8 - SE RS2"){
   URL="https://onelasrgui-d8.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_D8";
		window.open(URL, '_blank');	
   }else if(myCurrHost=="onelasrgui.stage.att.com" && regionSelected=="A0 - 12 states Dev"){
   URL="https://onelasrgui-a0.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_A0";
		window.open(URL, '_blank');	
   }else if(myCurrHost=="onelasrgui.stage.att.com" && regionSelected=="B1 - 12 states Dev"){
   URL="https://onelasrgui-b1.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_B1";
		window.open(URL, '_blank');	
   }else if(myCurrHost=="onelasrgui.stage.att.com" && regionSelected=="A5 - SW System Test"){
   URL="https://onelasrgui-a5.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_A5";
		window.open(URL, '_blank');	
   }else  if(myCurrHost=="onelasrgui.stage.att.com" && regionSelected=="AH - SW prod mirror"){
   URL="https://onelasrgui-ah.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_AH";
		window.open(URL, '_blank');	
   }else if(myCurrHost=="onelasrgui.stage.att.com" && regionSelected=="T3 - MW System Test"){
   URL="https://onelasrgui-t3.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_T3";
		window.open(URL, '_blank');	
   }else if(myCurrHost=="onelasrgui.stage.att.com" && regionSelected=="P3 - W System Test"){
   URL="https://onelasrgui-p3.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_P3";
		window.open(URL, '_blank');	
   }   

        
	else if(myCurrHost=="onelasrgui-d7.stage.az.3pc.att.com" && regionSelected=="D7 - SE ST1"){
		document.getElementById('submit').style.display = 'inline';
	
   }else if(myCurrHost=="onelasrgui-d6.stage.az.3pc.att.com" && regionSelected=="D6 - SE RS1"){
		document.getElementById('submit').style.display = 'inline';
	
   }else if(myCurrHost=="onelasrgui-d2.stage.az.3pc.att.com" && regionSelected=="D2 - 9 states Dev"){
			document.getElementById('submit').style.display = 'inline';
   }else if(myCurrHost=="onelasrgui-d5.stage.az.3pc.att.com"  && regionSelected=="D5 - SE ST2"){
			document.getElementById('submit').style.display = 'inline';
   }else if(myCurrHost=="onelasrgui-d8.stage.az.3pc.att.com" && regionSelected=="D8 - SE RS2"){
		document.getElementById('submit').style.display = 'inline';
	
   }else if(myCurrHost=="onelasrgui-a0.stage.az.3pc.att.com" && regionSelected=="A0 - 12 states Dev"){
		document.getElementById('submit').style.display = 'inline';
	
   }else if(myCurrHost=="onelasrgui-b1.stage.az.3pc.att.com" && regionSelected=="B1 - 12 states Dev"){
			document.getElementById('submit').style.display = 'inline';
   }else if(myCurrHost=="onelasrgui-a5.stage.az.3pc.att.com"  && regionSelected=="A5 - SW System Test"){
			document.getElementById('submit').style.display = 'inline';
   }else if(myCurrHost=="onelasrgui-ah.stage.az.3pc.att.com" && regionSelected=="AH - SW prod mirror"){
		document.getElementById('submit').style.display = 'inline';
	
   }else if(myCurrHost=="onelasrgui-t3.stage.az.3pc.att.com" && regionSelected=="T3 - MW System Test"){
		document.getElementById('submit').style.display = 'inline';
	
   }else if(myCurrHost=="onelasrgui-p3.stage.az.3pc.att.com" && regionSelected=="P3 - W System Test"){
			document.getElementById('submit').style.display = 'inline';
   }
        
     

        
   // MAT EAST PROD
   
	else if(myCurrHost=="onelasrgui.web.att.com" && regionSelected=="W Production"){
   URL="https://onelasrgui-w.web.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_W";
		window.open(URL, '_blank');	
   }else if(myCurrHost=="onelasrgui.web.att.com" && regionSelected=="MW Production"){
   URL="https://onelasrgui-mw.web.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_MW";
		window.open(URL, '_blank');	
   }else if(myCurrHost=="onelasrgui.web.att.com" && regionSelected=="SE Production"){
   URL="https://onelasrgui-se.web.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_SE";
		window.open(URL, '_blank');	
   }else if(myCurrHost=="onelasrgui.web.att.com" && regionSelected=="SW Production"){
   URL="https://onelasrgui-sw.web.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_SW";
		window.open(URL, '_blank');	
   }else if(myCurrHost=="onelasrgui-w.web.az.3pc.att.com" && regionSelected=="W Production"){
		document.getElementById('submit').style.display = 'inline';
	
   }else if(myCurrHost=="onelasrgui-se.web.az.3pc.att.com" && regionSelected=="SE Production"){
		document.getElementById('submit').style.display = 'inline';
	
   }else if(myCurrHost=="onelasrgui-sw.web.az.3pc.att.com" && regionSelected=="SW Production"){
			document.getElementById('submit').style.display = 'inline';
   }else if(myCurrHost=="onelasrgui-mw.web.az.3pc.att.com"  && regionSelected=="MW Production"){
			document.getElementById('submit').style.display = 'inline';
   }
	
	
	

        
   // MAT WEST PROD
   
	else if(myCurrHost=="onelasrgui-dr.web.att.com" && regionSelected=="W Production"){
   URL="https://onelasrgui-w-dr.web.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_W";
		window.open(URL, '_blank');	
   }else if(myCurrHost=="onelasrgui-dr.web.att.com" && regionSelected=="MW Production"){
   URL="https://onelasrgui-mw-dr.web.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_MW";
		window.open(URL, '_blank');	
   }else if(myCurrHost=="onelasrgui-dr.web.att.com" && regionSelected=="SE Production"){
   URL="https://onelasrgui-se-dr.web.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_SE";
		window.open(URL, '_blank');	
   }else if(myCurrHost=="onelasrgui-dr.web.att.com" && regionSelected=="SW Production"){
   URL="https://onelasrgui-sw-dr.web.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_SW";
		window.open(URL, '_blank');	
   }else if(myCurrHost=="onelasrgui-w-dr.web.az.3pc.att.com" && regionSelected=="W Production"){
		document.getElementById('submit').style.display = 'inline';
	
   }else if(myCurrHost=="onelasrgui-se-dr.web.az.3pc.att.com" && regionSelected=="SE Production"){
		document.getElementById('submit').style.display = 'inline';
	
   }else if(myCurrHost=="onelasrgui-sw-dr.web.az.3pc.att.com" && regionSelected=="SW Production"){
			document.getElementById('submit').style.display = 'inline';
   }else if(myCurrHost=="onelasrgui-mw-dr.web.az.3pc.att.com"  && regionSelected=="MW Production"){
			document.getElementById('submit').style.display = 'inline';
   }
	
	
	
   // Clec
   
	else if(myCurrHost=="onelasrgui-clec.web.att.com" && regionSelected=="D9 - SE CAVE/CLEC"){
   URL="https://onelasrgui-d9.web.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_D9";
		window.open(URL, '_blank');	
   }else if(myCurrHost=="onelasrgui-clec.web.att.com" && regionSelected=="A2 - SW Clec Test"){
   URL="https://onelasrgui-a2.web.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_A2";
		window.open(URL, '_blank');	
   }else if(myCurrHost=="onelasrgui-clec.web.att.com" && regionSelected=="T1 - MW Clec Test"){
   URL="https://onelasrgui-t1.web.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_T1";
		window.open(URL, '_blank');	
   }else if(myCurrHost=="onelasrgui-clec.web.att.com" && regionSelected=="P1 - W Clec Test"){
   URL="https://onelasrgui-p1.web.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_P1";
		window.open(URL, '_blank');	
   }else if(myCurrHost=="onelasrgui-d9.web.az.3pc.att.com" && regionSelected=="D9 - SE CAVE/CLEC"){
		document.getElementById('submit').style.display = 'inline';
   }else if(myCurrHost=="onelasrgui-a2.web.az.3pc.att.com" && regionSelected=="A2 - SW Clec Test"){
		document.getElementById('submit').style.display = 'inline';
   }else if(myCurrHost=="onelasrgui-t1.web.az.3pc.att.com" && regionSelected=="T1 - MW Clec Test"){
		document.getElementById('submit').style.display = 'inline';
   }else if(myCurrHost=="onelasrgui-p1.web.az.3pc.att.com" && regionSelected=="P1 - W Clec Test"){
		document.getElementById('submit').style.display = 'inline';
   }else{
   			document.getElementById('submit').style.display = 'none';
   }
   
   
	if(myCurrHost=="localhost" || myCurrHost=="127.0.0.1"){
   document.getElementById('submit').style.display = 'inline';
   
	
   
   
	}
   
   
	}
   
   
    
   
    
   //::::  print functionality code by satya start  :::://
function createAlerts(theCheckbox) {

    if (theCheckbox.checked) {
    	if(theCheckbox.id === 'selectAll'){
    		$('#treeViewList').find(':checkbox').each(function(){
				$("#"+this.id).prop("checked", true);
        		
        	});
        }
    }
    
    if (!theCheckbox.checked) {
    	if(theCheckbox.id === 'selectAll'){
    		$('#treeViewList').find(':checkbox').each(function(){
				$("#"+this.id).prop("checked", false);
        		
        	});
        }else {
        		$('#selectAll').prop("checked", false);
        
        }
 	}   
}



function getPrintSelection(){
	var listItemsLength = 0;
	//alert('in getprintselection');
	if(document.getElementById("ul1") != null && typeof document.getElementById("ul1") !== "undefined" ){
		const ul = document.getElementById('ul1');
		const listItems = ul.getElementsByTagName('li');
		listItemsLength = listItems.length;
	}
	listItemsLength =0;
	if(listItemsLength === 0){
		$('#printfunction').hide();
		PrintTable();
	}
	else{
		$('#treeViewList').empty();
		var label="";
		var idList =[];
		$('#treeViewList')	
		.append('<li style="list-style: none; margin: 0;"><input id="selectAll" type="checkbox" onclick="createAlerts(this)"><label for="selectAll">Select All</label></li>');
		$('ul span[id]' ).each( 
			function(){
			label=	$('#'+this.id).text();
			
				console.log(this.id   +'   '+$('#'+this.id).text());
				$('#treeViewList')
					.append('<li style="list-style: none; margin: 0;">')	
					.append('<input onclick="createAlerts(this)" type="checkbox" id="'+this.id+ '" name="'+this.id+ '" value="'+$("#"+this.id).text().trim()+'">')
			        .append('<label for='+this.id+'>')
			        .append(label)
			        .append('</label>')
			        .append('</li>')
			        .append(`<br>`);
				}
			);
			
	}			
	
}


  function PrintTable()
{
	//alert('in print table');
	var selected = [];
	$('#treeViewList input:checked').each(function() {
		if($(this).attr('id') != 'selectAll'){
			selected.push($(this).attr('id'));
		}
	    
	});
	
	newWin = window.open('', '', 'height=1000,width=1000');
   	newWin.document.write('<html><head><title>OneLASRGUI</title></head>');
    newWin.document.write('<body>');
	if(document.getElementById("selectReqStatusDiv") != null && typeof document.getElementById("selectReqStatusDiv") !== "undefined" ){
		newWin.document.write(document.getElementById("selectReqStatusDiv").innerHTML);
	}
	var pageId ='';
	for (var i = 0; i < selected.length; i++) {
		
		pageId=selected[i];
    	 targetPage(pageId);
	    if(document.getElementById("secondScreen") != null && typeof document.getElementById("secondScreen") !== "undefined" ){
	    	newWin.document.write(document.getElementById("secondScreen").innerHTML);
	    	//alert(document.getElementById("secondScreen").innerHTML);
	   	}else{
	   		alert('no content')

	   	}
	   	
	   
	}
	
	if(document.getElementById("div1") != null && typeof document.getElementById("div1") !== "undefined"){
	    newWin.document.write(document.getElementById("div1").innerHTML);
	   }
	 	if(document.getElementById("printform") != null && typeof document.getElementById("printform") !== "undefined"){
	    newWin.document.write(document.getElementById("printform").innerHTML);
	   }
		if(document.getElementById("secondScreen") != null && typeof document.getElementById("secondScreen") !== "undefined" ){
	    	//newWin.document.write(document.getElementById("secondScreen").innerHTML);
			//$(newWin.document.body).html($("#div1").html()+''+$("#secondScreen").html());
			var content =	$("#div1").html()+'<br/>'+$("#secondScreen").html();
			content = content.replace(/overflow/g,"");
			//console.log(content);
			
		
			//$(newWin.document.body).html($("#div1").html()+'<br/>'+$("#secondScreen").html());
			$(newWin.document.body).html(content);
	    	
	   	}
	  
	   if(document.getElementById("workloadtable12") != null && typeof document.getElementById("workloadtable12") !== "undefined"){
	    newWin.document.write(document.getElementById("workloadtable12").innerHTML);
	   }
	   if(document.getElementById("enhancedseltDiv") != null && typeof document.getElementById("enhancedseltDiv") !== "undefined"){
	    newWin.document.write(document.getElementById("enhancedseltDiv").innerHTML);
	   }
	   if(document.getElementById("restrictedFetchedData") != null && typeof document.getElementById("restrictedFetchedData") !== "undefined"){
	    newWin.document.write(document.getElementById("restrictedFetchedData").innerHTML);
	   }
	   if(document.getElementById("fupSelect") != null && typeof document.getElementById("fupSelect") !== "undefined"){
	    newWin.document.write(document.getElementById("fupSelect").innerHTML);
	   }
	   if(document.getElementById("confirmedSelect") != null && typeof document.getElementById("confirmedSelect") !== "undefined"){
	    newWin.document.write(document.getElementById("confirmedSelect").innerHTML);
	   }
	   if(document.getElementById("unrestrictedDiv") != null && typeof document.getElementById("unrestrictedDiv") !== "undefined"){
	    newWin.document.write(document.getElementById("unrestrictedDiv").innerHTML);
	   }
	   if(document.getElementById("issueProvdDiv") != null && typeof document.getElementById("issueProvdDiv") !== "undefined"){
	    newWin.document.write(document.getElementById("issueProvdDiv").innerHTML);
	   }
	   if(document.getElementById("selectProvdDiv") != null && typeof document.getElementById("selectProvdDiv") !== "undefined"){
	    newWin.document.write(document.getElementById("selectProvdDiv").innerHTML);
	   }
	   if(document.getElementById("userIdDiv") != null && typeof document.getElementById("userprofile1") !== "undefined"){
	    newWin.document.write(document.getElementById("userprofile1").innerHTML);
	   }
	   if(document.getElementById("selectRequest12States1") != null && typeof document.getElementById("selectRequest12States1") !== "undefined"){
	    newWin.document.write(document.getElementById("selectRequest12States1").innerHTML);
	   }
	   
	   if(document.getElementById("enhancedFetchedData") != null && typeof document.getElementById("enhancedFetchedData") !== "undefined"){
	    newWin.document.write(document.getElementById("enhancedFetchedData").innerHTML);
	   }

 	   /*
 	  if(document.getElementById("designHistoryTable") != null && typeof document.getElementById("designHistoryTable") !== "undefined"){
	    newWin.document.write(document.getElementById("designHistoryTable").innerHTML);
	   }*/
 	

	
		
	   
	  



	   
	  
	   
	   
	newWin.document.write('</body>');
   	newWin.document.write('</html>');
   
   	newWin.print();
   	newWin.close();
   	
   	
   
   
}

//::::  print functionality code by satya end  :::://
// declared to get selected request id
var selectedReqId = "";

function getAllFormData(dom_query) {
	var out = {};
	var s_data = $(dom_query).serializeArray();
	//transform into simple data/value object
	for (var i = 0; i < s_data.length; i++) {
		var record = s_data[i];
		out[record.name] = record.value;
	}
	return out;
}


function clearLocalStorage(){
localStorage.clear(); 
}
function clearLocalStorage1(){
localStorage.clear(); 
var myHost= document.location.hostname;
localStorage.setItem("myHost",myHost);
}
	
	function callListen(){
console.log("in callListen of toolbar.js");

callListen1();




}	
		
	


	
var modelOpen=false;	
	function isManRejModelOpened(){
	modelOpen=true;
	
	}
	function closedModel(){ 
	document.getElementById('contextMenuManualReject').style.display = 'none';
	modelOpen=false;
	}
	function MinimiseModel(){
	modelOpen=true;
	}


function destroyModal(){
if(confirm("Changes have not been saved. Are you sure you want to close?")){
modelOpen=false;
	document.getElementById('contextMenuManualReject').style.display = 'none';
document.getElementById("RejModSelData").innerHTML = "";
$("#minimizeBtn").click();
modelOpen=false;
}else{
modelOpen=true;
}
}

	
	 var otherFieldName=[];
	
function rightClickForManualReject(fieldName, listManualRejectLoginData){
	if(!modelOpen){
	//alert("Can not right click. Please Open Manual Reject Model First");	
	
	
}else{
	

var allTableData=[];
allTableData=fieldName.split("_");
var onlyFieldName=allTableData[0]; 
  otherFieldName=[]; 
otherFieldName=allTableData[1];
var sessiondata=localStorage.getItem("manualRejLoginData");

if(sessiondata== null || sessiondata==undefined){
localStorage.setItem("manualRejLoginData",listManualRejectLoginData);
}
listManualRejectLoginData=listManualRejectLoginData.replace("[", "");
listManualRejectLoginData=listManualRejectLoginData.replace("]", "");
listManualRejectLoginData=listManualRejectLoginData.replaceAll("-", onlyFieldName);
 
var rows=[];
rows= listManualRejectLoginData.split("$,");




//var html="<div  style='overflow-y: auto; height: 150px;'>";
 var html = "<div  style='overflow-y: auto; height: 150px;'> <table > ";
for (var i = 0; i < rows.length; i++) {
	
data="";
data=rows[i]; 
data= data.split(",");
 var dataOf2="";
 dataOf2=data[2];

if(dataOf2.includes("$")){
	dataOf2=dataOf2.replace("$", '');
}
//html+="<tr></tr>";	
//html+="<td onclick='manRejSelect(this)'>"+data[0]+" "+data[2]+"</td>";  
html+="<td  onclick='manRejSelect(this)'>"+data[0]+" "+dataOf2+"<span hidden='true'>"+data[0]+" "+data[1]+" "+dataOf2+"</span"+"</td>";

 

  
html+="</tr>";
 }
html+="</div></table> ";
document.getElementById("copyId").innerHTML = html;

var e = window.event;
 e.preventDefault();
menu = document.getElementById("contextMenuManualReject");
		menu.style.display = 'block';
		menu.style.left = e.pageX + "px";
		menu.style.top = e.pageY + "px";


	}
}

var totalSelectedData=[];
function manRejSelect(val) {
	console.log("after select manRejSelect", val);
	if (val == 'Reset') {
		totalSelectedData = [];
		modelOpen = false;
	document.getElementById('contextMenuManualReject').style.display = 'none';
	} else {
		var data = val.innerHTML;

		data = data.slice(
			data.indexOf('>') + 1,
			data.lastIndexOf('<')
		);
		console.log(data);
		data = data.trim();
		data = data + "_" + otherFieldName;
		totalSelectedData.push(data);

		console.log("totalSelectedData", totalSelectedData);
		var myComment = "";
	}
	var html = "";

	for (var i = (totalSelectedData.length - 1); i < totalSelectedData.length; i++) {
		var rows = [];
		var loppedData = [];
		loppedData = totalSelectedData[i].split("_");

		rows = loppedData[0];
		rows = rows.split(" ");

		var fieldName = [];
		var itemNum = "";
		var numName = "";
		var numNbr = "";
		var legItemNum = "";
		var legNum = "";
		if (loppedData[1] != null || loppedData[1] != undefined) {
			fieldName = loppedData[1].split("-");
			console.log("exceptFieldName", fieldName);
			itemNum = fieldName[0];
			numName = fieldName[1];
			numNbr = fieldName[2];
			legItemNum = fieldName[3];
			legNum = fieldName[4];
		}

		var comment = "";
		for (var y = 2; y < rows.length; y++) {
			comment = comment + " " + rows[y];
		}
		html += "<tr class='manualRejRow"+i+"' onClick='selectRejectedRow("+i+")'>";

		html += "<td colspan='1' class='lab1 tborder' scope='row' style='width: 95px;'>" + rows[0].trim() + "</td>";
		html += "<td colspan='1' class='lab1 tborder' scope='row' style='width: 70px;'>" + rows[1].trim() + "</td>";
		html += "<td colspan='1' class='lab1 tborder' scope='row' style='width: 60px;'>" + itemNum + "</td>";
		html += "<td colspan='1' class='lab1 tborder' scope='row' style='width: 66px;'>" + numName + "</td>";
		html += "<td colspan='1' class='lab1 tborder' scope='row' style='width: 60px;'>" + numNbr + "</td>";
		html += "<td colspan='1' class='lab1 tborder' scope='row' style='width: 80px;'>" + legItemNum + "</td>";
		html += "<td colspan='1' class='lab1 tborder' scope='row' style='width: 60px;'>" + legNum + "</td>";
		html += "</tr>";

		if (comment.trim() == 'Other') {
			html += "<tr  class='manualRejRow"+i+"'>";
			html += "<td colspan='7' headers='rejectmessage' class='lab1 tborder' scope='row' style='width: 60px;'>" + "<input type='text1' id='myJsInput" + rows[1].trim() + "' class='myJsInput" + rows[1].trim() + "' style='width: 408px;' maxlength='218'></input>" + "</td></tr>";
		} else {
			html += "<tr  class='manualRejRow"+i+"' onClick='selectRejectedRow("+i+")'>";
			html += "<td colspan='7' headers='rejectmessage' class='lab1 tborder' scope='row' style='width: 60px;'>" +rows[0].trim()+" "+ comment.trim() + "</td></tr>";
		}
	}
	$("#RejModSelData").append(html);

	document.getElementById('contextMenuManualReject').style.display = 'none';
}	


	
function manRejReset(val){
var html="<tr></tr>";
if(val =='Reset'){
document.getElementById('ManRejNotes').value='';
modelOpen=true;
emptyManRejModel(totalSelectedData);


}else if(val =='Cancel'){
document.getElementById('contextMenuManualReject').style.display = 'none';
document.getElementById('ManRejNotes').value='';
modelOpen=false;
emptyManRejModel(totalSelectedData);
}
}
	
function emptyManRejModel(totalSelectedData){
for (i = 0; i < totalSelectedData.length; i++) {
totalSelectedData.splice(i, 1);
$(".manualRejRow" + totalSelectedData[i]).remove();
}
document.getElementById("RejModSelData").innerHTML = "";
document.getElementById('contextMenuManualReject').style.display = 'none';


}
	
	function getWhichState(state){
//	console.log("loggedin satte is"+state);
	localStorage.setItem("state",state);
	
	}
var selectedRowsforDelete = [];
function selectRejectedRow(id) {
	var color = "white";
	if (selectedRowsforDelete.indexOf(id) == -1) {
		selectedRowsforDelete.push(id);
		color = "blue";
	} else {
		selectedRowsforDelete.splice(selectedRowsforDelete.indexOf(id), 1);
		color = "white";
	}

	var rows = document.getElementsByClassName("manualRejRow" + id);
	console.log("length", rows.length);
	for (i = 0; i < rows.length; i++) {
		rows[i].style.backgroundColor = color;
	}
}

function deleteSelectedRow() {
	for (i = 0; i < selectedRowsforDelete.length; i++) {
		totalSelectedData.splice(i, 1);
		$(".manualRejRow" + selectedRowsforDelete[i]).remove();
	}
}
//	function loaderOpen(){
//	var loaderHtml="<div id='manRejLoader' class='manRejLoader'></div>";	
//	$("#manRejUpper").append(loaderHtml);
//	document.getElementById('manualModel').style.display = 'inline';
//	}
	
function manRejIssueFun() {
	var loaderHtml="<div id='manRejLoader' class='manRejLoader'></div>";	
//	$("#manRejUpper").append(loaderHtml);
//	document.getElementById('manualModel').style.display = 'inline';
	
		var specialCharChk="";	
	
	var emptyRemarkIds = [];
	emptyRemarkIds.splice(0, emptyRemarkIds.length);
	var loggedInState = "";
	var state = localStorage.getItem("state");
	if (state == "12 States") {
		loggedInState = "treeViewDisplay";
	} else {
		loggedInState = "treeview9states";
	}

		var rejCodeAvailble ="";
//		var specialCharChk="";	
	//console.log("totalSelectedData:::issue", totalSelectedData);
	//console.log("totalSelectedData:::length", totalSelectedData.length);
	for (var i = 0; i < totalSelectedData.length; i++) {
		var rows = [];
		//CVER MR0172 Not Working/Not Found_----
		var loppedData = [];
		loppedData = totalSelectedData[i].split("_");

		rows = loppedData[0];
		rows = rows.split(" ");


		var fieldName = [];
		var itemNum = "";
		var numName = "";
		var numNbr = "";
		var legItemNum = "";
		var legNum = "";
		if (loppedData[1] != null || loppedData[1] != undefined) {
			fieldName = loppedData[1].split("-");
			console.log("exceptFieldName", fieldName);
			itemNum = fieldName[0];
			numName = fieldName[1];
			numNbr = fieldName[2];
			legItemNum = fieldName[3];
			legNum = fieldName[4];
		}

		var comment = "";
		for (var y = 2; y < rows.length; y++) {
			comment = comment + " " + rows[y];
		}

		
		
		if (comment.trim() == 'Other' || comment.includes("Other")) {
			var myTable = document.getElementById("RejModSelData");
			console.log("myTable.rows.length::" + myTable.rows.length);
			var myComment = "";
			var comen=""; // $&-_^+,#
			for (k = (i * 2); k < ((i * 2) + 2); k++) {
				var objCells = myTable.rows.item(k).cells;
				if (objCells.length == 1) {
					comen = objCells.item(0).getElementsByTagName("input")[0].value;
			if(comen.includes("$") ||comen.includes("&") || comen.includes("-") || comen.includes("_") || comen.includes("^") ||comen.includes("+") ||comen.includes(",") ||comen.includes("#") ){	
				specialCharChk="present";	
			}else{
				specialCharChk="notPresent";
			}
		
		
					myComment="Other "+comen;
					if(myComment.trim()=="Other"){
						emptyRemarkIds.push(objCells.item(0).getElementsByTagName("input")[0].id);
					} else {
						var newRow = rows[0].trim() + " " + rows[1].trim() + " " + myComment + "_" + itemNum + "-" + numName + "-" + numNbr + "-" + legItemNum + "-" + legNum;
						console.log("newRow", newRow);
						totalSelectedData.splice(i, 1, newRow);
						console.log("new", totalSelectedData);
						myComment = "";
					}
				}

			}

		}
	}
		
	if( totalSelectedData.length > 0){
		
			rejCodeAvailble="present";
	}else{
			rejCodeAvailble="notPresent";
	}
	
	console.log("totalSelectedData:::afetr issu", totalSelectedData);
	var lscNote = document.getElementById('ManRejNotes').value;
	
	var issueData = totalSelectedData;
	
	if(rejCodeAvailble =="notPresent"){
	document.getElementById('manualModel').style.display = 'none';
	
	alert("Reject code required");
	}else if (specialCharChk =="present"){
		alert("CLEC Notes can not contain these special Character. $ , & - _ ^ + # ");
	}else if (emptyRemarkIds.length > 0) {
		document.getElementById('manualModel').style.display = 'none';
	
		alert("LG0402: CLEC NOTES is required");

		var myTableValidation = document.getElementById("RejModSelData");
		var myCommentValidation = "";
		for (k = 0; k < myTableValidation.rows.length; k++) {
			var objCellsValidation = myTableValidation.rows.item(k).cells;
			if (objCellsValidation.length >= 1) {
				if (objCellsValidation.item(0).getElementsByTagName("input").length > 0) {
					myCommentValidation = objCellsValidation.item(0).getElementsByTagName("input")[0].value;
					if (myCommentValidation.trim() == "") {
						objCellsValidation.item(0).getElementsByTagName("input")[0].focus();
						break;
					} else {
						myCommentValidation = "";
					}
				}
			}
		}
	
	
	
	} else if (lscNote == null || lscNote.trim() == '') {
		document.getElementById('manualModel').style.display = 'none';
	
		alert("LG0035: Lsc Note is required");
	}
	else {
		document.getElementById('ManRejNotes').value = '';

		//manRejSelect('Reset');
		document.getElementById('myReject').style.display = 'none';
		var xhttp = new XMLHttpRequest();


		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
			document.getElementById('manualModel').style.display = 'none';
			document.getElementById('manualModel').style.display = 'none';
				alert("Transaction Successful");
				window.location.href = loggedInState;
			}



		};

		$("#manRejUpper").append(loaderHtml);
		document.getElementById('manualModel').style.display = 'inline';
	

		console.log("issueData",issueData);
		xhttp.open("POST", "manRejIssueFun", true);
		getTokenForHttps(xhttp);
		xhttp.send(issueData + "$" + lscNote);
		modelOpen = false;
		document.getElementById('contextMenuManualReject').style.display = 'none';
//	document.getElementById('manualModel').style.display = 'none';
	
	}
}




function issueFunction() {
	
	
	
	if (localStorage.getItem("name") == "CompletionProviderGenralTask") {
		var isValidData= true;
		
		var cord = document.getElementById("ord").value;
		
		if (cord == "") {
			document.getElementById("cdError").innerHTML = getErrorMsg(jsonData.LG0006, "ORD");
			isValidData = false;
		}
		
		var comp_dtTask= document.getElementById("comp_dtdata").value;
		
		if(comp_dtTask == "")
		{
			document.getElementById("cdError").innerHTML= getErrorMsg(jsonData.LG0006,"CD");
			isValidData=false;
		
		
		}
		if(isValidData== true){
			$("form[name='completaionG']").submit();
		}
	}
	
	if($("#PostToBillTask_9").val() == 'PostToBillTask9'){
		var isValidData= true;
		var comp_dt= document.getElementById("pd").value;
		if(comp_dt == "")
		{
	 	document.getElementById("pdError").innerHTML= getErrorMsg(jsonData.LG0006,"PD");
		isValidData=false;
		
		}
		if(isValidData== true)
		{
		//alert("post task issue");
	$("form[name='PostToBillTask9']").submit();
	}	
	}
	if($("#PostToBill_12Task").val() == 'PostToBillTask12_Post'){
		//alert("post task issue");
		var isValidData= true;
		var comp_dt= document.getElementById("pd").value;
		if(comp_dt == "")
		{
	 	document.getElementById("PdError").innerHTML= getErrorMsg(jsonData.LG0006,"PD");
		isValidData=false;
		
		}
		if(isValidData== true)
		{
		
	$("form[name='PostToBillTask12_Post']").submit();
	}
	}
	
	if($("#confTaskInput").val() == 'confTask'){
		document.getElementById("ordTable").innerHTML= "";
		document.getElementById("ordTableDiv").innerHTML= "";
var isValidData= true;
var ord= document.getElementsByClassName("ord");
var dd= document.getElementsByClassName("dd");
var ord3= document.getElementsByClassName("ord3");
var dd3= document.getElementsByClassName("dd3");
var ordl= document.getElementsByClassName("ordl1");
var nprod= document.getElementsByClassName("nprod1");

//added by Hrushi- Ecckt Validation: req type A & B
		var reqType = document.getElementById("confReqType").value;
		if (reqType == "A" || reqType == "B") {
			var ecckt = document.getElementsByClassName("ecckt1");

			for (var i = 0; i < ecckt.length; i++) {
				var ecckt1 = ecckt[i].value + "";

				if (ecckt1.trim() == "") {

					document.getElementById("ordTable").innerHTML = getErrorMsg(jsonData.LG0006, "ECCKT");
					isValidData = false;
					break;
				}
			}
		}

for(var i=0; i<ordl.length;i++)
{
var ordl1= ordl[i].value+"";

if(ordl1.trim() == "")
{

document.getElementById("ordTable").innerHTML = getErrorMsg(jsonData.LG0006, "ORDL");
isValidData=false;
break;
}
}

for(var i=0; i<nprod.length;i++)
{
var nprod1= nprod[i].value+"";

if(nprod1.trim() == "")
{

document.getElementById("ordTable").innerHTML = getErrorMsg(jsonData.LG0006, "NPORD");
isValidData=false;
break;
}
}

//added by Hrushi - DD/ORD fix
for (var i = 0; i < ord.length; i++) {
			var ord1 = ord[i].value + "";
			var dd1 = dd[i].value + "";
			if (ord1.trim() == "" && dd1.trim() != "") {
				document.getElementById("ordTableDiv").innerHTML = getErrorMsg(jsonData.LG0194, "ORD");
				isValidData = false;
				break;
			}

			if (ord1.trim() != "" && dd1.trim() == "") {
				document.getElementById("ordTableDiv").innerHTML = getErrorMsg(jsonData.LG0195, "DD");
				isValidData = false;
				break;
			}


		}

for(var i=0; i<ord3.length;i++)
{
var ord5= ord3[i].value+"";

if(ord5.trim() == "")
{

document.getElementById("ordTable").innerHTML = getErrorMsg(jsonData.LG0006, "ORD");
isValidData=false;
break;
} }
for(var i=0; i<dd3.length;i++)
{
var dd5= dd3[i].value+"";

if(dd5.trim() == "")
{

document.getElementById("ordTable").innerHTML = getErrorMsg(jsonData.LG0006, "DD");
isValidData=false;
break;
}


}

if(isValidData == true)
{


$("form[name='conftask']").submit();

}
	}
	
	if(localStorage.getItem("name") == "foc")
		{
			$("form[name='focTesttask']").submit();	
			
		}
	if($("#confTaskInput").val() == 'focTesttask'){
		$("form[name='focTesttask']").submit();
	}
	
	if($("#confTaskInput1").val() == 'confTask1'){
		$("form[name='conftask1']").submit();
	}
	
		if($("#corrconfTaskInput").val() == 'corrconfTask'){
		$("form[name='corrconftask']").submit();
	}
	
		
		if (localStorage.getItem("name") == "conftask2") {
			$("form[name='correctconftask9']").submit();
	
		}
		if(localStorage.getItem("name") == "correctconf")
		{
			$("form[name='correctconftask']").submit();	
			
		}
		if(localStorage.getItem("name") == "conftasknoprod")
		{
			$("form[name='conftasknoprod9']").submit();	
			
		}
	
	
	if(localStorage.getItem("name") == "correctconf12")
		{
			$("form[name='correctconftask12']").submit();	
			
		}
		if(localStorage.getItem("name") == "confnoprod12")
		{
			$("form[name='conftasknoprod12']").submit();	
			
		}
	if (localStorage.getItem("name") == "CompletionProviderGenralTask9") {
		$("form[name='completaionG9']").submit();
	}
	 if(localStorage.getItem("name") == "att")
		{
			//$("form[name='conftasknoprod12']").submit();
			if ($("#state").val() == '9 States') {
		
		         var sendingReq = "yes";
		         var xhttp = new XMLHttpRequest();
		         xhttp.open("POST", "attcanceltask9", true);
		
           		getTokenForHttps(xhttp);
		        xhttp.send(sendingReq);
                   setTimeout(function() {
                    window.location.href = "treeview9states";
                    }, 6000);

	           }	
			
		}
		
		
		if(localStorage.getItem("name") == "att12")
		{
			//$("form[name='conftasknoprod12']").submit();
			if ($("#state").val() == '12 States') {
		
		         var sendingReq = "yes";
		         var xhttp = new XMLHttpRequest();
		         xhttp.open("POST", "attcanceltask12", true);
		
          		getTokenForHttps(xhttp);
		        xhttp.send(sendingReq);
                   setTimeout(function() {
                    window.location.href = "treeViewDisplay";
                    }, 6000);

	           }
		
        }

	if (localStorage.getItem("name") == "jeopardyTask12") {
var isValidData= validateRowData();

if(isValidData == true){
$("form[name='jeopardyTask']").submit();
//document.forms["jeopardyTask"].submit();
}
}

if (localStorage.getItem("name") == "jeopardyTask9") {
var isValidData= validateRowData();

if(isValidData == true){
$("form[name='jeopardyTask']").submit();
}
}

	//Issue- Completion Provider task with loss
	if (localStorage.getItem("name") == "completionProviderWithLoss") {
		
		var isValidData = true;
		var lc = document.getElementById('company_code').value;
		isValidData = validateCompletionLossForm(isValidData);

		if (isValidData == true) {
			var request = getLossInfoData();

			if (lc != "" && request != "") {
				var xhttp = new XMLHttpRequest();
				xhttp.open("POST", "setLossInfoTableData", true);
				getTokenForHttps(xhttp);
				xhttp.onreadystatechange = function() {
					if (this.readyState == 4 && this.status == 200) {
						console.log("success");
					}
				};
				xhttp.send(request);

			}
			if ((lc != "" && request != "") || (lc == "" && request == "")) {
				setTimeout(function() {
					var form = document.getElementById("complWithLossMain")
					form.action = "issueForComplWithLoss";
					form.submit();
				}, 2000);

			}
			else {
				document.getElementById("disp_err").innerHTML = getErrorMsg(jsonData.LG0222);
			}
		}
	}
	
	//preIssueDisable();
	
}

//Start - completion provider task with loss
function doesArrayHaveDuplicates(dupArray) {
	var arr= [];
	for(var i=0;i<dupArray.length;i++)
	{
		arr.push(dupArray[i].value);
	}
  return arr.length !== new Set(arr).size;
}

function validateCompletionLossForm(isValidData)
{
	var comp_dtList= document.getElementsByClassName("cd_class");
	var wtnList = document.getElementsByName("wtnName");
	var cvdList= document.getElementsByName("cvdName");
	var eccktList= document.getElementsByName("eccktName");
	var ordList = document.getElementsByClassName("ord");
	
	if(isValidData == true)
	{
		if(doesArrayHaveDuplicates(ordList) == true)
		{
			document.getElementById("disp_ordCd_err").innerHTML= getErrorMsg(jsonData.LG0179);
			isValidData= false;
		}
		else
		{
			document.getElementById("disp_ordCd_err").innerHTML= "";
		}
	}
	
	if(isValidData == true)
	{
		for(var i=0; i<comp_dtList.length;i++)
		{
			var comp_dt= comp_dtList[i].value+"";
			if(comp_dt == "")
			{
				document.getElementById("disp_ordCd_err").innerHTML= getErrorMsg(jsonData.LG0006,"CD");
				isValidData=false;
				break;
			}
		}
	}
	
	if(isValidData == true)
	{
		for(var i=0; i<cvdList.length;i++)
		{
			var cvd= cvdList[i].value+"";
			if(cvd == "")
			{
				document.getElementById("disp_err").innerHTML= getErrorMsg(jsonData.LG0006,"CVD");
				isValidData=false;
				break;
			}
		}
	}
	
	if(isValidData == true)
	{
		for(var i=0; i<wtnList.length;i++)
		{
			var wtn= wtnList[i].value+"";
			var ecckt= eccktList[i].value+"";
			if(wtn.trim() == "" && ecckt.trim() == "")
			{
				document.getElementById("disp_err").innerHTML= getErrorMsg(jsonData.LG0208);
				isValidData=false;
				break;
			}
		}
	}
	
	if(isValidData == true){
	for(var i=0; i<wtnList.length;i++)
	{
		var value= (wtnList[i].value+"").length;
		if( value>0 && (value< 12 || (value>12 && value<17)) )
		{
			document.getElementById("disp_err").innerHTML= getErrorMsg(jsonData.LG0174);
			isValidData=false;
			break;
		}
	}
	}
	
	if(isValidData == true){
	for(var i=0; i<eccktList.length;i++)
	{
		var eccktLen= (eccktList[i].value+"").length;
		var ecckt= eccktList[i].value;
		if( ecckt!="" && eccktLen<15)
		{
			document.getElementById("disp_err").innerHTML= getErrorMsg(jsonData.LG0238);
			isValidData=false;
			break;
		}
		else if(eccktLen >= 15)
		{
			if(!ecckt.match(/^[0-9A-Za-z.]+$/))
			{
				document.getElementById("disp_err").innerHTML= getErrorMsg(jsonData.LG0238);
				isValidData=false;
				break;
			}
		}
	}
	}
	
	if(isValidData == true)
	{
		document.getElementById("disp_err").innerHTML = "";
		document.getElementById("disp_ordCd_err").innerHTML = "";
	}
	
	return isValidData;
	
}

function getLossInfoData()
{
	var input="";
			var n=1;
			var cells = document.querySelectorAll('.lossInfo');
			cells.forEach(function(cell) {
				
				if(cell.value.trim() != "")
				{
					var fieldValue= "";
					fieldValue= cell.value;
					input=input+ " "+fieldValue.trim();
				}
				else
				{
					input=input+ " #";
					
				}
				if(n%5 == 0)
				{
					input= input+ "$";
				}
				n=n+1;
				
				console.log(cell.value+ "*");
				
			});
	return input;
}
//End- Completion provider task with Loss

function yesFun() {

	if ($("#state").val() == '12 States') {
		var sendingReq = "no";
		var xhttp = new XMLHttpRequest();
		xhttp.open("POST", "attcanceltask12", true);
        getTokenForHttps(xhttp);
		        
		xhttp.send(sendingReq);
		setTimeout(function() {
                    window.location.href = "treeViewDisplay";
                    }, 6000);

	}
	if ($("#state").val() == '9 States') {
		//alert("9 state");
		var sendingReq = "no";
		var xhttp = new XMLHttpRequest();
		xhttp.open("POST", "attcanceltask9", true);
         getTokenForHttps(xhttp);
		        
		xhttp.send(sendingReq);
		setTimeout(function() {
                    window.location.href = "treeview9states";
                    }, 6000);

	}

}

function noFunc(){
	
//	alert("calling no fun")
	document.getElementById('buttonyesno').style.display = "none";
}
			
		




function notesSave() {
	
	let x = document.forms["confnotes"]["notes"].value;
	var error = document.getElementById("error")
  if (x == "") {
   error.textContent="Text Required "
   error.style.color = "red"
   error.style = padding.center;
    return false;
  }
else{
$("form[name='confnotes']").submit();	
setTimeout(function() {  }, 6000);
}
//	alert("savesseeee");
		var sendingReq = "";
		var inputFormData = {};
		var intialVal= "";
	/*if(document.getElementById("confnotes").value==''){
	alert("Enter Something");
	}
	else
	$("form[name='confnotes']").submit();
	
	*/
}

function closeShowFunction(){
	document.getElementById("form1").reset();
    location.reload();
}


function routeToRespectiveTab(myUrl) {
	console.log("qqq", myUrl);
	var arr = myUrl.split("-");
	console.log("arr to route", arr);
	var url = arr[0];
	var index = parseInt(arr[1]);
	var inputFormData = {};
	var fetchedFormData = {};
	if (localStorage.getItem("maxPageIndex") == "0") {
		localStorage.setItem("previousPageIndex", "-1");
		localStorage.setItem("currentPageIndex", index);
	} else {
		localStorage.setItem("previousPageIndex", localStorage.getItem("currentPageIndex"));
		localStorage.setItem("currentPageIndex", index);
	}

	localStorage.setItem("previousPageSwitch", localStorage.getItem("currentPage"));
	localStorage.setItem("currentPageSwitch", url);
	localStorage.setItem("currentPage", url);

	if (url == "treeViewDisplay" || url == "treeview9states") {
		//Hrushi - Commented for multiple treeview, added new logic
		/*var selctedRowIndexKey = "";
		selctedRowIndexKey = localStorage.getItem("currentPage") + "-" + parseInt(localStorage.getItem("currentPageIndex"));
		var selctedRowIndexValue = "";
		var finalSelectedIndex = "";
		finalSelectedIndex = url + "-" + index;
		var fetchDataForKey = localStorage.getItem(finalSelectedIndex);
		var sendingReq = "";
		sendingReq = url + "$F$" + index + "$" + localStorage.getItem("previousPageSwitch") + "$" + JSON.stringify(inputFormData) + "$" + JSON.stringify(fetchedFormData);
		//sendingReq = url + "$N$" + fetchDataForKey;
		console.log("sendingReq is -->", sendingReq);
		var xhttp = new XMLHttpRequest();
		xhttp.open("POST", url, true);
//		getTokenForHttps(xhttp);
		xhttp.send(sendingReq);
		setTimeout(function() {
			window.location.href = url;
		}, 3000);*/ 
		
		var sendingReq = "";
		sendingReq= arr[2]+"-"+arr[3] + "$"+ "R"; 
		var xhttp= new XMLHttpRequest();
		
		xhttp.onreadystatechange = function() {
		    	if (this.readyState == 4 && this.status == 200) {
					window.location.href = url;
		   		 }
		};
		xhttp.open("POST", url, true);
		getTokenForHttps(xhttp);
		xhttp.send(sendingReq);
		
	}
	else {

		var inputFormData = {};
		var fetchedFormData = {};

		console.log("FFD", inputFormData);
		console.log("SFD", fetchedFormData);

		var sendingReq = "";
		//		sendingReq=url+"$F$"+index+"$"+localStorage.getItem("previousPageSwitch")+"$"+JSON.stringify(inputFormData)+"$"+JSON.stringify(fetchedFormData);
		sendingReq = url + "$N$" + localStorage.getItem("previousPageSwitch") + "$" + JSON.stringify(inputFormData) + "$" + JSON.stringify(fetchedFormData) + "$" + localStorage.getItem("previousPageIndex") + "$" + localStorage.getItem("currentPageSwitch") + "$" + localStorage.getItem("currentPageIndex") + "$" + localStorage.getItem("maxPageIndex");
		console.log("sendingReq is -->", sendingReq);
		var xhttp = new XMLHttpRequest();

		//		 xhttp.onreadystatechange = function() {
		//    		if (this.readyState == 4 && this.status == 200) {
		//			window.location.href = url;
		//   		 	}
		// 		};



		xhttp.open("POST", url, true);
			getTokenForHttps(xhttp);
		xhttp.send(sendingReq);
		//alert("routing now to"+url)


		setTimeout(function() {
			window.location.href = url;
		}, 3000);


	}
}


function callJavaController(tab, flag) {
	//		console.log("abc"+document.getElementById("abc").value);
	//		localStorage.firstExecution = 0;

	var bkp="";
	var inputFormData = {};
	var fetchedFormData = {};
	var sendingReq = "";
	if (tab == "workloadFetch") {
		tab = "workload";
		inputFormData = getAllFormData("#workload");
		fetchedFormData = getAllFormData("#workloadFetchedData");
	}
	else if (tab == "requestFetch") {
		tab = "selectRequest";
		inputFormData = getAllFormData("#request");
		fetchedFormData = getAllFormData("#requestFetchedData");
	}
	else if (tab == "enhancedSelReqFetch") {
		tab = "enhancedSelReq";
		inputFormData = getAllFormData("#enhancedSelReqForm");
		fetchedFormData = getAllFormData("#enhancedFetchedData");
	}
	else if (tab == "confirmedByDDFetch") {
		tab = "confirmedByDDESDD";
		inputFormData = getAllFormData("#confirmedByDDESDD");
		fetchedFormData = getAllFormData("#confirmedFetchedData");
	}
	else if (tab == "fupRequestFetch") {
		tab = "fupRequest";
		inputFormData = getAllFormData("#fupRequest");
		fetchedFormData = getAllFormData("#fupFetchedData");
	}
	else if (tab == "restrictedMismatchFetch") {
		tab = "restrictedMismatch";
		inputFormData = getAllFormData("#restricted");
		fetchedFormData = getAllFormData("#restrictedFetchedData");
	}
	else if (tab == "unrestrictedMismatchFetch") {
		tab = "unrestrictedMismatch";
		inputFormData = getAllFormData("#unrestrictedMismatch");
		fetchedFormData = getAllFormData("#unrestrictedFetchedData");
	}
	else if (tab == "userProfileFetch") {
		tab = "userProfile";
		inputFormData = getAllFormData("#user_profile");
		fetchedFormData = getAllFormData("#userprofile1");
	}else if (tab == "userProfileSave") {
		tab = "userProfile";
		inputFormData = getAllFormData("#userprofile1");
		fetchedFormData = getAllFormData("#userprofile1");
		}
		else if (tab == "userProfileLogoff") {
		tab = "userProfile";
		inputFormData = getAllFormData("#user_profile");
		fetchedFormData = getAllFormData("#userprofile1");
		}
	else if (tab == "issueProviderFetch") {
		tab = "issueProvider";
		inputFormData = getAllFormData("#issueProviderForm");
		fetchedFormData = getAllFormData("#issueProviderFetchedData");
	}
	else if (tab == "selectProviderFetch") {
		bkp="selectProviderFetch";
		tab = "selectProvider";
		inputFormData = getAllFormData("#selectProvider");
		fetchedFormData = getAllFormData("#selectProviderFetchedData");
	}
	else if (tab == "lossFetch") {
		tab = "loss";
		inputFormData = getAllFormData("#lossForm");
		fetchedFormData = getAllFormData("#lossFetchedData");
	}
	else if(tab == "editEccktDataSave")
	{
		inputFormData = getAllFormData("#editEccktForm");
		console.log(JSON.stringify(inputFormData));
	}
	else {

		localStorage.setItem("firstExecution", "0");
		if (localStorage.getItem("secondRun") == "1") {
			localStorage.removeItem("previousPage");
			localStorage.setItem("previousPage", localStorage.getItem("currentPage"));
			localStorage.removeItem("currentPage");
			localStorage.setItem("currentPage", tab);
			localStorage.setItem("maxPageIndex", parseInt(localStorage.getItem("maxPageIndex")) + 1);
			localStorage.setItem("previousPageIndex", localStorage.getItem("currentPageIndex"));
			localStorage.setItem("currentPageIndex", localStorage.getItem("maxPageIndex"));

			console.log("previous" + localStorage.getItem("previousPage") + "current" + localStorage.getItem("currentPage") + "maxTab" + localStorage.getItem("maxPageIndex"));
		} else if (localStorage.getItem("firstExecution") == "0") {
			localStorage.setItem("secondRun", "1");
			localStorage.removeItem("firstExecution");
			localStorage.setItem("currentPage", tab);
			localStorage.setItem("currentPageIndex", 0);
			localStorage.setItem("previousPageIndex", -1);
			localStorage.setItem("maxPageIndex", 0);
			localStorage.setItem("previousPage", "");

		}

		console.log("FFD", inputFormData);
		console.log("SFD", fetchedFormData);


	}
//alert("111");
	sendingReq = tab + "$" + flag + "$" + localStorage.getItem("previousPage") + "$" + JSON.stringify(inputFormData) + "$" + JSON.stringify(fetchedFormData) + "$" + localStorage.getItem("previousPageIndex") + "$" + localStorage.getItem("currentPage") + "$" + localStorage.getItem("currentPageIndex") + "$" + localStorage.getItem("maxPageIndex");
	console.log("sendingReq is -->", sendingReq);
	var xhttp = new XMLHttpRequest();
	
	 xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
//      document.getElementById("demo").innerHTML =   this.responseText;
	window.location.href = tab;
    }
  };
	
	xhttp.open("POST", tab, true);
	getTokenForHttps(xhttp);

	xhttp.send(sendingReq);
	
//	
//	if (flag == "F" && bkp != "selectProviderFetch") {
//		setTimeout(function() {
//			window.location.href = tab;
//		}, 3000);
//
//	}
//	else if(bkp == "selectProviderFetch")
//	{
//		setTimeout(function() {
//			window.location.href = tab;
//		}, 9000);
//	}
//	else {
//			setTimeout(function() {
//			window.location.href = tab;
//		}, 5000);
//	}
}

function removeTab(id) {
	var flag=0;
	var arr = id.split("-");
	console.log("id to delete" + id);

	var url = arr[0];
	var index = arr[1];
	var navBarArr = {};
	var myUrl = "";
	var myCurrentPage = "";
	console.log("local Storage"+localStorage);
	
	//var s = arr.toString();
	//navBarArr = s.split(",");
	navBarArr = arr[2].split(',');
	navBarArr.splice(index, 1);
	
	var updatedArrayIndex = navBarArr.length - 1;
	
	localStorage.setItem("maxPageIndex", parseInt(localStorage.getItem("maxPageIndex")) - 1);
	
	
	var xhttp = new XMLHttpRequest();
	xhttp.open("POST", "removeThatTab", true);
	getTokenForHttps(xhttp);
	xhttp.send(id);
	
	
	
	var currentPageNow=localStorage.getItem("currentPage");
	currentPageNow=currentPageNow.trim();
	
	var currPageIndex=localStorage.getItem("currentPageIndex");
	currPageIndex=currPageIndex.trim();
	
	if(navBarArr.length == 0)
	{
		currPageIndex=0;
	}

	if (currentPageNow == url && currPageIndex == index) {
		
		if (updatedArrayIndex >= 0) {
			myCurrentPage = navBarArr[updatedArrayIndex];
			if (myCurrentPage.includes("[")) {
				myCurrentPage = myCurrentPage.replace("[", "");
				myCurrentPage = myCurrentPage.trim();
			}
			if (myCurrentPage.includes("]")) {
				myCurrentPage = myCurrentPage.replace("]", "");
				myCurrentPage = myCurrentPage.trim();
			}

			var prevPageIndx = parseInt(localStorage.getItem("previousPageIndex"));
			localStorage.setItem("currentPage", myCurrentPage);
			localStorage.setItem("currentPageIndex", updatedArrayIndex);

			localStorage.setItem("previousPageIndex", updatedArrayIndex - 1);
			localStorage.setItem("previousPage", navBarArr[updatedArrayIndex - 1]);
			myUrl = myCurrentPage.trim() + "-" + updatedArrayIndex + "-" + arr[3] + "-" + arr[4];

			if (myCurrentPage.trim() == "treeViewDisplay" || myCurrentPage.trim() == "treeview9states") {

				var ul = document.getElementById('myTab');
				var listItems = ul.getElementsByTagName('li');
				var prevTabContent = listItems[prevPageIndx].innerText;
				var lsrArr = prevTabContent.split(':');
				//alert("LSR: "+lsrArr[1].trim())
				if (lsrArr.length > 1) {
					routeToRespectiveTab(url + "-" + (parseInt(localStorage.getItem("currentPageIndex")) - 1) + "-" + lsrArr[1].trim());
					if (index < currPageIndex) {
						routeToRespectiveTab(url + "-" + (parseInt(localStorage.getItem("currentPageIndex")) - 1) + "-" + lsrArr[1].trim());
					}
					else {
						routeToRespectiveTab(url + "-" + (parseInt(localStorage.getItem("currentPageIndex")) + 1) + "-" + lsrArr[1].trim());
					}
					flag = 3;
				}
				else {
					routeToRespectiveTab(prevTabContent + "-" + prevPageIndx);
					myCurrentPage = prevTabContent;
					flag = 2;
				}
			}
			else {
				routeToRespectiveTab(myUrl);
			}

			//window.location.href =myCurrentPage;
			//			routeToRespective(myUrl);
		} else {
			flag = 1;
			localStorage.setItem("currentPage", "");
			localStorage.setItem("previousPage", "");
			localStorage.setItem("currentPageIndex", -1);
			localStorage.setItem("previousPageIndex", -1);
			//window.location.href="stateDiv";
		}


	}
	else if(url == "treeViewDisplay" || url== "treeview9states")
	{
		var routeURL= "";
		
		
		var prevPage= localStorage.getItem("currentPage")+"";
		if(index < currPageIndex){
			routeURL= localStorage.getItem("currentPage")+"-"+(parseInt(localStorage.getItem("currentPageIndex")) - 1)+"";
			localStorage.setItem("currentPageIndex", (parseInt(localStorage.getItem("currentPageIndex")) - 1)+"");


			localStorage.setItem("previousPageSwitch", localStorage.getItem("currentPage"));
			localStorage.setItem("currentPageSwitch", localStorage.getItem("currentPage"));
			localStorage.setItem("currentPage", localStorage.getItem("currentPage"));
		}
		else{
		routeURL= localStorage.getItem("currentPage")+"-"+localStorage.getItem("currentPageIndex");
		var curIndex= parseInt(localStorage.getItem("currentPageIndex"));
		var ul = document.getElementById('myTab');
		var listItems = ul.getElementsByTagName('li');
		var currTabContent= listItems[curIndex].innerText;
		var lsrArr=  currTabContent.split(':');
		if(lsrArr.length>1){
			myCurrentPage= prevPage;
		}
		else
		{
			routeURL= lsrArr[0].trim()+"-"+localStorage.getItem("currentPageIndex");
			//routeURL= "selectRequest-0";
			console.log(routeURL);
			routeToRespectiveTab(routeURL);
			myCurrentPage= lsrArr[0].trim();
		}
		//routeToRespectiveTab(routeURL);
		flag = 2;
		
		}	
		
	}
	else
	{
		//For all tabs except treeview tab
		var routeURL= "";
		if(index < currPageIndex){
			routeURL= localStorage.getItem("currentPage")+"-"+(parseInt(localStorage.getItem("currentPageIndex")) - 1)+"";
		}
		else{
		routeURL= localStorage.getItem("currentPage")+"-"+localStorage.getItem("currentPageIndex");
		}
		routeToRespectiveTab(routeURL);
	}
	
	//Hrushi changes done 02_Nov
	//To Reflect removed tab changes
	if (flag == 1 || updatedArrayIndex == -1) {
		localStorage.clear();
		setTimeout(function() {
			window.location.href = "stateDiv";
		}, 1500);
		
	}
	else if (flag == 2) {
		setTimeout(function() {
				window.location.href = myCurrentPage;
			}, 3000);
			
	}else if (flag == 3){
		setTimeout(function() {
				window.location.href = myCurrentPage;
				}, 6000);
	} else {
		window.location.href= myCurrentPage;
	}
	hideAllBtns();

}


function toTreeViewOnDblclk(index, pageName,lsrNo) { 	
	
	//Hrushi- to hide toolbar buttons on double click and then restirct double click 
	preIssueDisable();
	$("#enhancedseltable *").attr('ondblclick', '');
	//Hrushi- end
	
			localStorage.setItem("onNewTab","true");
	var lsrList=	localStorage.getItem("allTreeViewOpened");	
		if(lsrList== null || lsrList== "" | lsrList== undefined){
		localStorage.setItem("allTreeViewOpened",lsrNo);
		}else{
		var lsrNew=localStorage.getItem("allTreeViewOpened");
		lsrNew=lsrNew+"_"+lsrNo;
		localStorage.setItem("allTreeViewOpened",lsrNew);
		}
		 
		//var region= localStroge.getItem("region");
		console.log("totalTreeviewOpened",lsrList);
		//console.log("region",region);
	
	var tabsCount = document.getElementById('tabsCount').innerText;
	var ul = document.getElementById('myTab');
	var listItems = ul.getElementsByTagName('li');
	
	console.log("indexx" + index + "page" + pageName);
	var sendingReq = "";
	if(listItems.length >= 5 || tabsCount.length >= 5) {
		
		alert("Can't Open more than 5 Tabs..Please close unused Tabs");
	}
	else 
	{

		if ($("#state").val() == '12 States') {
			sendingReq = "treeViewDisplay" + "$Y" + "$" + index + "$" + lsrNo;
			console.log(sendingReq);
			var xhttp = new XMLHttpRequest();

			//		 xhttp.onreadystatechange = function() {
			//    		if (this.readyState == 4 && this.status == 200) {
			//			window.location.href = "treeViewDisplay";
			//   		 	}{
			//			window.location.href = "treeViewDisplay";
			//			}
			// 		};
			
			var xhttp = new XMLHttpRequest();

					 xhttp.onreadystatechange = function() {
			    		if (this.readyState == 4 && this.status == 200) {
						window.location.href = "treeViewDisplay";
			   		 	}
			 		};

			xhttp.open("POST", "treeViewDisplay", true);
					getTokenForHttps(xhttp);
			xhttp.send(sendingReq);

			//Hrushi - commented timer for treeview 
			/*setTimeout(function() {
				window.location.href = "treeViewDisplay";
			}, 7000);*/

		}

		if ($("#state").val() == '9 States') {
			sendingReq = "treeview9states" + "$Y" + "$" + index + "$" + lsrNo;
			var xhttp = new XMLHttpRequest();

			//		 xhttp.onreadystatechange = function() {
			//    		if (this.readyState == 4 && this.status == 200) {
			//			window.location.href = "treeview9states";
			//   		 	}else{
			//			window.location.href = "treeview9states";
			//			}
			// 		};
			
			xhttp.onreadystatechange = function() {
			    		if (this.readyState == 4 && this.status == 200) {
						window.location.href = "treeview9states";
			   		 	}
			 		};
				
			xhttp.open("POST", "treeview9states", true);
			getTokenForHttps(xhttp);
			xhttp.send(sendingReq);

			//Hrushi - commented timer for treeview
			/*setTimeout(function() {
				window.location.href = "treeview9states";
			}, 7000);*/
		}
		//bhavesh index correction code
		var tab = document.getElementById("state").value;
		if(tab == '9 States'){
			tab = "treeview9states";
		}else{
			tab = "treeViewDisplay";
		}
		
		
		localStorage.removeItem("previousPage");
		localStorage.setItem("previousPage", localStorage.getItem("currentPage"));
		localStorage.removeItem("currentPage");
		localStorage.setItem("currentPage", tab);
		localStorage.setItem("maxPageIndex", parseInt(localStorage.getItem("maxPageIndex")) + 1);
		localStorage.setItem("previousPageIndex", localStorage.getItem("currentPageIndex"));
		localStorage.setItem("currentPageIndex", localStorage.getItem("maxPageIndex"));

		console.log("previous" + localStorage.getItem("previousPage") + "current" + localStorage.getItem("currentPage") + "maxTab" + localStorage.getItem("maxPageIndex"));
	}

}

function hideAllBtns() {
	document.getElementById('logOffBtn').style.display = 'none';
	document.getElementById('showErrBtn').style.display = 'none';
	document.getElementById('addBtn').style.display = 'none';
	document.getElementById('retrieveBtn').style.display = 'none';
	document.getElementById('printBtn').style.display = 'none';
	document.getElementById('saveBtn').style.display = 'none';
	document.getElementById('removeBtn').style.display = 'none';
	//document.getElementById('resendBtn').style.display = 'none';
	//document.getElementById('justGoBtn').style.display = 'none';
	document.getElementById('noteBtn').style.display = 'none';
	document.getElementById('rejectBtn').style.display = 'none';
	document.getElementById('validateCCBtn').style.display = 'none';
	document.getElementById('updwrkdBtn').style.display = 'none';
	document.getElementById('updntwrkdBtn').style.display = 'none';
	document.getElementById('wowNAForSEBtn').style.display = 'none';
	//document.getElementById('reSubmitBtn').style.display = 'none';
	//document.getElementById('sortBtn').style.display = 'none';
	document.getElementById('issuePreBtn').style.display = 'none';
	document.getElementById('issueBtn').style.display = 'none';
	document.getElementById('resetBtn').style.display = 'none';
	document.getElementById('copyRecBtn').style.display = 'none';
	document.getElementById('loss').style.display = 'none';
	document.getElementById('myprovider').style.display = "none";
	document.getElementById('workloadBtn').style.display = "none";
	
	

		if ($("#state").val()== '9 States') {
		document.getElementById('loss').style.display = "inline";
		if ($("#usertype").val()== 'HD') {
         	document.getElementById('loss').disabled = true;
			document.getElementById('loss').style.background = 'lightgrey';
			}
		document.getElementById('listenBtn').disabled = true;
		document.getElementById('listenBtn').style.background = 'lightgrey';
		}
		if ($("#state").val()== '12 States') {
		document.getElementById('workloadBtn').style.display = "inline";
		document.getElementById('myprovider').style.display = "inline";
		document.getElementById('listenBtn').disabled = true;
		document.getElementById('listenBtn').style.background = 'lightgrey';
		//document.getElementById('resendBtn').style.display = 'none';
	//	document.getElementById('justGoBtn').style.display = 'none';
		document.getElementById('issuePreBtn').style.display = 'none';
		document.getElementById('preissue').style.display = 'none';
		document.getElementById('reSubmitBtn').style.display = 'none';
		document.getElementById('sortBtn').style.display = 'none';
		}
		
		
		if (window.location.href.indexOf("/treeViewDisplay") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
//		document.getElementById('saveBtn').disabled = true;
		document.getElementById('issueBtn').style.display = 'inline';
		//document.getElementById('issueBtn').disabled = true;
		document.getElementById('printBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		//document.getElementById('showErrBtn').disabled = true;
		//document.getElementById('rejectBtn').style.display = 'inline';
		document.getElementById('noteBtn').style.display = 'inline';
		document.getElementById('sortBtn').style.display = 'none';
	}
 else if (window.location.href.indexOf("/treeview9states") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
//		document.getElementById('saveBtn').disabled = true;
		//document.getElementById('sortBtn').style.display = 'inline';
		document.getElementById('issueBtn').style.display = 'inline';
//		document.getElementById('issueBtn').disabled = true;
		document.getElementById('printBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
//		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('rejectBtn').style.display = 'inline';
		document.getElementById('noteBtn').style.display = 'inline';
		
	}
	

		//=====================User type Integration========================Dt 12oct=============================
	
///===============================For Read Only Users============================================================================///
		if ($("#usertype").val()== 'RO') {
		document.getElementById('showErrBtn').style.display = 'none';
		document.getElementById('issueBtn').style.display = 'none';
	    document.getElementById('noteBtn').style.display = 'none';
		document.getElementById('workloadBtn').style.display = 'none';
	    document.getElementById('listenBtn').style.display = 'none';

if (window.location.href.indexOf("/treeViewDisplay") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
//		document.getElementById('saveBtn').disabled = true;
		document.getElementById('issueBtn').style.display = 'inline';
		//document.getElementById('issueBtn').disabled = true;
		document.getElementById('printBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		//document.getElementById('showErrBtn').disabled = true;
		//document.getElementById('rejectBtn').style.display = 'inline';
		document.getElementById('noteBtn').style.display = 'inline';
		document.getElementById('sortBtn').style.display = 'none';
	}
else if (window.location.href.indexOf("/treeview9states") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
//		document.getElementById('saveBtn').disabled = true;
		//document.getElementById('sortBtn').style.display = 'inline';
		document.getElementById('issueBtn').style.display = 'inline';
//		document.getElementById('issueBtn').disabled = true;
		document.getElementById('printBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
//		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('rejectBtn').style.display = 'inline';
		document.getElementById('noteBtn').style.display = 'inline';
		
	}
	

if (window.location.href.indexOf("/userProfile") > -1 || window.location.href.indexOf("/retrieveUserProfileForm") > -1 || window.location.href.indexOf("/saveUserProfileForm") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
		document.getElementById('saveBtn').disabled = true;
	    document.getElementById('saveBtn').style.background = 'lightgrey';
    	document.getElementById('printBtn').style.display = 'inline';
		//document.getElementById('printBtn').disabled = true;
	   // document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('retrieveBtn').disabled = true;
	    document.getElementById('retrieveBtn').style.background = 'lightgrey';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('resetBtn').disabled = true;
	    document.getElementById('resetBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		document.getElementById('showErrBtn').disabled = true;
	    document.getElementById('showErrBtn').style.background = 'lightgrey';
		document.getElementById('logOffBtn').style.display = 'inline'; 
	
         }

  else if (window.location.href.indexOf("/enhancedSelReq") > -1 || window.location.href.indexOf("/enhancedSelReqForm") > -1) {
		
	    document.getElementById('saveBtn').style.display = 'inline';
		document.getElementById('saveBtn').disabled = true;
	    document.getElementById('saveBtn').style.background = 'lightgrey';
		document.getElementById('issueBtn').style.display = 'inline';
		document.getElementById('issueBtn').disabled = true;
	    document.getElementById('issueBtn').style.background = 'lightgrey';
		document.getElementById('printBtn').style.display = 'inline';
		//document.getElementById('printBtn').disabled = true;
	    //document.getElementById('printBtn').style.background = 'lightgrey';
        document.getElementById('copyRecBtn').style.display = 'inline';
        document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('addBtn').style.display = 'inline';
		document.getElementById('addBtn').disabled = true;
	    document.getElementById('addBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		document.getElementById('showErrBtn').disabled = true;
	    document.getElementById('showErrBtn').style.background = 'lightgrey';
		
	    }
  else if (window.location.href.indexOf("/fupRequest") > -1 || window.location.href.indexOf("/fupForm") > -1) {
    	document.getElementById('saveBtn').style.display = 'inline';
		document.getElementById('saveBtn').disabled = true;
	    document.getElementById('saveBtn').style.background = 'lightgrey';
		document.getElementById('issueBtn').style.display = 'inline';
		document.getElementById('issueBtn').disabled = true;
	    document.getElementById('issueBtn').style.background = 'lightgrey';
		document.getElementById('printBtn').style.display = 'inline';
		//document.getElementById('printBtn').disabled = true;
	   // document.getElementById('printBtn').style.background = 'lightgrey';
        document.getElementById('copyRecBtn').style.display = 'inline';
        document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('addBtn').style.display = 'inline';
		document.getElementById('addBtn').disabled = true;
	    document.getElementById('addBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		document.getElementById('showErrBtn').disabled = true;
	    document.getElementById('showErrBtn').style.background = 'lightgrey';
		
		}
  else	if (window.location.href.indexOf("/confirmedByDDESDD") > -1 || window.location.href.indexOf("/confirmedByDDESDDForm") > -1) {
	    document.getElementById('printBtn').style.display= "inline";
		//document.getElementById('printBtn').disabled = true;
	   // document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('showErrBtn').style.display= "inline";
		document.getElementById('showErrBtn').disabled = true;
	    document.getElementById('showErrBtn').style.background = 'lightgrey';
		
		}
  else if (window.location.href.indexOf("/selectRequest") > -1 || window.location.href.indexOf("/processSelectRequest") > -1) {
	    document.getElementById('printBtn').style.display= "inline";
		//document.getElementById('printBtn').disabled = true;
	    //document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('showErrBtn').style.display= "inline";
		document.getElementById("showErrBtn").disabled = true;
	    document.getElementById('showErrBtn').style.background = 'lightgrey';
		
		}	
  else if (window.location.href.indexOf("/selectProvider") > -1 || window.location.href.indexOf("/selectProviderForm") > -1) {
	    document.getElementById('retrieveBtn').style.display = 'inline';
	    document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById("printBtn").style.display = 'inline';
	    
		}	
	else if (window.location.href.indexOf("/restrictedMismatch") > -1 || window.location.href.indexOf("/restrictedMismatchForm") > -1) {
		document.getElementById("printBtn").style.display = 'inline';
		//document.getElementById("printBtn").disabled = true;
	   // document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		}			
	
	else if (window.location.href.indexOf("/unrestrictedMismatch") > -1 || window.location.href.indexOf("/unrestrictedMismatchForm") > -1) {
	    document.getElementById("printBtn").style.display = 'inline';
		//document.getElementById("printBtn").disabled = true;
	   // document.getElementById('printBtn').style.background = 'lightgrey';
		
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		}
	else if  (window.location.href.indexOf("/loss") > -1 || window.location.href.indexOf("/lossForm") > -1) {

				document.getElementById('retrieveBtn').style.display = 'inline';
				document.getElementById('resetBtn').style.display = 'inline';
			}
				
		}
		
	///********************************For LSC Manager**************************************************************************************************////
		if ($("#usertype").val()== 'LM' ) {
		document.getElementById('showErrBtn').style.display = 'none';
		document.getElementById('issueBtn').style.display = 'none';
	    document.getElementById('noteBtn').style.display = 'none';
		document.getElementById('listenBtn').style.display = "inline";
		document.getElementById('listenBtn').disabled = true;
	    document.getElementById('listenBtn').style.background = 'lightgrey';
        document.getElementById('loss').disabled = true;
		document.getElementById('loss').style.background = 'lightgrey';
		
		if (window.location.href.indexOf("/treeViewDisplay") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
//		document.getElementById('saveBtn').disabled = true;
		document.getElementById('issueBtn').style.display = 'inline';
		//document.getElementById('issueBtn').disabled = true;
		document.getElementById('printBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		//document.getElementById('showErrBtn').disabled = true;
		//document.getElementById('rejectBtn').style.display = 'inline';
		document.getElementById('noteBtn').style.display = 'inline';
		document.getElementById('sortBtn').style.display = 'none';
	}
 else if (window.location.href.indexOf("/treeview9states") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
//		document.getElementById('saveBtn').disabled = true;
		//document.getElementById('sortBtn').style.display = 'inline';
		document.getElementById('issueBtn').style.display = 'inline';
//		document.getElementById('issueBtn').disabled = true;
		document.getElementById('printBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
//		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('rejectBtn').style.display = 'inline';
		document.getElementById('noteBtn').style.display = 'inline';
		
	}
		
		
		if (window.location.href.indexOf("/workload") > -1 || window.location.href.indexOf("/workloadForm") > -1) {
		
			document.getElementById('saveBtn').style.display = 'inline';
			document.getElementById('saveBtn').disabled = true;
	       	document.getElementById('saveBtn').style.background = 'lightgrey';
			document.getElementById('printBtn').style.display= "inline";
			//document.getElementById('printBtn').disabled = true;
	       	//document.getElementById('printBtn').style.background = 'lightgrey';
            document.getElementById('copyRecBtn').style.display = 'inline';
            document.getElementById('copyRecBtn').disabled = true;
		    document.getElementById('copyRecBtn').style.background = 'lightgrey';
			document.getElementById('retrieveBtn').style.display = 'inline';
			document.getElementById('resetBtn').style.display = 'inline';
			document.getElementById('showErrBtn').style.display= "inline";
			document.getElementById('showErrBtn').disabled = true;
	       	document.getElementById('showErrBtn').style.background = 'lightgrey';
		
		}

else if (window.location.href.indexOf("/userProfile") > -1 || window.location.href.indexOf("/retrieveUserProfileForm") > -1 || window.location.href.indexOf("/saveUserProfileForm") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
		//document.getElementById('saveBtn').disabled = true;
      // 	document.getElementById('saveBtn').style.background = 'lightgrey';
    	document.getElementById('printBtn').style.display = 'inline';
		//document.getElementById('printBtn').disabled = true;
      // 	document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('showErrBtn').style.display = 'inline';
		//document.getElementById('showErrBtn').disabled = true;
       //	document.getElementById('showErrBtn').style.background = 'lightgrey';
		document.getElementById('logOffBtn').style.display = 'inline';
	 
         }

  else if (window.location.href.indexOf("/enhancedSelReq") > -1 || window.location.href.indexOf("/enhancedSelReqForm") > -1) {
		
	    document.getElementById('saveBtn').style.display = 'inline';
		document.getElementById('saveBtn').disabled = true;
       	document.getElementById('saveBtn').style.background = 'lightgrey';
		document.getElementById('issueBtn').style.display = 'inline';
		document.getElementById('issueBtn').disabled = true;
       	document.getElementById('issueBtn').style.background = 'lightgrey';
		document.getElementById('printBtn').style.display = 'inline';
		//document.getElementById('printBtn').disabled = true;
       	//document.getElementById('printBtn').style.background = 'lightgrey';
        document.getElementById('copyRecBtn').style.display = 'inline';
        document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('addBtn').style.display = 'inline';
		document.getElementById('addBtn').disabled = true;
       	document.getElementById('addBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		document.getElementById('showErrBtn').disabled = true;
       	document.getElementById('showErrBtn').style.background = 'lightgrey';
		
	    }
  else if (window.location.href.indexOf("/fupRequest") > -1 || window.location.href.indexOf("/fupForm") > -1) {
    	document.getElementById('saveBtn').style.display = 'inline';
		document.getElementById('saveBtn').disabled = true;
       	document.getElementById('saveBtn').style.background = 'lightgrey';
		document.getElementById('issueBtn').style.display = 'inline';
		document.getElementById('issueBtn').disabled = true;
       	document.getElementById('issueBtn').style.background = 'lightgrey';
		document.getElementById('printBtn').style.display = 'inline';
		//document.getElementById('printBtn').disabled = true;
       //	document.getElementById('printBtn').style.background = 'lightgrey';
        document.getElementById('copyRecBtn').style.display = 'inline';
        document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('addBtn').style.display = 'inline';
		document.getElementById('addBtn').disabled = true;
       	document.getElementById('addBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		document.getElementById('showErrBtn').disabled = true;
       	document.getElementById('showErrBtn').style.background = 'lightgrey';
		
		}
  else	if (window.location.href.indexOf("/confirmedByDDESDD") > -1 || window.location.href.indexOf("/confirmedByDDESDDForm") > -1) {
	    document.getElementById('printBtn').style.display= "inline";
		//document.getElementById('printBtn').disabled = true;
       	//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('showErrBtn').style.display= "inline";
		document.getElementById('showErrBtn').disabled = true;
       	document.getElementById('showErrBtn').style.background = 'lightgrey';
		
		}
  else if (window.location.href.indexOf("/selectRequest") > -1 || window.location.href.indexOf("/processSelectRequest") > -1) {
	    document.getElementById('printBtn').style.display= "inline";
		//document.getElementById('printBtn').disabled = true;
       //	document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('showErrBtn').style.display= "inline";
		document.getElementById("showErrBtn").disabled = true;
       	document.getElementById('showErrBtn').style.background = 'lightgrey';
		
		}	
  else if (window.location.href.indexOf("/selectProvider") > -1 || window.location.href.indexOf("/selectProviderForm") > -1) {
	    document.getElementById('retrieveBtn').style.display = 'inline';
	    document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById("printBtn").style.display = 'inline';
	    
		}	
	else if (window.location.href.indexOf("/issueProvider") > -1) {
		document.getElementById('issueBtn').style.display = 'inline';
		document.getElementById('issueBtn').disabled= true;
       	document.getElementById('issueBtn').style.background = 'lightgrey';
		document.getElementById('printBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('validateCCBtn').style.display = 'inline';
		}	
		
	else if (window.location.href.indexOf("/restrictedMismatch") > -1 || window.location.href.indexOf("/restrictedMismatchForm") > -1) {
		document.getElementById("printBtn").style.display = 'inline';
		//document.getElementById("printBtn").disabled = true;
       //	document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		}			
	
	else if (window.location.href.indexOf("/unrestrictedMismatch") > -1 || window.location.href.indexOf("/unrestrictedMismatchForm") > -1) {
	    document.getElementById("printBtn").style.display = 'inline';
		//document.getElementById("printBtn").disabled = true;
       //	document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		}	
		}	
	//**************************************************Tester***********************************************************************************************///	
		if ($("#usertype").val()== 'TS') {
		document.getElementById('showErrBtn').style.display = 'none';
		document.getElementById('issueBtn').style.display = 'none';
	    document.getElementById('noteBtn').style.display = 'none';
		document.getElementById('listenBtn').style.display = "inline";
		document.getElementById('listenBtn').disabled = true;
	    document.getElementById('listenBtn').style.background = 'lightgrey';

	if (window.location.href.indexOf("/treeViewDisplay") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
//		document.getElementById('saveBtn').disabled = true;
		document.getElementById('issueBtn').style.display = 'inline';
		//document.getElementById('issueBtn').disabled = true;
		document.getElementById('printBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		//document.getElementById('showErrBtn').disabled = true;
		//document.getElementById('rejectBtn').style.display = 'inline';
		document.getElementById('noteBtn').style.display = 'inline';
		document.getElementById('sortBtn').style.display = 'none';
	}
 else if (window.location.href.indexOf("/treeview9states") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
//		document.getElementById('saveBtn').disabled = true;
		//document.getElementById('sortBtn').style.display = 'inline';
		document.getElementById('issueBtn').style.display = 'inline';
//		document.getElementById('issueBtn').disabled = true;
		document.getElementById('printBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
//		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('rejectBtn').style.display = 'inline';
		document.getElementById('noteBtn').style.display = 'inline';
		
	}
		
		
		if (window.location.href.indexOf("/workload") > -1 || window.location.href.indexOf("/workloadForm") > -1) {
		
			document.getElementById('saveBtn').style.display = 'inline';
			document.getElementById('saveBtn').disabled = true;
         	document.getElementById('saveBtn').style.background = 'lightgrey';
			document.getElementById('printBtn').style.display= "inline";
			//document.getElementById('printBtn').disabled = true;
	      	//document.getElementById('printBtn').style.background = 'lightgrey';
            document.getElementById('copyRecBtn').style.display = 'inline';
            document.getElementById('copyRecBtn').disabled = true;
		    document.getElementById('copyRecBtn').style.background = 'lightgrey';
			document.getElementById('retrieveBtn').style.display = 'inline';
			document.getElementById('resetBtn').style.display = 'inline';
			document.getElementById('showErrBtn').style.display= "inline";
			document.getElementById('showErrBtn').disabled = true;
	      	document.getElementById('showErrBtn').style.background = 'lightgrey';
		
		}

else if (window.location.href.indexOf("/userProfile") > -1 || window.location.href.indexOf("/retrieveUserProfileForm") > -1 || window.location.href.indexOf("/saveUserProfileForm") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
		//document.getElementById('saveBtn').disabled = true;
      	//document.getElementById('saveBtn').style.background = 'lightgrey';
    	document.getElementById('printBtn').style.display = 'inline';
		//document.getElementById('printBtn').disabled = true;
      //	document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('showErrBtn').style.display = 'inline';
		//document.getElementById('showErrBtn').disabled = true;
      	//document.getElementById('showErrBtn').style.background = 'lightgrey';
		document.getElementById('logOffBtn').style.display = 'inline'; 
	
         }

  else if (window.location.href.indexOf("/enhancedSelReq") > -1 || window.location.href.indexOf("/enhancedSelReqForm") > -1) {
		
	    document.getElementById('saveBtn').style.display = 'inline';
		document.getElementById('saveBtn').disabled = true;
      	document.getElementById('saveBtn').style.background = 'lightgrey';
		document.getElementById('issueBtn').style.display = 'inline';
		document.getElementById('issueBtn').disabled = true;
      	document.getElementById('issueBtn').style.background = 'lightgrey';
		document.getElementById('printBtn').style.display = 'inline';
		//document.getElementById('printBtn').disabled = true;
      //	document.getElementById('printBtn').style.background = 'lightgrey';
        document.getElementById('copyRecBtn').style.display = 'inline';
        document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('addBtn').style.display = 'inline';
		document.getElementById('addBtn').disabled = true;
      	document.getElementById('addBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		document.getElementById('showErrBtn').disabled = true;
      	document.getElementById('showErrBtn').style.background = 'lightgrey';
		
	    }
  else if (window.location.href.indexOf("/fupRequest") > -1 || window.location.href.indexOf("/fupForm") > -1) {
    	document.getElementById('saveBtn').style.display = 'inline';
		document.getElementById('saveBtn').disabled = true;
      	document.getElementById('saveBtn').style.background = 'lightgrey';
		document.getElementById('issueBtn').style.display = 'inline';
		document.getElementById('issueBtn').disabled = true;
      	document.getElementById('issueBtn').style.background = 'lightgrey';
		document.getElementById('printBtn').style.display = 'inline';
		//document.getElementById('printBtn').disabled = true;
      	//document.getElementById('printBtn').style.background = 'lightgrey';
        document.getElementById('copyRecBtn').style.display = 'inline';
        document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('addBtn').style.display = 'inline';
		document.getElementById('addBtn').disabled = true;
      	document.getElementById('addBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		document.getElementById('showErrBtn').disabled = true;
      	document.getElementById('showErrBtn').style.background = 'lightgrey';
		
		}
  else	if (window.location.href.indexOf("/confirmedByDDESDD") > -1 || window.location.href.indexOf("/confirmedByDDESDDForm") > -1) {
	    document.getElementById('printBtn').style.display= "inline";
	   // document.getElementById('printBtn').disabled = true;
      //	document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('showErrBtn').style.display= "inline";
		document.getElementById('showErrBtn').disabled = true;
      	document.getElementById('showErrBtn').style.background = 'lightgrey';
		
		}
  else if (window.location.href.indexOf("/selectRequest") > -1 || window.location.href.indexOf("/processSelectRequest") > -1) {
	    document.getElementById('printBtn').style.display= "inline";
		//document.getElementById('printBtn').disabled = true;
      //	document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('showErrBtn').style.display= "inline";
		document.getElementById("showErrBtn").disabled = true;
      	document.getElementById('showErrBtn').style.background = 'lightgrey';
		
		}	
  else if (window.location.href.indexOf("/selectProvider") > -1 || window.location.href.indexOf("/selectProviderForm") > -1) {
	    document.getElementById('retrieveBtn').style.display = 'inline';
	    document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById("printBtn").style.display = 'inline';
	    
		}	
	else if (window.location.href.indexOf("/issueProvider") > -1) {
		document.getElementById('issueBtn').style.display = 'inline';
		document.getElementById('issueBtn').disabled= true;
      	document.getElementById('issueBtn').style.background = 'lightgrey';
		document.getElementById('printBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('validateCCBtn').style.display = 'inline';
		}	
		
	else if (window.location.href.indexOf("/restrictedMismatch") > -1 || window.location.href.indexOf("/restrictedMismatchForm") > -1) {
		document.getElementById("printBtn").style.display = 'inline';
		//document.getElementById("printBtn").disabled = true;
    	//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		}			
	
	else if (window.location.href.indexOf("/unrestrictedMismatch") > -1 || window.location.href.indexOf("/unrestrictedMismatchForm") > -1) {
	    document.getElementById("printBtn").style.display = 'inline';
		//document.getElementById("printBtn").disabled = true;
   		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		}
	else if  (window.location.href.indexOf("/loss") > -1 || window.location.href.indexOf("/lossForm") > -1) {

				document.getElementById('retrieveBtn').style.display = 'inline';
				document.getElementById('resetBtn').style.display = 'inline';
			}
		
		}
  ///**************************************************LSC Provider Manager*****************************************************************************/	
		if ($("#usertype").val()== 'PR') {
		document.getElementById('showErrBtn').style.display = 'none';
		document.getElementById('issueBtn').style.display = 'none';
	    document.getElementById('noteBtn').style.display = 'none';
		document.getElementById('listenBtn').style.display = "inline";
		document.getElementById('listenBtn').disabled = true;
	    document.getElementById('listenBtn').style.background = 'lightgrey';
		
		if (window.location.href.indexOf("/treeViewDisplay") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
//		document.getElementById('saveBtn').disabled = true;
		document.getElementById('issueBtn').style.display = 'inline';
		//document.getElementById('issueBtn').disabled = true;
		document.getElementById('printBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		//document.getElementById('showErrBtn').disabled = true;
		//document.getElementById('rejectBtn').style.display = 'inline';
		document.getElementById('noteBtn').style.display = 'inline';
		document.getElementById('sortBtn').style.display = 'none';
	}
else if (window.location.href.indexOf("/treeview9states") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
//		document.getElementById('saveBtn').disabled = true;
		//document.getElementById('sortBtn').style.display = 'inline';
		document.getElementById('issueBtn').style.display = 'inline';
//		document.getElementById('issueBtn').disabled = true;
		document.getElementById('printBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
//		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('rejectBtn').style.display = 'inline';
		document.getElementById('noteBtn').style.display = 'inline';
		
	}
		
		
if (window.location.href.indexOf("/workload") > -1 || window.location.href.indexOf("/workloadForm") > -1) {
		
			document.getElementById('saveBtn').style.display = 'inline';
			document.getElementById('saveBtn').disabled = true;
     		document.getElementById('saveBtn').style.background = 'lightgrey';
			document.getElementById('printBtn').style.display= "inline";
			//document.getElementById('printBtn').disabled = true;
      		//document.getElementById('printBtn').style.background = 'lightgrey';
            document.getElementById('copyRecBtn').style.display = 'inline';
            document.getElementById('copyRecBtn').disabled = true;
		    document.getElementById('copyRecBtn').style.background = 'lightgrey';
			document.getElementById('retrieveBtn').style.display = 'inline';
			document.getElementById('resetBtn').style.display = 'inline';
			document.getElementById('showErrBtn').style.display= "inline";
			document.getElementById('showErrBtn').disabled = true;
			document.getElementById('showErrBtn').style.background = 'lightgrey';

		}
else if (window.location.href.indexOf("/userProfile") > -1 || window.location.href.indexOf("/retrieveUserProfileForm") > -1 || window.location.href.indexOf("/saveUserProfileForm") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
		document.getElementById('saveBtn').disabled = true;
		document.getElementById('saveBtn').style.background = 'lightgrey';
    	document.getElementById('printBtn').style.display = 'inline';
		//document.getElementById('printBtn').disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('retrieveBtn').disabled = true;
		document.getElementById('retrieveBtn').style.background = 'lightgrey';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('resetBtn').disabled = true;
		document.getElementById('resetBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('showErrBtn').style.background = 'lightgrey';
		document.getElementById('logOffBtn').style.display = 'inline'; 
 		
         }

  else if (window.location.href.indexOf("/enhancedSelReq") > -1 || window.location.href.indexOf("/enhancedSelReqForm") > -1) {
		
	    document.getElementById('saveBtn').style.display = 'inline';
		document.getElementById('saveBtn').disabled = true;
		document.getElementById('saveBtn').style.background = 'lightgrey';
		document.getElementById('issueBtn').style.display = 'inline';
		document.getElementById('issueBtn').disabled = true;
		document.getElementById('issueBtn').style.background = 'lightgrey';
		document.getElementById('printBtn').style.display = 'inline';
		//document.getElementById('printBtn').disabled = true;
	//	document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('copyRecBtn').style.display = 'inline';
        document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('addBtn').style.display = 'inline';
		document.getElementById('addBtn').disabled = true;
		document.getElementById('addBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('showErrBtn').style.background = 'lightgrey';
		
	    }
  else if (window.location.href.indexOf("/fupRequest") > -1 || window.location.href.indexOf("/fupForm") > -1) {
    	document.getElementById('saveBtn').style.display = 'inline';
		document.getElementById('saveBtn').disabled = true;
		document.getElementById('saveBtn').style.background = 'lightgrey';
		document.getElementById('issueBtn').style.display = 'inline';
		document.getElementById('issueBtn').disabled = true;
		document.getElementById('issueBtn').style.background = 'lightgrey';
		document.getElementById('printBtn').style.display = 'inline';
		//document.getElementById('printBtn').disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('copyRecBtn').style.display = 'inline';
        document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('addBtn').style.display = 'inline';
		document.getElementById('addBtn').disabled = true;
		document.getElementById('addBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('showErrBtn').style.background = 'lightgrey';
	
		
		}
  else	if (window.location.href.indexOf("/confirmedByDDESDD") > -1 || window.location.href.indexOf("/confirmedByDDESDDForm") > -1) {
	    document.getElementById('printBtn').style.display= "inline";
		//document.getElementById('printBtn').disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('showErrBtn').style.display= "inline";
		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('showErrBtn').style.background = 'lightgrey';
		
		}
  else if (window.location.href.indexOf("/selectRequest") > -1 || window.location.href.indexOf("/processSelectRequest") > -1) {
	    document.getElementById('printBtn').style.display= "inline";
		//document.getElementById('printBtn').disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('showErrBtn').style.display= "inline";
		document.getElementById("showErrBtn").disabled = true;
		document.getElementById('showErrBtn').style.background = 'lightgrey';
		
		}	
  else if (window.location.href.indexOf("/selectProvider") > -1 || window.location.href.indexOf("/selectProviderForm") > -1) {
	    document.getElementById('retrieveBtn').style.display = 'inline';
	    document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById("printBtn").style.display = 'inline';
	    
		}
	else if (window.location.href.indexOf("/issueProvider") > -1) {
		document.getElementById('issueBtn').style.display = 'inline';
		document.getElementById('issueBtn').disabled= true;
        document.getElementById('issueBtn').style.background = 'lightgrey';
		document.getElementById('printBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('validateCCBtn').style.display = 'inline';
		}			
	else if (window.location.href.indexOf("/restrictedMismatch") > -1 || window.location.href.indexOf("/restrictedMismatchForm") > -1) {
		document.getElementById("printBtn").style.display = 'inline';
		//document.getElementById("printBtn").disabled = true;
       // document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		}			
	
	else if (window.location.href.indexOf("/unrestrictedMismatch") > -1 || window.location.href.indexOf("/unrestrictedMismatchForm") > -1) {
	    document.getElementById("printBtn").style.display = 'inline';
		//document.getElementById("printBtn").disabled = true;
       // document.getElementById('printBtn').style.background = 'lightgrey';
		
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		}
	else if  (window.location.href.indexOf("/loss") > -1 || window.location.href.indexOf("/lossForm") > -1) {

				document.getElementById('retrieveBtn').style.display = 'inline';
				document.getElementById('resetBtn').style.display = 'inline';
			}	
			
		}
	//////*******************************HelpDesk*********************************************************************************************////
	if ($("#usertype").val()== 'HD') {
		document.getElementById('showErrBtn').style.display = 'none';
		document.getElementById('issueBtn').style.display = 'none';
	    document.getElementById('noteBtn').style.display = 'none';
		document.getElementById('listenBtn').style.display = "inline";
		document.getElementById('listenBtn').disabled = true;
		document.getElementById('listenBtn').style.background = 'lightgrey';
		
		
		if (window.location.href.indexOf("/treeViewDisplay") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
//		document.getElementById('saveBtn').disabled = true;
		document.getElementById('issueBtn').style.display = 'inline';
		//document.getElementById('issueBtn').disabled = true;
		document.getElementById('printBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		//document.getElementById('showErrBtn').disabled = true;
		//document.getElementById('rejectBtn').style.display = 'inline';
		document.getElementById('noteBtn').style.display = 'inline';
		document.getElementById('sortBtn').style.display = 'none';
	}
else if (window.location.href.indexOf("/treeview9states") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
//		document.getElementById('saveBtn').disabled = true;
		//document.getElementById('sortBtn').style.display = 'inline';
		document.getElementById('issueBtn').style.display = 'inline';
//		document.getElementById('issueBtn').disabled = true;
		document.getElementById('printBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
//		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('rejectBtn').style.display = 'inline';
		document.getElementById('noteBtn').style.display = 'inline';
		
	}
		
		
		if (window.location.href.indexOf("/workload") > -1 || window.location.href.indexOf("/workloadForm") > -1) {
		
			document.getElementById('saveBtn').style.display = 'inline';
			document.getElementById('saveBtn').disabled = true;
			document.getElementById('saveBtn').style.background = 'lightgrey';
			document.getElementById('printBtn').style.display= "inline";
			//document.getElementById('printBtn').disabled = true;
		//	document.getElementById('printBtn').style.background = 'lightgrey';
			document.getElementById('copyRecBtn').style.display = 'inline';
            document.getElementById('copyRecBtn').disabled = true;
		    document.getElementById('copyRecBtn').style.background = 'lightgrey';
			document.getElementById('retrieveBtn').style.display = 'inline';
			document.getElementById('resetBtn').style.display = 'inline';
			document.getElementById('showErrBtn').style.display= "inline";
			document.getElementById('showErrBtn').disabled = true;
			document.getElementById('showErrBtn').style.background = 'lightgrey';
			
		}

else if (window.location.href.indexOf("/userProfile") > -1 || window.location.href.indexOf("/retrieveUserProfileForm") > -1 || window.location.href.indexOf("/saveUserProfileForm") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
    	document.getElementById('printBtn').style.display = 'inline';
		//document.getElementById('printBtn').disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('showErrBtn').style.display = 'inline';
		//document.getElementById('showErrBtn').disabled = true;
		//document.getElementById('showErrBtn').style.background = 'lightgrey';
		document.getElementById('logOffBtn').style.display = 'inline'; 
	
         }

  else if (window.location.href.indexOf("/enhancedSelReq") > -1 || window.location.href.indexOf("/enhancedSelReqForm") > -1) {
		
	    document.getElementById('saveBtn').style.display = 'inline';
		document.getElementById('saveBtn').disabled = true;
		document.getElementById('saveBtn').style.background = 'lightgrey';
		document.getElementById('issueBtn').style.display = 'inline';
		document.getElementById('issueBtn').disabled = true;
		document.getElementById('issueBtn').style.background = 'lightgrey';
		document.getElementById('printBtn').style.display = 'inline';
		//document.getElementById('printBtn').disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('copyRecBtn').style.display = 'inline';
        document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('addBtn').style.display = 'inline';
		document.getElementById('addBtn').disabled = true;
		document.getElementById('addBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('showErrBtn').style.background = 'lightgrey';
	

	    }
  else if (window.location.href.indexOf("/fupRequest") > -1 || window.location.href.indexOf("/fupForm") > -1) {
    	document.getElementById('saveBtn').style.display = 'inline';
		document.getElementById('saveBtn').disabled = true;
		document.getElementById('saveBtn').style.background = 'lightgrey';
		document.getElementById('issueBtn').style.display = 'inline';
		document.getElementById('issueBtn').disabled = true;
		document.getElementById('issueBtn').style.background = 'lightgrey';
		document.getElementById('printBtn').style.display = 'inline';
		//document.getElementById('printBtn').disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('copyRecBtn').style.display = 'inline';
        document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('addBtn').style.display = 'inline';
		document.getElementById('addBtn').disabled = true;
		document.getElementById('addBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('showErrBtn').style.background = 'lightgrey';
		

		}
  else	if (window.location.href.indexOf("/confirmedByDDESDD") > -1 || window.location.href.indexOf("/confirmedByDDESDDForm") > -1) {
	    document.getElementById('printBtn').style.display= "inline";
		//document.getElementById('printBtn').disabled = true;
	//	document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('showErrBtn').style.display= "inline";
		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('showErrBtn').style.background = 'lightgrey';
		
		}
  else if (window.location.href.indexOf("/selectRequest") > -1 || window.location.href.indexOf("/processSelectRequest") > -1) {
	    document.getElementById('printBtn').style.display= "inline";
		//document.getElementById('printBtn').disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('showErrBtn').style.display= "inline";
		document.getElementById("showErrBtn").disabled = true;
		document.getElementById('showErrBtn').style.background = 'lightgrey';
		}	
  else if (window.location.href.indexOf("/selectProvider") > -1 || window.location.href.indexOf("/selectProviderForm") > -1) {
	   document.getElementById('issueBtn').style.display = 'inline';
		document.getElementById('issueBtn').disabled= true;
		document.getElementById('issueBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('validateCCBtn').style.display = 'inline';
		document.getElementById('validateCCBtn').disabled= true;
		document.getElementById('validateCCBtn').style.background = 'lightgrey';
		document.getElementById("printBtn").style.display = 'inline';
		
		}	
	else if (window.location.href.indexOf("/issueProvider") > -1) {
		document.getElementById('issueBtn').style.display = 'inline';
		document.getElementById('issueBtn').disabled= true;
		document.getElementById('issueBtn').style.background = 'lightgrey';
		document.getElementById('printBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('validateCCBtn').style.display = 'inline';
		document.getElementById('validateCCBtn').disabled= true;
		document.getElementById('validateCCBtn').style.background = 'lightgrey';

		}	
		
	else if (window.location.href.indexOf("/restrictedMismatch") > -1 || window.location.href.indexOf("/restrictedMismatchForm") > -1) {
		document.getElementById("printBtn").style.display = 'inline';
		//document.getElementById("printBtn").disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		}			
	
	else if (window.location.href.indexOf("/unrestrictedMismatch") > -1 || window.location.href.indexOf("/unrestrictedMismatchForm") > -1) {
	    document.getElementById("printBtn").style.display = 'inline';
		//document.getElementById("printBtn").disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		}
		
		}	
			
	////*************************************SA********************System Admin**********************************************************************************////////
	if ($("#usertype").val()== 'SA') {
		document.getElementById('showErrBtn').style.display = 'none';
		document.getElementById('issueBtn').style.display = 'none';
	    document.getElementById('noteBtn').style.display = 'none';
	  //document.getElementById('myprovider').style.display = 'inline';
	  //document.getElementById('workloadBtn').style.display = 'inline';
	    document.getElementById('listenBtn').style.display = "inline";
		document.getElementById('listenBtn').disabled = true;	
		
		if (window.location.href.indexOf("/treeViewDisplay") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
//		document.getElementById('saveBtn').disabled = true;
		document.getElementById('issueBtn').style.display = 'inline';
		//document.getElementById('issueBtn').disabled = true;
		document.getElementById('printBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		//document.getElementById('showErrBtn').disabled = true;
		//document.getElementById('rejectBtn').style.display = 'inline';
		document.getElementById('noteBtn').style.display = 'inline';
		document.getElementById('sortBtn').style.display = 'none';
	}
 else if (window.location.href.indexOf("/treeview9states") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
//		document.getElementById('saveBtn').disabled = true;
		//document.getElementById('sortBtn').style.display = 'inline';
		document.getElementById('issueBtn').style.display = 'inline';
//		document.getElementById('issueBtn').disabled = true;
		document.getElementById('printBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
//		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('rejectBtn').style.display = 'inline';
		document.getElementById('noteBtn').style.display = 'inline';
		
	}
	if (window.location.href.indexOf("/workload") > -1 || window.location.href.indexOf("/workloadForm") > -1) {
		
			document.getElementById('saveBtn').style.display = 'inline';
			document.getElementById('saveBtn').disabled = true;
      		document.getElementById('saveBtn').style.background = 'lightgrey';
			document.getElementById('printBtn').style.display= "inline";
			//document.getElementById('printBtn').disabled = true;
			//document.getElementById('printBtn').style.background = 'lightgrey';
			document.getElementById('retrieveBtn').style.display = 'inline';
			document.getElementById('resetBtn').style.display = 'inline';
			document.getElementById('copyRecBtn').style.display = 'inline';
            document.getElementById('copyRecBtn').disabled = true;
			document.getElementById('copyRecBtn').style.background = 'lightgrey';
			document.getElementById('showErrBtn').style.display= "inline";
			document.getElementById('showErrBtn').disabled = true;
			document.getElementById('showErrBtn').style.background = 'lightgrey';

		}
    	
	
  else	if (window.location.href.indexOf("/enhancedSelReq") > -1 || window.location.href.indexOf("/enhancedSelReqForm") > -1) {
		
	    document.getElementById('saveBtn').style.display = 'inline';
		document.getElementById('saveBtn').disabled = true;
		document.getElementById('saveBtn').style.background = 'lightgrey';
		document.getElementById('issueBtn').style.display = 'inline';
		document.getElementById('issueBtn').disabled = true;
		document.getElementById('issueBtn').style.background = 'lightgrey';
		document.getElementById('printBtn').style.display = 'inline';
		//document.getElementById('printBtn').disabled = true;
	//	document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').style.display = 'inline';
        document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('addBtn').style.display = 'inline';
		document.getElementById('addBtn').disabled = true;
		document.getElementById('addBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('showErrBtn').style.background = 'lightgrey';
		
	    }
	
	
 else	if (window.location.href.indexOf("/fupRequest") > -1 || window.location.href.indexOf("/fupForm") > -1) {
	    
	    document.getElementById('saveBtn').style.display = 'inline';
        document.getElementById('saveBtn').disabled = true;
		document.getElementById('saveBtn').style.background = 'lightgrey';
		document.getElementById('issueBtn').style.display = 'inline';
		document.getElementById('issueBtn').disabled = true;
		document.getElementById('issueBtn').style.background = 'lightgrey';
		document.getElementById('printBtn').style.display = 'inline';
		//document.getElementById('printBtn').disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').style.display = 'inline';
        document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('addBtn').style.display = 'inline';
		document.getElementById('addBtn').disabled = true;
		document.getElementById('addBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('showErrBtn').style.background = 'lightgrey';	
	    
		
		}
	else if (window.location.href.indexOf("/selectRequest") > -1 || window.location.href.indexOf("/processSelectRequest") > -1) {
	    document.getElementById('printBtn').style.display= "inline";
		//document.getElementById('printBtn').disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('showErrBtn').style.display= "inline";
		document.getElementById("showErrBtn").disabled = true;
		document.getElementById('showErrBtn').style.background = 'lightgrey';
		}
	
 else	if (window.location.href.indexOf("/confirmedByDDESDD") > -1 || window.location.href.indexOf("/confirmedByDDESDDForm") > -1) {
	    document.getElementById('printBtn').style.display= "inline";
	 //   document.getElementById('printBtn').disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('showErrBtn').style.display= "inline";
		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('showErrBtn').style.background = 'lightgrey';
		}
	
	
 else if (window.location.href.indexOf("/userProfile") > -1 || window.location.href.indexOf("/retrieveUserProfileForm") > -1 || window.location.href.indexOf("/saveUserProfileForm") > -1) {
	    document.getElementById('saveBtn').style.display = 'inline';
		//document.getElementById('saveBtn').disabled = true;
		//document.getElementById('saveBtn').style.background = 'lightgrey';
		document.getElementById('printBtn').style.display = 'inline';
		//document.getElementById('printBtn').disabled = true;
	   // document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('showErrBtn').style.display = 'inline';
		//document.getElementById('showErrBtn').disabled = true;
		//document.getElementById('showErrBtn').style.background = 'lightgrey';
		document.getElementById('logOffBtn').style.display = 'inline';
		
		}
	
	else if (window.location.href.indexOf("/loss") > -1 || window.location.href.indexOf("/lossForm") > -1) {
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		}
		
	
	else if (window.location.href.indexOf("/issueProvider") > -1) {
		document.getElementById('issueBtn').style.display = 'inline';
		//document.getElementById('issueBtn').disabled= true;
		//document.getElementById('issueBtn').style.background = 'lightgrey';
		document.getElementById('printBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('validateCCBtn').style.display = 'inline';
		}
		
 else if (window.location.href.indexOf("/selectProvider") > -1 || window.location.href.indexOf("/selectProviderForm") > -1) {
	    document.getElementById('retrieveBtn').style.display = 'inline';
	    document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById("printBtn").style.display = 'inline';
	    }
		
 else	if (window.location.href.indexOf("/restrictedMismatch") > -1 || window.location.href.indexOf("/restrictedMismatchForm") > -1) {
		document.getElementById("printBtn").style.display = 'inline';
		//document.getElementById("printBtn").disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		}
	
  else	if (window.location.href.indexOf("/unrestrictedMismatch") > -1 || window.location.href.indexOf("/unrestrictedMismatchForm") > -1) {
	    document.getElementById("printBtn").style.display = 'inline';
	    //document.getElementById("printBtn").disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		}
		}
		
//=================For Dispacher User Type===========Sneha============================

if ($("#usertype").val()== 'SC') {
	document.getElementById('showErrBtn').style.display = 'none';
	document.getElementById('listenBtn').disabled = true;
	document.getElementById('listenBtn').style.background = 'lightgrey';
	document.getElementById('noteBtn').style.display = 'none';
	document.getElementById('issueBtn').style.display = 'none';
	
	if (window.location.href.indexOf("/treeViewDisplay") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
//		document.getElementById('saveBtn').disabled = true;
		document.getElementById('issueBtn').style.display = 'inline';
		//document.getElementById('issueBtn').disabled = true;
		document.getElementById('printBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		//document.getElementById('showErrBtn').disabled = true;
		//document.getElementById('rejectBtn').style.display = 'inline';
		document.getElementById('noteBtn').style.display = 'inline';
		document.getElementById('sortBtn').style.display = 'none';
	}
else if (window.location.href.indexOf("/treeview9states") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
//		document.getElementById('saveBtn').disabled = true;
	//	document.getElementById('sortBtn').style.display = 'inline';
		document.getElementById('issueBtn').style.display = 'inline';
//		document.getElementById('issueBtn').disabled = true;
		document.getElementById('printBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
//		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('rejectBtn').style.display = 'inline';
		document.getElementById('noteBtn').style.display = 'inline';
		
	}

	if (window.location.href.indexOf("/selectRequest") > -1 || window.location.href.indexOf("/processSelectRequest") > -1) {
	
	    document.getElementById('printBtn').style.display= "inline";
		//document.getElementById('printBtn').disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('showErrBtn').style.display= "inline";
		document.getElementById("showErrBtn").disabled = true;
		document.getElementById('showErrBtn').style.background = 'lightgrey';
		}
		
	if (window.location.href.indexOf("/fupRequest") > -1 || window.location.href.indexOf("/fupForm") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
		document.getElementById('saveBtn').disabled = true;
		document.getElementById('saveBtn').style.background = 'lightgrey';
		document.getElementById('issueBtn').style.display = 'inline';
		document.getElementById('issueBtn').disabled = true;
		document.getElementById('issueBtn').style.background = 'lightgrey';
		document.getElementById('printBtn').style.display = 'inline';
		//document.getElementById('printBtn').disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('addBtn').style.display = 'inline';
		document.getElementById('addBtn').disabled = true;
		document.getElementById('addBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('showErrBtn').style.background = 'lightgrey';
		}
		
	if (window.location.href.indexOf("/confirmedByDDESDD") > -1 || window.location.href.indexOf("/confirmedByDDESDDForm") > -1) {
	    document.getElementById('printBtn').style.display= "inline";
		//document.getElementById('printBtn').disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('showErrBtn').style.display= "inline";
		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('showErrBtn').style.background = 'lightgrey';
		
		}
	
 	if (window.location.href.indexOf("/enhancedSelReq") > -1 || window.location.href.indexOf("/enhancedSelReqForm") > -1) {

		document.getElementById('saveBtn').style.display = 'inline';
		document.getElementById('saveBtn').disabled = true;
		document.getElementById('saveBtn').style.background = 'lightgrey';
		document.getElementById('issueBtn').style.display = 'inline';
		document.getElementById('issueBtn').disabled = true;
		document.getElementById('issueBtn').style.background = 'lightgrey';
		document.getElementById('printBtn').style.display = 'inline';
		//document.getElementById('printBtn').disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('addBtn').style.display = 'inline';
		document.getElementById('addBtn').disabled = true;
		document.getElementById('addBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('showErrBtn').style.background = 'lightgrey';
		}
	if (window.location.href.indexOf("/userProfile") > -1 || window.location.href.indexOf("/retrieveUserProfileForm") > -1 || window.location.href.indexOf("/saveUserProfileForm") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
		document.getElementById('saveBtn').disabled = true;
		document.getElementById('saveBtn').style.background = 'lightgrey';
		document.getElementById('printBtn').style.display = 'inline';
		//document.getElementById('printBtn').disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('retrieveBtn').disabled = true;
		document.getElementById('retrieveBtn').style.background = 'lightgrey';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('resetBtn').disabled = true;
		document.getElementById('resetBtn').style.background = 'lightgrey';
		
		document.getElementById('showErrBtn').style.display = 'inline';
		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('showErrBtn').style.background = 'lightgrey';
		document.getElementById('logOffBtn').style.display = 'inline';
		}

	if (window.location.href.indexOf("/restrictedMismatch") > -1 || window.location.href.indexOf("/restrictedMismatchForm") > -1) {
		document.getElementById("printBtn").style.display = 'inline';
		//document.getElementById("printBtn").disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		}

	if (window.location.href.indexOf("/unrestrictedMismatch") > -1 || window.location.href.indexOf("/unrestrictedMismatchForm") > -1) {
		document.getElementById("printBtn").style.display = 'inline';
		//document.getElementById("printBtn").disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		}

	if (window.location.href.indexOf("/loss") > -1 || window.location.href.indexOf("/lossForm") > -1) {
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		}
	}
	    
	//==Dispacher User Type===========Sneha=======	
		
	//=================For Area Manager User Type===========Sneha============================

   if ($("#usertype").val()== 'AM') {
				
		document.getElementById('showErrBtn').style.display = 'none';
		document.getElementById('listenBtn').disabled = true;
		document.getElementById('listenBtn').style.background = 'lightgrey';
		document.getElementById('noteBtn').style.display = 'none';
		document.getElementById('issueBtn').style.display = 'none';
	
	if (window.location.href.indexOf("/treeViewDisplay") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
//		document.getElementById('saveBtn').disabled = true;
		document.getElementById('issueBtn').style.display = 'inline';
		//document.getElementById('issueBtn').disabled = true;
		document.getElementById('printBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		//document.getElementById('showErrBtn').disabled = true;
		//document.getElementById('rejectBtn').style.display = 'inline';
		document.getElementById('noteBtn').style.display = 'inline';
		document.getElementById('sortBtn').style.display = 'none';
	}
else if (window.location.href.indexOf("/treeview9states") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
//		document.getElementById('saveBtn').disabled = true;
		//document.getElementById('sortBtn').style.display = 'inline';
		document.getElementById('issueBtn').style.display = 'inline';
//		document.getElementById('issueBtn').disabled = true;
		document.getElementById('printBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
//		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('rejectBtn').style.display = 'inline';
		document.getElementById('noteBtn').style.display = 'inline';
		
	}
	
	
	if (window.location.href.indexOf("/selectRequest") > -1 || window.location.href.indexOf("/processSelectRequest") > -1) {
	    document.getElementById('printBtn').style.display= "inline";
		//document.getElementById('printBtn').disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('showErrBtn').style.display= "inline";
		document.getElementById("showErrBtn").disabled = true;
		document.getElementById('showErrBtn').style.background = 'lightgrey';
		}

	if (window.location.href.indexOf("/enhancedSelReq") > -1 || window.location.href.indexOf("/enhancedSelReqForm") > -1) {

		document.getElementById('saveBtn').style.display = 'inline';
		document.getElementById('saveBtn').disabled = true;
		document.getElementById('saveBtn').style.background = 'lightgrey';
		document.getElementById('issueBtn').style.display = 'inline';
		document.getElementById('issueBtn').disabled = true;
		document.getElementById('issueBtn').style.background = 'lightgrey';
		document.getElementById('printBtn').style.display = 'inline';
		//document.getElementById('printBtn').disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('addBtn').style.display = 'inline';
		document.getElementById('addBtn').disabled = true;
		document.getElementById('addBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('showErrBtn').style.background = 'lightgrey';
		
		}

	if (window.location.href.indexOf("/confirmedByDDESDD") > -1 || window.location.href.indexOf("/confirmedByDDESDDForm") > -1) {
	    document.getElementById('printBtn').style.display= "inline";
		//document.getElementById('printBtn').disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('showErrBtn').style.display= "inline";
		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('showErrBtn').style.background = 'lightgrey';
		}
	
		
	if (window.location.href.indexOf("/fupRequest") > -1 || window.location.href.indexOf("/fupForm") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
		document.getElementById('saveBtn').disabled = true;
		document.getElementById('saveBtn').style.background = 'lightgrey';
		document.getElementById('issueBtn').style.display = 'inline';
		document.getElementById('issueBtn').disabled = true;
		document.getElementById('issueBtn').style.background = 'lightgrey';
		document.getElementById('printBtn').style.display = 'inline';
		//document.getElementById('printBtn').disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('addBtn').style.display = 'inline';
		document.getElementById('addBtn').disabled = true;
		document.getElementById('addBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('showErrBtn').style.background = 'lightgrey';
		
		}
		
 
	if (window.location.href.indexOf("/userProfile") > -1 || window.location.href.indexOf("/retrieveUserProfileForm") > -1 || window.location.href.indexOf("/saveUserProfileForm") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
		document.getElementById('saveBtn').disabled = true;
		document.getElementById('saveBtn').style.background = 'lightgrey';
		document.getElementById('printBtn').style.display = 'inline';
		//document.getElementById('printBtn').disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('retrieveBtn').disabled = true;
		document.getElementById('retrieveBtn').style.background = 'lightgrey';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('resetBtn').disabled = true;
		document.getElementById('resetBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('showErrBtn').style.background = 'lightgrey';
		document.getElementById('logOffBtn').style.display = 'inline';
		}

	if (window.location.href.indexOf("/restrictedMismatch") > -1 || window.location.href.indexOf("/restrictedMismatchForm") > -1) {
		
		document.getElementById("printBtn").style.display = 'inline';
		//document.getElementById("printBtn").disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		}

	if (window.location.href.indexOf("/unrestrictedMismatch") > -1 || window.location.href.indexOf("/unrestrictedMismatchForm") > -1) {
		document.getElementById("printBtn").style.display = 'inline';
		//document.getElementById("printBtn").disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		}
	if (window.location.href.indexOf("/issueProvider") > -1) {
		document.getElementById('issueBtn').style.display = 'inline';
		document.getElementById('issueBtn').disabled= true;
		document.getElementById('issueBtn').style.background = 'lightgrey';
		document.getElementById('issueBtn').style.background = 'lightgrey';
		document.getElementById('printBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('validateCCBtn').style.display = 'inline';
		document.getElementById('validateCCBtn').disabled= true;
		document.getElementById('validateCCBtn').style.background = 'lightgrey';
		document.getElementById('validateCCBtn').style.background = 'lightgrey';
		}
	if (window.location.href.indexOf("/selectProvider") > -1 || window.location.href.indexOf("/selectProviderForm") > -1) {
	document.getElementById('issueBtn').style.display = 'inline';
	document.getElementById('issueBtn').disabled= true;	 
	document.getElementById('issueBtn').style.background = 'lightgrey';
	document.getElementById('retrieveBtn').style.display = 'inline';
	document.getElementById('resetBtn').style.display = 'inline';
	document.getElementById('validateCCBtn').style.display = 'inline';
    document.getElementById('validateCCBtn').disabled= true;
	document.getElementById('validateCCBtn').style.background = 'lightgrey';
	document.getElementById("printBtn").style.display = 'inline';
	    }

	
}   
	//==Area manager User Type===========Sneha End=======	
	
	//=====LSC Representative User Type===========Sneha start=======
	
	if ($("#usertype").val()== 'LR') {
				
	document.getElementById('showErrBtn').style.display = 'none';
	document.getElementById('listenBtn').disabled = true;
	document.getElementById('listenBtn').style.background = 'lightgrey';
	document.getElementById('noteBtn').style.display = 'none';
	document.getElementById('issueBtn').style.display = 'none';
	document.getElementById('myprovider').style.display= "inline"
	
	if (window.location.href.indexOf("/treeViewDisplay") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
//		document.getElementById('saveBtn').disabled = true;
		document.getElementById('issueBtn').style.display = 'inline';
		//document.getElementById('issueBtn').disabled = true;
		document.getElementById('printBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		//document.getElementById('showErrBtn').disabled = true;
		//document.getElementById('rejectBtn').style.display = 'inline';
		document.getElementById('noteBtn').style.display = 'inline';
		document.getElementById('sortBtn').style.display = 'none';
	}
else if (window.location.href.indexOf("/treeview9states") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
//		document.getElementById('saveBtn').disabled = true;
		//document.getElementById('sortBtn').style.display = 'inline';
		document.getElementById('issueBtn').style.display = 'inline';
//		document.getElementById('issueBtn').disabled = true;
		document.getElementById('printBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
//		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('rejectBtn').style.display = 'inline';
		document.getElementById('noteBtn').style.display = 'inline';
		
	}

	if (window.location.href.indexOf("/selectRequest") > -1 || window.location.href.indexOf("/processSelectRequest") > -1) {
	    document.getElementById('printBtn').style.display= "inline";
		//document.getElementById('printBtn').disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('showErrBtn').style.display= "inline";
		document.getElementById("showErrBtn").disabled = true;
		document.getElementById('showErrBtn').style.background = 'lightgrey';
		}
		
	if (window.location.href.indexOf("/fupRequest") > -1 || window.location.href.indexOf("/fupForm") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
		document.getElementById('saveBtn').disabled = true;
		document.getElementById('saveBtn').style.background = 'lightgrey';
		document.getElementById('issueBtn').style.display = 'inline';
		document.getElementById('issueBtn').disabled = true;
		document.getElementById('issueBtn').style.background = 'lightgrey';
		document.getElementById('printBtn').style.display = 'inline';
		//document.getElementById('printBtn').disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('addBtn').style.display = 'inline';
		document.getElementById('addBtn').disabled = true;
		document.getElementById('addBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('showErrBtn').style.background = 'lightgrey';
		}
		
	if (window.location.href.indexOf("/confirmedByDDESDD") > -1 || window.location.href.indexOf("/confirmedByDDESDDForm") > -1) {
	    document.getElementById('printBtn').style.display= "inline";
		//document.getElementById('printBtn').disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('showErrBtn').style.display= "inline";
		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('showErrBtn').style.background = 'lightgrey';
		}
	
 	if (window.location.href.indexOf("/enhancedSelReq") > -1 || window.location.href.indexOf("/enhancedSelReqForm") > -1) {
	
		document.getElementById('saveBtn').style.display = 'inline';
		document.getElementById('saveBtn').disabled = true;
		document.getElementById('saveBtn').style.background = 'lightgrey';
		document.getElementById('issueBtn').style.display = 'inline';
		document.getElementById('issueBtn').disabled = true;
		document.getElementById('issueBtn').style.background = 'lightgrey';
		document.getElementById('printBtn').style.display = 'inline';
		//document.getElementById('printBtn').disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').disabled = true;
		document.getElementById('copyRecBtn').style.background = 'lightgrey';
		document.getElementById('addBtn').style.display = 'inline';
		document.getElementById('addBtn').disabled = true;
		document.getElementById('addBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('showErrBtn').style.background = 'lightgrey';
		}
	if (window.location.href.indexOf("/userProfile") > -1 || window.location.href.indexOf("/retrieveUserProfileForm") > -1 || window.location.href.indexOf("/saveUserProfileForm") > -1) {
		document.getElementById('saveBtn').style.display = 'inline';
		document.getElementById('saveBtn').disabled = true;
		document.getElementById('saveBtn').style.background = 'lightgrey';
		document.getElementById('printBtn').style.display = 'inline';
		//document.getElementById('printBtn').disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('retrieveBtn').disabled = true;
		document.getElementById('retrieveBtn').style.background = 'lightgrey';
		document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById('resetBtn').disabled = true;
		document.getElementById('resetBtn').style.background = 'lightgrey';
		document.getElementById('showErrBtn').style.display = 'inline';
		document.getElementById('showErrBtn').disabled = true;
		document.getElementById('showErrBtn').style.background = 'lightgrey';
		document.getElementById('logOffBtn').style.display = 'inline';
		document.getElementById('logOffBtn').style.display = 'inline';
		}

	if (window.location.href.indexOf("/restrictedMismatch") > -1 || window.location.href.indexOf("/restrictedMismatchForm") > -1) {
		document.getElementById("printBtn").style.display = 'inline';
		//document.getElementById("printBtn").disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		}

	if (window.location.href.indexOf("/unrestrictedMismatch") > -1 || window.location.href.indexOf("/unrestrictedMismatchForm") > -1) {
		document.getElementById("printBtn").style.display = 'inline';
		//document.getElementById("printBtn").disabled = true;
		//document.getElementById('printBtn').style.background = 'lightgrey';
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		}
		
		if (window.location.href.indexOf("/selectProvider") > -1 || window.location.href.indexOf("/selectProviderForm") > -1) {
		 
	document.getElementById('retrieveBtn').style.display = 'inline';
	document.getElementById('resetBtn').style.display = 'inline';
		document.getElementById("printBtn").style.display = 'inline';
	
	    }

	if (window.location.href.indexOf("/loss") > -1 || window.location.href.indexOf("/lossForm") > -1) {
		document.getElementById('retrieveBtn').style.display = 'inline';
		document.getElementById('resetBtn').style.display = 'inline';
		}
		
	
	}   
	//======LSC Representative User Type===========Sneha End=======	
		treeviewButtonsDisable();
		
 }
		
		//=====================User type Integration End ========================Dt 12oct=============================



function showHideBtn(submitType) {
	
	var tabsCount = document.getElementById('tabsCount').innerText;
	var ul = document.getElementById('myTab');
	var listItems = ul.getElementsByTagName('li');
		//alert(listItems.length);
		
	if(listItems.length >= 5 || tabsCount.length >= 5) 
	{
		alert("Can't Open more than 5 Tabs..Please close unused Tabs");
	}
	else{
	
	if (submitType == 0) {
		callJavaController("workload", "Y");
		location.href = 'workload';
		hideAllBtns();
	}
	

	if (submitType == 1) {
		if ($("#selectModalBody input:radio:checked").val() == 'Request') {
			callJavaController("selectRequest", "Y");
			location.href = 'selectRequest';
			hideAllBtns();
		}
		if ($("#selectModalBody input:radio:checked").val() == 'Enhanced Sel Req') {
			callJavaController("enhancedSelReq", "Y");
			location.href = 'enhancedSelReq';
			hideAllBtns();
		}
		if ($("#selectModalBody input:radio:checked").val() == 'Confirmed By DD/ESD') {
			callJavaController("confirmedByDDESDD","Y");
			location.href = 'confirmedByDDESDD';
			hideAllBtns();
		}
		if ($("#selectModalBody input:radio:checked").val() == 'FUP Req') {
			callJavaController("fupRequest", "Y");
			location.href = 'fupRequest';
			hideAllBtns();
		}
	}
	
	if (submitType == 2) {
		if ($("#mismatchModalBody input:radio:checked").val() == 'Restricted Mismatch') {
			callJavaController("restrictedMismatch", "Y");
			location.href = 'restrictedMismatch';
			hideAllBtns();
		}
		if ($("#mismatchModalBody input:radio:checked").val() == 'Unrestricted Mismatch') {
			callJavaController("unrestrictedMismatch", "Y");
			location.href = 'unrestrictedMismatch';
			hideAllBtns();
		}
	}
	
	if (submitType == 5) {
	
		if ($("#providerModalBody input:radio:checked").val() == 'Issue Provider') {
			callJavaController("issueProvider", "Y");
			location.href = 'issueProvider';
			hideAllBtns();
		}
		if ($("#providerModalBody input:radio:checked").val() == 'Select Provider') {
			callJavaController("selectProvider", "Y");
			location.href = 'selectProvider';
			hideAllBtns();
		}
		
	}
	
	if (submitType == 7) {
		callJavaController("userProfile", "Y");
		location.href = 'userProfile';
		hideAllBtns();
	}
	
	if (submitType == 8) {
		hideAllBtns();
	}
	
	if (submitType == 9) {
		callJavaController("loss", "Y");
		location.href = 'loss';
		hideAllBtns();
	}
	
  }
   
}


function retrieveFunction() {
	if (window.location.href.indexOf("/userProfile") > -1 || window.location.href.indexOf("/retrieveUserProfileForm") > -1 || window.location.href.indexOf("/saveUserProfileForm") > -1) {

		var isValidData = true;
		document.getElementById('saveBtn').disabled = '';
		document.getElementById('removeBtn').disabled = '';
		document.getElementById('showErrBtn').disabled = '';
		// out1= getFormData("#userprofile1");
		var parent = document.getElementById("userIdDiv");
		var child = parent.children[1];
		var option = child.value;
		if (option == "") {
			document.getElementById("userid_primary_err").innerHTML = getErrorMsg(jsonData.LG0038);
			child.focus();
			isValidData = false;
		}

		if ($("#state").val() == '9 States' && isValidData == true) {
			//hideAllBtns();
			//document.forms["user_profile"].submit();
			callJavaController("userProfileFetch", "F");
			//hideAllBtns();
			preIssueDisable();
		}
		if ($("#state").val() == '12 States' && isValidData == true) {
			//document.forms["user_profile"].submit();
			callJavaController("userProfileFetch", "F");
			//hideAllBtns();
			preIssueDisable();
		}

	}
	
if (window.location.href.indexOf("/enhancedSelReq") > -1 || window.location.href.indexOf("/enhancedSelReqForm") > -1) {
	var ls_nc = document.getElementById("nc").value;
	var ls_nci = document.getElementById("nci").value;
	var ls_cc = document.getElementById("company_code").value;
	var ls_sc = document.getElementById("sc").value;
	var ls_tns = document.getElementById("tns").value;
	var ls_ecckt = document.getElementById("ecckt").value;
	var ls_ported_nbr = document.getElementById("ported_nbr").value;
	var ls_otn = document.getElementById("otn").value;
	var ls_ord = document.getElementById("ord").value;
	var ls_ordl = document.getElementById("ordl").value;
	var ls_npord = document.getElementById("npord").value;
	var ls_startDate = document.getElementById("date_received_begin_date").value;
	var ls_endDate = document.getElementById("date_received_end_date").value;
	var isvalidData = true;
	
	if(ls_startDate != "" && ls_endDate == ""){
	if(ls_endDate == ""){
	var inp=document.getElementById("date_received_end_date");
	document.getElementById("date_received_end_dateerr").innerHTML="";
	inp.addEventListener("invalid", function(){
	document.getElementById("date_received_end_dateerr").innerHTML=getErrorMsg(jsonData.LG0009, "Date Received End Date","mm/dd/yyyy");
	isvalidData = false;
	});
	inp.checkValidity();
	}
	}
	
	
	else if(ls_endDate != "" && ls_startDate == ""){
	if(ls_startDate == ""){
	var inp1=document.getElementById("date_received_begin_date");
	document.getElementById("date_received_begin_dateerr").innerHTML="";
	inp1.addEventListener("invalid", function(){
	document.getElementById("date_received_begin_dateerr").innerHTML=getErrorMsg(jsonData.LG0009, "Date Received Begin Date","mm/dd/yyyy");
	isvalidData = false;
	});
	inp1.checkValidity();
	}
	}
	
	
	if ($("#state").val()== '9 States') {
	
		if(((ls_cc != "" && (ls_sc =="AL" || ls_sc =="AR" || ls_sc =="CA" || ls_sc =="CT" || ls_sc =="FL" || ls_sc =="GA" || ls_sc =="IL" || ls_sc == "IN" || ls_sc == "KS" || ls_sc =="KY" || ls_sc =="LA" || ls_sc == "MI" || ls_sc =="MS" || ls_sc == "MO" || ls_sc == "NV" || ls_sc =="NC" || ls_sc == "OH" || ls_sc == "OK" || ls_sc =="SC" || ls_sc =="TN" || ls_sc == "TX" || ls_sc == "WI")) && ((ls_nci != "" && ls_nc !="") || ls_tns != "" || ls_ported_nbr != "" || ls_ecckt != "" || ls_otn != "" || ls_ord != "" || ls_ordl != "" || ls_npord != "" || ls_startDate != "")) ||
		( ls_nc !="" || ls_tns != "" || ls_ecckt != "" || ls_otn != "" || ls_ord != "" || ls_ordl != "" || ls_npord != "" || ls_startDate != "" || ls_ported_nbr != "" || (ls_startDate != "" && ls_endDate != ""))){
		document.getElementById("multisearcherr").innerHTML="";
		document.getElementById("ncerr").innerHTML="";
		
		//document.forms["enhancedSelReqForm"].submit();
		callJavaController("enhancedSelReqFetch","F");
		preIssueDisable();
		}
		
		else if((ls_sc =="AL" || ls_sc =="AR" || ls_sc =="CA" || ls_sc =="CT" || ls_sc =="FL" || ls_sc =="GA" || ls_sc =="IL" || ls_sc == "IN" || ls_sc == "KS" || ls_sc =="KY" || ls_sc =="LA" || ls_sc == "MI" || ls_sc =="MS" || ls_sc == "MO" || ls_sc == "NV" || ls_sc =="NC" || ls_sc == "OH" || ls_sc == "OK" || ls_sc =="SC" || ls_sc =="TN" || ls_sc == "TX" || ls_sc == "WI") && ls_cc == "" && (ls_nc == "" && ls_nci == "")){
		document.getElementById("companycodeerr").innerHTML=getErrorMsg(jsonData.LG0275);
		}
		
		else if(ls_nc == "" && ls_nci != "" ){
		document.getElementById("ncerr").innerHTML=getErrorMsg(jsonData.LG0288);
		
		}
		else if((ls_cc != "" || ls_sc != "") && (
		ls_tns == "" || ls_ecckt == "" || ls_otn == "" || ls_ported_nbr !="" || ls_ord == "" || ls_ordl == "" || ls_npord == "" || ls_startDate == "")){
		document.getElementById("multisearcherr").innerHTML=getErrorMsg(jsonData.LG0274);
		}
		
		
		else{
		document.getElementById("multisearcherr").innerHTML="";
		}
		
		/*location.href = 'treeView9States';*/
		//hideAllBtns();
	}
	
	
	if( ($("#state").val() == '12 States') && (isvalidData == true) ){
	
	
		if(((ls_cc != "" && (ls_sc =="AR" || ls_sc =="CA" || ls_sc =="CT" || ls_sc =="IL" || ls_sc == "IN" || ls_sc == "KS" || ls_sc == "MI" || ls_sc == "MO" || ls_sc == "NV" || ls_sc == "OH" || ls_sc == "OK" || ls_sc == "TX" || ls_sc == "WI")) && ((ls_nci != "" && ls_nc !="") || ls_tns != "" || ls_ported_nbr != "" || ls_ecckt != "" || ls_otn != "" || ls_ord != "" || ls_ordl != "" || ls_npord != "" || ls_startDate != "")) ||
		( ls_nc !="" || ls_tns != "" || ls_ecckt != "" || ls_otn != "" || ls_ord != "" || ls_ordl != "" || ls_npord != "" || ls_startDate != "" || ls_ported_nbr != "" || (ls_startDate != "" && ls_endDate != ""))){
		document.getElementById("multisearcherr").innerHTML="";
		document.getElementById("ncerr").innerHTML="";
		
		//document.forms["enhancedSelReqForm"].submit();
		callJavaController("enhancedSelReqFetch","F");
		preIssueDisable();
		}
		
		else if((ls_sc =="AR" || ls_sc =="CA" || ls_sc =="CT" || ls_sc =="IL" || ls_sc == "IN" || ls_sc == "KS" || ls_sc == "MI" || ls_sc == "MO" || ls_sc == "NV" || ls_sc == "OH" || ls_sc == "OK" || ls_sc == "TX" || ls_sc == "WI") && ls_cc == "" && (ls_nc == "" && ls_nci == "")){
		document.getElementById("companycodeerr").innerHTML=getErrorMsg(jsonData.LG0275);
		}
		
		else if(ls_nc == "" && ls_nci != "" ){
		document.getElementById("ncerr").innerHTML=getErrorMsg(jsonData.LG0288);
		
		}
		else if((ls_cc != "" || ls_sc != "") && (
		ls_tns == "" || ls_ecckt == "" || ls_otn == "" || ls_ported_nbr !="" || ls_ord == "" || ls_ordl == "" || ls_npord == "" || ls_startDate == "")){
		document.getElementById("multisearcherr").innerHTML=getErrorMsg(jsonData.LG0274);
		}
		
		
		
		else{
		document.getElementById("multisearcherr").innerHTML="";
		}
		
		/*location.href = 'treeViewDisplay';*/
		//hideAllBtns();
	
	}
}
	
	if (window.location.href.indexOf("/loss") > -1 || window.location.href.indexOf("/lossForm") > -1) {
	      var isvalid=true;
		  var companyCode = document.getElementById("company_code").value;
          var inp=document.getElementById("history_date");
          if ($("#state").val()== '9 States') {
           document.getElementById("history_dateErr").innerHTML="";
			inp.addEventListener("invalid", function(){
			document.getElementById("history_dateErr").innerHTML=getErrorMsg(jsonData.LG0009, "History Date","mm/dd/yyyy");
			isvalid=false;
			});
			inp.checkValidity();
          
          if(isvalid==true){
              //document.forms["lossForm"].submit();
              callJavaController("lossFetch","F");
				preIssueDisable();
          }
          } 
		  }

if (window.location.href.indexOf("/selectProvider") > -1) {
		var ls_cc = document.getElementById("company_code").value;
		var beginDate = document.getElementById("conversion_begin_date").value;
		var endDate = document.getElementById("conversion_end_date").value;
		var wtn = document.getElementById("wtn").value;
		var ecckt = document.getElementById("ecckt").value;
		var date1 = new Date(beginDate);
		var date2 = new Date(endDate);
		var time_diff = date2.getTime() - date1.getTime();
		var diff = time_diff / (1000 * 60 * 60 *  24);
		var ls_len = ls_cc.length;
		var format = /[ `!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
		var isValidData = true;

		// Check Validations

			if (ls_cc == "") {
				document.getElementById("losingCCErr").innerHTML = getErrorMsg(JSONData.LG0006, "Losing CC");
				document.getElementById("cbdErr").innerHTML = "";
				isValidData = false ;
			}
			else if (ls_cc.length < 4) {
				document.getElementById("losingCCErr").innerHTML = getErrorMsg(JSONData.LG0007, "Losing CC", 4);
				document.getElementById("cbdErr").innerHTML = "";
				isValidData = false ;
			}
			else if (format.test(ls_cc) == true) {
				document.getElementById("losingCCErr").innerHTML = getErrorMsg(JSONData.LG0065, "Losing CC");
				isValidData = false ;
			}
			else if (ls_cc != "" && ls_len == 4 && beginDate == "") {
				document.getElementById("cbdErr").innerHTML = getErrorMsg(JSONData.LG0006, "Conversion Begin Date");
				document.getElementById("losingCCErr").innerHTML = "";
				isValidData = false ;
			}
			else if (beginDate == "" && endDate != "")  {
				document.getElementById('company_code').style.borderColor = "";
				document.getElementById("cbdErr").innerHTML = getErrorMsg(JSONData.LG0042);
				isValidData = false ;
			}
//			if (beginDate == "" && endDate != "") {
//				document.getElementById("cbdErr").innerHTML = getErrorMsg(JSONData.LG0042);
//				isValidData = false ;
//			}
			else if (endDate != "" && beginDate > endDate) {
				document.getElementById("cbdErr").innerHTML = getErrorMsg(JSONData.LG0043);
				isValidData = false ;
			}
			else if (diff > 7) {
				document.getElementById("cbdErr").innerHTML = getErrorMsg(JSONData.LG0044);
				isValidData = false ;
			} 
			else {
				document.getElementById("cbdErr").innerHTML = "";
				document.getElementById("losingCCErr").innerHTML = "";
			}
			var begin = document.getElementById("conversion_begin_date");
			begin.addEventListener("invalid", function() {
				document.getElementById("cbdErr").innerHTML = getErrorMsg(JSONData.LG0009, "Conversion Begin Date", "mm/dd/yyyy");
				document.getElementById("losingCCErr").innerHTML = "";
				isValidData = false ;
			});
			begin.checkValidity();

			var end = document.getElementById("conversion_end_date");
			end.addEventListener("invalid", function() {
				document.getElementById("cbdErr").innerHTML = getErrorMsg(JSONData.LG0009, "Conversion End Date", "mm/dd/yyyy");
				document.getElementById("losingCCErr").innerHTML = "";
				isValidData = false ;
			});
			end.checkValidity();

			var inp1 = document.getElementById("wtn").value;
			var inp2 = document.getElementById("ecckt").value;
			if (inp1 != "") {
				document.getElementById("ecckt").disabled = true;
			}
			else if (inp2 != "") {
				document.getElementById("wtn").disabled = true;
			}
			else {
				document.getElementById("wtn").disabled = false;
				document.getElementById("ecckt").disabled = false;
			}
			if (($("#state").val() == '12 States') && (isValidData == true)) {
				
				//document.forms["selectProvider"].submit();
				callJavaController("selectProviderFetch","F");
				preIssueDisable();
			}
			if (($("#state").val() == '9 States') && (isValidData == true)) {
				//document.forms["selectProvider"].submit();
				callJavaController("selectProviderFetch","F");
				//hideAllBtns();
				preIssueDisable();
			}

	}	
	if (window.location.href.indexOf("/fupRequest") > -1 || window.location.href.indexOf("/fupForm") > -1) {

             var companycd=document.getElementById("company_code").value;
             var userid=document.getElementById("userid").value;
             var startDate=document.getElementById("followup_begin_date").value;
             var endDate=document.getElementById("followup_end_date").value;
             var date1= new  Date(startDate);
             var date2= new  Date(endDate);
             var time_diff = date2.getTime()-date1.getTime();
             var diff = time_diff / (1000 * 60 * 60 * 24);
             var bg = document.getElementById("begindateerr");
             var bg2 = document.getElementById("companycodeerr");
             var bg3 = document.getElementById("multiplefielderr");
             var isValidData = true;
             
            if(companycd == "" && userid == "" && startDate != ""){
	 			document.getElementById("multiplefielderr").innerHTML=getErrorMsg(jsonData.LG0239);
	 			isValidData = false;
	  			 }	 
	  		else if(companycd == "" && userid == "" ){
	  		   document.getElementById("companycodeerr").innerHTML=getErrorMsg(jsonData.LG0006,"Company code");
	  		   isValidData = false;
	  		}
			else if((companycd != "" && startDate == "") || (companycd != ""  && endDate != "" && startDate == "")){
				document.getElementById("begindateerr").innerHTML=getErrorMsg(jsonData.LG0128);
				isValidData = false;
				if(startDate== "") {
	 		           var startD=document.getElementById("followup_begin_date");
                       document.getElementById("multiplefielderr").innerHTML="";
                       startD.addEventListener("invalid", function(){
                       document.getElementById("multiplefielderr").innerHTML=getErrorMsg(jsonData.LG0009,  "Follow-up Begin Date","mm/dd/yyyy");
                       isValidData = false;
                       });
                       startD.checkValidity();
				}
			}
	  		else if(userid != "" && startDate == ""){
	   		   document.getElementById("begindateerr").innerHTML=getErrorMsg(jsonData.LG0240);
	   		   isValidData = false;
				if(startDate== "") {
	 		           var startD=document.getElementById("followup_begin_date");
                       document.getElementById("multiplefielderr").innerHTML="";
                       startD.addEventListener("invalid", function(){
                       document.getElementById("multiplefielderr").innerHTML=getErrorMsg(jsonData.LG0009, "Follow-up Begin Date","mm/dd/yyyy");
                       isValidData = false;
                       });
                       startD.checkValidity();
				}
	   		}
	   		else if(startDate != "" && endDate != "" && startDate > endDate){
				document.getElementById("enddateerr").innerHTML=getErrorMsg(jsonData.LG0043);
				isValidData = false;
			  }
			else if(diff >7){
			    document.getElementById("enddateerr").innerHTML=getErrorMsg(jsonData.LG0044);
			    isValidData = false;
			  }  
			else if((companycd != "" && startDate != "" && endDate =="") || (userid != ""  && startDate != "" && endDate == "")){
			       if(endDate ==""){
			       //function to check valid date format:-	 		
	 		       var endD=document.getElementById("followup_end_date");
                   document.getElementById("enddateerr").innerHTML="";
                   endD.addEventListener("invalid", function(){
                   document.getElementById("enddateerr").innerHTML=getErrorMsg(jsonData.LG0009,  "Follow-up End Date","mm/dd/yyyy");
                   isValidData = false;
                   });
                   endD.checkValidity();
			                      }
			    }
	  		else{
	 			document.getElementById("companycodeerr").innerHTML="";
	 			document.getElementById("multiplefielderr").innerHTML="";
	 			document.getElementById("begindateerr").innerHTML="";
	 			document.getElementById("enddateerr").innerHTML="";	 			
	 		}
             
		if (($("#state").val()== '9 States')&& (isValidData == true)) {
		
/*			location.href = 'treeView9States';*/

			//document.forms["fupRequest"].submit();
			callJavaController("fupRequestFetch","F");
			preIssueDisable(); 
			//hideAllBtns();
		}
		if (($("#state").val() == '12 States')&& (isValidData == true)) {
		
/*			  location.href = 'treeViewDisplay';*/
          
			callJavaController("fupRequestFetch","F");
			preIssueDisable();
			//hideAllBtns();
		}

	}
	if (window.location.href.indexOf("/confirmedByDDESDD") > -1) {
			
			if($("form[name='confirmedByDDESDD']").valid()){
				
			if ($("#state").val() == '9 States') {
				//$("form[name='confirmedByDDESDD']").submit();
				/*location.href = 'treeView9States';*/
				
				callJavaController("confirmedByDDFetch","F");
				preIssueDisable();
				//hideAllBtns();
				
			}
			if ($("#state").val() == '12 States') {
				//$("form[name='confirmedByDDESDD']").submit();
				/*location.href = 'treeViewDisplay';*/
				callJavaController("confirmedByDDFetch","F");
				preIssueDisable();
				//hideAllBtns();
			}
		}
	}
	
	if (window.location.href.indexOf("/selectRequest") > -1 || window.location.href.indexOf("/processSelectRequest") > -1) {
		var isValidData = false;
		var bd_val = $("input[name='date_received_begin_date']").val();
		var end_val = $("input[name='date_received_end_date']").val();
		
		if($("input[name='request_id']").val() != "" && ($("input[name='request_id']").val().length) == 14) {
			isValidData = true;
		}
		
		if($("form[name='selectRequest']").valid()){
			isValidData = true;
		}
		
		if(bd_val !=  '' && end_val != '' && bd_val>end_val ) {
			document.getElementById('ederr').innerHTML = "DATE RECEIVED END DATE must be > or = to DATE RECEIVED BEGIN DATE" ;
			isValidData = false;
		}
		
		if($("input[name='company_code']").val() != "" && ($("input[name='company_code']").val().length) == 4) {
			if($("input[name='pon']").val() == "" && $("input[name='rpon']").val() == "" && $("input[name='project']").val() == "" 
			&& $("input[name='date_received_begin_date']").val() == "" && $("input[name='date_received_end_date']").val() == "") {
			isValidData = false;
			}
			else if($("input[name='date_received_end_date']").val() != "" && $("input[name='date_received_begin_date']").val() == ""){
					isValidData = false;
			}
			else if($("input[name='pon']").val() != "" || $("input[name='rpon']").val() != "" || $("input[name='project']").val() != "" 
			|| $("input[name='date_received_begin_date']").val() != ""){
				isValidData = true;
			}
		}
		
		if(isValidData==true){
			preIssueDisable();
			callJavaController("requestFetch","F");
		}
		
	}

		
		
	
		
	if (window.location.href.indexOf("/workload") > -1 || window.location.href.indexOf("/workloadForm") > -1) {
	var isValidData = true;
	var userId = document.getElementById("user").value;
	var groupId = document.getElementById("group_id").value;
	var sm = document.getElementById("sm_time").value;
	var amPm = document.getElementById("am_pm").value;
	
	
	if((userId == "NA" || userId == null || userId == "") && (groupId == "" || groupId == "NA" || groupId == null))
	{ 
	document.getElementById("GroupIDErr").innerHTML=getErrorMsg(jsonData.LG0012,"ID");
	isValidData = false;
	}	
	
	
	if ((document.getElementById("sm_time").disabled == false) && (document.getElementById("sm_time").value != "" ))
	   {
		if(( (sm != null ) || (sm != "" )) && ( amPm == "NA" || amPm == null || amPm == "" ))
			{
				document.getElementById("PmErr").innerHTML= getErrorMsg(jsonData.LG0266,"AmPm");
				isValidData = false;
			}
	    }	
	    
	   //for date format check
    var inp=document.getElementById("sm_dttm_rcvd");
	document.getElementById("Sm_DateErr").innerHTML="";
	
	inp.addEventListener("invalid", function(){
	document.getElementById("Sm_DateErr").innerHTML=getErrorMsg(jsonData.LG0009, "SM date","MM/DD/YYYY");
	isValidData = false;
	});
	inp.checkValidity();
	
	var inp1=document.getElementById("due_date");
	document.getElementById("due_dateErr").innerHTML="";
	
	inp1.addEventListener("invalid", function(){
	document.getElementById("due_dateErr").innerHTML=getErrorMsg(jsonData.LG0009, "Due date","MM/DD/YYYY");
	isValidData = false;
	});
	inp1.checkValidity();
	
	var inp2=document.getElementById("cd");
	document.getElementById("cdErr").innerHTML="";
	
	inp2.addEventListener("invalid", function(){
	document.getElementById("cdErr").innerHTML=getErrorMsg(jsonData.LG0009, "CD date","MM/DD/YYYY");
	isValidData = false;
	});
	inp2.checkValidity();


//for  AMPM and time  error

	if(( (sm == null ) || (sm == "" )) && ( amPm == "AM" || amPm == "PM" ))
	{
		
		document.getElementById("PmErr").innerHTML= getErrorMsg(jsonData.LG0266,"AmPm");
		isValidData = false;
	}
	
		if (($("#state").val() == '12 States') && (isValidData == true)) {
		
			/*location.href = 'treeViewDisplay';*/
			
			//document.forms["workload"].submit();
			callJavaController("workloadFetch", "F");
			//hideAllBtns();
			preIssueDisable();
		}
	}
	
		if (window.location.href.indexOf("/restrictedMismatch") > -1 || window.location.href.indexOf("/restrictedMismatchForm") > -1) {
     var isValidData = true; 
     var companyCode = document.getElementById("company_code").value;
     var pon = document.getElementById("pon").value;
     var startDate = document.getElementById("cbd").value;
     var endDate = document.getElementById("ced").value;
     var lsr_no = document.getElementById("lsr_no").value;
     var version = document.getElementById("version").value;
     var req_typ = document.getElementById("req_typ").value;
     var sc = document.getElementById("sc").value;
     var system = document.getElementById("system").value; 
	var myRadio = document.getElementById("radio1");
    var date1= new  Date(startDate);
    var date2= new  Date(endDate);

   // var diff = date2.getDate()-date1.getDate();
var time_diff = date2.getTime()-date1.getTime();
     var diff = time_diff / (1000*60*60*24);
      var inp=document.getElementById("ced");
//alert("inp"+inp);
document.getElementById("enddateerr").innerHTML="";
inp.addEventListener("invalid", function(){
document.getElementById("enddateerr").innerHTML=getErrorMsg(jsonData.LG0009, "End Date","MM/DD/YYYY");
});
inp.checkValidity();

var bgnDte=document.getElementById("cbd");
//alert("bgnDte"+bgnDte);
document.getElementById("begindateerr").innerHTML="";
bgnDte.addEventListener("invalid", function(){
document.getElementById("begindateerr").innerHTML=getErrorMsg(jsonData.LG0009, "Begin Date","MM/DD/YYYY");
});
bgnDte.checkValidity();

//if((myRadio.value== "O") && (system == "CABS/ACIS-PTB")){
/*if((myRadio.value== "O") && (system == "SORD-PTB")||(system == "CABS/ACIS-PTB")){
isValidData = false;
document.getElementById("systemerr").innerHTML=getErrorMsg(jsonData.LG0267);

}*/
       if((req_typ != " " && req_typ != null)  && (sc != " " && sc != null) && (system != " " && system != null) && (startDate == "" || startDate == null) ){  
     
document.getElementById("begindateerr").innerHTML=getErrorMsg(jsonData.LG0006,"Begin Date");
     document.getElementById("systemerr").innerHTML="";
     isValidData = false;
     }else{
              document.getElementById("systemerr").innerHTML="";
              
          }
     
     
     if(startDate == "" && endDate != ""){
document.getElementById("begindateerr").innerHTML=getErrorMsg(jsonData.LG0042);
   //  document.getElementById('cbd').focus();
     isValidData = false;
     }//susheel start defect no
     else if(endDate != "" && startDate != "" && startDate > endDate){
document.getElementById("begindateerr").innerHTML=getErrorMsg(jsonData.LG0043);
    // document.getElementById('cbd').focus();
     isValidData = false;
     }
	else{
			document.getElementById("begindateerr").innerHTML="";
		}// susheel end
      if(diff >7){
    document.getElementById("begindateerr").innerHTML=getErrorMsg(jsonData.LG0044);
  //  document.getElementById('cbd').focus();
     isValidData = false;
    }                   
     else{
               //document.getElementById("begindateerr").innerHTML="";
              document.getElementById("systemerr").innerHTML="";
          }
     
if((req_typ == "O" || req_typ == "C" || req_typ == "R") && (system == "SORD-PTB" || system == "CABS/ACIS-PTB" || system == "SONAR-PTB")){
     //LG0267   Invalid System Code for this Mismatch Type.
document.getElementById("systemerr").innerHTML=getErrorMsg(jsonData.LG0267);
     document.getElementById('systemerr').focus();
     isValidData = false;
     }
     else if((req_typ == "P") &&  !(system == "SORD-PTB" || system == "CABS/ACIS-PTB" || system == "SONAR-PTB")){
     document.getElementById("systemerr").innerHTML=getErrorMsg(jsonData.LG0267);
          document.getElementById('systemerr').focus();
          isValidData = false;
     }
     else{
              document.getElementById("systemerr").innerHTML="";
          }

if((startDate != "") && (system == "SORD-PTB" ||system == "CABS/ACIS-PTB")){
isValidData = false;
document.getElementById("systemerr").innerHTML = getErrorMsg(jsonData.LG0267);
}
if(( myRadio.value== "O" && startDate!=null||startDate != "") && (system == "SOI-PTB/BCN")){
	//alert("test");
isValidData = false;
document.getElementById("vererr").innerHTML=getErrorMsg(jsonData.LG0267);

}
     //defect no susheel 68959 Start

     if(lsr_no == ""  && version != ""){
		    	 
		   document.getElementById("lsrerr").innerHTML=getErrorMsg(jsonData.LG0006,"LSR NO"); 
 		isValidData = false;
		   }
// 68959 End
      if(companyCode == "" && pon == "" && startDate == "" && endDate == "" && lsr_no == "" && version == "" && req_typ ==" " && sc == "" && system == " "){
    //"LSR No, PON, or Begin Date required."
    
  document.getElementById("systemerr").innerHTML=getErrorMsg(jsonData.LG0269);
    isValidData = false;
    }
    if(companyCode != "" && pon == "" && startDate == "" && endDate == "" && lsr_no == "" && version == "" && req_typ ==" " && sc == "" && system == " "){
    //PON or D/R Begin Date is required
    document.getElementById("systemerr").innerHTML=getErrorMsg(jsonData.LG0031);
    
     isValidData = false;
    }
/* if(companyCode == "" && pon != "" && startDate == "" && endDate == "" && lsr_no == "" && version == "" && req_typ ==" " && sc == " " && system == " "){
    //document.getElementById("begindateerr").innerHTML=getErrorMsg(jsonData.LG0031);
     
    //479
      // Need to call MQ BE to fetch records
    // document.getElementById("version").disabled = this.value != "";
     // document.getElementById("lsr_no").disabled = this.value != "";
       document.getElementById("req_typ").disabled = this.value != "";
      document.getElementById("sc").disabled = this.value != "";
      document.getElementById("system").disabled = this.value != "";
    
    }
     else if(companyCode == "" && pon == "" && startDate == "" && endDate == "" && lsr_no != "" && version == "" && req_typ ==" " && sc == " " && system == " "){
    
    
    // Need to call MQ BE to fetch records
    
     document.getElementById("company_code").disabled = this.value != "";
      document.getElementById("pon").disabled = this.value != "";
      document.getElementById("cbd").disabled = this.value != "";
      document.getElementById("ced").disabled = this.value != "";
//      document.getElementById("version").disabled = this.value != "";
      document.getElementById("req_typ").disabled = this.value != "";
      document.getElementById("sc").disabled = this.value != "";
      document.getElementById("system").disabled = this.value != "";
    }
     else if(companyCode != "" && pon != "" && startDate != "" && endDate != "" && lsr_no == "" && version == "" && req_typ !=" " && (sc != " " || system != " ")){
    document.getElementById("lsr_no").disabled = this.value != "";
    }
     else if(companyCode == "" && (pon != "" || startDate != "") && endDate == "" && lsr_no == "" && version == "" && req_typ ==" " && sc == " " && system == " "){
     //479
     document.getElementById("req_typ").disabled = this.value != "";
      document.getElementById("sc").disabled = this.value != "";
      document.getElementById("system").disabled = this.value != "";
    } else if(companyCode == "" && pon == "" && startDate == "" && endDate == "" && lsr_no == "" && version == "" && (req_typ !=" " || sc != " " || system != " ")){
    //479
    document.getElementById("pon").disabled = this.value != "";
    }*/
     if ((sc != "" || req_typ != " " || system != " ") && (companyCode == "" && pon == "" && startDate == "" && endDate == "" && lsr_no == "" && version == "") ){
    document.getElementById("version").disabled = this.value != "";
     document.getElementById("pon").disabled = this.value != "";
      document.getElementById("lsr_no").disabled = this.value != "";
      document.getElementById("begindateerr").innerHTML=getErrorMsg(jsonData.LG0006,"Begin Date");
     isValidData = false;
    }     
      if((companyCode == "" && pon == "" && startDate == "" && endDate == "" && lsr_no == "" && version == "") && ((req_typ !=" " && sc != "") || system != " ")){
    //483
     document.getElementById("begindateerr").innerHTML=getErrorMsg(jsonData.LG0006,"Begin Date");
     isValidData = false;
    }

if (($("#state").val() == '12 States') && (isValidData == true)) {

   //document.forms["restrictedMismatchData12states"].submit();
    callJavaController("restrictedMismatchFetch","F");
	//hideAllBtns();
	preIssueDisable();
}
if (($("#state").val() == '9 States') && (isValidData == true)) { 
 
//document.forms["restrictedMismatchData12states"].submit(); 
callJavaController("restrictedMismatchFetch","F"); 
//hideAllBtns(); 
preIssueDisable(); 
}

}



/*for unrestircted*/


   if (window.location.href.indexOf("/unrestrictedMismatch") > -1 ) {
	//alert("retrieve");
	
     var isValidData = true; 
     var companyCode = document.getElementById("company_code").value;

     var pon = document.getElementById("pon").value;

     var startDate = document.getElementById("cbd").value;

 
     var endDate = document.getElementById("ced").value;

     var lsr_no = document.getElementById("lsr_no").value;

     var version = document.getElementById("version").value;

     var request_type = document.getElementById("req_typ").value;

     var sc = document.getElementById("sc").value;

     var systemm = document.getElementById("systemm").value; 
	var ptb= document.getElementById("sampleptb").checked;
   var myRadio = document.getElementById("radio1");
   
  var date1= new  Date(startDate);

    var date2= new  Date(endDate);


 
var time_diff = date2.getTime()-date1.getTime();
     var diff = time_diff / (1000*60*60*24);
      var inp=document.getElementById("ced");

document.getElementById("enddateerr").innerHTML="";
inp.addEventListener("invalid", function(){
document.getElementById("enddateerr").innerHTML=getErrorMsg(jsonData.LG0009, "End Date","MM/DD/YYYY");
});
inp.checkValidity();

var bgnDte=document.getElementById("cbd");
//alert("bgnDte"+bgnDte);
document.getElementById("begindateerr").innerHTML="";
bgnDte.addEventListener("invalid", function(){
document.getElementById("begindateerr").innerHTML=getErrorMsg(jsonData.LG0009, "Begin Date","MM/DD/YYYY");
});

bgnDte.checkValidity();

   if(startDate == "" && endDate != ""){
document.getElementById("begindateerr").innerHTML=getErrorMsg(jsonData.LG0042);
   //  document.getElementById('cbd').focus();
     isValidData = false;
     }
     else if(endDate != "" && startDate != "" && startDate > endDate){
document.getElementById("begindateerr").innerHTML=getErrorMsg(jsonData.LG0043);
    // document.getElementById('cbd').focus();
     isValidData = false;
     }
	
      if(diff >7){
    document.getElementById("begindateerr").innerHTML=getErrorMsg(jsonData.LG0044);
  //  document.getElementById('cbd').focus();
     isValidData = false;
    }                   
     
if((myRadio.value== "O" && startDate!=null||startDate != "" ) && (systemm == "SORD-PTB")){
	//alert("test");
isValidData = false;
document.getElementById("vererr").innerHTML=getErrorMsg(jsonData.LG0267);

}

   


if(( systemm =="SORD-FOC/SOC/CANC") && ptb==true ){
	//alert("system"+system);
	document.getElementById("lsrerr").innerHTML=getErrorMsg(jsonData.LG0267);
	isValidData = false;
}


 
if(companyCode != "" && pon == "" && startDate == "" && endDate == "" && lsr_no == "" && version == "" && request_type ==" " && sc == " " && systemm == " "){
    //PON or D/R Begin Date is required
    document.getElementById("begindateerr").innerHTML=getErrorMsg(jsonData.LG0031);
    
     isValidData = false;
    }
    
   else if((request_type != " " && request_type != null)  && (sc != " " && sc != null)  && (startDate == "" || startDate == null) && (companyCode == "" || companyCode == null) && (pon == "" || pon == null) && (endDate == "" || endDate == null) && (lsr_no == "" || lsr_no == null) && (version == "" || version == null) && (systemm == " " || systemm == null)){  
    // alert("testing for retreive");
 document.getElementById("begindateerr").innerHTML=getErrorMsg(jsonData.LG0006,"Begin Date");
     document.getElementById("systemerr").innerHTML="";
     isValidData = false;
     }
 
  
 if((companyCode == "" && pon == "" && startDate == "" && endDate == "" && lsr_no == "" && version == "") && ((request_type !="" && sc != "") || systemm != " ")){
    //483
     document.getElementById("lsrerr").innerHTML=getErrorMsg(jsonData.LG0006,"Begin Date");
     isValidData = false;
    }
  
if((companyCode == "" && pon == "" && startDate == "" && endDate == "" && lsr_no == "" && version == "") && ((request_type !=" " && sc != " ") || systemm != " ")){
    
     document.getElementById("begindateerr").innerHTML=getErrorMsg(jsonData.LG0006,"Begin Date");
     isValidData = false;
    }

if (($("#state").val() == '9 States') && (isValidData == true)) { 
 
//alert("Form submission"); 
   	//document.forms["unrestrictedMismatchData12states"].submit(); 
   	callJavaController("unrestrictedMismatchFetch","F"); 
	//hideAllBtns(); 
	preIssueDisable(); 
}

if (($("#state").val() == '12 States') && (isValidData == true)) {

//alert("Form submission");
   	//document.forms["unrestrictedMismatchData12states"].submit();
   	callJavaController("unrestrictedMismatchFetch","F");
	//hideAllBtns();
	preIssueDisable();
}
}
 /*End of unrestircted*/ 

}


	function addFunction() {
	
		if (window.location.href.indexOf("/userProfile") > -1 || window.location.href.indexOf("/saveUserProfileForm") > -1 || window.location.href.indexOf("/retrieveUserProfileForm") > -1) {
		var parent = document.getElementById("User_id_second");
		var child = parent.children[1];
		child.disabled = '';
		document.getElementById('showErrBtn').disabled = '';
		
		var x = document.getElementById("userProfileDiv");
		x.style.display = "block";
		document.getElementById('multiregionalDiv').style.display = "none";
		document.getElementById('saveBtn').disabled = '';
		document.getElementById("userid_common_err").innerHTML = "";
		document.getElementById("userid_primary_err").innerHTML = "";
		document.getElementById("userid_err").innerHTML = "";
		document.getElementById("name_err").innerHTML = "";
		document.getElementById("telephone_err").innerHTML = "";
		document.getElementById("usertype_err").innerHTML = "";
		document.getElementById("salescode_err").innerHTML = "";
		document.getElementById("manager_err").innerHTML = "";
		document.getElementById("areamanager_err").innerHTML = "";
		}
	}

//changes done by Shalu to correct reset functionality
		function setReqId(reqId){
			window.selectedReqId=reqId;
			console.log("selectedReqId is -->",window.selectedReqId);
		}

//changes done by Shalu to correct reset functionality

function resetFunction() {
	console.log("in reset fun toolbar js");
		$('label.error').remove();

	if (window.location.href.indexOf("/userProfile") > -1 || window.location.href.indexOf("/saveUserProfileForm") > -1 || window.location.href.indexOf("/retrieveUserProfileForm") > -1) {
		var x = document.getElementById("userProfileDiv");
	//	x.style.display = "none";
	//	document.getElementById('multiregionalDiv').style.display = "none";
		document.getElementById("user_profile").reset();
		document.getElementById("userprofile1").reset();
		
		var sendingReq= "userProfile"+ "$" + "R" +"$"+localStorage.getItem("currentPageIndex");
		//var userID= document.getElementById("user_id2").value;
		var parent = document.getElementById("User_id_second");
		var child = parent.children[1];
		var option = child.value;
		//alert(option);
		
		if(option!=""){
			console.log("Remove Data From Model");
		var xhttp= new XMLHttpRequest();
		xhttp.open("POST", "userProfile", true);
		xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			console.log("success");
			window.location.href= "userProfile";
			}
		
		};
		getTokenForHttps(xhttp);
		xhttp.send(sendingReq);
		}
		
	}
	
	// Added by Sadasiva for reset functionality

if (window.location.href.indexOf("/issueProvider") > -1) {
document.getElementById("issueProviderForm").reset();
location.reload();
}
	
	console.log("resetFunction->",selectedReqId);
	
	if(window.location.href.indexOf("/workload") > -1){
	document.getElementById("workload").reset();
	location.reload();
	}
	if(window.location.href.indexOf("/unrestrictedMismatch") > -1){
	document.getElementById("unrestrictedMismatch").reset();
	location.reload();
	}

if (window.location.href.indexOf("/restrictedMismatch") > -1) {

document.getElementById("restricted").reset();
location.reload();
}

if (window.location.href.indexOf("/selectRequest") > -1) {

document.getElementById("request").reset();
//location.reload();
//Added by Hrushi - to reset data from backend
var sendingReq= "selectRequest"+ "$" + "R" +"$"+localStorage.getItem("currentPageIndex");
		var cc = document.getElementById("companycode").value;
		var lsrNo = document.getElementById("lsrno").value;
		
		
		if(cc!="" || lsrNo!=""){
			console.log("Remove Data From Model");
		var xhttp= new XMLHttpRequest();
		xhttp.open("POST", "selectRequest", true);
		xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			console.log("success");
			window.location.href= "selectRequest";
			}
		
		};
		getTokenForHttps(xhttp);
		xhttp.send(sendingReq);
		}
		else
		{
			location.reload();
		}
}


if (window.location.href.indexOf("/confirmedByDDESDD") > -1) {

document.getElementById("confirmedByDDESDD").reset();
location.reload();
}

//Reset function coded by Saurabh
	if (window.location.href.indexOf("/selectProvider") > -1) {
		document.getElementById("selectProvider").reset();
		document.getElementById("cbdErr").innerHTML = "";
		document.getElementById("losingCCErr").innerHTML = "";
	}

//Aprajita
	if(window.selectedReqId=="loss9"){
        console.log("selectedReqId 9 -->",window.selectedReqId);
        document.getElementById("history_dateErr").remove();
        $("form").trigger('reset');
        location.reload();
        }

//changes done by Shalu to correct reset functionality
	if(window.selectedReqId=="radio4"){
	console.log("selectedReqId 4 -->",window.selectedReqId);
	document.getElementById("fupRequest").reset();
	location.reload();
	}
//changes done by Shalu to correct reset functionality

// code by Rupa
	
if (window.location.href.indexOf("/enhancedSelReq") > -1) {
	console.log("selectedReqId 2 -->",window.selectedReqId);
	document.getElementById("enhancedSelReqForm").reset();
	//document.getElementById("enhancedSelReq").reset();
	//location.reload();
	//Added by Hrushi - to reset data from backend
	var sendingReq= "enhancedSelReq"+ "$" + "R" +"$"+localStorage.getItem("currentPageIndex");
		//var userID= document.getElementById("user_id2").value;
		var cc = document.getElementById("company_code").value;
		var ecckt = document.getElementById("ecckt").value;
		var ported_nbr = document.getElementById("ported_nbr").value;
		var nc= document.getElementById("nc").value;
		var ord= document.getElementById("ord").value;
		var ordl= document.getElementById("ordl").value;
		var npord = document.getElementById("npord").value;
		var tns = document.getElementById("tns").value;
		var otn = document.getElementById("otn").value;
		var beginDate = document.getElementById("date_received_begin_date").value;
		//alert(option);
		
		if(cc!="" || ecckt!="" || ported_nbr!="" || nc!="" || ord!="" || ordl!="" || npord!="" || tns!="" || otn!="" || beginDate!=""){
			console.log("Remove Data From Model");
		var xhttp= new XMLHttpRequest();
		xhttp.open("POST", "enhancedSelReq", true);
		xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			console.log("success");
			window.location.href= "enhancedSelReq";
			}
		
		};
		getTokenForHttps(xhttp);
		xhttp.send(sendingReq);
		}
		else
		{
			location.reload();
		}
	}



}

//////////yash changes for all buttons ///////////
function resubmit(){
	document.getElementById("sort_process").innerHTML = "Resubmit is still processing";
	document.getElementById('reSubmitBtn').style.display = 'none';
	var xhttp = new XMLHttpRequest();
	xhttp.responseType='text';
xhttp.onreadystatechange = function() {
if (this.readyState == 4 && this.status == 200) {
console.log("success");
document.getElementById("sort_process").innerHTML = xhttp.response;

setTimeout(function() {
		document.getElementById("sort_process").innerHTML =""	
			}, 15000);


}
};
xhttp.open("POST", "resubmit", true);
getTokenForHttps(xhttp);
xhttp.send(null);

	
}

function resend(){ 
	//document.getElementById('resendBtn').disabled = true; 
 
 
	//window.location.reload(); 
document.getElementById("sort_process").innerHTML = "Resend is still processing"; 
 
	//$("form[name='resend']").submit(); 
	//$("form[name='preIssue']").submit(); 
	var xhttp = new XMLHttpRequest(); 
xhttp.responseType='text'; 
xhttp.onreadystatechange = function() { 
if (this.readyState == 4 && this.status == 200) { 
console.log("success"); 
document.getElementById("sort_process").innerHTML = xhttp.response; 
setTimeout(function() { 
		document.getElementById("sort_process").innerHTML ="" 
			}, 15000); 
} 
}; 
xhttp.open("POST", "resend", true); 
getTokenForHttps(xhttp); 
xhttp.send(null); 
 
 
 
}

function justGo(){
	//document.getElementById('resendBtn').disabled = true;
	
	
	//window.location.reload();
document.getElementById("sort_process").innerHTML = "Just Go is still processing";

	//$("form[name='resend']").submit();
	//$("form[name='preIssue']").submit();
	var xhttp = new XMLHttpRequest();
xhttp.responseType='text';
xhttp.onreadystatechange = function() {
if (this.readyState == 4 && this.status == 200) {
console.log("success");
document.getElementById("sort_process").innerHTML = xhttp.response;
setTimeout(function() {
		document.getElementById("sort_process").innerHTML =""	
			}, 15000);


}
};
xhttp.open("POST", "justGo", true);
getTokenForHttps(xhttp);
xhttp.send(null);



}


 function showDiv() {
            div = document.getElementById('resenderror');
            div.style.display = "block";
        }
 
   
function disable(){
	//window.location.reload();
	document.getElementById('resendBtn').style.display = 'none';
	
	document.getElementById('noteBtn').style.display = 'none';
	
	document.getElementById('sortBtn').style.display = 'none';
	document.getElementById('rejectBtn').style.display = 'none';
	
	//document.getElementById('showErrBtn').disabled = true;
	//document.getElementById('issueBtn').disabled = true;
	
	
}

function preIssueDisable(){
	document.getElementById('resendBtn').style.display = 'none';
	
	document.getElementById('noteBtn').style.display = 'none';
	document.getElementById('reSubmitBtn').style.display = 'none';
	document.getElementById('sortBtn').style.display = 'none';
	document.getElementById('rejectBtn').style.display = 'none';
	document.getElementById('saveBtn').style.display = 'none';
	document.getElementById('preissue').style.display = 'none';
	document.getElementById('showErrBtn').style.display = 'none';
	document.getElementById('printBtn').style.display = 'none';
	document.getElementById('issueBtn').style.display = 'none';
	document.getElementById('copyRecBtn').style.display = 'none';
	document.getElementById('justGoBtn').style.display = 'none';
	document.getElementById('rejectBtn1').style.display = 'none';
	document.getElementById('validateCCBtn').style.display = 'none';
	document.getElementById('retrieveBtn').style.display = 'none';
	document.getElementById('resetBtn').style.display = 'none';
	document.getElementById('showErrBtn').style.display = 'none';
	document.getElementById('addBtn').style.display = 'none';
	document.getElementById('logOffBtn').style.display = 'none';
}

function preIssueFunction(){
	 //window.location.reload();
	//$("form[name='preIssue']").submit();
var xhttp = new XMLHttpRequest();
xhttp.responseType='text';
xhttp.onreadystatechange = function() {
if (this.readyState == 4 && this.status == 200) {
console.log(xhttp.responseText);
document.getElementById("sort_process").innerHTML = xhttp.response;

setTimeout(function() {
		document.getElementById("sort_process").innerHTML =""	
			}, 5000);


}


};




xhttp.open("POST", "preIssue", true);
getTokenForHttps(xhttp);
xhttp.send(null);

}





///////////////////**************** */


function saveFunction() {
		if (window.location.href.indexOf("/userProfile") > -1 || window.location.href.indexOf("/retrieveUserProfileForm") > -1 || window.location.href.indexOf("/saveUserProfileForm") > -1) {
		
		var isValidData = true;
		document.getElementById('saveBtn').disabled = '';
		document.getElementById('removeBtn').disabled = '';
		document.getElementById('showErrBtn').disabled = '';
        document.getElementById("userid_primary_err").innerHTML="";
		
		var typist= document.getElementById("typist").value;
		var parent = document.getElementById("User_id_second");
	 	var child = parent.children[1];
	 	var user_id = child.value;
		var name= document.getElementById("name").value;
		var telephone_number= document.getElementById("telephone_number").value;
		var user_type= document.getElementById("user_type").value;
	 	var sales_code= document.getElementById("sales_code").value;
	 	var manager= document.getElementById("manager").value;
	 	var area_manager= document.getElementById("area_manager").value;
		var userid_err= document.getElementById("userid_err").value;
	 	document.getElementById("salescode_err").innerHTML="";
	 	document.getElementById("manager_err").innerHTML="";
	 	document.getElementById("areamanager_err").innerHTML="";
	 	document.getElementById("userid_err").innerHTML="";
		document.getElementById("name_err").innerHTML="";
		document.getElementById("telephone_err").innerHTML="";
		document.getElementById("usertype_err").innerHTML="";
		document.getElementById("typistid_err").innerHTML="";
		
		var format =/[ `!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
		var twoString=/^([a-zA-Z]+), ([a-zA-Z]+)$/;
		
			if(user_id == "NA" || user_id == ""){
				document.getElementById("userid_err").innerHTML = "";
				document.getElementById("userid_err").innerHTML=getErrorMsg(jsonData.LG0006,"User ID");
				isValidData = false;
			}
			else if (format.test(user_id) == true) {
				document.getElementById("userid_err").innerHTML = "";
				document.getElementById("userid_err").innerHTML = getErrorMsg(jsonData.LG0065, "User ID");
				isValidData = false;
			}
			else if (user_id.length < 4) {
				document.getElementById("userid_err").innerHTML = "";
				document.getElementById("userid_err").innerHTML = getErrorMsg(jsonData.LG0007,"User ID","4 to 7");
				isValidData = false;	
			}
			else{
				document.getElementById("userid_err").innerHTML = "";
			}
			
			if(name == "NA" || name == ""){
				document.getElementById("name_err").innerHTML = "";
				document.getElementById("name_err").innerHTML=getErrorMsg(jsonData.LG0006,"Name");
				isValidData = false;
			}
			else if(!twoString.test(name)){
				document.getElementById("name_err").innerHTML = "";
				document.getElementById("name_err").innerHTML = getErrorMsg(jsonData.LG0009,"Name","Lastname, Firstname");
				isValidData = false;
			}
			else{
				document.getElementById("name_err").innerHTML = "";
			}
			
			if(telephone_number == "NA" || telephone_number == ""){
				document.getElementById("telephone_err").innerHTML = "";
				document.getElementById("telephone_err").innerHTML=getErrorMsg(jsonData.LG0006,"Telephone Number");
				isValidData = false;
			}
			else{
				document.getElementById("telephone_err").innerHTML = "";
			}
			
			if(user_type == "NA" || user_type == ""){
				document.getElementById("usertype_err").innerHTML = "";
				document.getElementById("usertype_err").innerHTML=getErrorMsg(jsonData.LG0006,"User Type");
				isValidData = false;
			}
			else{
				document.getElementById("usertype_err").innerHTML = "";
			}
		
		  		if((user_type=="BR" || user_type=="SC" || user_type=="LR" || user_type=="LM" || user_type=="AM" || user_type=="PR") && (sales_code == "" || sales_code == null)){
					  document.getElementById("salescode_err").innerHTML=getErrorMsg(jsonData.LG0006,"Sales Code");
					  document.getElementById('sales_code').focus();
					  isValidData = false;
				  }
				  else{
						document.getElementById("salescode_err").innerHTML="";
					}
				  
				  if((user_type=="BR" || user_type=="SC" || user_type=="LR" || user_type=="PR") && (manager == "" || manager == null)){
					  document.getElementById("manager_err").innerHTML=getErrorMsg(jsonData.LG0006,"Manager");
					  document.getElementById('manager').focus();
					  isValidData = false;
				  }
				  else{
						document.getElementById("manager_err").innerHTML="";
					}
				  
				if((user_type=="BR" || user_type=="SC" || user_type=="LR" || user_type=="PR" || user_type=="LM") && (area_manager == "" || area_manager == null)){
					 document.getElementById("areamanager_err").innerHTML=getErrorMsg(jsonData.LG0006,"Area Manager");
					 document.getElementById("area_manager").disabled='';
					 document.getElementById('area_manager').focus();
					 isValidData = false;
				}
				else{
					document.getElementById("areamanager_err").innerHTML="";
				}
				
				if(user_type=="LM"){
				    document.getElementById("manager").innerHTML = "";
					document.getElementById("manager").disabled='true';
					document.getElementById("area_manager").disabled='';
				}
				else{
					document.getElementById("manager").disabled='';
				}
				if(user_type=="SA"|| user_type=="RO" || user_type=="AM" || user_type=="HD" || user_type=="TS"){
					document.getElementById("manager").disabled='true';
					document.getElementById("area_manager").disabled='true';
				}
				
			
			if((user_type=="BR" || user_type=="SC" || user_type=="LR" || user_type=="LM" || user_type=="AM" || user_type=="PR") && (sales_code == "" || sales_code == null)){
				 document.getElementById("salescode_err").innerHTML="";
				 document.getElementById("salescode_err").innerHTML=getErrorMsg(jsonData.LG0006,"Sales Code");
				 document.getElementById('sales_code').focus();
				 isValidData = false;
			}	
			else if((user_type=="BR" || user_type=="SC" || user_type=="LR" || user_type=="LM" || user_type=="AM" || user_type=="PR") && (format.test(sales_code) == true)){
				document.getElementById("salescode_err").innerHTML="";
				document.getElementById("salescode_err").innerHTML = getErrorMsg(jsonData.LG0065,"Sales Code");
				isValidData = false; 
			}
			else if((user_type=="BR" || user_type=="SC" || user_type=="LR" || user_type=="PR") && (manager == "" || manager == null)){
				 document.getElementById("manager_err").innerHTML="";
				 document.getElementById("manager_err").innerHTML=getErrorMsg(jsonData.LG0006,"Manager");
				 document.getElementById('manager').focus();
				 isValidData = false;
			}
			else if((user_type=="BR" || user_type=="SC" || user_type=="LR" || user_type=="PR" || user_type=="LM") && (area_manager == "" || area_manager == null)){
				 document.getElementById("areamanager_err").innerHTML="";
				 document.getElementById("areamanager_err").innerHTML=getErrorMsg(jsonData.LG0006,"Area Manager");
				 document.getElementById("area_manager").disabled='';
				 document.getElementById('area_manager').focus();
				 isValidData = false;
			}
			else{
				 document.getElementById("manager_err").innerHTML="";
				 document.getElementById("areamanager_err").innerHTML="";
				 document.getElementById("salescode_err").innerHTML="";
			}
			
			if((user_type=="SC" || user_type=="LR") && (typist == "" || typist == null)){
				document.getElementById("typistid_err").innerHTML=getErrorMsg(jsonData.LG0006,"Typist Id");
				document.getElementById('typist').focus();
				isValidData = false;
			} 
			else if ((user_type=="SC" || user_type=="LR") && (format.test(typist) == true)) {
				document.getElementById("typistid_err").innerHTML = getErrorMsg(jsonData.LG0065,"Typist Id");
				isValidData = false;
			}
			else {
				document.getElementById("typistid_err").innerHTML="";
			}
			
			if ($("#state").val()== '9 States' && isValidData == true) {
			//document.forms["userprofile1"].submit();
			callJavaController("userProfileSave","S");
			//hideAllBtns();
			preIssueDisable();
		}
		if ($("#state").val() == '12 States' && isValidData == true) {
			//document.forms["userprofile1"].submit();
			callJavaController("userProfileSave","S");
			//hideAllBtns();
			preIssueDisable();
		}
	}else
	{
		
		if(localStorage.getItem("name") == "follow_up")
		{
			$("form[name='follow_Up12']").submit();	
			
		}
		if(localStorage.getItem("name") == "updateOrderNumber")
		{
			var isValidData= true;
			var ordList = document.getElementsByClassName("updateOrd");
	
			if (isValidData == true) {
				if (doesArrayHaveDuplicates(ordList) == true) {
					document.getElementById("uon_err").innerHTML = getErrorMsg(jsonData.LG0179);
					isValidData = false;
				}
				else {
					document.getElementById("uon_err").innerHTML = "";
				}
			}
			
			if(isValidData == true){
				$("form[name='updateOrderNumber']").submit();	
			}
			
		}
		if(localStorage.getItem("name") == "editEcckt")
		{
			
			var input="";
			var n=1;
			var cells = document.querySelectorAll('.editEcckt');
			cells.forEach(function(cell) {
				
				if(cell.value != " ")
				{
					var fieldValue= "";
					fieldValue= cell.value;
					input=input+ " "+fieldValue.trim();
				}
				else
				{
					input=input+ " #,";
					
				}
				if(n%3 == 0)
				{
					input= input+ "$,";
				}
				n=n+1;
				
				//console.log(cell.value+ "*");
				
			});
			console.log("Final String Input: "+input);
			var xhttp = new XMLHttpRequest();
			xhttp.open("POST", "editEcckt", true);
           	getTokenForHttps(xhttp);
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					location.reload();
				}

			};
			xhttp.send(input);
			/*setTimeout(function() {
			window.location.href = "treeViewDisplay";
			}, 5000);*/
			
		}
	
	}
	

	
		
}


function logoffFunction(){

	if (window.location.href.indexOf("/userProfile") > -1) {
		
		
		var loggedInUserId = document.getElementById("logedInUser").value;
		
		var parent = document.getElementById("userIdDiv");
	 	var child = parent.children[1];
	 	var user_id = child.value;
	
		//alert(user_id);
		//alert(loggedInUserId);
		if(loggedInUserId === user_id){
			
			document.getElementById("userid_common_err").innerHTML=getErrorMsg(jsonData.LG0064);
		}
		else{
			callJavaController("userProfileLogoff","L");
		}

	}
}

function validateCCFunction() {
		if (window.location.href.indexOf("/issueProvider") > -1) {
		
		if ($("#state").val() == '9 States') {
			hideAllBtns();
			
		}
		
		
		if ($("#state").val() == '12 States') {
			hideAllBtns();
		var ls_cc = document.getElementById("losing_cc").value;
		var lsrNumber = document.getElementById("lsr_no").value;
		var gainingCC = document.getElementById("gaining_cc").value;
		
		var ls_len = ls_cc.length;
		var format =/[ `!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
		var isValidData = true;
		
		// Losing CC Validation 
		
		if (ls_cc == "") {
			document.getElementById("losingCCErr").innerHTML = "";
			document.getElementById("losingCCErr").innerHTML = getErrorMsg(JSONData.LG0006, "Losing CC");
		
		}
		else if (ls_cc.length < 4) {
			document.getElementById("losingCCErr").innerHTML = "";
			document.getElementById("losingCCErr").innerHTML = getErrorMsg(JSONData.LG0007, "Losing CC", 4);
			
			
		}
		else if (format.test(ls_cc) == true) {
			document.getElementById("losingCCErr").innerHTML = "";
			document.getElementById("losingCCErr").innerHTML = getErrorMsg(JSONData.LG0065, "Losing CC");
			
		}  
		else {
			document.getElementById("lsrNoErr").innerHTML = "";
			document.getElementById("losingCCErr").innerHTML = "";
			
		}
		
		// LASR Number Validation 
		if (ls_cc == "" && lsrNumber != ""){
			document.getElementById("losingCCErr").innerHTML = "";
			document.getElementById("losingCCErr").innerHTML = getErrorMsg(JSONData.LG0006, "Losing CC");
			}else if(ls_cc != "" && ls_cc.length == 4 && format.test(ls_cc) == false && lsrNumber == ""){
			document.getElementById("lsrNoErr").innerHTML = "";
			document.getElementById("lsrNoErr").innerHTML = getErrorMsg(JSONData.LG0006, "LSR NO");
		}
		else if (lsrNumber != "" && lsrNumber.length < 14) {
			document.getElementById("lsrNoErr").innerHTML = "";
			document.getElementById("lsrNoErr").innerHTML = getErrorMsg(JSONData.LG0007, "LSR NO", 14);
		}
		else if (lsrNumber != "" && format.test(lsrNumber) == true) {
			document.getElementById("lsrNoErr").innerHTML = "";
			document.getElementById("lsrNoErr").innerHTML = getErrorMsg(JSONData.LG0065, "LSR NO");
		}
		else {
			document.getElementById("lsrNoErr").innerHTML = "";
		}
		if(ls_cc != "" && ls_cc.length == 4 && format.test(ls_cc) == false && lsrNumber != "" && lsrNumber.length == 14 && format.test(lsrNumber) == false  ){
			
			callJavaController("issueProviderFetch","F");
			preIssueDisable();
		}
		
			var inp = document.getElementById("cvd");
			document.getElementById("cvdErr").innerHTML = "";
			inp.addEventListener("invalid", function() {
				document.getElementById("cvdErr").innerHTML = getErrorMsg(JSONData.LG0009, "CVD", "mm/dd/yyyy");
			});
			inp.checkValidity();

		}
		
	}
	
	if (localStorage.getItem("name") == "completionProviderWithLoss") {
		
		var form = document.getElementById("complWithLossMain")
    	form.action = "validateccForComplWithLoss";
		form.submit();
	}
}

//supriya
function showErrorFunction(){

document.getElementById("userid_common_err").innerHTML = "";
}

function setSelectedNode(selectedNodeName)
{
	console.log(selectedNodeName);
	localStorage.setItem("name",selectedNodeName);
	
	if(selectedNodeName=="completionProviderWithLoss")
	{
		document.getElementById('validateCCBtn').style.display = 'inline';
	}
	else
	{
		document.getElementById('validateCCBtn').style.display = 'none';
	}
	
	if(selectedNodeName=="follow_up" || selectedNodeName=="follow_up9"){
		
		 
document.getElementById('showErrBtn').style.display = 'none'; 
 
document.getElementById('issueBtn').style.display = 'none'; 
 
 
document.getElementById('copyRecBtn').style.display = 'none'; 
//document.getElementById('rejectBtn').style.display = 'none'; 
document.getElementById('noteBtn').style.display = 'none'; 
document.getElementById('sortBtn').style.display = 'none'; 
document.getElementById('reSubmitBtn').style.display = 'none'; 
//document.getElementById('preissue').style.display = 'none'; 
document.getElementById('justGoBtn').style.display = 'none'; 
document.getElementById('resendBtn').style.display = 'none'; 
document.getElementById('rejectBtn1').style.display = 'none'; 		
		
	}
	else if (selectedNodeName == "sort_errors") {


		document.getElementById('saveBtn').style.display = 'none';
		document.getElementById('issueBtn').style.display = 'inline';
		document.getElementById('printBtn').style.display = 'inline';
		document.getElementById('copyRecBtn').style.display = 'none';
		document.getElementById('showErrBtn').style.display = 'none';
		document.getElementById('rejectBtn').style.display = 'inline';
		document.getElementById('noteBtn').style.display = 'inline';

	}
	else if(selectedNodeName == "log6_confirmation12" || selectedNodeName == "ConfirmationView_ABC9"){
		preIssueDisable();
	}
	
else{
	
	document.getElementById('showErrBtn').style.display = 'inline'; 
 //document.getElementById('rejectBtn').style.display = 'none'; 
document.getElementById('issueBtn').style.display = 'inline'; 
 
 
document.getElementById('copyRecBtn').style.display = 'inline'; 
document.getElementById('rejectBtn1').style.display = 'inline'; 
document.getElementById('noteBtn').style.display = 'inline'; 
//document.getElementById('sortBtn').style.display = 'inline'; 
//document.getElementById('reSubmitBtn').style.display = 'inline'; 
//document.getElementById('preissue').style.display = 'none'; 
//document.getElementById('justGoBtn').style.display = 'inline'; 
//document.getElementById('resendBtn').style.display = 'inline'; 
}
	
treeviewButtonsDisable();	
	
}

// bharti code
// bharti code

//Right Click logic
//Right Click logic

function rightClick(e) {
	e.preventDefault();
}
var myForm = "";

function onRightclickTable(formId) {
	var e = window.event;
	myForm = "";
	myForm = formId;

	
  if (myForm == "rightClickMenu") {
		var menu = document.getElementById("contextMenu");
		menu.style.display = 'block';
		menu.style.left = e.pageX + "px";
		menu.style.top = e.pageY + "px";
		
	}


}

function onRightclickTable1(formId) {
	var e = window.event;
	myForm = "";
	myForm = formId;

	
  if (myForm == "rightClickMenu1") {
		var menu = document.getElementById("contextMenu1");
		menu.style.display = 'block';
		menu.style.left = e.pageX + "px";
		menu.style.top = e.pageY + "px";
		
	}


}


function sortAscending() {



	var list1 = $("#select1 option:selected").text();
	var list2 = $("#select2 option:selected").text();
	var list3 = $("#select3 option:selected").text();

	let inputs1 = document.getElementById('check01');
	let inputs2 = document.getElementById('check02');
	let inputs3 = document.getElementById('check03');


	var col1index = $("#select1 option:selected").index() - 1;
	var col2index = $("#select2 option:selected").index() - 1;
	var col3index = $("#select3 option:selected").index() - 1;


	//location.reload(true); 

	var $tbody = $('#enhancedseltable tbody');

	if ((inputs1.checked == true) && (list1 != null) && ((inputs2.checked != true) && (list2 === '')) && ((inputs3.checked != true) && (list3 === ''))) {
		sortUsingOneColumn(col1index)
	}
	else
		if ((inputs1.checked == false) && (list1 != null) && ((inputs2.checked != true) && (list2 === '')) && ((inputs3.checked != true) && (list3 === ''))) {
			sortDescUsingOneColumn(col1index)
		}
		else
			if ((inputs2.checked == true) && (list2 != null) && (inputs1.checked != true) && (list1 === '') && (inputs3.checked != true) && (list3 === '')) {
				sortUsingOneColumn(col2index)

			}
			else
				if ((inputs2.checked == false) && (list2 != null) && (inputs1.checked != true) && (list1 === '') && (inputs3.checked != true) && (list3 === '')) {
					sortDescUsingOneColumn(col2index)

				}
				else
					if ((inputs3.checked == true) && (list3 != null) && (inputs1.checked != true) && (list1 === '') && (inputs2.checked != true) && (list2 === '')) {
						sortUsingOneColumn(col3index)
					}
					else
						if ((inputs3.checked == false) && (list3 != null) && (inputs1.checked != true) && (list1 === '') && (inputs2.checked != true) && (list2 === '')) {
							sortDescUsingOneColumn(col3index)
						}
						else
							if ((inputs1.checked == true) && (list1 != null) && (inputs2.checked == true) && (list2 != null) && (inputs3.checked != true) && (list3 === '')) {
								
								sortUsingTwoColumn(col1index, col2index);
							}
							else
								if ((inputs1.checked == false) && (list1 != null) && (inputs2.checked == false) && (list2 != null) && (inputs3.checked != true) && (list3 === '')) {
									
									sortDescUsingTwoColumn(col1index, col2index);
								}

								else
									if ((inputs1.checked == false) && (list1 != null) && (inputs2.checked == true) && (list2 != null) && (inputs3.checked != true) && (list3 === '')) {
									
										sortDesc1UsingTwoColumn(col1index, col2index);
									}
									else
										if ((inputs1.checked == true) && (list1 != null) && (inputs2.checked == false) && (list2 != null) && (inputs3.checked != true) && (list3 === '')) {
											
											sortDesc2UsingTwoColumn(col1index, col2index);
										}
										else
											if ((inputs1.checked == true) && (list1 != null) && (inputs2.checked == true) && (list2 != null) && (inputs3.checked == true) && (list3 != null)) {
												
												sortUsingThreeColumn(col1index, col2index, col3index);
											}
											else
												if ((inputs1.checked == false) && (list1 != null) && (inputs2.checked == false) && (list2 != null) && (inputs3.checked == false) && (list3 != null)) {
													
													sortUsingDescThreeColumn(col1index, col2index, col3index);
												}

												else
													if ((inputs1.checked == true) && (list1 != null) && (inputs2.checked == false) && (list2 != null) && (inputs3.checked == false) && (list3 != null)) {
														
														sortUsingDesc1ThreeColumn(col1index, col2index, col3index);
													}
													else
														if ((inputs1.checked == false) && (list1 != null) && (inputs2.checked == true) && (list2 != null) && (inputs3.checked == false) && (list3 != null)) {
														
															sortUsingDesc2ThreeColumn(col1index, col2index, col3index);
														}
														else
															if ((inputs1.checked == false) && (list1 != null) && (inputs2.checked == false) && (list2 != null) && (inputs3.checked == true) && (list3 != null)) {
																
																sortUsingDesc3ThreeColumn(col1index, col2index, col3index);
															}
															else
																if ((inputs1.checked == true) && (list1 != null) && (inputs2.checked == true) && (list2 != null) && (inputs3.checked == false) && (list3 != null)) {
																	
																	sortUsingDesc12ThreeColumn(col1index, col2index, col3index);
																}
																else
																	if ((inputs1.checked == true) && (list1 != null) && (inputs2.checked == false) && (list2 != null) && (inputs3.checked == true) && (list3 != null)) {
																		
																		sortUsingDesc13ThreeColumn(col1index, col2index, col3index);
																	}
																	else
																		if ((inputs1.checked == false) && (list1 != null) && (inputs2.checked == true) && (list2 != null) && (inputs3.checked == true) && (list3 != null)) {
																			
																			sortUsingDesc23ThreeColumn(col1index, col2index, col3index);
																		}


	function sortUsingOneColumn(index1) {
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text(); // can replace 1 with the column you want to sort on
			var tdb = $(b).find('td:eq(' + index1 + ')').text(); // this will sort on the second column

			return tda > tdb ? 1 : tda < tdb ? -1 : 0;

		}).appendTo($tbody);
	}
	function sortDescUsingOneColumn(index1) {
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text(); // can replace 1 with the column you want to sort on
			var tdb = $(b).find('td:eq(' + index1 + ')').text(); // this will sort on the second column

			return tda < tdb ? 1 : tda > tdb ? -1 : 0;

		}).appendTo($tbody);
	}
	function sortUsingTwoColumn(index1, index2) {
		//Using First Column
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + col1index + ')').text();
			var tdb = $(b).find('td:eq(' + col1index + ')').text();

			return tda > tdb ? 1 : tda < tdb ? -1 : 0;
		}).appendTo($tbody);

		//Using Second Column 
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			var tda1 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index2 + ')').text();
			if (tda == tdb) {
				return tda1 > tdb1 ? 1 : tda1 < tdb1 ? -1 : 0;
			}
		}).appendTo($tbody);
	}

	function sortDescUsingTwoColumn(index1, index2) {
		//Using First Column
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + col1index + ')').text();
			var tdb = $(b).find('td:eq(' + col1index + ')').text();

			return tda < tdb ? 1 : tda > tdb ? -1 : 0;
		}).appendTo($tbody);

		//Using Second Column 
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			var tda1 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index2 + ')').text();
			if (tda == tdb) {
				return tda1 < tdb1 ? 1 : tda1 > tdb1 ? -1 : 0;
			}
		}).appendTo($tbody);
	}
	function sortDesc1UsingTwoColumn(index1, index2) {
		//Using First Column
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + col1index + ')').text();
			var tdb = $(b).find('td:eq(' + col1index + ')').text();

			return tda < tdb ? 1 : tda > tdb ? -1 : 0;
		}).appendTo($tbody);

		//Using Second Column 
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			var tda1 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index2 + ')').text();
			if (tda == tdb) {
				return tda1 > tdb1 ? 1 : tda1 < tdb1 ? -1 : 0;
			}
		}).appendTo($tbody);
	}
	function sortDesc2UsingTwoColumn(index1, index2) {
		//Using First Column
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + col1index + ')').text();
			var tdb = $(b).find('td:eq(' + col1index + ')').text();

			return tda > tdb ? 1 : tda < tdb ? -1 : 0;
		}).appendTo($tbody);

		//Using Second Column 
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			var tda1 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index2 + ')').text();
			if (tda == tdb) {
				return tda1 < tdb1 ? 1 : tda1 > tdb1 ? -1 : 0;
			}
		}).appendTo($tbody);
	}

	function sortUsingThreeColumn(index1, index2, index3) {
		//Using First Column
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			return tda > tdb ? 1 : tda < tdb ? -1 : 0;
		}).appendTo($tbody);

		//Using Second Column 
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			var tda1 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index2 + ')').text();
			if (tda == tdb) {
				return tda1 > tdb1 ? 1 : tda1 < tdb1 ? -1 : 0;
			}
		}).appendTo($tbody);

		//Using Third Colmn
		$tbody.find('tr').sort(function(a, b) {
			var tda1 = $(a).find('td:eq(' + index1 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index1 + ')').text();

			var tda2 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb2 = $(b).find('td:eq(' + index2 + ')').text();

			var tda3 = $(a).find('td:eq(' + index3 + ')').text();
			var tdb3 = $(b).find('td:eq(' + index3 + ')').text();

			if (tda1 == tdb1) {
				if (tda2 == tdb2) {
					return tda3 > tdb3 ? 1 : tda3 < tdb3 ? -1 : 0;
				}
			}
		}).appendTo($tbody);





	}
	function sortUsingDescThreeColumn(index1, index2, index3) {
		//Using First Column
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			return tda < tdb ? 1 : tda > tdb ? -1 : 0;
		}).appendTo($tbody);

		//Using Second Column 
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			var tda1 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index2 + ')').text();
			if (tda == tdb) {
				return tda1 < tdb1 ? 1 : tda1 > tdb1 ? -1 : 0;
			}
		}).appendTo($tbody);

		//Using Third Colmn
		$tbody.find('tr').sort(function(a, b) {
			var tda1 = $(a).find('td:eq(' + index1 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index1 + ')').text();

			var tda2 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb2 = $(b).find('td:eq(' + index2 + ')').text();

			var tda3 = $(a).find('td:eq(' + index3 + ')').text();
			var tdb3 = $(b).find('td:eq(' + index3 + ')').text();

			if (tda1 == tdb1) {
				if (tda2 == tdb2) {
					return tda3 < tdb3 ? 1 : tda3 > tdb3 ? -1 : 0;
				}
			}
		}).appendTo($tbody);





	}
	function sortUsingDesc1ThreeColumn(index1, index2, index3) {
		//Using First Column
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			return tda > tdb ? 1 : tda < tdb ? -1 : 0;
		}).appendTo($tbody);

		//Using Second Column 
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			var tda1 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index2 + ')').text();
			if (tda == tdb) {
				return tda1 < tdb1 ? 1 : tda1 > tdb1 ? -1 : 0;
			}
		}).appendTo($tbody);

		//Using Third Colmn
		$tbody.find('tr').sort(function(a, b) {
			var tda1 = $(a).find('td:eq(' + index1 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index1 + ')').text();

			var tda2 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb2 = $(b).find('td:eq(' + index2 + ')').text();

			var tda3 = $(a).find('td:eq(' + index3 + ')').text();
			var tdb3 = $(b).find('td:eq(' + index3 + ')').text();

			if (tda1 == tdb1) {
				if (tda2 == tdb2) {
					return tda3 < tdb3 ? 1 : tda3 > tdb3 ? -1 : 0;
				}
			}
		}).appendTo($tbody);
	}
	function sortUsingDesc2ThreeColumn(index1, index2, index3) {
		//Using First Column
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			return tda < tdb ? 1 : tda > tdb ? -1 : 0;
		}).appendTo($tbody);

		//Using Second Column 
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			var tda1 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index2 + ')').text();
			if (tda == tdb) {
				return tda1 > tdb1 ? 1 : tda1 < tdb1 ? -1 : 0;
			}
		}).appendTo($tbody);

		//Using Third Colmn
		$tbody.find('tr').sort(function(a, b) {
			var tda1 = $(a).find('td:eq(' + index1 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index1 + ')').text();

			var tda2 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb2 = $(b).find('td:eq(' + index2 + ')').text();

			var tda3 = $(a).find('td:eq(' + index3 + ')').text();
			var tdb3 = $(b).find('td:eq(' + index3 + ')').text();

			if (tda1 == tdb1) {
				if (tda2 == tdb2) {
					return tda3 < tdb3 ? 1 : tda3 > tdb3 ? -1 : 0;
				}
			}
		}).appendTo($tbody);
	}
	function sortUsingDesc3ThreeColumn(index1, index2, index3) {
		//Using First Column
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			return tda < tdb ? 1 : tda > tdb ? -1 : 0;
		}).appendTo($tbody);

		//Using Second Column 
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			var tda1 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index2 + ')').text();
			if (tda == tdb) {
				return tda1 < tdb1 ? 1 : tda1 > tdb1 ? -1 : 0;
			}
		}).appendTo($tbody);

		//Using Third Colmn
		$tbody.find('tr').sort(function(a, b) {
			var tda1 = $(a).find('td:eq(' + index1 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index1 + ')').text();

			var tda2 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb2 = $(b).find('td:eq(' + index2 + ')').text();

			var tda3 = $(a).find('td:eq(' + index3 + ')').text();
			var tdb3 = $(b).find('td:eq(' + index3 + ')').text();

			if (tda1 == tdb1) {
				if (tda2 == tdb2) {
					return tda3 > tdb3 ? 1 : tda3 < tdb3 ? -1 : 0;
				}
			}
		}).appendTo($tbody);
	}
	function sortUsingDesc13ThreeColumn(index1, index2, index3) {
		//Using First Column
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			return tda > tdb ? 1 : tda < tdb ? -1 : 0;
		}).appendTo($tbody);

		//Using Second Column 
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			var tda1 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index2 + ')').text();
			if (tda == tdb) {
				return tda1 < tdb1 ? 1 : tda1 > tdb1 ? -1 : 0;
			}
		}).appendTo($tbody);

		//Using Third Colmn
		$tbody.find('tr').sort(function(a, b) {
			var tda1 = $(a).find('td:eq(' + index1 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index1 + ')').text();

			var tda2 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb2 = $(b).find('td:eq(' + index2 + ')').text();

			var tda3 = $(a).find('td:eq(' + index3 + ')').text();
			var tdb3 = $(b).find('td:eq(' + index3 + ')').text();

			if (tda1 == tdb1) {
				if (tda2 == tdb2) {
					return tda3 > tdb3 ? 1 : tda3 < tdb3 ? -1 : 0;
				}
			}
		}).appendTo($tbody);
	}
	function sortUsingDesc12ThreeColumn(index1, index2, index3) {
		//Using First Column
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			return tda > tdb ? 1 : tda < tdb ? -1 : 0;
		}).appendTo($tbody);

		//Using Second Column 
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			var tda1 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index2 + ')').text();
			if (tda == tdb) {
				return tda1 > tdb1 ? 1 : tda1 < tdb1 ? -1 : 0;
			}
		}).appendTo($tbody);

		//Using Third Colmn
		$tbody.find('tr').sort(function(a, b) {
			var tda1 = $(a).find('td:eq(' + index1 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index1 + ')').text();

			var tda2 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb2 = $(b).find('td:eq(' + index2 + ')').text();

			var tda3 = $(a).find('td:eq(' + index3 + ')').text();
			var tdb3 = $(b).find('td:eq(' + index3 + ')').text();

			if (tda1 == tdb1) {
				if (tda2 == tdb2) {
					return tda3 < tdb3 ? 1 : tda3 > tdb3 ? -1 : 0;
				}
			}
		}).appendTo($tbody);
	}
	function sortUsingDesc23ThreeColumn(index1, index2, index3) {
		//Using First Column
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			return tda < tdb ? 1 : tda > tdb ? -1 : 0;
		}).appendTo($tbody);

		//Using Second Column 
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			var tda1 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index2 + ')').text();
			if (tda == tdb) {
				return tda1 > tdb1 ? 1 : tda1 < tdb1 ? -1 : 0;
			}
		}).appendTo($tbody);

		//Using Third Colmn
		$tbody.find('tr').sort(function(a, b) {
			var tda1 = $(a).find('td:eq(' + index1 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index1 + ')').text();

			var tda2 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb2 = $(b).find('td:eq(' + index2 + ')').text();

			var tda3 = $(a).find('td:eq(' + index3 + ')').text();
			var tdb3 = $(b).find('td:eq(' + index3 + ')').text();

			if (tda1 == tdb1) {
				if (tda2 == tdb2) {
					return tda3 > tdb3 ? 1 : tda3 < tdb3 ? -1 : 0;
				}
			}
		}).appendTo($tbody);
	}

}


function filterData() {


	var column1 = $("#filterColumn1 option:selected").val();
	var operator1 = $("#filterOperator1 option:selected").val();
	var value1 = $("#filterValue1").val().toUpperCase();

	var column2 = $("#filterColumn2 option:selected").val();
	var operator2 = $("#filterOperator2 option:selected").val();
	var value2 = $("#filterValue2").val().toUpperCase();

	var column3 = $("#filterColumn3 option:selected").val();
	var operator3 = $("#filterOperator3 option:selected").val();
	var value3 = $("#filterValue3").val().toUpperCase();


	var tableLength = $("#enhancedseltable tr").length;


	var tableTr1 = $("#enhancedseltable tr");




	var x = $("#filterColumn1 option:selected").index() - 1;

	var filter = [];


	if (operator1 == "equals") {
		equals(x, value1);




	}
	else
		if (operator1 == "doesnt_equal") {
			doesntEquals(x, value1);
		}
		else
			if (operator1 == "begins_with") {
				beginsWith(x, value1);
			}
			else
				if (operator1 == "end_with") {
					endsWith(x, value1)
				}
				else
					if (operator1 == "contains") {
						contains(x, value1);
					}
	var y = $("#filterColumn2 option:selected").index() - 1;

	var secondFilter = [];
	if (operator2 == "equals") {
		equals(y, value2);

	}
	else
		if (operator2 == "doesnt_equal") {
			doesntEquals(y, value2);
		}
		else
			if (operator2 == "begins_with") {
				beginsWith(y, value2);
			}
			else
				if (operator2 == "end_with") {
					endsWith(y, value2)
				}
				else
					if (operator2 == "contains") {
						contains(y, value2);
					}

	var z = $("#filterColumn3 option:selected").index() - 1;


	if (operator3 == "equals") {
		equals(z, value3);
	}
	else
		if (operator3 == "doesnt_equal") {
			doesntEquals(z, value3);
		}
		else
			if (operator3 == "begins_with") {
				beginsWith(z, value3);
			}
			else
				if (operator3 == "end_with") {
					endsWith(z, value3)
				}
				else
					if (operator3 == "contains") {
						contains(z, value3);
					}

	function equals(x, value) {
		for (i = 1; i < tableLength; i++) {
			if (tableTr1[i].cells[x].textContent == value)
				tableTr1[i].style.display = "";
			else {
				// tableTr1[i].style.display="none";  
				tableTr1[i].remove();
			}
		}

	}
	function doesntEquals(x, value) {
		for (i = 1; i < tableLength; i++) {
			if (tableTr1[i].cells[x].textContent != value)
				tableTr1[i].style.display = "";
			else
				tableTr1[i].remove();
		}
	}
	function beginsWith(x, value) {
		for (i = 1; i < tableLength; i++) {
			if ((tableTr1[i].cells[x].textContent).startsWith(value))
				tableTr1[i].style.display = "";
			else
				tableTr1[i].remove();
		}
	}
	function endsWith(x, value) {
		for (i = 1; i < tableLength; i++) {
			if ((tableTr1[i].cells[x].textContent).endsWith(value))
				tableTr1[i].style.display = "";
			else
				tableTr1[i].remove();
		}
	}
	function contains(x, value) {
		for (i = 1; i < tableLength; i++) {
			if ((tableTr1[i].cells[x].textContent).includes(value))
				tableTr1[i].style.display = "";
			else
				tableTr1[i].remove();
		}
	}

}

function sortFunction() {
			var myTab = document.getElementsByClassName('lsrDetailTable_9States')[0];

			var dataString = "";
//			console.log("myTab.rows.length::" +   myTab.rows.length);

			var objCells = myTab.rows.item(1).cells;
			var lsrNoSortError = objCells.item(5).innerHTML;
//			console.log("lsrNoSortError" + lsrNoSortError);
			sortErrorFunction(lsrNoSortError);
}

function sortErrorFunction(lsrNoSortError) {

	document.getElementById("sort_process").innerHTML = "SORT is still processing";
	
	document.getElementById('resendBtn').style.display = 'none';

	document.getElementById('noteBtn').style.display = 'none';
	document.getElementById('reSubmitBtn').style.display = 'none';

	document.getElementById('sortBtn').style.display = 'none';
	document.getElementById('rejectBtn').style.display = 'none';
	document.getElementById('saveBtn').style.display = 'none';
	document.getElementById('preissue').style.display = 'none';
	document.getElementById('showErrBtn').style.display = 'none';
	document.getElementById('printBtn').style.display = 'none';
	document.getElementById('issueBtn').style.display = 'none';
	document.getElementById('copyRecBtn').style.display = 'none';
	document.getElementById('justGoBtn').style.display = 'none';

	var xhttp = new XMLHttpRequest();
	xhttp.open("POST", "sortErrorsTask", true);
				getTokenForHttps(xhttp);
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			console.log("SORT Complete");
			refreshPage();
		}
	};
	xhttp.send(lsrNoSortError);
}

function issueErrorFunction(input){
	var xhttp = new XMLHttpRequest();
			xhttp.open("POST", "issueSortErrorTask", true);
			getTokenForHttps(xhttp);
			xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
					console.log("SORT Issue Complete");
					refreshPage();
				}
			};
			xhttp.send(input);
			
}

function refreshPage()
{
	setTimeout(function() {
			window.location.href = "treeview9states";
			}, 3000);
	document.getElementById("sort_process").innerHTML = "";
}

function setErrorInfo(infoStr,errorStr){
	var xhttp = new XMLHttpRequest();
	xhttp.open("POST", "setErrorInfo", true);
	getTokenForHttps(xhttp);
	xhttp.send(infoStr+"~"+errorStr);
}

function resetSortErrors()
{
	var xhttp = new XMLHttpRequest();
	xhttp.open("POST", "resetSortErrors", true);
			getTokenForHttps(xhttp);
	xhttp.send(null);
	setTimeout(function() {
			location.reload();
		}, 2500);
}

//bhavesh's integration focus on tab

function adjustFocus() {
	var onNewTab = localStorage.getItem("onNewTab");
	var currentPageIndex = localStorage.getItem("currentPageIndex");
	var currentPageSwitch = localStorage.getItem("currentPageSwitch");
	var loadedCorrectly = localStorage.getItem("loadedCorrectly");
	var curIndex= parseInt(localStorage.getItem("currentPageIndex"));
	
	console.log("loadedCorrectly", loadedCorrectly);
	console.log("currentPageIndex", currentPageIndex);
	console.log("currentPageSwitch", currentPageSwitch);

	var focusElement = document.getElementById(currentPageSwitch + "-" + currentPageIndex);
	if (focusElement == null && currentPageSwitch != null) {
		focusElement = document.getElementById(currentPageSwitch.trim() + "-" + currentPageIndex.trim());
	}


	if (onNewTab == "true" || onNewTab == true || currentPageSwitch == null || focusElement == null) {
		var tabsCount = document.getElementById('tabsCount').innerText;
		var ul = document.getElementById('myTab');
		var listItems = ul.getElementsByTagName('button');
		for (k = 0; k < tabsCount; k++)
			listItems[k].classList.remove("active");
		listItems[(tabsCount - 1)].className = "active";
		if (loadedCorrectly == null || loadedCorrectly == "" || loadedCorrectly == undefined || loadedCorrectly != (currentPageIndex.trim())) {
//			listItems[(tabsCount - 1)].click();
			location.reload();
			localStorage.setItem("loadedCorrectly", currentPageIndex.trim());
		}
	} else if (currentPageSwitch != null && currentPageSwitch != "null" && currentPageIndex != null && currentPageIndex != "null") {
		if (loadedCorrectly == null || loadedCorrectly == "" || loadedCorrectly == undefined || loadedCorrectly != (currentPageIndex.trim())) {
			document.getElementById(currentPageSwitch.trim() + "-" + currentPageIndex.trim()).className = "active";
//			document.getElementById(currentPageSwitch.trim() + "-" + currentPageIndex.trim()).click();
			location.reload();
			localStorage.setItem("loadedCorrectly", currentPageIndex.trim());
			console.log("inside if 2", loadedCorrectly);
		}
	}

	localStorage.setItem("onNewTab", "false");
	
	//Hrushikesh- For muliple tab highlight issue
	var tabsCount = document.getElementById('tabsCount').innerText;
	var ul = document.getElementById('myTab');
	var listItems = ul.getElementsByTagName('button');
	for (k = 0; k < tabsCount; k++){
		if(k!=curIndex)
			listItems[k].classList.remove("active");
	}
	
}

function onRightclickForm(tempStr){
	
}




//sort and filter for 9state
function sortAscending1() {


    //alert("in sort");
	var list1 = $("#select4 option:selected").text();
	//alert("list1"+list1);
	var list2 = $("#select5 option:selected").text();
	//alert("list2"+list2);
	var list3 = $("#select6 option:selected").text();
  //  alert("list3"+list3);
	let inputs1 = document.getElementById('check04');
	let inputs2 = document.getElementById('check05');
	let inputs3 = document.getElementById('check06');


	var col1index = $("#select4 option:selected").index() - 1;
	var col2index = $("#select5 option:selected").index() - 1;
	var col3index = $("#select6 option:selected").index() - 1;


	//location.reload(true); 

	var $tbody = $('#enhancedseltable tbody');

	if ((inputs1.checked == true) && (list1 != null) && ((inputs2.checked != true) && (list2 === '')) && ((inputs3.checked != true) && (list3 === ''))) {
		sortUsingOneColumn(col1index)
	}
	else
		if ((inputs1.checked == false) && (list1 != null) && ((inputs2.checked != true) && (list2 === '')) && ((inputs3.checked != true) && (list3 === ''))) {
			sortDescUsingOneColumn(col1index)
		}
		else
			if ((inputs2.checked == true) && (list2 != null) && (inputs1.checked != true) && (list1 === '') && (inputs3.checked != true) && (list3 === '')) {
				sortUsingOneColumn(col2index)

			}
			else
				if ((inputs2.checked == false) && (list2 != null) && (inputs1.checked != true) && (list1 === '') && (inputs3.checked != true) && (list3 === '')) {
					sortDescUsingOneColumn(col2index)

				}
				else
					if ((inputs3.checked == true) && (list3 != null) && (inputs1.checked != true) && (list1 === '') && (inputs2.checked != true) && (list2 === '')) {
						sortUsingOneColumn(col3index)
					}
					else
						if ((inputs3.checked == false) && (list3 != null) && (inputs1.checked != true) && (list1 === '') && (inputs2.checked != true) && (list2 === '')) {
							sortDescUsingOneColumn(col3index)
						}
						else
							if ((inputs1.checked == true) && (list1 != null) && (inputs2.checked == true) && (list2 != null) && (inputs3.checked != true) && (list3 === '')) {
								
								sortUsingTwoColumn(col1index, col2index);
							}
							else
								if ((inputs1.checked == false) && (list1 != null) && (inputs2.checked == false) && (list2 != null) && (inputs3.checked != true) && (list3 === '')) {
									
									sortDescUsingTwoColumn(col1index, col2index);
								}

								else
									if ((inputs1.checked == false) && (list1 != null) && (inputs2.checked == true) && (list2 != null) && (inputs3.checked != true) && (list3 === '')) {
									
										sortDesc1UsingTwoColumn(col1index, col2index);
									}
									else
										if ((inputs1.checked == true) && (list1 != null) && (inputs2.checked == false) && (list2 != null) && (inputs3.checked != true) && (list3 === '')) {
											
											sortDesc2UsingTwoColumn(col1index, col2index);
										}
										else
											if ((inputs1.checked == true) && (list1 != null) && (inputs2.checked == true) && (list2 != null) && (inputs3.checked == true) && (list3 != null)) {
												
												sortUsingThreeColumn(col1index, col2index, col3index);
											}
											else
												if ((inputs1.checked == false) && (list1 != null) && (inputs2.checked == false) && (list2 != null) && (inputs3.checked == false) && (list3 != null)) {
													
													sortUsingDescThreeColumn(col1index, col2index, col3index);
												}

												else
													if ((inputs1.checked == true) && (list1 != null) && (inputs2.checked == false) && (list2 != null) && (inputs3.checked == false) && (list3 != null)) {
														
														sortUsingDesc1ThreeColumn(col1index, col2index, col3index);
													}
													else
														if ((inputs1.checked == false) && (list1 != null) && (inputs2.checked == true) && (list2 != null) && (inputs3.checked == false) && (list3 != null)) {
														
															sortUsingDesc2ThreeColumn(col1index, col2index, col3index);
														}
														else
															if ((inputs1.checked == false) && (list1 != null) && (inputs2.checked == false) && (list2 != null) && (inputs3.checked == true) && (list3 != null)) {
																
																sortUsingDesc3ThreeColumn(col1index, col2index, col3index);
															}
															else
																if ((inputs1.checked == true) && (list1 != null) && (inputs2.checked == true) && (list2 != null) && (inputs3.checked == false) && (list3 != null)) {
																	
																	sortUsingDesc12ThreeColumn(col1index, col2index, col3index);
																}
																else
																	if ((inputs1.checked == true) && (list1 != null) && (inputs2.checked == false) && (list2 != null) && (inputs3.checked == true) && (list3 != null)) {
																		
																		sortUsingDesc13ThreeColumn(col1index, col2index, col3index);
																	}
																	else
																		if ((inputs1.checked == false) && (list1 != null) && (inputs2.checked == true) && (list2 != null) && (inputs3.checked == true) && (list3 != null)) {
																			
																			sortUsingDesc23ThreeColumn(col1index, col2index, col3index);
																		}


	function sortUsingOneColumn(index1) {
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text(); // can replace 1 with the column you want to sort on
			var tdb = $(b).find('td:eq(' + index1 + ')').text(); // this will sort on the second column

			return tda > tdb ? 1 : tda < tdb ? -1 : 0;

		}).appendTo($tbody);
	}
	function sortDescUsingOneColumn(index1) {
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text(); // can replace 1 with the column you want to sort on
			var tdb = $(b).find('td:eq(' + index1 + ')').text(); // this will sort on the second column

			return tda < tdb ? 1 : tda > tdb ? -1 : 0;

		}).appendTo($tbody);
	}
	function sortUsingTwoColumn(index1, index2) {
		//Using First Column
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + col1index + ')').text();
			var tdb = $(b).find('td:eq(' + col1index + ')').text();

			return tda > tdb ? 1 : tda < tdb ? -1 : 0;
		}).appendTo($tbody);

		//Using Second Column 
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			var tda1 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index2 + ')').text();
			if (tda == tdb) {
				return tda1 > tdb1 ? 1 : tda1 < tdb1 ? -1 : 0;
			}
		}).appendTo($tbody);
	}

	function sortDescUsingTwoColumn(index1, index2) {
		//Using First Column
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + col1index + ')').text();
			var tdb = $(b).find('td:eq(' + col1index + ')').text();

			return tda < tdb ? 1 : tda > tdb ? -1 : 0;
		}).appendTo($tbody);

		//Using Second Column 
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			var tda1 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index2 + ')').text();
			if (tda == tdb) {
				return tda1 < tdb1 ? 1 : tda1 > tdb1 ? -1 : 0;
			}
		}).appendTo($tbody);
	}
	function sortDesc1UsingTwoColumn(index1, index2) {
		//Using First Column
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + col1index + ')').text();
			var tdb = $(b).find('td:eq(' + col1index + ')').text();

			return tda < tdb ? 1 : tda > tdb ? -1 : 0;
		}).appendTo($tbody);

		//Using Second Column 
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			var tda1 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index2 + ')').text();
			if (tda == tdb) {
				return tda1 > tdb1 ? 1 : tda1 < tdb1 ? -1 : 0;
			}
		}).appendTo($tbody);
	}
	function sortDesc2UsingTwoColumn(index1, index2) {
		//Using First Column
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + col1index + ')').text();
			var tdb = $(b).find('td:eq(' + col1index + ')').text();

			return tda > tdb ? 1 : tda < tdb ? -1 : 0;
		}).appendTo($tbody);

		//Using Second Column 
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			var tda1 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index2 + ')').text();
			if (tda == tdb) {
				return tda1 < tdb1 ? 1 : tda1 > tdb1 ? -1 : 0;
			}
		}).appendTo($tbody);
	}

	function sortUsingThreeColumn(index1, index2, index3) {
		//Using First Column
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			return tda > tdb ? 1 : tda < tdb ? -1 : 0;
		}).appendTo($tbody);

		//Using Second Column 
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			var tda1 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index2 + ')').text();
			if (tda == tdb) {
				return tda1 > tdb1 ? 1 : tda1 < tdb1 ? -1 : 0;
			}
		}).appendTo($tbody);

		//Using Third Colmn
		$tbody.find('tr').sort(function(a, b) {
			var tda1 = $(a).find('td:eq(' + index1 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index1 + ')').text();

			var tda2 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb2 = $(b).find('td:eq(' + index2 + ')').text();

			var tda3 = $(a).find('td:eq(' + index3 + ')').text();
			var tdb3 = $(b).find('td:eq(' + index3 + ')').text();

			if (tda1 == tdb1) {
				if (tda2 == tdb2) {
					return tda3 > tdb3 ? 1 : tda3 < tdb3 ? -1 : 0;
				}
			}
		}).appendTo($tbody);





	}
	function sortUsingDescThreeColumn(index1, index2, index3) {
		//Using First Column
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			return tda < tdb ? 1 : tda > tdb ? -1 : 0;
		}).appendTo($tbody);

		//Using Second Column 
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			var tda1 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index2 + ')').text();
			if (tda == tdb) {
				return tda1 < tdb1 ? 1 : tda1 > tdb1 ? -1 : 0;
			}
		}).appendTo($tbody);

		//Using Third Colmn
		$tbody.find('tr').sort(function(a, b) {
			var tda1 = $(a).find('td:eq(' + index1 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index1 + ')').text();

			var tda2 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb2 = $(b).find('td:eq(' + index2 + ')').text();

			var tda3 = $(a).find('td:eq(' + index3 + ')').text();
			var tdb3 = $(b).find('td:eq(' + index3 + ')').text();

			if (tda1 == tdb1) {
				if (tda2 == tdb2) {
					return tda3 < tdb3 ? 1 : tda3 > tdb3 ? -1 : 0;
				}
			}
		}).appendTo($tbody);





	}
	function sortUsingDesc1ThreeColumn(index1, index2, index3) {
		//Using First Column
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			return tda > tdb ? 1 : tda < tdb ? -1 : 0;
		}).appendTo($tbody);

		//Using Second Column 
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			var tda1 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index2 + ')').text();
			if (tda == tdb) {
				return tda1 < tdb1 ? 1 : tda1 > tdb1 ? -1 : 0;
			}
		}).appendTo($tbody);

		//Using Third Colmn
		$tbody.find('tr').sort(function(a, b) {
			var tda1 = $(a).find('td:eq(' + index1 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index1 + ')').text();

			var tda2 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb2 = $(b).find('td:eq(' + index2 + ')').text();

			var tda3 = $(a).find('td:eq(' + index3 + ')').text();
			var tdb3 = $(b).find('td:eq(' + index3 + ')').text();

			if (tda1 == tdb1) {
				if (tda2 == tdb2) {
					return tda3 < tdb3 ? 1 : tda3 > tdb3 ? -1 : 0;
				}
			}
		}).appendTo($tbody);
	}
	function sortUsingDesc2ThreeColumn(index1, index2, index3) {
		//Using First Column
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			return tda < tdb ? 1 : tda > tdb ? -1 : 0;
		}).appendTo($tbody);

		//Using Second Column 
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			var tda1 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index2 + ')').text();
			if (tda == tdb) {
				return tda1 > tdb1 ? 1 : tda1 < tdb1 ? -1 : 0;
			}
		}).appendTo($tbody);

		//Using Third Colmn
		$tbody.find('tr').sort(function(a, b) {
			var tda1 = $(a).find('td:eq(' + index1 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index1 + ')').text();

			var tda2 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb2 = $(b).find('td:eq(' + index2 + ')').text();

			var tda3 = $(a).find('td:eq(' + index3 + ')').text();
			var tdb3 = $(b).find('td:eq(' + index3 + ')').text();

			if (tda1 == tdb1) {
				if (tda2 == tdb2) {
					return tda3 < tdb3 ? 1 : tda3 > tdb3 ? -1 : 0;
				}
			}
		}).appendTo($tbody);
	}
	function sortUsingDesc3ThreeColumn(index1, index2, index3) {
		//Using First Column
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			return tda < tdb ? 1 : tda > tdb ? -1 : 0;
		}).appendTo($tbody);

		//Using Second Column 
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			var tda1 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index2 + ')').text();
			if (tda == tdb) {
				return tda1 < tdb1 ? 1 : tda1 > tdb1 ? -1 : 0;
			}
		}).appendTo($tbody);

		//Using Third Colmn
		$tbody.find('tr').sort(function(a, b) {
			var tda1 = $(a).find('td:eq(' + index1 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index1 + ')').text();

			var tda2 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb2 = $(b).find('td:eq(' + index2 + ')').text();

			var tda3 = $(a).find('td:eq(' + index3 + ')').text();
			var tdb3 = $(b).find('td:eq(' + index3 + ')').text();

			if (tda1 == tdb1) {
				if (tda2 == tdb2) {
					return tda3 > tdb3 ? 1 : tda3 < tdb3 ? -1 : 0;
				}
			}
		}).appendTo($tbody);
	}
	function sortUsingDesc13ThreeColumn(index1, index2, index3) {
		//Using First Column
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			return tda > tdb ? 1 : tda < tdb ? -1 : 0;
		}).appendTo($tbody);

		//Using Second Column 
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			var tda1 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index2 + ')').text();
			if (tda == tdb) {
				return tda1 < tdb1 ? 1 : tda1 > tdb1 ? -1 : 0;
			}
		}).appendTo($tbody);

		//Using Third Colmn
		$tbody.find('tr').sort(function(a, b) {
			var tda1 = $(a).find('td:eq(' + index1 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index1 + ')').text();

			var tda2 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb2 = $(b).find('td:eq(' + index2 + ')').text();

			var tda3 = $(a).find('td:eq(' + index3 + ')').text();
			var tdb3 = $(b).find('td:eq(' + index3 + ')').text();

			if (tda1 == tdb1) {
				if (tda2 == tdb2) {
					return tda3 > tdb3 ? 1 : tda3 < tdb3 ? -1 : 0;
				}
			}
		}).appendTo($tbody);
	}
	function sortUsingDesc12ThreeColumn(index1, index2, index3) {
		//Using First Column
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			return tda > tdb ? 1 : tda < tdb ? -1 : 0;
		}).appendTo($tbody);

		//Using Second Column 
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			var tda1 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index2 + ')').text();
			if (tda == tdb) {
				return tda1 > tdb1 ? 1 : tda1 < tdb1 ? -1 : 0;
			}
		}).appendTo($tbody);

		//Using Third Colmn
		$tbody.find('tr').sort(function(a, b) {
			var tda1 = $(a).find('td:eq(' + index1 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index1 + ')').text();

			var tda2 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb2 = $(b).find('td:eq(' + index2 + ')').text();

			var tda3 = $(a).find('td:eq(' + index3 + ')').text();
			var tdb3 = $(b).find('td:eq(' + index3 + ')').text();

			if (tda1 == tdb1) {
				if (tda2 == tdb2) {
					return tda3 < tdb3 ? 1 : tda3 > tdb3 ? -1 : 0;
				}
			}
		}).appendTo($tbody);
	}
	function sortUsingDesc23ThreeColumn(index1, index2, index3) {
		//Using First Column
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			return tda < tdb ? 1 : tda > tdb ? -1 : 0;
		}).appendTo($tbody);

		//Using Second Column 
		$tbody.find('tr').sort(function(a, b) {
			var tda = $(a).find('td:eq(' + index1 + ')').text();
			var tdb = $(b).find('td:eq(' + index1 + ')').text();

			var tda1 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index2 + ')').text();
			if (tda == tdb) {
				return tda1 > tdb1 ? 1 : tda1 < tdb1 ? -1 : 0;
			}
		}).appendTo($tbody);

		//Using Third Colmn
		$tbody.find('tr').sort(function(a, b) {
			var tda1 = $(a).find('td:eq(' + index1 + ')').text();
			var tdb1 = $(b).find('td:eq(' + index1 + ')').text();

			var tda2 = $(a).find('td:eq(' + index2 + ')').text();
			var tdb2 = $(b).find('td:eq(' + index2 + ')').text();

			var tda3 = $(a).find('td:eq(' + index3 + ')').text();
			var tdb3 = $(b).find('td:eq(' + index3 + ')').text();

			if (tda1 == tdb1) {
				if (tda2 == tdb2) {
					return tda3 > tdb3 ? 1 : tda3 < tdb3 ? -1 : 0;
				}
			}
		}).appendTo($tbody);
	}

}


function filterData1() {


	var column1 = $("#filterColumn4 option:selected").val();
	var operator1 = $("#filterOperator4 option:selected").val();
	var value1 = $("#filterValue4").val().toUpperCase();

	var column2 = $("#filterColumn5 option:selected").val();
	var operator2 = $("#filterOperator5 option:selected").val();
	var value2 = $("#filterValue5").val().toUpperCase();

	var column3 = $("#filterColumn6 option:selected").val();
	var operator3 = $("#filterOperator6 option:selected").val();
	var value3 = $("#filterValue6").val().toUpperCase();


	var tableLength = $("#enhancedseltable tr").length;


	var tableTr1 = $("#enhancedseltable tr");




	var x = $("#filterColumn4 option:selected").index() - 1;

	var filter = [];


	if (operator1 == "equals") {
		equals(x, value1);




	}
	else
		if (operator1 == "doesnt_equal") {
			doesntEquals(x, value1);
		}
		else
			if (operator1 == "begins_with") {
				beginsWith(x, value1);
			}
			else
				if (operator1 == "end_with") {
					endsWith(x, value1)
				}
				else
					if (operator1 == "contains") {
						contains(x, value1);
					}
	var y = $("#filterColumn5 option:selected").index() - 1;

	var secondFilter = [];
	if (operator2 == "equals") {
		equals(y, value2);

	}
	else
		if (operator2 == "doesnt_equal") {
			doesntEquals(y, value2);
		}
		else
			if (operator2 == "begins_with") {
				beginsWith(y, value2);
			}
			else
				if (operator2 == "end_with") {
					endsWith(y, value2)
				}
				else
					if (operator2 == "contains") {
						contains(y, value2);
					}

	var z = $("#filterColumn6 option:selected").index() - 1;


	if (operator3 == "equals") {
		equals(z, value3);
	}
	else
		if (operator3 == "doesnt_equal") {
			doesntEquals(z, value3);
		}
		else
			if (operator3 == "begins_with") {
				beginsWith(z, value3);
			}
			else
				if (operator3 == "end_with") {
					endsWith(z, value3)
				}
				else
					if (operator3 == "contains") {
						contains(z, value3);
					}

	function equals(x, value) {
		for (i = 1; i < tableLength; i++) {
			if (tableTr1[i].cells[x].textContent == value)
				tableTr1[i].style.display = "";
			else {
				// tableTr1[i].style.display="none";  
				tableTr1[i].remove();
			}
		}

	}
	function doesntEquals(x, value) {
		for (i = 1; i < tableLength; i++) {
			if (tableTr1[i].cells[x].textContent != value)
				tableTr1[i].style.display = "";
			else
				tableTr1[i].remove();
		}
	}
	function beginsWith(x, value) {
		for (i = 1; i < tableLength; i++) {
			if ((tableTr1[i].cells[x].textContent).startsWith(value))
				tableTr1[i].style.display = "";
			else
				tableTr1[i].remove();
		}
	}
	function endsWith(x, value) {
		for (i = 1; i < tableLength; i++) {
			if ((tableTr1[i].cells[x].textContent).endsWith(value))
				tableTr1[i].style.display = "";
			else
				tableTr1[i].remove();
		}
	}
	function contains(x, value) {
		for (i = 1; i < tableLength; i++) {
			if ((tableTr1[i].cells[x].textContent).includes(value))
				tableTr1[i].style.display = "";
			else
				tableTr1[i].remove();
		}
	}

}
// buttons issue resolution
function treeviewButtonsDisable(){

if ((window.location.href.indexOf("/treeViewDisplay") > -1)||(window.location.href.indexOf("/treeview9states") > -1)){

if ($("#usertype").val()== 'RO'){

document.getElementById('resendBtn').style.display = 'none';

document.getElementById('noteBtn').style.display = 'none';
document.getElementById('reSubmitBtn').style.display = 'none';
document.getElementById('sortBtn').style.display = 'none';
document.getElementById('rejectBtn').style.display = 'none';
document.getElementById('saveBtn').style.display = 'none';
document.getElementById('preissue').style.display = 'none';
document.getElementById('showErrBtn').style.display = 'none';
document.getElementById('issueBtn').style.display = 'none';
document.getElementById('copyRecBtn').style.display = 'none';
document.getElementById('justGoBtn').style.display = 'none';
document.getElementById('rejectBtn1').style.display = 'none';
document.getElementById('validateCCBtn').style.display = 'none';
document.getElementById('retrieveBtn').style.display = 'none';
document.getElementById('resetBtn').style.display = 'none';
document.getElementById('showErrBtn').style.display = 'none';
document.getElementById('addBtn').style.display = 'none';
document.getElementById('logOffBtn').style.display = 'none';


}
else if($("#usertype").val()== 'HD'){
document.getElementById('resendBtn').style.display = 'none';

document.getElementById('noteBtn').style.display = 'none';
document.getElementById('reSubmitBtn').style.display = 'none';
document.getElementById('sortBtn').style.display = 'none';
document.getElementById('rejectBtn').style.display = 'none';
document.getElementById('saveBtn').style.display = 'none';
document.getElementById('preissue').style.display = 'none';
document.getElementById('showErrBtn').style.display = 'none';
document.getElementById('issueBtn').style.display = 'none';
document.getElementById('copyRecBtn').style.display = 'none';
document.getElementById('justGoBtn').style.display = 'none';
document.getElementById('rejectBtn1').style.display = 'none';
document.getElementById('validateCCBtn').style.display = 'none';
document.getElementById('retrieveBtn').style.display = 'none';
document.getElementById('resetBtn').style.display = 'none';
document.getElementById('showErrBtn').style.display = 'none';
document.getElementById('addBtn').style.display = 'none';
document.getElementById('logOffBtn').style.display = 'none';

}

else if($("#usertype").val()== 'AM'){
document.getElementById('resendBtn').style.display = 'none';


document.getElementById('reSubmitBtn').style.display = 'none';
document.getElementById('sortBtn').style.display = 'none';
document.getElementById('rejectBtn').style.display = 'none';
document.getElementById('saveBtn').style.display = 'none';
document.getElementById('preissue').style.display = 'none';
document.getElementById('showErrBtn').style.display = 'none';
document.getElementById('issueBtn').style.display = 'none';
document.getElementById('copyRecBtn').style.display = 'none';
document.getElementById('justGoBtn').style.display = 'none';
document.getElementById('rejectBtn1').style.display = 'none';
document.getElementById('validateCCBtn').style.display = 'none';
document.getElementById('retrieveBtn').style.display = 'none';
document.getElementById('resetBtn').style.display = 'none';
document.getElementById('showErrBtn').style.display = 'none';
document.getElementById('addBtn').style.display = 'none';
document.getElementById('logOffBtn').style.display = 'none';

}
else if($("#usertype").val()== 'PR'){
document.getElementById('resendBtn').style.display = 'none';


document.getElementById('reSubmitBtn').style.display = 'none';
document.getElementById('sortBtn').style.display = 'none';
document.getElementById('rejectBtn').style.display = 'none';
document.getElementById('saveBtn').style.display = 'none';
document.getElementById('preissue').style.display = 'none';
document.getElementById('showErrBtn').style.display = 'none';
document.getElementById('issueBtn').style.display = 'none';
document.getElementById('copyRecBtn').style.display = 'none';
document.getElementById('justGoBtn').style.display = 'none';
document.getElementById('rejectBtn1').style.display = 'none';
document.getElementById('validateCCBtn').style.display = 'none';
document.getElementById('retrieveBtn').style.display = 'none';
document.getElementById('resetBtn').style.display = 'none';
document.getElementById('showErrBtn').style.display = 'none';
document.getElementById('addBtn').style.display = 'none';
document.getElementById('logOffBtn').style.display = 'none';

}
else if($("#readonly").val()== 'Y'){
document.getElementById('resendBtn').style.display = 'none';

document.getElementById('noteBtn').style.display = 'none';
document.getElementById('reSubmitBtn').style.display = 'none';
document.getElementById('sortBtn').style.display = 'none';
document.getElementById('rejectBtn').style.display = 'none';
document.getElementById('saveBtn').style.display = 'none';
document.getElementById('preissue').style.display = 'none';
document.getElementById('showErrBtn').style.display = 'none';

document.getElementById('issueBtn').style.display = 'none';
document.getElementById('copyRecBtn').style.display = 'none';
document.getElementById('justGoBtn').style.display = 'none';
document.getElementById('rejectBtn1').style.display = 'none';
document.getElementById('validateCCBtn').style.display = 'none';
document.getElementById('retrieveBtn').style.display = 'none';
document.getElementById('resetBtn').style.display = 'none';
document.getElementById('showErrBtn').style.display = 'none';
document.getElementById('addBtn').style.display = 'none';
document.getElementById('logOffBtn').style.display = 'none';
}


}
}
//added by Hrushi
function getSelectedEcverData(ecver)
{
	var loaderHtml="<div id='ecverLoader' class='manRejLoader'></div>";	
	$("#loaderDiv").append(loaderHtml);
	
	$('#secondScreen').hide();
	$("#ecver_par_li").hide();
	//$("#ecver_ul").children().hide();
	var xhttp = new XMLHttpRequest();
	xhttp.open("POST", "issueEcverView", true);
			getTokenForHttps(xhttp);
	xhttp.send(ecver.innerText);
	xhttp.onreadystatechange = function() { 
		if (this.readyState == 4 && this.status == 200) { 
			//console.log("success "+ecver.innerText); 
			location.reload();
		}
			
	};
}
