	
function logout(){
	console.log("in logout"); 
	localStorage.clear();
	
}
			
function callListen1(){
console.log("in callListen1 bootnavbar");
    _idleSecondsCounter = 0;
}
			
		
	
 function confirmationLogout(){
	
		if(confirm(" Are you sure you want to Logout?")){
		 callLogout();
		}else{
		}
	
	}    		
 

	function callLogout(){
	console.log("callLogout called after okay click"); 
	var host=document.location.hostname;
	console.log("host in callLogout ",host);
	 routeToEnvRegion(host);
		
	var lsrList=	localStorage.getItem("allTreeViewOpened");
	
	if(lsrList== null || lsrList==undefined){
	lsrList="dummy";
	}
		console.log("calllogout",lsrList);
	var xhttp = new XMLHttpRequest(); 
	 
				 xhttp.onreadystatechange = function() {
			    		if (this.readyState == 4 && this.status == 200) {
						logout();
//						var url=routeToEnvRegion();
//						console.log("logoutTo-->",url);
//						window.location.href = url;
				 		window.location.assign(redirectUrl);
//						window.location.href = "envRegion";
						}
			 		};
	
	xhttp.open("POST", "logoutWithTreeview", true);	
	getTokenForHttps(xhttp);
	xhttp.send(lsrList+"$"+host);
	
}
   		var redirectUrl="";
   		// https://onelasrgui-se.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_SE
	function routeToEnvRegion(host){
   		var myCurrHostIs=""; 
   		myCurrHostIs =host;
   		
//   	 myCurrHostIs = document.location.hostname;
   		console.log("myCurrHostIs from routeToEnvRegion session-->",myCurrHostIs);
   		var routeUrl="";
		
	// NPRD
   		if(myCurrHostIs=="onelasrgui-sw.stage.az.3pc.att.com"){
			routeUrl="https://onelasrgui-sw.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_SW";
   		}else if(myCurrHostIs=="onelasrgui-w.stage.az.3pc.att.com"){
			routeUrl="https://onelasrgui-w.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_W";
   		}else if(myCurrHostIs=="onelasrgui-se.stage.az.3pc.att.com"){
			routeUrl="https://onelasrgui-se.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_SE";
   		}else if(myCurrHostIs=="onelasrgui-mw.stage.az.3pc.att.com"){
			routeUrl="https://onelasrgui-mw.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_MW";
   		}    

		else if(myCurrHostIs=="onelasrgui-d7.stage.az.3pc.att.com"){
			routeUrl="https://onelasrgui-d7.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_D7";
   		}else if(myCurrHostIs=="onelasrgui-d6.stage.az.3pc.att.com"){
			routeUrl="https://onelasrgui-d6.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_D6";
   		}else if(myCurrHostIs=="onelasrgui-d2.stage.az.3pc.att.com"){
			routeUrl="https://onelasrgui-d2.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_D2";
   		}else if(myCurrHostIs=="onelasrgui-d5.stage.az.3pc.att.com"){
			routeUrl="https://onelasrgui-d5.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_D5";
   		}else if(myCurrHostIs=="onelasrgui-d8.stage.az.3pc.att.com"){
			routeUrl="https://onelasrgui-d8.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_D8";
   		}else if(myCurrHostIs=="onelasrgui-a0.stage.az.3pc.att.com"){
			routeUrl="https://onelasrgui-a0.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_A0";
   		}else if(myCurrHostIs=="onelasrgui-b1.stage.az.3pc.att.com"){
			routeUrl="https://onelasrgui-b1.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_B1";
   		}else if(myCurrHostIs=="onelasrgui-a5.stage.az.3pc.att.com"){
			routeUrl="https://onelasrgui-a5.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_A5";
   		}else if(myCurrHostIs=="onelasrgui-ah.stage.az.3pc.att.com"){
			routeUrl="https://onelasrgui-ah.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_AH";
   		}else if(myCurrHostIs=="onelasrgui-t3.stage.az.3pc.att.com"){
			routeUrl="https://onelasrgui-t3.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_T3";
   		}else if(myCurrHostIs=="onelasrgui-p3.stage.az.3pc.att.com"){
			routeUrl="https://onelasrgui-p3.stage.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_P3";
   		}
        
       
		//MAT EAST Prod
		else if(myCurrHostIs=="onelasrgui-w.web.az.3pc.att.com"){
			routeUrl="https://onelasrgui-w.web.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_W";
   		}else if(myCurrHostIs=="onelasrgui-se.web.az.3pc.att.com"){
			routeUrl="https://onelasrgui-se.web.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_SE";
   		}else if(myCurrHostIs=="onelasrgui-sw.web.az.3pc.att.com"){
			routeUrl="https://onelasrgui-sw.web.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_SW";
   		}else if(myCurrHostIs=="onelasrgui-mw.web.az.3pc.att.com"){
			routeUrl="https://onelasrgui-mw.web.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_MW";
   		}
   		// clec
		else if(myCurrHostIs=="onelasrgui-d9.web.az.3pc.att.com"){
			routeUrl="https://onelasrgui-d9.web.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_D9";
   		}else if(myCurrHostIs=="onelasrgui-a2.web.az.3pc.att.com"){
			routeUrl="https://onelasrgui-a2.web.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_A2";
   		}else if(myCurrHostIs=="onelasrgui-t1.web.az.3pc.att.com"){
			routeUrl="https://onelasrgui-t1.web.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_T1";
   		}else if(myCurrHostIs=="onelasrgui-p1.web.az.3pc.att.com"){
			routeUrl="https://onelasrgui-p1.web.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_P1";
   		}
		
	
   		
       
		//MAT WEST Prod
		else if(myCurrHostIs=="onelasrgui-w-dr.web.az.3pc.att.com"){
			routeUrl="https://onelasrgui-w-dr.web.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_W";
   		}else if(myCurrHostIs=="onelasrgui-se-dr.web.az.3pc.att.com"){
			routeUrl="https://onelasrgui-se-dr.web.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_SE";
   		}else if(myCurrHostIs=="onelasrgui-sw-dr.web.az.3pc.att.com"){
			routeUrl="https://onelasrgui-sw-dr.web.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_SW";
   		}else if(myCurrHostIs=="onelasrgui-mw-dr.web.az.3pc.att.com"){
			routeUrl="https://onelasrgui-mw-dr.web.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_MW";
   		}
   		// clec
		else if(myCurrHostIs=="onelasrgui-d9.web.az.3pc.att.com"){
			routeUrl="https://onelasrgui-d9.web.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_D9";
   		}else if(myCurrHostIs=="onelasrgui-a2.web.az.3pc.att.com"){
			routeUrl="https://onelasrgui-a2.web.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_A2";
   		}else if(myCurrHostIs=="onelasrgui-t1.web.az.3pc.att.com"){
			routeUrl="https://onelasrgui-t1.web.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_T1";
   		}else if(myCurrHostIs=="onelasrgui-p1.web.az.3pc.att.com"){
			routeUrl="https://onelasrgui-p1.web.az.3pc.att.com/OneLASRGUI/oauth2/authorization/globallogon_P1";
   		}
		
	
//		else{
//   		routeUrl="https://onelasrgui.stage.att.com/OneLASRGUI/oauth2/authorization/globallogon";
//   		}
   		
	
		
	
   		redirectUrl=routeUrl;
	//return routeUrl;
   		
	}
		
	
   		
	
   		
	
   		
	
function getTokenForHttps(xhttp){
	var token = $("meta[name='_csrf']").attr("content");
	var header = $("meta[name='_csrf_header']").attr("content");
	xhttp.setRequestHeader(header, token);
	
}

// sample idleTime trcking rakesh      	
   
var IDLE_TIMEOUT = 30; //minutes
var _idleSecondsCounter = 0;
document.onclick = function() {
    _idleSecondsCounter = 0;
	document.getElementById('SecondsUntilExpire').style.display = 'none';
};
//document.onmousemove = function() {
//    _idleSecondsCounter = 0;
//};
//document.onkeypress = function() {
//    _idleSecondsCounter = 0;
//};
window.setInterval(CheckIdleTime, 60000);



	var noOfTimesCalled=0;
function CheckIdleTime() {  
	
	
	let currentDate = new Date();
	let time = currentDate.getHours() + ":" + currentDate.getMinutes() + ":" + currentDate.getSeconds();
	document.getElementById('SecondsUntilExpire').style.display = 'none';
	
	 noOfTimesCalled++;
	if(noOfTimesCalled==3){
	console.log("in CheckIdleTime method",time);
    _idleSecondsCounter++;
	noOfTimesCalled=0;
	console.log(" _idleSecondsCounter",_idleSecondsCounter);
	}
	
    var oPanel = document.getElementById("SecondsUntilExpire");

	if(_idleSecondsCounter >= 24){
		document.getElementById('SecondsUntilExpire').style.display = 'inline';
		oPanel = document.getElementById("SecondsUntilExpire");
 		oPanel.innerHTML = "Your Session will Expire in - "+"<b>"+(IDLE_TIMEOUT - _idleSecondsCounter)+"</b>"+" minutes. Please click on the screen to restore your session.";


}

	
    if (_idleSecondsCounter >= IDLE_TIMEOUT) {
	document.getElementById('SecondsUntilExpire').style.display = 'none';
		callLogout();
    }

} 


(function($) {
    var defaults={
        sm : 540,
        md : 720,
        lg : 960,
        xl : 1140,
        navbar_expand: 'lg',
        animation: true,
        animateIn: 'fadeIn',
    };
    $.fn.bootnavbar = function(options) {

        var screen_width = $(document).width();
        settings = $.extend(defaults, options);

        if(screen_width >= settings.lg){
            $(this).find('.dropdown').hover(function() {
                $(this).addClass('show');
                $(this).find('.dropdown-menu').first().addClass('show');
                if(settings.animation){
                    $(this).find('.dropdown-menu').first().addClass('animated ' + settings.animateIn);
                }
            }, function() {
                $(this).removeClass('show');
                $(this).find('.dropdown-menu').first().removeClass('show');
            });
        }

        $('.dropdown-menu a.dropdown-toggle').on('click', function(e) {
          if (!$(this).next().hasClass('show')) {
            $(this).parents('.dropdown-menu').first().find('.show').removeClass("show");
          }
          var $subMenu = $(this).next(".dropdown-menu");
          $subMenu.toggleClass('show');

          $(this).parents('li.nav-item.dropdown.show').on('hidden.bs.dropdown', function(e) {
            $('.dropdown-submenu .show').removeClass("show");
          });

          return false;
        });
    };
})(jQuery);